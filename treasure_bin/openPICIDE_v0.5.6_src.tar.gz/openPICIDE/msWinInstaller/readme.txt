Windows installer
~~~~~~~~~~~~~~~~~

For installing openPICIDE on Microsoft Windows Platforms, the NSI installer 
from Nullsoft are beeing used.

The installer is beeing downloadable from http://nsis.sourceforge.net/Download
