openPICIDE
~~~~~~~~~~

openPICIDE is free software: you can redistribute it and/or modify it under the terms of 
the GNU General Public License as published by the Free Software Foundation, either 
version 3 of the License, or (at your option) any later version. 

openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
See the GNU General Public License (LICENSE_GPL file) for more details.

Compilation and Installation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

openPICIDE is linked against Qt libraries from nokia (http://qt.nokia.com) and supports 
cmake as well as qmake project handling.

Using cmake on Linux systems:
	- Install Qt4 packages
		* libqt4
		* libqt4-devel
		* libqt4-devel-doc
		* libqt4-devel-doc-data
		* libqt4-sql
		* libqt4-sql-sqlite
		* libqt4-x11
		* libQtWebKit4-devel
		* libQtWebKit4

	- Install cmake packages
		* cmake
		* automoc4

	- Change into build folder
	- run "cmake ../"
	- run "make"
	- run "make install"
	- A link will be made to /usr/local/bin automatically

Using qmake on Windows systems:
	- Install Qt4 from Nokia homepage: http://qt.nokia.com

	- Run Qt konsole
	- Change into buildQt folder
	- run "qmake ../openpicide.pro"
	- run "make" or "mingw32-make" platform dependent
	- Make the following folder structure
		mkdir openPICIDE
		mkdir openPICIDE/bin
		mkdir openPICIDE/hlp
	- Copy the openpicide binary to the openPICIDE/bin folder.
	- Copy the hlp folder containing the *.qhc and *.qch files to the openPICIDE/hlp folder
	- Move the openPICIDE folder structure to the place you want to start openPICIDE

	The hlp folder is beeing needed for the offline help.