/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "SetPrjRdWrV02.h"
#include "PicPblze.h"

/**
 *****************************************************************************************************************************
 */

SetPrjRdWrV02::SetPrjRdWrV02 ( )
{
	
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWrV02::rdXml ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader )
{
	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if      ( QString_tag == "versioning" )	this->rdXmlVersioning ( pSetPrj, pQXmlStreamReader );
		else if ( QString_tag == "processor" )	this->rdXmlProcessor  ( pSetPrj, pQXmlStreamReader );
		else if ( QString_tag == "sources" )	this->rdXmlSources    ( pSetPrj, pQXmlStreamReader );
		else if ( QString_tag == "editor" )	this->rdXmlEdt        ( pSetPrj, pQXmlStreamReader );
	}
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWrV02::rdXmlVersioning ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader )
{
	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if ( "version" == QString_tag )
		{
			pSetPrj->sVer.QString_version = pQXmlStreamReader->readElementText ();
		}
		else if ( "title" == QString_tag )
		{
			pSetPrj->sVer.QString_title = pQXmlStreamReader->readElementText ();
		}
		else if ( "comment" == QString_tag )
		{
			pSetPrj->sVer.QString_comment = pQXmlStreamReader->readElementText ();
		}
		else if ( pQXmlStreamReader->isEndElement () && ( "versioning" == QString_tag ) )
		{
			break;
		}
	}
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWrV02::rdXmlProcessor ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader )
{
	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if ( "type" == QString_tag )
		{
			pSetPrj->sPic.QString_picType = pQXmlStreamReader->readElementText ();
		}
		else if ( "settings" == QString_tag )
		{
			if ( pSetPrj->sPic.QString_picType == PicPblze::getName () )
			{
				PicPblzeSet * pPicPblzeSet = new PicPblzeSet;
				
				pPicPblzeSet->rdXml ( pQXmlStreamReader, pSetPrj->sPrj.QString_prjPath );
				
				pSetPrj->sPic.pv_picSet = static_cast <void *> ( pPicPblzeSet );
				
			}
		}
		else if ( pQXmlStreamReader->isEndElement () && ( "processor" == QString_tag ) )
		{
			break;
		}
	}
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWrV02::rdXmlSources ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader )
{
	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if ( "files" == QString_tag )
		{
			this->rdXmlSourcesFiles ( pSetPrj, pQXmlStreamReader );
		}
		else if ( pQXmlStreamReader->isEndElement () && ( "sources" == QString_tag ) )
		{
			break;
		}
	}
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWrV02::rdXmlSourcesFiles ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader )
{
	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if ( "file" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();

			if ( QString_relFilePath.isEmpty () )
				continue;

			QString QString_absFilePath = pSetPrj->sPrj.QString_prjPath + QString_relFilePath;

			pSetPrj->sSrc.QStringList_srcFiles << QString_absFilePath;
		}
		else if ( pQXmlStreamReader->isEndElement () && ( "files" == QString_tag ) )
		{
			break;
		}
	}
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWrV02::rdXmlEdt ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader )
{
	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if ( "loadedFiles" == QString_tag )
		{
			this->rdXmlLoadedFiles ( pSetPrj, pQXmlStreamReader );
		}
		else if ( pQXmlStreamReader->isEndElement () && ( "editor" == QString_tag ) )
		{
			break;
		}
	}
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWrV02::rdXmlLoadedFiles ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader )
{
	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if ( "file" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();

			if ( QString_relFilePath.isEmpty () )
				continue;

			QString QString_absFilePath = pSetPrj->sPrj.QString_prjPath + QString_relFilePath;

			pSetPrj->sEdt.QStringList_loadedFiles << QString_absFilePath;
		}
		else if ( pQXmlStreamReader->isEndElement () && ( "loadedFiles" == QString_tag ) )
		{
			break;
		}
	}
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWrV02::wrXml ( SetPrj * pSetPrj, QString * pQString_xml )
{
	QXmlStreamWriter * pQXmlStreamWriter = new QXmlStreamWriter ( pQString_xml );

	pQXmlStreamWriter->setCodec ( QTextCodec::codecForName ( "UTF-8" ) );

	// Writes DTD
	pQXmlStreamWriter->writeDTD ( QString ( "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" ) );

	pQXmlStreamWriter->setAutoFormatting ( TRUE );
	pQXmlStreamWriter->setAutoFormattingIndent ( 4 );

	// Writes root element
	pQXmlStreamWriter->writeStartElement ( "project"  );
	pQXmlStreamWriter->writeAttribute ( QXmlStreamAttribute ( "version", "2" ) );
	{
		// Writes versioning section
		pQXmlStreamWriter->writeStartElement ( "versioning"  );
		{
			// Writes version
			pQXmlStreamWriter->writeTextElement ( "version", pSetPrj->sVer.QString_version );

			// Writes version
			pQXmlStreamWriter->writeTextElement ( "title", pSetPrj->sVer.QString_title );

			// Writes comment
			pQXmlStreamWriter->writeTextElement ( "comment", pSetPrj->sVer.QString_comment );

			pQXmlStreamWriter->writeEndElement ();
		}

		// Writes processor section
		pQXmlStreamWriter->writeStartElement ( "processor"  );
		{
			// Writes type
			pQXmlStreamWriter->writeTextElement ( "type", pSetPrj->sPic.QString_picType );

			if ( pSetPrj->sPic.QString_picType == PicPblze::getName () )
			{
				PicPblzeSet * pPicPblzeSet = static_cast<PicPblzeSet *> ( pSetPrj->sPic.pv_picSet );
				
				pPicPblzeSet->wrXml ( pQXmlStreamWriter, pSetPrj->sPrj.QString_prjPath );
			}

			pQXmlStreamWriter->writeEndElement ();
		}

		// Write sources section
		pQXmlStreamWriter->writeStartElement ( "sources"  );
		{
			// Writes files settings section
			pQXmlStreamWriter->writeStartElement ( "files"  );
			{
				QDir QDir_prjPath;
				QDir_prjPath.setPath ( pSetPrj->sPrj.QString_prjPath );

				int i_fileCount = pSetPrj->sSrc.QStringList_srcFiles.size();

				for ( int i_iterator = 0; i_iterator < i_fileCount; i_iterator++ )
				{
					QString QString_absFilePath = pSetPrj->sSrc.QStringList_srcFiles.at ( i_iterator );
					QString QString_relFilePath = QDir_prjPath.relativeFilePath ( QString_absFilePath );

					// Writes hexOutputFile
					pQXmlStreamWriter->writeTextElement ( "file", QString_relFilePath );
				}
				pQXmlStreamWriter->writeEndElement ();
			}
			pQXmlStreamWriter->writeEndElement ();
		}
		
		// Write project depending editor settings
		pQXmlStreamWriter->writeStartElement ( "editor"  );
		{
			this->wrEdt ( pSetPrj, pQXmlStreamWriter );
			
			pQXmlStreamWriter->writeEndElement ();
		}
		
		pQXmlStreamWriter->writeEndElement ();
	}
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWrV02::wrEdt ( SetPrj * pSetPrj, QXmlStreamWriter * pQXmlStreamWriter )
{
	// Writes loaded files settings section
	pQXmlStreamWriter->writeStartElement ( "loadedFiles"  );
	{
		QDir QDir_prjPath;
		QDir_prjPath.setPath ( pSetPrj->sPrj.QString_prjPath );

		int i_fileCount = pSetPrj->sEdt.QStringList_loadedFiles.size();

		for ( int i_iterator = 0; i_iterator < i_fileCount; i_iterator++ )
		{
			QString QString_absFilePath = pSetPrj->sEdt.QStringList_loadedFiles.at ( i_iterator );
			QString QString_relFilePath = QDir_prjPath.relativeFilePath ( QString_absFilePath );

			// Writes hexOutputFile
			pQXmlStreamWriter->writeTextElement ( "file", QString_relFilePath );
		}
		pQXmlStreamWriter->writeEndElement ();
	}
	pQXmlStreamWriter->writeEndElement ();
}

/**
 *****************************************************************************************************************************
 */

 
 
