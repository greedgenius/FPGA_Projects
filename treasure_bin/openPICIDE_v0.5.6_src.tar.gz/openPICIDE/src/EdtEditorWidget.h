/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   The original code of this file was copied from nokia qt 4.6.0 examples and then modified for openPICIDE.                *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef EDTEDITORAREATEXT_H
#define EDTEDITORAREATEXT_H

#include <QtCore>
#include <QtGui>

#include "EdtEditorHighlighter.h"
#include "EdtNaviTagList.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Text editor widget.
 *
 *	This code
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-09-15
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */

class EdtEditorWidgetLeftMargin;

class EdtEditorWidget : public QPlainTextEdit
{
		Q_OBJECT

	// *******************************************************************************************************************
	// Init
	// *******************************************************************************************************************
	public:

		/// Constructor. This class is the left margin of the PicIOFifoEditor widget.
		/// \param pQWidget_parent	Reference to parent widget
		EdtEditorWidget ( QWidget * pQWidget_parent = 0 );


	// *******************************************************************************************************************
	// Left margin
	// *******************************************************************************************************************
	public:
		
		/// Paint method for painting the left margin.
		/// Will be called by \c PicIOFifoEditorLeftMargin class.
		/// \param pQPaintEvent			Paint event
		void leftMarginPaintEvent ( QPaintEvent * pQPaintEvent );

		/// Calculates the with of the left margin from line number digits.
		/// \retval int				Line margin width
		int  leftMarginWidth ( void );

		/// Gets the line number from y coordinate.
		/// \param i_posY			Y coordinate
		void  leftMarginLineFromPos ( int i_posY );

	private slots:

		/// Updates the left margin width if the block count was changed.
		/// \param i_newBlockCount		New block count
		void updateLeftMarginWidth ( int i_newBlockCount );

		/// Updates the left margin. Will be called, if the content of the left margin was changed.
		/// \param QRect			Rectangle
		/// \param i_pixelScrolledVertical	The pixel, the document was scralled vertical
		void updateLeftMargin ( const QRect &, int );

	protected:

		/// Handles all resize events.
		/// \param pQResizeEvent_event		Resize event
		void resizeEvent ( QResizeEvent *event );

	private:
		
		/// The left margin widget
		QWidget * pEdtEditorWidgetLeftMargin;

		/// Line number enable
		bool b_lineNumberEn;

	// *******************************************************************************************************************
	// Breakpoints
	// *******************************************************************************************************************
	public:
	
		/// Sets breakpoints enable/disable
		/// \param b_breakpointEn	Breakpoints enable/disable
		void setBreakpointEn ( bool b_breakpointEn );

		/// Gets break points.
		/// \param pQListI_lineNumber		Reference to return line number list
		void getbreakpoints ( QList<int> * pQListI_lineNumber );

		/// Clears the break point list.
		void clearBreakpoints ( void );

	signals:

		/// Break point changed
		void breakpointChanged ( void );

	private:
		
		/// Breakpoints enable
		bool b_breakpointEn;

		/// List of breakpoints
		QList <int> QListI_breakpoints;
		
	// *******************************************************************************************************************
	// Highlighting and formating
	// *******************************************************************************************************************

	public:
		
		/// Sets highlighting parameter
		/// \param sHighlighting		Highlighting parameter
		void setHighlightingParameter ( EdtEditorHighlighter::sHighlightingParameter_t sHighlightingParameter );

		/// Gets given line
		/// \param i_lineNumber		Line number
		/// \param pQString_line	Pointer to return line content
		/// \retval bool		Success
		bool getLine ( int i_lineNumber, QString * pQString_line );

		/// Replaces given line
		/// \param i_lineNumber		Line number
		/// \param QString_line		Line content
		/// \retval bool		Success
		bool setLine ( int i_lineNumber, QString QString_line );

		/// Selects line within editor widget by given line number
		/// \param i_lineNumber		Line number
		bool selectLine ( int i_lineNumber );

		/// Selects the given tag
		/// \param QString_tag		Tag
		void selectTag ( QString QString_tag );
		
		/// Gets tag list from editor widget.
		/// \param pEdtNaviTagList		Reference to store tag list
		void getTagList ( EdtNaviTagList * pEdtNaviTagList );
		
		/// Highlights line
		/// \param QTextCursor_highlight	Text cursor to highlight
		void highlightLine ( QTextCursor & QTextCursor_highlight );

		/// Clears line highlighting
		void clearLineHighlighting ( void );

		/// Sets background color for cursor,
		/// \param QColor_bgCursor		Color
		void setBgColorCursor ( QColor QColor_bgCursor );

		/// Sets background color for cursor,
		/// \param QColor_bgCursor		Color
		void setBgColorHighlight ( QColor QColor_bgHighlight );

		/// Sets dynamic word wrap enable/disable
		/// \param b_dynamicWordWrapEn		Dynamic word wrap enable/disable
		void setDynamicWordWrapEn ( bool b_dynamicWordWrapEn );

	public slots:
		
		/// Sets indent for tab stops
		/// \param i_tabIndent			Tab indent
		void setTabStopWidth ( int i_tabIndent );

	private slots:
		
		/// Highlights the current line, the cursor is located.
		void highlightCurrentLine();

	private:
		
		/// The cursor selection
		QTextEdit::ExtraSelection ExtraSelection_cursor;

		/// A list of all selections to highlight
		QTextEdit::ExtraSelection ExtraSelection_highlight;
		
		/// A list of all selections to grayout
		QTextEdit::ExtraSelection ExtraSelection_grayout;

		/// A list of all selections to grayout
		QList<QTextEdit::ExtraSelection> QListExtraSelection_grayout;
		
		/// Highlighting enable
		bool b_highlightEn;

		/// Sets all extraselections to the document widget.
		void highlightLines ( void );
		
	// *******************************************************************************************************************
	// Internal key handling
	// *******************************************************************************************************************
	private:
	
		/// Handles press key events
		/// \param pQKeyEvent_event	Event passed by the event handler
		void keyPressEvent ( QKeyEvent * pQKeyEvent_event );
		
		/// Handles release key events
		/// \param pQKeyEvent_event	Event passed by the event handler
		void keyReleaseEvent ( QKeyEvent * pQKeyEvent_event );
		
		/// Shift key pressed
		bool b_keyPressedShift;
		
		/// Insert enter and tab spaces
		void insertEnterTab ( QKeyEvent * pQKeyEvent_event );

	// *******************************************************************************************************************
	// Document handling
	// *******************************************************************************************************************
	public:
		
		/// Sets the document file path.
		/// \param QString_filePath	File path
		void setFilePath ( QString QString_filePath );

		/// Gets the document file path
		/// \retval QString		File path
		QString getFilePath ( void );

		/// Sets the document text to editor widget.
		/// \param QString_document	Document text
		void setText ( QString QString_document );

	private:
		
		/// The text document viewed in editor widget
		QTextDocument * pQTextDocument;

		/// File path of document
		QString QString_filePath;

		/// Highlighter
		EdtEditorHighlighter * pEdtEditorHighlighter;


	// *******************************************************************************************************************
	// Document state
	// *******************************************************************************************************************

	public:
		
		/// Gets if document was changed
		/// \retval bool		True, if document changed, otherwise false
		bool getDocumentChanged ( void );

		/// Clears the document change status
		void clearDocumentChanged ( void );

		/// Gets if copy capability available
		/// \retval bool		True, if capability available, otherwise false
		bool getCopyAvailable ( void );

		/// Gets if undo capability available
		/// \retval bool		True, if capability available, otherwise false
		bool getUndoAvailable ( void );

		/// Gets if redo capability available
		/// \retval bool		True, if capability available, otherwise false
		bool getRedoAvailable ( void );

		/// Gets line from cursor
		/// \retval int			Line number
		int getLineFromCursor ( void );
		
		/// Gets the selected text within editor widget
		/// \retval QString		Selected text, if any. Otherwise empty string.
		QString getSelection ( void );
		
	private slots:

		/// Sets document changed status. Will be called by editor widget.
		void setDocumentChanged ( void );
		
		/// Sets copy available status. Will be called by editor widget.
		void setCopyAvailable ( bool b_copyAvailable );

		/// Sets redo available status. Will be called by editor widget.
		void setUndoAvailable ( bool b_undoAvailable );

		/// Sets undo available status. Will be called by editor widget.
		void setRedoAvailable ( bool b_redoAvailable );

	private:
		
		/// Document changed staus
		bool b_documentChanged;

		/// Copy available status
		bool b_copyAvailable;

		/// Undo available status
		bool b_undoAvailable;

		/// Redo available status
		bool b_redoAvailable;
		
	signals:
		
		/// Will be emitted, if the document changes
		void documentChanged ( QWidget * pQWidget_EdtEditor, bool b_documentChanged );
		
		/// Signs copy capability
		/// \param pQWidget_EdtEditor	Reference to the editor widget
		/// \param b_copyAvailable	TRUE, if capability available
		void copyAvailable ( QWidget * pQWidget_EdtEditor, bool b_copyAvailable );

		/// Signs undo capability
		/// \param pQWidget_EdtEditor	Reference to the editor widget
		/// \param b_copyAvailable	TRUE, if capability available
		void undoAvailable ( QWidget * pQWidget_EdtEditor, bool b_undoAvailable );

		/// Signs redo capability
		/// \param pQWidget_EdtEditor	Reference to the editor widget
		/// \param b_copyAvailable	TRUE, if capability available
		void redoAvailable ( QWidget * pQWidget_EdtEditor, bool b_redoAvailable );
		
	// *******************************************************************************************************************
	// Editing document
	// *******************************************************************************************************************
	public:
	
		/// Settings for find and replace
		struct sSetFndRepl_t
		{
			bool b_fndCaseSensitive;
			bool b_fndBackwards;
			bool b_fndWholeWords;
			bool b_fndFromCursor;

			QString QString_find;
			QString QString_replace;
		};

		/// Finds text within editor widget.
		/// \param ppsSetFndRepl	Find/replace settings
		bool find ( sSetFndRepl_t * ppsSetFndRepl );

		/// Replaces text within editor widget.
		/// \param ppsSetFndRepl	Find/replace settings
		bool replace ( sSetFndRepl_t * ppsSetFndRepl );

		/// Replaces text within editor widget.
		/// \param ppsSetFndRepl	Find/replace settings
		void replaceAll ( sSetFndRepl_t * ppsSetFndRepl );

		/// Duplicates the current line within editor widget.
		void duplicateLine ( void );
	
	public slots:

		/// Indent lines
		void indent ( void );

		/// Deindent lines
		void deindent ( void );
		
		/// Comment out lines
		void commentOut ( void );
		
		/// Comment in lines
		void commentIn ( void );
};

/**
 *****************************************************************************************************************************
 *
 *      \brief Text editor left margin widget.
 *
 *	This code
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-09-15
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class EdtEditorWidgetLeftMargin : public QWidget
{
		Q_OBJECT

	public:


		/// Constructor. This class is the left margin of the PicIOFifoEditor widget.
		/// \param pPicIOFifoEditor	Reference to parent widget
		EdtEditorWidgetLeftMargin ( EdtEditorWidget * pEdtEditorWidget ) : QWidget ( pEdtEditorWidget )
		{
			this->pEdtEditorWidget = pEdtEditorWidget;
		}

		/// Returns the size hint.
		/// \retval QSize	Size hint
		QSize sizeHint() const
		{
			return QSize ( this->pEdtEditorWidget->leftMarginWidth(), 0 );
		}

	protected:

		/// Handles double click event.
		/// \param pQMouseEvent		Mouse event
		void mouseDoubleClickEvent ( QMouseEvent * pQMouseEvent )
		{
			this->pEdtEditorWidget->leftMarginLineFromPos ( pQMouseEvent->y() );
			QWidget::update ();
		}

		/// Paints the widget.
		/// \param pQPaintEvent		Paint event
		void paintEvent ( QPaintEvent * pQPaintEvent )
		{
			this->pEdtEditorWidget->leftMarginPaintEvent ( pQPaintEvent );
		}

	private:

		/// Reference to parent widget.
		EdtEditorWidget * pEdtEditorWidget;
};

#endif
