/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicIOMem.h"

/**
 *****************************************************************************************************************************
 */

PicIOMem::PicIOMem ( QWidget * pQWidget_parent ) : QWidget ( pQWidget_parent )
{
	this->QColor_bgNormal      = Qt::black;
	this->QColor_bgHighlighted = Qt::red;

	QFont QFont_bold;
	QFont_bold.setBold ( TRUE );

	QVBoxLayout * pQVBoxLayout_main = new QVBoxLayout;
	{
		QFrame * pQFrame = new QFrame;
		{
			QHBoxLayout * pQHBoxLayout_frame = new QHBoxLayout;
			{
				QVBoxLayout * pQVBoxLayout_content = new QVBoxLayout;
				{
					this->pQWidget_addr = new QWidget;
					{
						QHBoxLayout * pQHBoxLayout_addr = new QHBoxLayout;
						{
							QLabel * pQLabel_addrTitle = new QLabel;
							{
								QPalette QPalette_actual = pQLabel_addrTitle->palette();
								QPalette_actual.setColor ( QPalette::Active, QPalette::Foreground, Qt::white );
								QPalette_actual.setColor ( QPalette::Inactive, QPalette::Foreground, Qt::white );
								pQLabel_addrTitle->setPalette ( QPalette_actual );

								pQLabel_addrTitle->setFont ( QFont_bold );
								pQLabel_addrTitle->setText ( "Addr:" );
							}

							this->pPicEdtInteger_addr = new PicEdtInteger;
							{
								this->pPicEdtInteger_addr->setToolTip ( QObject::tr ( "Address" ) );
							}

							this->pQLabel_addrSymbol = new QLabel;
							{
								QPalette QPalette_actual = pQLabel_addrSymbol->palette();
								QPalette_actual.setColor ( QPalette::Active, QPalette::Foreground, Qt::white );
								QPalette_actual.setColor ( QPalette::Inactive, QPalette::Foreground, Qt::white );
								this->pQLabel_addrSymbol->setPalette ( QPalette_actual );

								this->pQLabel_addrSymbol->setToolTip ( QObject::tr ( "Address substitute" ) );
							}

							pQHBoxLayout_addr->addWidget ( pQLabel_addrTitle );
							pQHBoxLayout_addr->addWidget ( this->pPicEdtInteger_addr );
							pQHBoxLayout_addr->addWidget ( pQLabel_addrSymbol );
							pQHBoxLayout_addr->addStretch ();
							pQHBoxLayout_addr->setContentsMargins ( 2, 2, 2, 2 );
						}

						this->pQWidget_addr->setLayout ( pQHBoxLayout_addr );

						// Set background color
						QPalette QPalette_actual = this->pQWidget_addr->palette();
						QPalette_actual.setColor ( QPalette::Active, QPalette::Window, QColor_bgNormal );
						QPalette_actual.setColor ( QPalette::Inactive, QPalette::Window, QColor_bgNormal );
						this->pQWidget_addr->setPalette ( QPalette_actual );
						this->pQWidget_addr->setAutoFillBackground ( TRUE );
						this->pQWidget_addr->setContentsMargins ( 0, 0, 0, 0 );
					}

					QHBoxLayout * pQHBoxLayout_ctrl = new QHBoxLayout;
					{
						this->pQLabel_dir = new QLabel;
						{
							this->pQLabel_dir->setToolTip ( QObject::tr ( "Direction" ) );
						}

						this->pPicEdtInteger_valueLst = new PicEdtInteger;
						{
							this->pPicEdtInteger_valueLst->setToolTip ( QObject::tr ( "Last value" ) );
						}

						QLabel * pQLabel = new QLabel ( "@" );

						this->pPicEdtInteger_valueAddr = new PicEdtInteger;
						{
							this->pPicEdtInteger_valueAddr->setToolTip ( QObject::tr ( "Last address" ) );
						}

						this->pQComboBox_memSize = new QComboBox;
						{
							this->pQComboBox_memSize->setToolTip ( QObject::tr ( "Size" ) );

							this->pQComboBox_memSize->addItem ( QString ( "  2" ) );
							this->pQComboBox_memSize->addItem ( QString ( "  4" ) );
							this->pQComboBox_memSize->addItem ( QString ( "  8" ) );
							this->pQComboBox_memSize->addItem ( QString ( " 16" ) );
							this->pQComboBox_memSize->addItem ( QString ( " 32" ) );
							this->pQComboBox_memSize->addItem ( QString ( " 64" ) );
							this->pQComboBox_memSize->addItem ( QString ( "128" ) );
							this->pQComboBox_memSize->addItem ( QString ( "256" ) );

							connect ( this->pQComboBox_memSize, SIGNAL ( currentIndexChanged ( QString ) ), this, SLOT ( setupEditor ( QString ) ) );
						}

						this->pQPushButton_editor = new QPushButton;
						{
							this->pQPushButton_editor->setToolTip ( QObject::tr ( "Expand memory block" ) );
							this->pQPushButton_editor->setIcon ( QIcon ( ":/pic/img/pic/memExpand.png" ) );

							connect ( this->pQPushButton_editor, SIGNAL ( clicked() ), this, SLOT ( expandCollapseEditor () ) );
						}

						this->pQComboBox_direction = new QComboBox;
						{
							this->pQComboBox_direction->setToolTip ( QObject::tr ( "Direction" ) );

							this->pQComboBox_direction->addItem ( QString ( "I" ) );
							this->pQComboBox_direction->addItem ( QString ( "O" ) );
							this->pQComboBox_direction->addItem ( QString ( "IO" ) );

							this->pQComboBox_direction->setCurrentIndex ( 2 );
						}

// 						QPushButton * pQPushButton_close = new QPushButton;
// 						{
// 							pQPushButton_close->setToolTip ( QObject::tr ( "Close device" ) );
// 							pQPushButton_close->setFlat ( TRUE );
// 							pQPushButton_close->setIcon ( QIcon ( ":/main/img/main/closeWidget.png" ) );
// 
// 							connect ( pQPushButton_close, SIGNAL ( clicked() ), this, SLOT ( closePort() ) );
// 						}

						pQHBoxLayout_ctrl->addWidget ( this->pQLabel_dir );
						pQHBoxLayout_ctrl->addWidget ( this->pPicEdtInteger_valueLst );
						pQHBoxLayout_ctrl->addWidget ( pQLabel );
						pQHBoxLayout_ctrl->addWidget ( this->pPicEdtInteger_valueAddr );
						pQHBoxLayout_ctrl->addStretch ();
						pQHBoxLayout_ctrl->addWidget ( this->pQComboBox_memSize );
						pQHBoxLayout_ctrl->addWidget ( this->pQPushButton_editor );
						pQHBoxLayout_ctrl->addWidget ( this->pQComboBox_direction );
// 						pQHBoxLayout_ctrl->addStretch ();
// 						pQHBoxLayout_ctrl->addWidget ( pQPushButton_close );

						pQHBoxLayout_ctrl->setContentsMargins ( 0, 0, 2, 0 );
					}

					QVBoxLayout * pQVBoxLayout_mem = new QVBoxLayout;
					{
						this->pPicIOMemEditor = new PicIOMemEditor;

						this->pPicIOMemEditor->hide ();
						
						this->pQComboBox_memSize->setCurrentIndex ( 3 );

						pQVBoxLayout_mem->addWidget ( this->pPicIOMemEditor );
					}

					pQVBoxLayout_content->addWidget ( this->pQWidget_addr );
					pQVBoxLayout_content->addLayout ( pQHBoxLayout_ctrl );
					pQVBoxLayout_content->addLayout ( pQVBoxLayout_mem );

					pQVBoxLayout_content->setSpacing ( 2 );
					pQVBoxLayout_content->setContentsMargins ( 0, 0, 0, 2 );
				}
				
				QWidget * pQWidget_ioType = new QWidget;
				{
					QVBoxLayout * pQVBoxLayout_ioType = new QVBoxLayout;
					{
						QPushButton * pQPushButton_close = new QPushButton;
						{
							pQPushButton_close->setToolTip ( QObject::tr ( "Close device" ) );
							pQPushButton_close->setFlat ( TRUE );
							pQPushButton_close->setIcon ( QIcon ( ":/main/img/main/closeWidget.png" ) );

							connect ( pQPushButton_close, SIGNAL ( clicked() ), this, SLOT ( closePort() ) );
						}

	// 					pQVBoxLayout_ioType->addStretch ();
						pQVBoxLayout_ioType->addWidget ( pQPushButton_close );
						pQVBoxLayout_ioType->setAlignment ( Qt::AlignTop );
						
						pQVBoxLayout_ioType->setSpacing ( 0 );
						pQVBoxLayout_ioType->setContentsMargins ( 0, 0, 0, 0 );
					}
					pQWidget_ioType->setLayout ( pQVBoxLayout_ioType );
					
					QPalette QPalette_actual = pQWidget_ioType->palette();
					QPalette_actual.setColor ( QPalette::Window, Qt::darkRed );
					pQWidget_ioType->setPalette ( QPalette_actual );
					pQWidget_ioType->setAutoFillBackground ( TRUE );
				}
				
				pQHBoxLayout_frame->addLayout ( pQVBoxLayout_content );
				pQHBoxLayout_frame->addWidget ( pQWidget_ioType );

				pQHBoxLayout_frame->setSpacing ( 0 );
				pQHBoxLayout_frame->setContentsMargins ( 0, 0, 0, 0 );
			}
				
			QPalette QPalette_actual = pQFrame->palette();
			QPalette_actual.setColor ( QPalette::Normal, QPalette::Foreground, Qt::black );
			pQFrame->setPalette ( QPalette_actual );

			pQFrame->setFrameShape ( QFrame::Box );
			pQFrame->setFrameShadow ( QFrame::Plain );

			pQFrame->setLayout ( pQHBoxLayout_frame );
		}
		pQVBoxLayout_main->addWidget ( pQFrame );
		pQVBoxLayout_main->setContentsMargins ( 0, 0, 0, 0 );
	}
	QWidget::setLayout ( pQVBoxLayout_main );
}

/**
 *****************************************************************************************************************************
 */

void PicIOMem::setValue ( int i_value )
{
	int i_addrStart;

	if ( ! this->pPicEdtInteger_addr->getValue ( & i_addrStart ) )
		return;

	QString QString_value = QString ( "%1" ).arg ( i_value, 0, this->i_base );

	this->pPicEdtInteger_valueAddr->setValue ( this->i_addrNxt );
	this->pPicEdtInteger_valueLst->setValue ( i_value );

	this->pPicIOMemEditor->setValue ( ( this->i_addrNxt - i_addrStart ), QString_value );

	this->pQLabel_dir->setPixmap  ( QPixmap ( ":/pic/img/pic/memDirIn.png" ) );

	this->pPicEdtInteger_valueAddr->setHighlighted ( TRUE );
	this->pPicEdtInteger_valueLst->setHighlighted ( TRUE );

}

/**
 *****************************************************************************************************************************
 */

bool PicIOMem::getValue ( int * pi_value )
{
	int i_addrStart;

	if ( ! this->pPicEdtInteger_addr->getValue ( & i_addrStart ) )
		return FALSE;

	QString QString_value;

	this->pPicIOMemEditor->getValue ( ( this->i_addrNxt - i_addrStart ), & QString_value );

	bool b_retval;

	* pi_value = QString_value.toInt ( & b_retval, this->i_base );

	if ( ! b_retval )
		return FALSE;

	this->pPicEdtInteger_valueAddr->setValue ( this->i_addrNxt );
	this->pPicEdtInteger_valueLst->setValue ( * pi_value );

	this->pQLabel_dir->setPixmap  ( QPixmap ( ":/pic/img/pic/memDirOut.png" ) );

	this->pPicEdtInteger_valueAddr->setHighlighted ( TRUE );
	this->pPicEdtInteger_valueLst->setHighlighted ( TRUE );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

void PicIOMem::setBase ( int i_base )
{
	this->i_base =  i_base;
	
	this->pPicEdtInteger_addr->setBase ( i_base );
	this->pPicEdtInteger_valueLst->setBase ( i_base );
	this->pPicIOMemEditor->setBase ( this->i_base );
}

/**
 *****************************************************************************************************************************
 */

void PicIOMem::closePort ( void )
{
	emit closeRequest ( this );
}

/**
 *****************************************************************************************************************************
 */

void PicIOMem::setAddr ( int i_addr )
{
	this->pPicEdtInteger_addr->setValue ( i_addr );
}

/**
 *****************************************************************************************************************************
 */
void PicIOMem::setAddrSymbol ( QString QString_addrSymbol )
{
	this->pQLabel_addrSymbol->setText ( QString_addrSymbol );
}

/**
 *****************************************************************************************************************************
 */

bool PicIOMem::chkAddr ( int i_value )
{
	int i_addrStart;
	int i_addrEnd;

	if ( ! this->pPicEdtInteger_addr->getValue ( & i_addrStart ) )
		return FALSE;

	i_addrEnd = i_addrStart + this->pQComboBox_memSize->currentText ().toInt () - 1;

	if ( ( i_value < i_addrStart ) || ( i_value > i_addrEnd ) )
		return FALSE;

	this->i_addrNxt = i_value;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicIOMem::setDirection ( PicIOCommon::eDirection_t eDirection )
{
	if ( static_cast < int > ( eDirection > 2 ) )
		return FALSE;

	this->pQComboBox_direction->setCurrentIndex ( static_cast < int > ( eDirection ) );
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicIOMem::chkDirection ( PicIOCommon::eDirection_t eDirection_chk )
{
	PicIOCommon::eDirection_t eDirection_port = static_cast < PicIOCommon::eDirection_t > ( this->pQComboBox_direction->currentIndex() );

	if ( ( eDirection_chk == eDirIn ) && ( ( eDirection_port == eDirIn ) || ( eDirection_port == eDirInOut ) ) )
	{
		return TRUE;
	}
	else if ( ( eDirection_chk == eDirOut ) && ( ( eDirection_port == eDirOut ) || ( eDirection_port == eDirInOut ) ) )
	{
		return TRUE;
	}
	else if ( ( eDirection_chk == eDirInOut ) && ( eDirection_port == eDirInOut ) )
	{
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

void PicIOMem::setHighlighted ( bool b_highlighted )
{
	QPalette QPalette_actual = this->pQWidget_addr->palette();

	if ( b_highlighted )
	{
		QPalette_actual.setColor ( QPalette::Active,   QPalette::Window, this->QColor_bgHighlighted );
		QPalette_actual.setColor ( QPalette::Inactive, QPalette::Window, this->QColor_bgHighlighted );
	}
	else
	{
		QPalette_actual.setColor ( QPalette::Active,   QPalette::Window, this->QColor_bgNormal );
		QPalette_actual.setColor ( QPalette::Inactive, QPalette::Window, this->QColor_bgNormal );
	}

	this->pQWidget_addr->setPalette ( QPalette_actual );
}

/**
 *****************************************************************************************************************************
 */

void PicIOMem::clearHighlighted ( void )
{
	this->setHighlighted ( FALSE );
	this->pPicEdtInteger_valueAddr->setHighlighted ( FALSE );
	this->pPicEdtInteger_valueLst->setHighlighted ( FALSE );
}

/**
 *****************************************************************************************************************************
 */

void PicIOMem::clear ( void )
{
	this->pPicIOMemEditor->clear ();
}

/**
 *****************************************************************************************************************************
 */

void PicIOMem::expandCollapseEditor ( void )
{
	if ( this->pPicIOMemEditor->isVisible () )
	{
		this->pQPushButton_editor->setToolTip ( QObject::tr ( "Expand list" ) );
		this->pQPushButton_editor->setIcon ( QIcon ( ":/pic/img/pic/fifoExpand.png" ) );

		this->pPicIOMemEditor->hide ();
	}
	else
	{
		this->pQPushButton_editor->setToolTip ( QObject::tr ( "Collapse list" ) );
		this->pQPushButton_editor->setIcon ( QIcon ( ":/pic/img/pic/fifoCollapse.png" ) );

		this->pPicIOMemEditor->show ();
	}
}

/**
 *****************************************************************************************************************************
 */

void PicIOMem::setupEditor ( QString QString_memSize )
{
	int i_memSize  = QString_memSize.toInt ();

	this->pPicIOMemEditor->setSize ( i_memSize );
}

/**
 *****************************************************************************************************************************
 */

