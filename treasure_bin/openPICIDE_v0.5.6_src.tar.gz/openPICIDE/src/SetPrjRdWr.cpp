/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "SetPrjRdWr.h"
#include "SetPrjRdWrV01.h"
#include "SetPrjRdWrV02.h"

/**
 *****************************************************************************************************************************
 */

SetPrjRdWr::SetPrjRdWr ( )
{
	
}

/**
 *****************************************************************************************************************************
 */

bool SetPrjRdWr::read ( SetPrj * pSetPrj, QString * pQString_errMsg )
{
	// Reads file
	QFile QFile_settings ( pSetPrj->sPrj.QString_prjPath + pSetPrj->sPrj.QString_prjFile );
	
	// Open file
	if ( ! QFile_settings.open ( QIODevice::ReadOnly | QIODevice::Text ) )
	{
		*pQString_errMsg = QObject::tr ( "Can not open project file for read access!" );

		return FALSE;
	}

	// Parse xml stream
	QXmlStreamReader QXmlStreamReader_rd ( & QFile_settings );

	while ( ! QXmlStreamReader_rd.atEnd () )
	{
		QXmlStreamReader_rd.readNext ();

		if ( "project" == QXmlStreamReader_rd.qualifiedName ().toString () )
		{
			QString QString_version = QXmlStreamReader_rd.attributes ().value ( "version" ).toString ();

			switch ( QString_version.toInt () )
			{
				case 2:

					this->readV02 ( pSetPrj, & QXmlStreamReader_rd );

					break;

				case 1:

					this->readV01 ( pSetPrj, & QXmlStreamReader_rd );

					break;
					
				default:

					*pQString_errMsg = QObject::tr ( "The project file seems to be generated with a newer version of openPICIDE and can not be interpreted." );

					QFile_settings.close();
					return FALSE;
			}
		}
	}

	// Closes file
	QFile_settings.close();

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWr::readV01 ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader_rd )
{
	SetPrjRdWrV01 SetPrjRdWrV01_rd;

	SetPrjRdWrV01_rd.rdXml ( pSetPrj, pQXmlStreamReader_rd );
}

/**
 *****************************************************************************************************************************
 */
	
void SetPrjRdWr::readV02 ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader_rd )
{
	SetPrjRdWrV02 SetPrjRdWrV02_rd;

	SetPrjRdWrV02_rd.rdXml ( pSetPrj, pQXmlStreamReader_rd );
}

/**
 *****************************************************************************************************************************
 */
	
bool SetPrjRdWr::save ( SetPrj * pSetPrj, QString * pQString_errMsg )
{
	QString QString_xml;

	// Generates xml stream
	SetPrjRdWrV02 SetPrjRdWrV02_tmp;
	{
		SetPrjRdWrV02_tmp.wrXml ( pSetPrj, & QString_xml );
	}

	// Writes xml string to file
	QFile QFile_settings ( QString ( pSetPrj->sPrj.QString_prjPath + pSetPrj->sPrj.QString_prjFile ) );
	{
		// Write settings to file
		if ( ! QFile_settings.open ( QIODevice::WriteOnly | QIODevice::Text ) )
		{
			*pQString_errMsg = QObject::tr ( "Can't open project file for write access!" );

			return FALSE;
		}

		QFile_settings.seek ( 0 );

		QFile_settings.write ( QString_xml.toUtf8().data() );

		QFile_settings.close();
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */


 
 
 
 
