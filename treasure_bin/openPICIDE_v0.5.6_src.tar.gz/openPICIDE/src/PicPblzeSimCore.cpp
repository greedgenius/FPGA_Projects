/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeSimCore.h"

/**
 *****************************************************************************************************************************
 */

PicPblzeSimCore::PicPblzeSimCore ( sCfg_t sCfg, QWidget * pQWidget_parent )  : QWidget ( pQWidget_parent )
{
	this->pPicEdtInteger_hwbld = NULL;
	
	QVBoxLayout * pQVBoxLayout_main = new QVBoxLayout;
	{
		QHBoxLayout * pQHBoxLayout_clkCntr = new QHBoxLayout;
		{
			QLabel * pQLabel = new QLabel ( "Clock count:" );

			this->pPicEdtInteger_clkCntr = new PicEdtInteger;
			{
				this->pPicEdtInteger_clkCntr->setEnabled ( FALSE );
				this->pPicEdtInteger_clkCntr->setMaxValue ( 0xFFFFFF );
				this->pPicEdtInteger_clkCntr->setBase ( 10 );
			}
		
			QPushButton * pQPushButton = new QPushButton ( QObject::tr ( "Clear" ) );

			connect ( pQPushButton, SIGNAL ( clicked () ), this, SLOT ( clearClkCntr () ) );
		
			pQHBoxLayout_clkCntr->addWidget ( pQLabel );
			pQHBoxLayout_clkCntr->addWidget ( this->pPicEdtInteger_clkCntr );
			pQHBoxLayout_clkCntr->addStretch ();
			pQHBoxLayout_clkCntr->addWidget ( pQPushButton );
		}
		
		QHBoxLayout * pQHBoxLayout_pc = new QHBoxLayout;
		{
			QLabel * pQLabel = new QLabel ( "PC:" );

			this->pPicEdtInteger_pc = new PicEdtInteger;
			{
				this->pPicEdtInteger_pc->setEnabled ( FALSE );
			}

			this->pQLabel_memRange = new QLabel;
			
			pQHBoxLayout_pc->addWidget ( pQLabel );
			pQHBoxLayout_pc->addWidget ( this->pPicEdtInteger_pc );
			pQHBoxLayout_pc->addWidget ( this->pQLabel_memRange );
			pQHBoxLayout_pc->addStretch ();
			
			if ( sCfg.b_hwbuildEn )
			{
				this->pPicEdtInteger_hwbld = new PicEdtInteger;

				pQHBoxLayout_pc->addWidget ( new QLabel ( "HWBuild:" ) );
				pQHBoxLayout_pc->addWidget ( this->pPicEdtInteger_hwbld );
			}
			
			pQHBoxLayout_pc->addStretch ();
			pQHBoxLayout_pc->setSizeConstraint ( QLayout::SetMinimumSize );
		}

		this->pPicPblzeSimCoreFlag  = new PicPblzeSimCoreFlag;
		this->pPicPblzeSimCoreReg   = new PicPblzeSimCoreReg   ( sCfg.i_regCountA, sCfg.i_regCountB );
		this->pPicPblzeSimCoreScrpd = new PicPblzeSimCoreScrpd ( sCfg.i_scrpdSize );

		pQVBoxLayout_main->addLayout ( pQHBoxLayout_clkCntr );
		pQVBoxLayout_main->addWidget ( this->setLine() );
		pQVBoxLayout_main->addLayout ( pQHBoxLayout_pc );
		pQVBoxLayout_main->addWidget ( this->setLine() );
		pQVBoxLayout_main->addWidget ( this->pPicPblzeSimCoreFlag );
		pQVBoxLayout_main->addWidget ( this->setLine() );
		pQVBoxLayout_main->addWidget ( this->pPicPblzeSimCoreReg );
		pQVBoxLayout_main->addWidget ( this->setLine() );
		pQVBoxLayout_main->addWidget ( this->pPicPblzeSimCoreScrpd );
		pQVBoxLayout_main->addStretch ( );
	}

	this->setBase ( 16 );

	QWidget::setLayout ( pQVBoxLayout_main );
// 	QWidget::setSizePolicy ( QSizePolicy::Minimum, QSizePolicy::Minimum );
}

/**
 *****************************************************************************************************************************
 */

PicPblzeSimCore::~PicPblzeSimCore ()
{
	if ( this->pPicPblzeSimCoreFlag )
		delete this->pPicPblzeSimCoreFlag;

	if ( this->pPicPblzeSimCoreReg )
		delete this->pPicPblzeSimCoreReg;

	if ( this->pPicPblzeSimCoreScrpd )
		delete this->pPicPblzeSimCoreScrpd;
	
	if ( this->pPicEdtInteger_pc )
		delete this->pPicEdtInteger_pc;
	
	if ( this->pPicEdtInteger_clkCntr )
		delete this->pPicEdtInteger_clkCntr;
	
}

/**
 *****************************************************************************************************************************
 */

QFrame * PicPblzeSimCore::setLine ( void )
{
	QFrame * pQFrame = new QFrame;
	{
		pQFrame->setFrameStyle ( QFrame::Plain | QFrame::HLine );
		pQFrame->setLineWidth ( 1 );
	}

	return pQFrame;
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCore::setBase ( int i_base )
{
	this->pPicPblzeSimCoreReg->setBase ( i_base );
	this->pPicPblzeSimCoreScrpd->setBase ( i_base );
	this->pPicEdtInteger_pc->setBase ( i_base );
	
	if ( this->pPicEdtInteger_hwbld )
		this->pPicEdtInteger_hwbld->setBase ( i_base );

	emit contentChanged ( this );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCore::setCarry ( int i_value )
{
	this->pPicPblzeSimCoreFlag->setCarry ( i_value );

	emit contentChanged ( this );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCore::getCarry ( void )
{
	return this->pPicPblzeSimCoreFlag->getCarry ();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCore::setZero ( int i_value )
{
	this->pPicPblzeSimCoreFlag->setZero ( i_value );

	emit contentChanged ( this );
}

/**
 *****************************************************************************************************************************
 */


bool PicPblzeSimCore::getZero ( void )
{
	return this->pPicPblzeSimCoreFlag->getZero ();
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCore::setBank ( PicPblzeSimCoreReg::eBankSel_t eBankSel )
{
	emit contentChanged ( this );
	
	return this->pPicPblzeSimCoreReg->setBank ( eBankSel );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCore::setRegister ( QString QString_regName, QString QString_regSubst, int i_value )
{
	emit contentChanged ( this );
	
	return this->pPicPblzeSimCoreReg->setRegister ( QString_regName, QString_regSubst, i_value );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCore::getRegister ( QString QString_regName, QString QString_regSubst, int * pi_value )
{
	return this->pPicPblzeSimCoreReg->getRegister ( QString_regName, QString_regSubst, pi_value );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCore::setScrpd ( int i_addr, int i_value )
{
	emit contentChanged ( this );
	
	return this->pPicPblzeSimCoreScrpd->setValue ( i_addr, i_value );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCore::getScrpd ( int i_addr, int * pi_value )
{
	return this->pPicPblzeSimCoreScrpd->getValue ( i_addr, pi_value );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCore::setInt ( PicEdtInterrupt::eInt_t eInt )
{
	emit contentChanged ( this );
	
	this->pPicPblzeSimCoreFlag->setInt ( eInt );
}

/**
 *****************************************************************************************************************************
 */

PicEdtInterrupt::eInt_t PicPblzeSimCore::getInt ( void )
{
	return this->pPicPblzeSimCoreFlag->getInt ();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCore::clearHighlighted ( void )
{
	this->pPicPblzeSimCoreFlag->clearHighlighted ();
	this->pPicPblzeSimCoreReg->clearHighlighted ();
	this->pPicPblzeSimCoreScrpd->clearHighlighted ();
	this->pPicEdtInteger_clkCntr->setHighlighted ( FALSE );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCore::clear ( void )
{
	this->pPicPblzeSimCoreFlag->clear ();
	this->pPicPblzeSimCoreReg->clear ();
	this->pPicPblzeSimCoreScrpd->clear ();
	this->clearClkCntr();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCore::setPc ( int i_pc, QString QString_memRange )
{
	this->pPicEdtInteger_pc->setValue ( i_pc );
	
	this->pQLabel_memRange->setText ( QString_memRange );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCore::setMaxPc ( int i_maxPc )
{
	this->pPicEdtInteger_pc->setMaxValue ( i_maxPc );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCore::getPc ( int * pi_pc )
{
	this->pPicEdtInteger_pc->getValue ( pi_pc );
}

/**
 *****************************************************************************************************************************
 */

QSize PicPblzeSimCore::minimumSizeHint ( void )
{
	return QWidget::minimumSizeHint();

// 	QSize ( i_width, QWidget::height () );

// qDebug() << i_widthScrpd;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCore::toggleBank ( void )
{
	return this->pPicPblzeSimCoreReg->toggleBank ();
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCore::setHwbld ( int i_value )
{
	if ( ! this->pPicEdtInteger_hwbld )
		return FALSE;
	
	return this->pPicEdtInteger_hwbld->setValue ( i_value );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCore::getHwbld ( int * pi_value )
{
	if ( ! this->pPicEdtInteger_hwbld )
		return FALSE;
	
	return this->pPicEdtInteger_hwbld->getValue ( pi_value );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCore::addClkCntr ( int i_clkCntOffset )
{
	int i_clkCntr;
	
	this->pPicEdtInteger_clkCntr->getValue ( & i_clkCntr );
	this->pPicEdtInteger_clkCntr->setValue ( i_clkCntr + i_clkCntOffset );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCore::clearClkCntr ( void )
{
	this->pPicEdtInteger_clkCntr->setValue ( 0 );
}

/**
 *****************************************************************************************************************************
 */










