/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/
#include "PicPblzeCmplrPblze.h"

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Constructor/destructor
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

PicPblzeCmplrPblze::PicPblzeCmplrPblze ( QObject * pQObject_parent ) : PicPblzeCmplr ( pQObject_parent )
{
	this->QMap_reg [ "s0" ] = 0x0;
	this->QMap_reg [ "s1" ] = 0x1;
	this->QMap_reg [ "s2" ] = 0x2;
	this->QMap_reg [ "s3" ] = 0x3;
	this->QMap_reg [ "s4" ] = 0x4;
	this->QMap_reg [ "s5" ] = 0x5;
	this->QMap_reg [ "s6" ] = 0x6;
	this->QMap_reg [ "s7" ] = 0x7;
	this->QMap_reg [ "s8" ] = 0x8;
	this->QMap_reg [ "s9" ] = 0x9;
	this->QMap_reg [ "sA" ] = 0xA;
	this->QMap_reg [ "sB" ] = 0xB;
	this->QMap_reg [ "sC" ] = 0xC;
	this->QMap_reg [ "sD" ] = 0xD;
	this->QMap_reg [ "sE" ] = 0xE;
	this->QMap_reg [ "sF" ] = 0xF;
}

/**
 *****************************************************************************************************************************
 */


PicPblzeCmplrPblze::~PicPblzeCmplrPblze()
{
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Compile
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compile ( void )
{
	// Parse code
	if ( ! PicPblzeAsmParser::parse () )
		return FALSE;

	// Allocate new pic memory
	PicPblzeCmplr::asMemCell = new sMemCell_t[ PicPblzeAsmParser::sMem.i_memSize ];

	// Preset pic memory with zero
	memset ( PicPblzeCmplr::asMemCell, NULL, ( PicPblzeAsmParser::sMem.i_memSize * sizeof ( PicPblzeCmplr::sMemCell_t ) ) );
	
	// Compile
	for ( int i_iterator = 0; i_iterator < this->sMem.i_memSize; ++i_iterator )
	{
		unsigned int ui_memCell;
		
		sCodeLine_t * psCodeLine = PicPblzeAsmParser::sMem.apsCodeLine_memMap[ i_iterator ];
		
		if ( ! psCodeLine )
			continue;
		
		if ( psCodeLine->eLineType > PicPblzeAsmParser::eLineType_cmd )
		{
			// Get memory line
			if ( ! this->compileCmd ( psCodeLine, & ui_memCell ) )
			{
				PicPblzeCmplr::msgEmit ( PicPblzeCmplr::eMsgType_compError );
				return FALSE;
			}

			// Store memory line
			PicPblzeCmplr::asMemCell [ i_iterator ].b_valid  = TRUE;
			PicPblzeCmplr::asMemCell [ i_iterator ].ui_value = ui_memCell;
		}
		else
		{
			PicPblzeCmplr::msgEmit ( PicPblzeCmplr::eMsgType_compError );
			return FALSE;
		}
	}

	// Write output file
	return PicPblzeCmplr::writeOutputFile ();
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Compile commands
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	switch ( psCodeLine->eLineType )
	{
		case eLineType_cmdRet:		return this->compileCmdReturn  ( psCodeLine, pui_memCell );
		case eLineType_cmdReti:		return this->compileCmdReturnI ( psCodeLine, pui_memCell );
		case eLineType_cmdAddc:		return this->compileCmdAddCy   ( psCodeLine, pui_memCell );
		case eLineType_cmdSubc:		return this->compileCmdSubCy   ( psCodeLine, pui_memCell );
		case eLineType_cmdIn:		return this->compileCmdInput   ( psCodeLine, pui_memCell );
		case eLineType_cmdOut:		return this->compileCmdOutput  ( psCodeLine, pui_memCell );
		case eLineType_cmdEint:		return this->compileCmdIntEn   ( psCodeLine, pui_memCell );
		case eLineType_cmdDint:		return this->compileCmdIntDis  ( psCodeLine, pui_memCell );
// 		case eLineType_cmdComp:		return this->compileCmdCompare ( psCodeLine, pui_memCell );
		case eLineType_cmdAdd:		return this->compileCmdAdd     ( psCodeLine, pui_memCell );
		case eLineType_cmdAnd:		return this->compileCmdAnd     ( psCodeLine, pui_memCell );
		case eLineType_cmdCall:		return this->compileCmdCall    ( psCodeLine, pui_memCell );
		case eLineType_cmdJump:		return this->compileCmdJump    ( psCodeLine, pui_memCell );
		case eLineType_cmdLoad:		return this->compileCmdLoad    ( psCodeLine, pui_memCell );
		case eLineType_cmdOr:		return this->compileCmdOr      ( psCodeLine, pui_memCell );
		case eLineType_cmdRl:		return this->compileCmdRl      ( psCodeLine, pui_memCell );
		case eLineType_cmdRr:		return this->compileCmdRr      ( psCodeLine, pui_memCell );
		case eLineType_cmdSl0:		return this->compileCmdSl0     ( psCodeLine, pui_memCell );
		case eLineType_cmdSl1:		return this->compileCmdSl1     ( psCodeLine, pui_memCell );
		case eLineType_cmdSlA:		return this->compileCmdSla     ( psCodeLine, pui_memCell );
		case eLineType_cmdSlX:		return this->compileCmdSlx     ( psCodeLine, pui_memCell );
		case eLineType_cmdSr0:		return this->compileCmdSr0     ( psCodeLine, pui_memCell );
		case eLineType_cmdSr1:		return this->compileCmdSr1     ( psCodeLine, pui_memCell );
		case eLineType_cmdSrA:		return this->compileCmdSra     ( psCodeLine, pui_memCell );
		case eLineType_cmdSrX:		return this->compileCmdSrx     ( psCodeLine, pui_memCell );
		case eLineType_cmdSub:		return this->compileCmdSub     ( psCodeLine, pui_memCell );
// 		case eLineType_cmdTest:		return this->compileCmdTest    ( psCodeLine, pui_memCell );
		case eLineType_cmdXor:		return this->compileCmdXor     ( psCodeLine, pui_memCell );
// 		case eLineType_cmdStore:	return this->compileCmdStore   ( psCodeLine, pui_memCell );
// 		case eLineType_cmdFetch:	return this->compileCmdFetch   ( psCodeLine, pui_memCell );
	}

	PicPblzeAsmParser::msgEmit ( PicPblzeAsmParser::eMsgType_ivldCmd, psCodeLine );

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdAdd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x4000, 0xC004, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdAddCy ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x5000, 0xC005, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdAnd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x1000, 0xC001, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdCall ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();
	QString QString_addr;

	//********************************************************************************************************************
	//* Check for jump type
	//********************************************************************************************************************
	if ( QString_arg0 == QString ( "C" ) )		// CALL C
	{
		*pui_memCell = 0x9B00;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "NC" ) )	// CALL NC
	{
		*pui_memCell = 0x9F00;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "NZ" ) )	// CALL NZ
	{
		*pui_memCell = 0x9700;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "Z" ) )	// CALL Z
	{
		*pui_memCell = 0x9300;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else
	{
		*pui_memCell = 0x8300;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	}

	//********************************************************************************************************************
	//* Check for address
	//********************************************************************************************************************
	{
		sCodeLine_t * psCodeLine_addr;

		if ( ! PicPblzeAsmParser::checkArgRef ( QString_addr, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell |= compileArgMAddr ( psCodeLine_addr->i_addr );
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdIntDis ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	*pui_memCell = 0x8010;
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdIntEn ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	*pui_memCell = 0x8030;
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdInput ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegPAddr ( psCodeLine, 0xA000, 0xB000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdJump ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();
	QString QString_addr;

	//********************************************************************************************************************
	//* Check for jump type
	//********************************************************************************************************************
	if ( QString_arg0 == QString ( "C" ) )		// JUMP C
	{
		*pui_memCell = 0x9900;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "NC" ) )	// JUMP NC
	{
		*pui_memCell = 0x9D00;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "NZ" ) )	// JUMP NZ
	{
		*pui_memCell = 0x9500;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "Z" ) )	// JUMP Z
	{
		*pui_memCell = 0x9100;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else
	{
		*pui_memCell = 0x8100;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	}

	//********************************************************************************************************************
	//* Check for address
	//********************************************************************************************************************
	{
		sCodeLine_t * psCodeLine_addr;

		if ( ! PicPblzeAsmParser::checkArgRef ( QString_addr, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell |= compileArgMAddr ( psCodeLine_addr->i_addr );
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdLoad ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x0000, 0xC000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdOr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x2000, 0xC002, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdOutput ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegPAddr ( psCodeLine, 0xE000, 0xF000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdReturn ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0;

	if ( psCodeLine->QStringList_args.count () > 0 )
		QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();

	//********************************************************************************************************************
	//* Check for jump type
	//********************************************************************************************************************
	if ( QString_arg0 == QString ( "C" ) )		// RETURN C
	{
		*pui_memCell  = 0x9880;
	}
	else if ( QString_arg0 == QString ( "NC" ) )	// RETURN NC
	{
		*pui_memCell  = 0x9C80;
	}
	else if ( QString_arg0 == QString ( "NZ" ) )	// RETURN NZ
	{
		*pui_memCell  = 0x9480;
	}
	else if ( QString_arg0 == QString ( "Z" ) )	// RETURN Z
	{
		*pui_memCell  = 0x9080;
	}
	else
	{
		*pui_memCell  = 0x8080;
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdReturnI ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();

	if ( QString_arg0 == QString ( "DISABLE" ) )
		*pui_memCell = 0x80D0;

	else if ( QString_arg0 == QString ( "ENABLE" ) )
		*pui_memCell = 0x80F0;

	else
		return FALSE;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdRl ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xD002, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdRr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xD00C, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdSl0 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xD006, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdSl1 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xD007, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdSla ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xD000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdSlx ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xD004, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdSr0 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xD00E, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdSr1 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xD00F, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdSra ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xD008, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdSrx ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xD00A, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdSub ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x6000, 0xC006, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdSubCy ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x7000, 0xC007, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileCmdXor ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x3000, 0xC003, pui_memCell );
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Compile arguments
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileArgMemRegVsRegConst ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memConst, int i_memReg, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QStirng_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	QString QString_regDst;
	QString QString_regSrc;
	int i_constant;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	//********************************************************************************************************************
	//* Check for constant
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgNumberConst ( QStirng_arg1, & i_constant ) )
	{
		*pui_memCell = i_memConst | compileArgRegDst ( QString_regDst ) | compileArgConst ( i_constant );
		return TRUE;
	}

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgRegSubst ( QStirng_arg1, & QString_regSrc ) )
	{
		*pui_memCell = i_memReg | compileArgRegDst ( QString_regDst ) | compileArgRegSrc ( QString_regSrc );
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileArgMemRegVsRegPAddr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memPAddr, int i_memReg, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QStirng_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	QString QString_regDst;
	QString QString_regSrc;
	int i_pAddr;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	//********************************************************************************************************************
	//* Check for port address
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgNumberConst ( QStirng_arg1, & i_pAddr ) )
	{
		*pui_memCell = i_memPAddr | compileArgRegDst ( QString_regDst ) | compileArgPAddr ( i_pAddr );
		return TRUE;
	}

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgAddrByReg ( QStirng_arg1, & QString_regSrc ) )
	{
		*pui_memCell = i_memReg | compileArgRegDst ( QString_regDst ) | compileArgRegSrc ( QString_regSrc );
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze::compileArgMemReg ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_mem, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );

	QString QString_regDst;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	*pui_memCell = i_mem | compileArgRegDst ( QString_regDst );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze::compileArgRegDst ( QString QString_regDst )
{
	return ( this->QMap_reg [ QString_regDst ] & 0xF ) << 8;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze::compileArgRegSrc ( QString QString_regSrc )
{
	return ( this->QMap_reg [ QString_regSrc ] & 0xF ) << 4;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze::compileArgConst ( int i_const )
{
	return i_const & 0xFF;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze::compileArgMAddr ( int i_addr )
{
	return i_addr & 0xFF;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze::compileArgPAddr ( int i_addr )
{
	return i_addr & 0xFF;
}

/**
 *****************************************************************************************************************************
 */
