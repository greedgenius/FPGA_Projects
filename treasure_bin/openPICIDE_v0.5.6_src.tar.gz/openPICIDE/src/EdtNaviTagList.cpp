/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "EdtNaviTagList.h"

#include <QtAlgorithms>

/**
 *****************************************************************************************************************************
 */

QStringList EdtNaviTagList::getCmdList ( void )
{
	QStringList QStringList_cmd;
	
	QStringList_cmd

		<< "^*\\\\navHw"
		<< "^*\\\\navConst"
		<< "^*\\\\navSep"
		<< "^*\\\\navGrpBegin"
		<< "^*\\\\navGrpEnd"

		<< "^*\\\\navHw\\s+\".*\""
		<< "^*\\\\navHw\\s+\\S+\\s*"
		
		<< "^*\\\\navConst\\s+\".*\""
		<< "^*\\\\navConst\\s+\\S+\\s*"
		
		<< "^*\\\\navSep\\s+\".*\""
		<< "^*\\\\navSep\\s+\\S+\\s*"
		
		<< "^*\\\\navGrpBegin\\s+\".*\""
		<< "^*\\\\navGrpBegin\\s+\\S+\\s*"
		
		<< "^*\\\\navGrpEnd";
		
	return QStringList_cmd;
}

/**
 *****************************************************************************************************************************
 */

EdtNaviTagList::EdtNaviTagList ()
{
}

/**
 *****************************************************************************************************************************
 */

EdtNaviTagList::~EdtNaviTagList ()
{
	this->clear();
}

/**
 *****************************************************************************************************************************
 */

QRegExp EdtNaviTagList::getRegExp ( void )
{
	QString QString_regExp;
	
	QString_regExp  = "^;-\\S+\\s*";
	QString_regExp += "|^;\\+\\S+\\s*";
	
	QString_regExp += "|^\\S+:";
	
	QString_regExp += "|^*\\\\navHw\\s+\".*\"";
	QString_regExp += "|^*\\\\navHw\\s+\\S+\\s*";
	
	QString_regExp += "|^*\\\\navConst\\s+\".*\"";
	QString_regExp += "|^*\\\\navConst\\s+\\S+\\s*";
	
	QString_regExp += "|^*\\\\navSep\\s+\".*\"";
	QString_regExp += "|^*\\\\navSep\\s+\\S+\\s*";
	
	QString_regExp += "|^*\\\\navGrpBegin\\s+\".*\"";
	QString_regExp += "|^*\\\\navGrpBegin\\s+\\S+\\s*";
	
	QString_regExp += "|^*\\\\navGrpEnd";
	
	QRegExp QRegExp_tags ( QString_regExp, Qt::CaseInsensitive );
	
	return QRegExp_tags;
}

/**
 *****************************************************************************************************************************
 */

void EdtNaviTagList::addTag ( QString QString_tag )
{
// 	qDebug() << QString_tag;
	
	// Check for constants
	if ( QString_tag.contains ( QRegExp ( "^;-\\S+", Qt::CaseInsensitive ) ) )
	{
		QPairTag_t QPair_tag;

		// Setup tag info
		QPair_tag.second.eTagType    = eTagTypeConst;
		QPair_tag.second.QString_ref = QString_tag;
		
		// Setup label
		QString_tag.remove ( 0, 2 );
		
		QPair_tag.first  = QString_tag;
		
		this->QListTags_doc.append ( QPair_tag );
	}
	else if ( QString_tag.contains ( QRegExp ( "^*\\\\navConst\\s+\\S+", Qt::CaseInsensitive ) ) )
	{
		QPairTag_t QPair_tag;

		// Setup tag info
		QPair_tag.second.eTagType    = eTagTypeConst;
		QPair_tag.second.QString_ref = QString_tag;
		
		// Setup label
		QString_tag.remove ( QRegExp ( "^*\\\\navConst\\s+", Qt::CaseInsensitive ) );
		QString_tag.remove ( QRegExp ( "^\"", Qt::CaseInsensitive ) );
		QString_tag.remove ( QRegExp ( "\"$", Qt::CaseInsensitive ) );

		QPair_tag.first  = QString_tag;
		
		this->QListTags_doc.append ( QPair_tag );
	}
	
	// Check for hardware
	else if ( QString_tag.contains ( QRegExp ( "^*\\\\navHw\\s+\\S+", Qt::CaseInsensitive ) ) )
	{
		QPairTag_t QPair_tag;

		// Setup tag info
		QPair_tag.second.eTagType    = eTagTypeHw;
		QPair_tag.second.QString_ref = QString_tag;
		
		// Setup label
		QString_tag.remove ( QRegExp ( "^*\\\\navHw\\s+", Qt::CaseInsensitive ) );
		QString_tag.remove ( QRegExp ( "^\"", Qt::CaseInsensitive ) );
		QString_tag.remove ( QRegExp ( "\"$", Qt::CaseInsensitive ) );
		
		QPair_tag.first  = QString_tag;
		
		this->QListTags_doc.append ( QPair_tag );
	}
	
	// Check for separator
	else if ( QString_tag.contains ( QRegExp ( "^*\\\\navSep\\s+\\S+", Qt::CaseInsensitive ) ) )
	{
		QPairTag_t QPair_tag;

		// Setup tag info
		QPair_tag.second.eTagType    = eTagTypeSep;
		QPair_tag.second.QString_ref = QString_tag;
		
		// Setup label
		QString_tag.remove ( QRegExp ( "^*\\\\navSep\\s+", Qt::CaseInsensitive ) );
		QString_tag.remove ( QRegExp ( "^\"", Qt::CaseInsensitive ) );
		QString_tag.remove ( QRegExp ( "\"$", Qt::CaseInsensitive ) );

		QPair_tag.first  = QString_tag;
		
		this->QListTags_doc.append ( QPair_tag );
	}
	else if ( QString_tag.contains ( QRegExp ( "^;\\+\\S+" ) ) )
	{
		QPairTag_t QPair_tag;

		// Setup tag info
		QPair_tag.second.eTagType    = eTagTypeSep;
		QPair_tag.second.QString_ref = QString_tag;
		
		// Setup label
		QString_tag.remove ( 0, 2 );
		
		QPair_tag.first  = QString_tag;
		
		this->QListTags_doc.append ( QPair_tag );
	}
	
	// Check for references
	else if ( QString_tag.contains ( QRegExp ( "^\\S+:" ) ) )
	{
		QPairTag_t QPair_tag;

		// Setup tag info
		QPair_tag.second.eTagType    = eTagTypeRef;
		QPair_tag.second.QString_ref = QString_tag;
		
		// Setup label
		QPair_tag.first  = QString_tag;
		
		this->QListTags_doc.append ( QPair_tag );
	}
	
	// Check for groups
	else if ( QString_tag.contains ( QRegExp ( "^*\\\\navGrpBegin\\s+\\S+", Qt::CaseInsensitive ) ) )
	{
		QPairTag_t QPair_tag;

		// Setup tag info
		QPair_tag.second.eTagType    = eTagTypeGrpBegin;
		QPair_tag.second.QString_ref = QString_tag;
		
		// Setup label
		QString_tag.remove ( QRegExp ( "^*\\\\navGrpBegin\\s+", Qt::CaseInsensitive ) );
		QString_tag.remove ( QRegExp ( "^\"", Qt::CaseInsensitive ) );
		QString_tag.remove ( QRegExp ( "\"$", Qt::CaseInsensitive ) );

		QPair_tag.first  = QString_tag;
		
		this->QListTags_doc.append ( QPair_tag );
	}
	else if ( QString_tag.contains ( QRegExp ( "^*\\\\navGrpEnd", Qt::CaseInsensitive ) ) )
	{
		QPairTag_t QPair_tag;

		// Setup tag info
		QPair_tag.second.eTagType    = eTagTypeGrpEnd;
		QPair_tag.second.QString_ref = QString_tag;
		
		// Setup label
		QString_tag.remove ( QRegExp ( "^*\\\\navGrpEnd", Qt::CaseInsensitive ) );

		QPair_tag.first  = QString_tag;
		
		this->QListTags_doc.append ( QPair_tag );
	}
}

/**
 *****************************************************************************************************************************
 */

void EdtNaviTagList::clear ( void )
{
	this->QListTags_doc.clear();
	this->QListTags_asc.clear();
	this->QListTags_desc.clear();
}

/**
 *****************************************************************************************************************************
 */

void EdtNaviTagList::sort ( void )
{
	this->QListTags_asc  = this->QListTags_doc;
	this->QListTags_desc = this->QListTags_doc;
	
	qSort ( this->QListTags_asc.begin(),  this->QListTags_asc.end(),  sortPairAsc );
	qSort ( this->QListTags_desc.begin(), this->QListTags_desc.end(), sortPairDesc );
}

/**
 *****************************************************************************************************************************
 */

bool EdtNaviTagList::sortPairAsc ( const QPairTag_t & QPairTag_tag1, const QPairTag_t & QPairTag_tag2 )
{
	if ( QPairTag_tag1.first.toLower() > QPairTag_tag2.first.toLower() )
		return FALSE;
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool EdtNaviTagList::sortPairDesc ( const QPairTag_t & QPairTag_tag1, const QPairTag_t & QPairTag_tag2 )
{
	if ( QPairTag_tag1.first.toLower() < QPairTag_tag2.first.toLower() )
		return FALSE;
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */
		