/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "EdtHlpIndex.h"

/**
 *****************************************************************************************************************************
 */

EdtHlpIndex::EdtHlpIndex ( QHelpEngine * pQHelpEngine, QWidget * pQWidget_parent )  : QWidget ( pQWidget_parent )
{
	QVBoxLayout * pQVBoxLayout_main = new QVBoxLayout ( this );
	{
		this->pQTabWidget = new QTabWidget ( this );
		{
			this->pQTabWidget->addTab ( this->setupTabPageContent ( pQHelpEngine ), QObject::tr ( "Content" ) );
			this->pQTabWidget->addTab ( this->setupTabPageIndex ( pQHelpEngine ),   QObject::tr ( "Index" ) );

			pQVBoxLayout_main->addWidget ( this->pQTabWidget );
		}
	}

	connect (
		pQHelpEngine->contentWidget(), 
		SIGNAL ( linkActivated ( const QUrl & ) ), 
		this, 
		SLOT ( setLinkActivated ( const QUrl & ) ) 
	);

	connect (
		pQHelpEngine->indexWidget(), 
		SIGNAL ( linkActivated ( const QUrl &, const QString & ) ), 
		this, 
		SLOT ( setLinkActivated ( const QUrl &, const QString & ) ) 
	);

	connect (
		pQHelpEngine->indexWidget(), 
		SIGNAL ( linksActivated ( const QMap<QString, QUrl> &, const QString & ) ), 
		this, 
		SLOT ( topicSetupList ( const QMap<QString, QUrl> &, const QString & ) ) 
	);

	QWidget::setLayout ( pQVBoxLayout_main );
}

/**
 *****************************************************************************************************************************
 */

QWidget * EdtHlpIndex::setupTabPageContent ( QHelpEngine * pQHelpEngine )
{
	QWidget * pQWidget = new QWidget ( this );
	{
		QVBoxLayout * pQVBoxLayout = new QVBoxLayout ( this );
		{
			pQVBoxLayout->addWidget ( pQHelpEngine->contentWidget() );
		}
		pQWidget->setLayout ( pQVBoxLayout );
	}
	return pQWidget;
}

/**
 *****************************************************************************************************************************
 */

QWidget * EdtHlpIndex::setupTabPageIndex ( QHelpEngine * pQHelpEngine )
{
	QWidget * pQWidget = new QWidget ( this );
	{
		QVBoxLayout * pQVBoxLayout = new QVBoxLayout ( this );
		{
			QHBoxLayout * pQHBoxLayout = new QHBoxLayout ( this );
			{
				QLabel * pQLabel = new QLabel ( QObject::tr ( "Filter:" ), this );
			
				this->pQLineEdit_filter = new QLineEdit;
				{
					connect (
						this->pQLineEdit_filter,
						SIGNAL ( textChanged ( QString ) ),
						pQHelpEngine->indexWidget(),
						SLOT ( filterIndices ( QString ) )
					);
				}
				pQHBoxLayout->addWidget ( pQLabel );
				pQHBoxLayout->addWidget ( this->pQLineEdit_filter );
			}

			this->pQWidget_selTopic = new QWidget;
			{
				this->pQWidget_selTopic->setVisible ( FALSE );
				
				QVBoxLayout * pQVBoxLayout_topic = new QVBoxLayout;
				{
					this->pQLabel_topic = new QLabel;
					{
					}

					this->pQTreeView_topic = new QTreeView ( this );
					{
						this->pQStandardItemModel = new QStandardItemModel ( this );
						
						this->pQTreeView_topic->setModel ( this->pQStandardItemModel );
						this->pQTreeView_topic->setRootIsDecorated ( FALSE );
						this->pQTreeView_topic->setAlternatingRowColors ( TRUE );
						this->pQTreeView_topic->setHeaderHidden ( TRUE );
	// 					this->pQTreeView_topic->setH

						connect ( 
							this->pQTreeView_topic, 
							SIGNAL ( clicked ( QModelIndex ) ), 
							this, 
							SLOT ( topicSelected ( QModelIndex ) )
						);
						connect ( 
							this->pQTreeView_topic, 
							SIGNAL ( doubleClicked ( QModelIndex ) ), 
							this, 
							SLOT ( topicSelected ( QModelIndex ) )
						);
					}
					pQVBoxLayout_topic->addWidget ( this->pQLabel_topic );
					pQVBoxLayout_topic->addWidget ( this->pQTreeView_topic );
				}
				this->pQWidget_selTopic->setMaximumHeight ( 100 );
				this->pQWidget_selTopic->setLayout ( pQVBoxLayout_topic );
			}
			pQVBoxLayout->addLayout ( pQHBoxLayout );
			pQVBoxLayout->addWidget ( pQHelpEngine->indexWidget() );
			pQVBoxLayout->addWidget ( this->pQWidget_selTopic );
		}
		pQWidget->setLayout ( pQVBoxLayout );
	}
	return pQWidget;
}

/**
 *****************************************************************************************************************************
 */
	
void EdtHlpIndex::setLinkActivated ( const QUrl & QUrl_src )
{
	emit linkActivated ( QUrl_src );
}

/**
 *****************************************************************************************************************************
 */

void EdtHlpIndex::setLinkActivated ( const QUrl & QUrl_src, const QString & QString_keyword )
{
	this->pQWidget_selTopic->setVisible ( FALSE );

	emit linkActivated ( QUrl_src );
}

/**
 *****************************************************************************************************************************
 */

void EdtHlpIndex::topicSetupList ( const QMap<QString, QUrl> & QMapQStringQUrl_src, const QString & QString_keyword )
{
	this->pQWidget_selTopic->setVisible ( TRUE );

	this->pQLabel_topic->setText ( tr ( "Choose a topic for <b>%1</b>:" ).arg ( QString_keyword ) );
	
	// Setup topic list
	{
		this->pQStandardItemModel->clear ();
	
		this->pQStandardItemModel->setColumnCount ( 1 );
		this->pQStandardItemModel->setRowCount ( 0 );

		QMap<QString, QUrl>::const_iterator QMapIterator = QMapQStringQUrl_src.constBegin ();
	
		while ( QMapIterator != QMapQStringQUrl_src.constEnd () )
		{
			QStandardItem * pQStandardItem_topic = new QStandardItem;
			{
				pQStandardItem_topic->setEditable ( FALSE );
				pQStandardItem_topic->setText ( QMapIterator.key() );
			}		

			this->pQStandardItemModel->appendRow ( pQStandardItem_topic );
			
			++QMapIterator;
		}
	}
	
	this->QMapQStringQUrl_src = QMapQStringQUrl_src;
}

/**
 *****************************************************************************************************************************
 */

void EdtHlpIndex::topicSelected ( QModelIndex QModelIndex_clicked )
{
	int i_selRow = QModelIndex_clicked.row();

	// Get selection
	QUrl QUrl_selection;
	{
		if ( i_selRow >= 0 )
		{
			QString QString_key = this->pQStandardItemModel->item ( i_selRow, 0 )->text();

			QUrl_selection = this->QMapQStringQUrl_src.value ( QString_key );

		}
	}
	
	emit linkActivated ( QUrl_selection );
}

/**
 *****************************************************************************************************************************
 */

	
	