/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "SetApp.h"
#include "SetAppRdWr.h"

#include <QWindowsStyle>
#include <QWindowsXPStyle>

/**
 *****************************************************************************************************************************
 */

SetApp::SetApp ()
{
	this->setStyle ();
	
	this->sSup.eChkIval      		= eChkIvalDaily;
	this->sSup.QString_serNo		= this->genRandomSerNo ();
	this->sSup.QString_appVer		= "0.5.6";
	this->sSup.QString_platform		= this->getPlatform ();
	this->sSup.QString_updateServer 	= "http://update.openpicide.org";
	this->sSup.b_showStartInfo		= TRUE;
	this->sSup.b_showHlpCtrlOnRightSide	= TRUE;
	
	// Get help path
	QString QString_hlpCollectionPath;
	{
		// Get installation environment location
		QFileInfo QFileInfo_app ( QCoreApplication::applicationFilePath () );
	
		while ( QFileInfo_app.isSymLink() )
			QFileInfo_app.setFile ( QFileInfo_app.symLinkTarget () );

		QString_hlpCollectionPath = QFileInfo_app.path ();

		// Get help file location
		QFileInfo_app.setFile ( QString_hlpCollectionPath + "/../hlp/hlpCollection.qhc" );
		
		if ( ! QFileInfo_app.exists() )
			QFileInfo_app.setFile ( QString_hlpCollectionPath + "/../../hlp/hlpCollection.qhc" );
		
		QString_hlpCollectionPath = QFileInfo_app.filePath();
	}

	this->sSup.QString_hlpCollectionFile	= QString_hlpCollectionPath;

	this->sGui.i_mainWindowWidth    	= 800;
	this->sGui.i_mainWindowHeight   	= 600;
	this->sGui.i_mainWindowX        	= 0;
	this->sGui.i_mainWindowY        	= 0;
	this->sGui.i_iconSize           	= 22;
	this->sGui.i_style	           	= 0;
	
	// Preset edit page settings
	this->sEdt.b_dynamicWordWrapEn  	= FALSE;
	this->sEdt.i_tabIndent          	= 8;
	this->sEdt.QColor_bgCursor      	= QColor ( 0xEEF6FF );
	this->sEdt.QColor_bgHighlight   	= QColor ( 0xF5CACA );

	this->sEdt.QFont_std = QFont ( this->getNominalFont (), 10, 0, 0 );

	this->sEdt.QTextCharFormat_cmd.setFontWeight ( QFont::Bold );
	this->sEdt.QTextCharFormat_cmd.setForeground ( Qt::black );

	this->sEdt.QTextCharFormat_directive.setFontWeight ( QFont::Bold );
	this->sEdt.QTextCharFormat_directive.setForeground ( Qt::darkGreen );

	this->sEdt.QTextCharFormat_hw.setFontWeight ( QFont::Bold );
	this->sEdt.QTextCharFormat_hw.setForeground ( Qt::darkBlue );

	this->sEdt.QTextCharFormat_decNumber.setFontWeight ( QFont::Bold );
	this->sEdt.QTextCharFormat_decNumber.setForeground ( Qt::blue );

	this->sEdt.QTextCharFormat_hexNumber.setFontWeight ( QFont::Bold );
	this->sEdt.QTextCharFormat_hexNumber.setForeground ( Qt::darkMagenta );

	this->sEdt.QTextCharFormat_octNumber.setFontWeight ( QFont::Bold );
	this->sEdt.QTextCharFormat_octNumber.setForeground ( Qt::darkYellow );

	this->sEdt.QTextCharFormat_comment.setForeground ( Qt::darkGray );

	this->sEdt.QTextCharFormat_separator.setForeground ( Qt::darkRed );

	this->sEdt.QTextCharFormat_fct.setFontWeight ( QFont::Bold );
	this->sEdt.QTextCharFormat_fct.setForeground ( Qt::black );
	
	this->sEdt.QTextCharFormat_doc.setForeground ( Qt::blue );
	
	this->sEdt.QTextCharFormat_navi.setFontWeight ( QFont::Bold );
	this->sEdt.QTextCharFormat_navi.setForeground ( Qt::darkGray );

	this->read ();
}

/**
 *****************************************************************************************************************************
 */

void SetApp::read ( void )
{
	SetAppRdWr SetAppRdWr_rd;
	
	SetAppRdWr_rd.readSet ( this );
	
	this->checkSerNo ();
}

/**
 *****************************************************************************************************************************
 */

void SetApp::save ( void )
{
	SetAppRdWr SetAppRdWr_wr;
	
	SetAppRdWr_wr.saveSet ( this );
}

/**
 *****************************************************************************************************************************
 */

void SetApp::setDirty ( void )
{
	this->save ();
}

/**
 *****************************************************************************************************************************
 */

QString SetApp::getPlatform ( void )
{
#ifdef Q_WS_X11
	return QString ( "Linux" );
#endif

#ifdef Q_WS_MAC
	return QString ( "Mac" );
#endif

#ifdef Q_WS_QWS
	return QString ( "Embedded Linux" );
#endif

#ifdef Q_WS_WIN
	return QString ( "Windows" );
#endif

	return QString ( "Unknown" );
}

/**
 *****************************************************************************************************************************
 */

QString SetApp::genRandomSerNo ( void )
{
	QString QString_serNo = "R";
	
	qsrand ( QDateTime::currentDateTime().toTime_t () );
	
	return "R" + QString::number ( qrand() );
}

/**
 *****************************************************************************************************************************
 */

void SetApp::checkSerNo ( void )
{
	if ( this->sSup.QString_serNo != "R5056715081186278907" )
		return;
		
	this->sSup.QString_serNo = this->genRandomSerNo ();
	
	this->setDirty ();
}

/**
 *****************************************************************************************************************************
 */

QString SetApp::getNominalFont ( void )
{
#ifdef Q_WS_X11
	return QString ( "Liberation Mono" );
#endif

#ifdef Q_WS_MAC
	return QString ( "Liberation Mono" );
#endif

#ifdef Q_WS_QWS
	return QString ( "Liberation Mono" );
#endif

#ifdef Q_WS_WIN
	return QString ( "Courier New" );
#endif

	return QString ( "Liberation Mono" );
}

/**
 *****************************************************************************************************************************
 */

void SetApp::setStyle ( void )
{
// #ifdef Q_WS_X11
// 
// #endif

// #ifdef Q_WS_MAC
// 
// #endif

// #ifdef Q_WS_QWS
// 
// #endif

#ifdef Q_WS_WIN
// 	QApplication::setStyle(new QWindowsStyle);
	QApplication::setStyle(new QWindowsVistaStyle);
// QApplication::setStyle(new QWindowsXPStyle);

#endif
}

/**
 *****************************************************************************************************************************
 */


