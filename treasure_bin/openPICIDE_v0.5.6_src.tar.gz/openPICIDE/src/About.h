/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef About_H
#define About_H


#include <QtGui>
#include <QtCore>

#include "SetApp.h"

/**
 *****************************************************************************************************************************
 *
 *	\brief About dialog class.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 * History
 *
 * 2010-03-06
 *	Changed version from const to given variable
 *
 *****************************************************************************************************************************
 */

class About : public QDialog
{

                Q_OBJECT

        public:
		/**
		*************************************************************************************************************
		* Constructor. Sets up dialog.
		*
		* \param	pQWidgetParent		Pointer to the parent widget
		*************************************************************************************************************
		*/
                About ( SetApp * pSetApp, QWidget * pQWidgetParent = 0 );

        private:

		/**
		*************************************************************************************************************
		* Sets up the widget for the "About" tab page
		* 
		* \retval	QWidget*	Tab page widget
		*************************************************************************************************************
		*/
                QWidget * tabPageAbout ( void );

		/**
		*************************************************************************************************************
		* Sets up the widget for the "License" tab page
		* 
		* \retval	QWidget*	Tab page widget
		*************************************************************************************************************
		*/
                QWidget * tabPageLicense ( void );

		/**
		*************************************************************************************************************
		* Sets up the widget for the "Thanks" tab page
		* 
		* \retval	QWidget*	Tab page widget
		*************************************************************************************************************
		*/
                QWidget * tabPageThanks ( void );

		/**
		*************************************************************************************************************
		* Sets up the widget for the "Authors" tab page
		* 
		* \retval	QWidget*	Tab page widget
		*************************************************************************************************************
		*/
                QWidget * tabPageAuthors ( void );

		/**
		*************************************************************************************************************
		* Adds author to the "Authors" tab page widget
		* \param	QString_name	Name of the author
		* \param	QString_email	Email of the author
		* \param	QString_job	Job withing openPICIDE project done by author
		* \retval	QVBoxLayout*	Layout containing author elements
		*************************************************************************************************************
		*/
		QVBoxLayout * addAuthor ( QString QString_name, QString QString_email, QString QString_job );

		/**
		*************************************************************************************************************
		* Adds author to the "Authors" tab page widget
		* \param	QString_name	Name thanks to
		* \param	QString_text	Thanks text
		* \param	QString_web	Email address
		* \retval	QString_url	Web address
		*************************************************************************************************************
		*/
		QVBoxLayout * addThanksEntry ( QString QString_name, QString QString_text, QString QString_email, QString QString_url );

	private slots:

		/**
		*************************************************************************************************************
		* Opens the given url. The slot method has is connected to text widgets containing clickable urls.
		* 
		* \param	QString_link	Url to open
		*************************************************************************************************************
		*/
		void openUrl ( QString QString_link );
};

#endif
