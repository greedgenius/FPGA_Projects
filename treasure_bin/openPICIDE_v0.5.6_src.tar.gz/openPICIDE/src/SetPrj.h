/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef SetPrj_H
#define SetPrj_H


#include <QtCore>

/**
 *****************************************************************************************************************************
 *
 *	\brief Set class
 *
 *      Contains project settings.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2010-03-26
 *	\version	0.1.0
 *
 *	Change log
 *
 *	2010-03-26
 *		Initialized
 *
 *****************************************************************************************************************************
 */

class SetPrj
{
	public:

		SetPrj ();

		/// Marks settings as dirty
		void setDirty ( void );

		// Helpers
		
		/// Gets relative file path to project dir path from given absolute file path
		/// \param QString_absoluteFilePath	Absolute file path
		QString getRelativeFilePath ( QString QString_absoluteFilePath );

		/// Gets absolute file path from given relative file path
		/// \param QString_relativeFilePath	Relative file path
		QString getAbsoluteFilePath ( QString QString_relativeFilePath );

		// Set

		/// Structure, containing project path
		struct sPrj_t
		{
			/// Project file.
			QString  QString_prjFile;
		
			/// Project path.
			QString  QString_prjPath;
			
			/// Project valid status
			bool b_prjVld;
		} sPrj;
		
		/// Structure, containing settings for versioning.
		struct sVer_t
		{
			QString QString_title;
			QString QString_version;
			QString QString_comment;
		} sVer;

		/// Structure, containing type and settings for processor.
		struct sPic_t
		{
			/// Processor type
			QString QString_picType;

			/// A void pointer to processor specific settings.
			void * pv_picSet;

		} sPic;

		/// Structure, source settings.
		struct sSrc_t
		{
			/// Source file list
			QStringList QStringList_srcFiles;

		} sSrc;

		struct sEdt_t
		{
			/// Loaded file from editor
			QStringList QStringList_loadedFiles;
		} sEdt;
		
		
		/// Opens an existing project. The location may be given by argument or, if argument is emtpy, get
		/// from dialog.
		/// \param QString_prjFilePath	Project file path
		bool openPrj ( QString QString_prjFilePath );

		/// Closes the loaded project
		bool closePrj ( void );
		
	private:
		
		void showErrMsg ( QString QString_errMsg );

		/// Reads settings from project file
		bool read ( void );
		
		/// Write settings to project file
		bool save ( void );
		
		bool chkPrjPathVld ( void );
		
};

#endif
 
 
