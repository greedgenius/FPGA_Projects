/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicEdtInteger.h"

/**
 *****************************************************************************************************************************
 */

PicEdtInteger::PicEdtInteger ( QLineEdit * pQLineEdit_parent ) : QLineEdit ( pQLineEdit_parent )
{
	this->QColor_bgInvalid     = QColor ( 0xff7d7d );
	this->QColor_bgValid       = Qt::white;
	this->QColor_fgHighlighted = Qt::red;
	this->QColor_fgNormal      = Qt::black;

	this->i_maxVal = 0xFF;
	this->i_maxLen = 2;
	this->i_base   = 16;
	this->setBase ( 16 );

	QLineEdit::setText ( QString ( "00" ) );
	QLineEdit::setMaxLength ( 2 );
	QLineEdit::setFrame ( FALSE );
	QLineEdit::setAlignment ( Qt::AlignHCenter | Qt::AlignVCenter );
	QLineEdit::setAutoFillBackground ( TRUE );

	this->setHighlighted ( FALSE );

	connect ( this, SIGNAL ( textChanged ( QString ) ), this, SLOT ( checkValue ( QString ) ) );
	connect ( this, SIGNAL ( editingFinished () ), this, SLOT ( keepFocus () ) );
}

/**
 *****************************************************************************************************************************
 */

void PicEdtInteger::setBase ( int i_base )
{
	int i_value;

	if ( QLineEdit::text().isEmpty () )
	{
		this->i_base = i_base;
		return;
	}

	i_value = QLineEdit::text().toInt ( 0, this->i_base );

	this->i_base = i_base;

	this->i_maxLen = QString ( "%1" ).arg ( this->i_maxVal, 0, this->i_base ).length ();

	QLineEdit::setMaxLength ( this->i_maxLen );
	QLineEdit::setText ( QString ( "%1" ).arg ( i_value, this->i_maxLen, this->i_base, QChar ( '0' ) ).toUpper() );

	int i_width = QFontMetrics ( QLineEdit::font() ).width ( "0" ) * ( this->i_maxLen + 1 );

	QLineEdit::resize ( i_width, QLineEdit::size ().height () );
	QLineEdit::setMinimumWidth ( i_width );
	QLineEdit::setMaximumWidth ( i_width );
}

/**
 *****************************************************************************************************************************
 */

bool PicEdtInteger::checkValue ( QString QString_value )
{
	int i_value;
	bool b_success = FALSE;

	i_value = QString_value.toInt ( & b_success, this->i_base );

	if ( ( ! b_success ) || ( i_value > this->i_maxVal ) )
	{
		this->setValid ( FALSE );
		return FALSE;
	}

	this->setValid ( TRUE );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

void PicEdtInteger::keepFocus ( void )
{
	if ( ! this->checkValue ( QLineEdit::text() ) )
	{
		this->setFocus ( );
		return;
	}

	// Convert hex to upper case
	int i_value;

	if ( this->getValue ( & i_value ) )
		this->setValue ( i_value );

	emit valueChanged ( i_value );
}

/**
 *****************************************************************************************************************************
 */

void PicEdtInteger::setValid ( bool b_valid )
{
	QPalette QPalette_actual = QLineEdit::palette();

	if ( b_valid )
	{
		QPalette_actual.setColor ( QPalette::Active,   QPalette::Base, this->QColor_bgValid );
		QPalette_actual.setColor ( QPalette::Inactive, QPalette::Base, this->QColor_bgValid );
	}
	else
	{
		QPalette_actual.setColor ( QPalette::Active, QPalette::Base, this->QColor_bgInvalid );
		QPalette_actual.setColor ( QPalette::Inactive, QPalette::Base, this->QColor_bgInvalid );
	}

	QLineEdit::setPalette ( QPalette_actual );
}

/**
 *****************************************************************************************************************************
 */

bool PicEdtInteger::setValue ( int i_value )
{
	if ( i_value > this->i_maxVal )
		return FALSE;

	QLineEdit::setText ( QString ( "%1" ).arg ( i_value, this->i_maxLen, this->i_base, QChar ( '0' ) ).toUpper() );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicEdtInteger::getValue ( int * pi_value )
{
	bool b_valid = FALSE;

	*pi_value = QLineEdit::text().toInt ( & b_valid, this->i_base );

	return b_valid;
}

/**
 *****************************************************************************************************************************
 */

void PicEdtInteger::setHighlighted ( bool b_highlighted )
{
	QPalette QPalette_actual = QLineEdit::palette();

	if ( b_highlighted )
	{
		QPalette_actual.setColor ( QPalette::Active,   QPalette::Text, this->QColor_fgHighlighted );
		QPalette_actual.setColor ( QPalette::Inactive, QPalette::Text, this->QColor_fgHighlighted );
	}
	else
	{
		QPalette_actual.setColor ( QPalette::Active,   QPalette::Text, this->QColor_fgNormal );
		QPalette_actual.setColor ( QPalette::Inactive, QPalette::Text, this->QColor_fgNormal );
	}

	QLineEdit::setPalette ( QPalette_actual );
}

/**
 *****************************************************************************************************************************
 */

void PicEdtInteger::setMaxValue ( int i_value )
{
	this->i_maxVal = i_value;
}

/**
 *****************************************************************************************************************************
 */

void PicEdtInteger::setContentsMargins ( int i_left, int i_top, int i_right, int i_bottom )
{
	QLineEdit::setContentsMargins ( 0, 0, 0, 0 );
}
		
/**
 *****************************************************************************************************************************
 */

// void PicEdtInteger::setContentsMargins ( const QMargins & QMargins_margins )
// {
// 	QLineEdit::setContentsMargins ( 0, 0, 0, 0 );
// }

/**
 *****************************************************************************************************************************
 */















