/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PICEDTBITFIELD8_H
#define PICEDTBITFIELD8_H

#include <QtCore>
#include <QtGui>

#include "PicEdtBit.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Simulator bit field
 *
 *
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class PicEdtBitField8 : public QWidget
{
		Q_OBJECT

	public:

		/// Constructor
		/// \param pQWidget_parent		Pointer to parent widget
		PicEdtBitField8 ( QWidget * pQWidget_parent = 0 );

		/// Sets given value
		/// \param i_value		Value
		void setValue ( int i_value );

		/// Gets value
		int getValue ( void );

		/// Sets integer highlighted
		/// \param b_highlighted		True, if highlighted, false, if normal mode
		void setHighlighted ( bool b_highlighted );

	public slots:

		/// Sets value changed. Will be called by PicEdtBit
		void setValueChanged ( bool b_value );

	signals:

		/// Will be emitted, if the value will be changed
		/// \param b_value		Value
		void valueChanged ( int i_value );

	protected:

		/// Handles mouse press event from gui
		void mousePressEvent ( QMouseEvent * pQMouseEvent );

	private:

		struct sBitFieldValue_t
		{
			PicEdtBit PicEdtBit_value;

			sBitFieldValue_t * psBitFieldValue_next;
		};

		sBitFieldValue_t * psBitFieldValue_start;
		sBitFieldValue_t * psBitFieldValue_stop;

		void toggleValue ( void );

};

#endif
