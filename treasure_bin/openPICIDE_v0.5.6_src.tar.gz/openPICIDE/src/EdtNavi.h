/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef EDTNAVI_H
#define EDTNAVI_H

#include <QtCore>
#include <QtGui>

#include "EdtNaviTreeWidget.h"
#include "EdtNaviTagList.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Tag browser widget.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *	Changelog
 *
 *	2009-08-30	Generated
 *	2009-10-02	Added tool tip to jump button
 *			Fixed losing of selecting during setTagList
 *
 *****************************************************************************************************************************
 */
class EdtNavi : public QWidget
{
		Q_OBJECT

	public:

		/// Constructor
		/// \param pQWidget_parent		Pointer to parent widget
		EdtNavi ( QWidget * pQWidget_parent = 0 );

		/// Sets tag list
		/// \param pQString_tagListName		Pointer to tag list name
		/// \param QString_tagListName		Pointer to tag list
		void setTagList ( QString QString_tagListName, EdtNaviTagList * pEdtNaviTagList );

		/// Clears tag list
		void clearTagList ( void );

	private:

		/// Holds sort mode gui element instance
		QComboBox * pQComboBox_sortMode;

		/// Holds tag browser tree widget instance
		EdtNaviTreeWidget * pEdtNaviTreeWidget_tagList;

		/// Holds tag list data model
		QStandardItemModel * pQStandardItemModel_tags;

		/// Tag list name
		QString QString_tagListName;

		/// Tag list
		EdtNaviTagList * pEdtNaviTagList;

		/// The selected tag to highlight
		QString QString_tagHighlighted;

		/// The selected tag
		QString QString_tagSelected;

		/// Pushbutton to jump back to highlighted tag
		QPushButton * pQPushButton_jumpBack;

	private slots:

		/// Selects a tag in list
		/// \param pQTreeWidgetItem_selected	
		/// \param i_column			
		void tagSelected    ( QTreeWidgetItem * pQTreeWidgetItem_selected, int i_column );

		/// Gets the highlighted tag from list
		/// \param pQTreeWidgetItem_selected	
		/// \param i_column			
		void tagHighlighted ( QTreeWidgetItem * pQTreeWidgetItem_selected, int i_column );

		/// Shows the tag list. Called, if the sort mode was changed
		void displayTagList ( int i_SortMode );

		/// Jumps to the highlighted tag. Will be called from \c pQPushButton_jumpBack.
		void jumpToHighlighted ( void );

	signals:

		/// Will be emited, if a tag was selected by double clicking
		/// \param QString_tabName	Tab name
		/// \param QString_tag		Tag name
		void selectTag ( QString QString_tabName, QString QString_tag );

		/// Signs that content changed
		/// \param pQWidget		Reference to itself
		void contentChanged ( QWidget * pQWidget );
};

#endif
