/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PROJECTDIALOGPAGEEDITOR_H
#define PROJECTDIALOGPAGEEDITOR_H

#include <QtGui>
#include <QtCore>

#include "SetApp.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Project dialog page class for editing editor settings.
 *
 *	The class provides a dialog page for editing the editor settings.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class SetDlgPgApp : public QWidget
{
		Q_OBJECT

	public:

		/// Constructor. Generates the editor dialog page layout.
		/// \param pSetApp_dlg	Reference to the dialog project settings
		/// \param pQWidgetParent	Reference to the parent widget.
		SetDlgPgApp ( SetApp * pSetApp_dlg, QWidget * pQWidgetParent = 0 );

		/// Initializes the copy of the settings from gui to dialog project settings.
		void getSet ( void );

	private:

		QColor getColor ( QColor QColor_preset );


		void   setBgColor ( QWidget * pQWidget, QColor QColor_bg );
		QColor getBgColor ( QWidget * pQWidget );

		/// Copies the settings from dialog project settings object
		/// to the gui.
		void setSet ( void );


		/// Gets font settings from gui
		void getSetFont ( int i_row, QTextCharFormat * pQTextCharFormat_font );

		/// Shows selected font
		void showFontSelection ( void );
		
	private slots:

		void getBgCursorColor ( void );
		void getBgHighlightColor ( void );
		void getFontColor ( const QModelIndex & QModelIndex_item );
		void setFontParameter ( QStandardItem * pQStandardItem );
		void hndlFontFamilySel ( const QString & QString_fontFamily );
		void hndlFontSizeSel ( const QString & QString_fontSize );

	// Common
	private:
		
		/// Reference to the dialog project settings
		SetApp * pSetApp_dlg;

		QFrame * setLine ( void );

	// Appearance
	private:
		
	// Editor
	private:
		
		struct sEdt_t
		{
			/// Widget for tab indent
			QSpinBox  * pQSpinBox_tabIndent;

			/// Widget for dynamic word wrap
			QCheckBox * pQCheckBox_dynamicWordWrap;

			QComboBox * pQComboBox_fontFamily;

			QComboBox * pQComboBox_fontSize;
		
			QPushButton * pQPushButton_bgCursor;
			
			QPushButton * pQPushButton_bgHighlight;
			
			QStandardItemModel QStandardItemModel_fonts;

			QTreeView * pQTreeView_fonts;

			QFontDatabase QFontDatabase_system;
		} sEdt;
		
		/// Sets up the appearance tab page
		/// \retval	QWidget		Tab page widget
		QWidget * edtSetupTabPage ( void );

		void edtGetSet ( void );
		
		/// Sets font settings to gui
		void edtSetFont ( QString QString_context, QTextCharFormat QTextCharFormat_font );
		
	// Support
	private:
		
		struct sSup_t
		{
			/// Widget for setting show start info
			QCheckBox * pQCheckBox_showStartInfo;
		
			/// Check interval
			QComboBox * pQComboBox_showHelpSide;

			/// Check interval
			QComboBox * pQComboBox_chkIval;
		} sSup;
		
		/// Setting up support tab page
		QWidget * supSetupTabPage ( void );
		
		void supGetSet ( void );

	private slots:
		
		/// Show support dialog
		void supViewSupportDlg ( void );
		
};

#endif
