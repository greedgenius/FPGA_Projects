/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef EdtNaviTagList_H
#define EdtNaviTagList_H


#include <QtCore>

/**
 *****************************************************************************************************************************
 *
 *	\brief EdtNaviTagList class.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 * History
 *
 * 2010-03-06
 *	Changed version from const to given variable
 *
 *****************************************************************************************************************************
 */

class EdtNaviTagList
{

        public:
		/**
		*************************************************************************************************************
		* Constructor. Sets up dialog.
		*
		* \param	pQWidgetParent		Pointer to the parent widget
		*************************************************************************************************************
		*/
                EdtNaviTagList ();
		
                ~EdtNaviTagList ();
		
		/// Returns command list
		/// \retval QStringList			Command list
		static QStringList getCmdList ( void );

		QRegExp getRegExp ( void );
		
		void addTag ( QString QString_tag );

		void clear ( void );
		
		enum eSortMode_t
		{
			eSortModeDoc,
			eSortModeAsc,
			eSortModeDesc
		};
		
		void sort ( void );
		
		enum eTagType_t
		{
			eTagTypeRef,
			eTagTypeHw,
			eTagTypeConst,
			eTagTypeSep,
			eTagTypeGrpBegin,
			eTagTypeGrpEnd
		};

		struct sTagInfo_t
		{
			eTagType_t eTagType;
			QString QString_ref;
		};
		
		typedef QPair<QString,sTagInfo_t> QPairTag_t;
		typedef QList<QPairTag_t> QListTags_t;
		
		QListTags_t QListTags_doc;
		QListTags_t QListTags_asc;
		QListTags_t QListTags_desc;
		
		
		
		
		
		
		
		
		QStringList QList_tags;
		
	// Sorting
	public:
		
		static bool sortPairAsc  ( const QPairTag_t & QPairTag_tag1, const QPairTag_t & QPairTag_tag2 );
		static bool sortPairDesc ( const QPairTag_t & QPairTag_tag1, const QPairTag_t & QPairTag_tag2 );

};

#endif
