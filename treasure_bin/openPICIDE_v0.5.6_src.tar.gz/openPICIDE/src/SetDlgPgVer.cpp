/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "SetDlgPgVer.h"

/**
 *****************************************************************************************************************************
 */

SetDlgPgVer::SetDlgPgVer ( SetPrj * pSetPrj_dlg, QWidget * pQWidgetParent ) : QWidget ( pQWidgetParent )
{
	this->pSetPrj_dlg = pSetPrj_dlg;

	// Files group box
	QGroupBox * pQGroupBox_files = new QGroupBox ( QObject::tr ( "Versioning" ) );
	{
		// Layout files group box
		QGridLayout * pQGridLayout_groupBox = new QGridLayout;
		{
			// Layout title
			{
				// Set label
				QLabel * pQLabel = new QLabel ( QObject::tr ( "Title:" ) );

				// Set spin box
				this->pQLineEdit_title = new QLineEdit();
				{
					this->pQLineEdit_title->setText ( this->pSetPrj_dlg->sVer.QString_title );
				}

				pQGridLayout_groupBox->addWidget ( pQLabel,                  0, 0, 1, 1 );
				pQGridLayout_groupBox->addWidget ( this->pQLineEdit_title  , 0, 1, 1, 1 );
			}

			// Layout version
			{
				// Set label
				QLabel * pQLabel = new QLabel ( QObject::tr ( "Version:" ) );

				// Set spin box
				this->pQLineEdit_version = new QLineEdit();
				{
					this->pQLineEdit_version->setText ( this->pSetPrj_dlg->sVer.QString_version );
				}

				pQGridLayout_groupBox->addWidget ( pQLabel,                  1, 0, 1, 1 );
				pQGridLayout_groupBox->addWidget ( this->pQLineEdit_version, 1, 1, 1, 1 );
			}

			// Layout commment
			{
				// Set label
				QLabel * pQLabel = new QLabel ( QObject::tr ( "Comment:" ) );

				// Set spin box
				this->pQTextEdit_comment = new QTextEdit();
				{
					this->pQTextEdit_comment->setText ( this->pSetPrj_dlg->sVer.QString_comment );
				}

				// Set layout
				pQGridLayout_groupBox->addWidget ( pQLabel,                  2, 0, 1, 1, Qt::AlignTop );
				pQGridLayout_groupBox->addWidget ( this->pQTextEdit_comment, 2, 1, 1, 1 );
			}

// 			pQGridLayout_groupBox->addItem ( new QSpacerItem ( 1, 1, QSizePolicy::Expanding, QSizePolicy::Minimum ), 0, 2, 1, 2 );
		}

		pQGroupBox_files->setLayout ( pQGridLayout_groupBox );
	}

	// Set Page Layout
	QVBoxLayout * pQVBoxLayout_page = new QVBoxLayout;
	pQVBoxLayout_page->addWidget ( pQGroupBox_files );
	setLayout ( pQVBoxLayout_page );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgVer::getSet ( void )
{
	this->pSetPrj_dlg->sVer.QString_title   = this->pQLineEdit_title->text ();
	this->pSetPrj_dlg->sVer.QString_version = this->pQLineEdit_version->text ();
	this->pSetPrj_dlg->sVer.QString_comment = this->pQTextEdit_comment->toPlainText ();
}

/**
 *****************************************************************************************************************************
 */
