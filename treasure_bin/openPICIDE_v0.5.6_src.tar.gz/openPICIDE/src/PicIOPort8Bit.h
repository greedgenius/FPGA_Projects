/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PicIOPort8Bit_H
#define PicIOPort8Bit_H

#include <QtCore>
#include <QtGui>

#include "PicIOCommon.h"
#include "PicEdtInteger.h"
#include "PicEdtBitField8.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Port widget.
 *
 *	The widget provides port capability.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class PicIOPort8Bit : public QWidget, public PicIOCommon
{
		Q_OBJECT

	public:

		/// Constructor.
		/// \param pQWidget_parent		Pointer to parent widget
		PicIOPort8Bit ( QWidget * pQWidget_parent = 0 );

		/// Gets value from port
		/// \param pi_value		Returned integer value
		/// \return bool		True, if value is valid, otherwise false
		bool getValue ( int * pi_value );

		/// Sets base.
		/// \param i_base		Integer base
		void setBase ( int i_base );

		/// Sets port address
		/// \param i_addr		Port address
		void setAddr ( int i_addr );

		/// Sets port address symbol
		/// \param QString_addrSymbol	Address symbol
		void setAddrSymbol ( QString QString_addrSymbol );

		/// Checks address
		/// \param i_value		Address to validate
		/// \return bool		True, if address matches, otherwise FALSE
		bool chkAddr ( int i_value );

		/// Sets given port direction
		/// \param eDirection		Direction
		bool setDirection ( PicIOCommon::eDirection_t eDirection );

		/// Checks port direction
		/// \param eDirection		Direction
		/// \retval bool		Given direction contained in set direction
		bool chkDirection ( PicIOCommon::eDirection_t eDirection );

		/// Clears highlighting
		void clearHighlighted ( void );

		/// Sets integer highlighted
		/// \param b_highlighted		True, if highlighted, false, if normal mode
		void setHighlighted ( bool b_highlighted );

		/// Clears all
		void clear ( void );

	signals:

		/// Request to close the widget
		/// \param pQWidget		Own widget
		void closeRequest ( QWidget * pQWidget );

	public slots:

		/// Sets given value to port
		/// \param i_value		Value
		void setValue ( int i_value );

		/// Closes the port
		void closePort ( void );

	private:

		/// Background color for highlighted value
		QColor QColor_bgHighlighted;

		/// Nominal background color
		QColor QColor_bgNormal;

		/// Widget to show address line
		QWidget * pQWidget_addr;

		/// Widget to show and edit address
		PicEdtInteger * pPicEdtInteger_addr;

		/// Widget to show and edit value
		PicEdtInteger * pPicEdtInteger_value;

		/// Widget to show and edit value as bit field
		PicEdtBitField8 * pPicEdtBitField8_value;

		/// Widget to show the substitute
		QLabel * pQLabel_addrSymbol;

		/// Widget to select the direction
		QComboBox * pQComboBox_direction;

};

#endif
