/*****************************************************************************************************************************
 *   Copyright (C) 2010 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "SupChkUpdate.h"

/**
 *****************************************************************************************************************************
 */

SupChkUpdate::SupChkUpdate ( QObject * pQObject_parent ) : QObject ( pQObject_parent )
{	
	this->pQHttp = new QHttp ( this );
	
	connect ( this->pQHttp,
	       SIGNAL ( requestFinished ( int, bool ) ),
	       this,
	       SLOT ( httpRequestFinished ( int, bool ) )
	);
}

/**
 *****************************************************************************************************************************
 */

void SupChkUpdate::cfgProxy ( QString QString_host, int i_port, QString QString_username, QString QString_password )
{	
	this->pQHttp->setProxy ( QString_host, i_port, QString_username, QString_password );
}

/**
 *****************************************************************************************************************************
 */

void SupChkUpdate::chkUpdate ( QString QString_curRelease, QString QString_serNo, QString QString_platform, bool b_quiet )
{
	QString QString_getDta;
	
	QString_getDta  = "release="   + QUrl::toPercentEncoding ( QString_curRelease );
	QString_getDta += "&serNo="    + QUrl::toPercentEncoding ( QString_serNo );
	QString_getDta += "&platform=" + QUrl::toPercentEncoding ( QString_platform );

	if ( b_quiet )
		QString_getDta += "&quiet";
	
	QHttpRequestHeader QHttpRequestHeader_chkUpdate ( "GET", "/chkUpdate/?" + QString_getDta );
	QHttpRequestHeader_chkUpdate.setValue ( "Host", "update.openpicide.org" );
	QHttpRequestHeader_chkUpdate.setContentType ( "application/x-www-form-urlencoded" );

	this->pQHttp->setHost ( "update.openpicide.org" );
	this->pQHttp->request ( QHttpRequestHeader_chkUpdate, QString_getDta.toUtf8() );
	
	qDebug() << QString_getDta;
} 

/**
 *****************************************************************************************************************************
 */
 
void SupChkUpdate::httpRequestFinished ( int, bool )
{
// 	qDebug() << this->pQHttp->readAll ();
	
	if ( this->pQHttp->bytesAvailable() <= 0 )
		return;
	
	if ( ! this->getUpdateInfo () )
		return;
		
	emit updateInfo ( & this->sUpdateInfo );
	emit expired ( this->sUpdateInfo.b_expired );
}

/**
 *****************************************************************************************************************************
 */

bool SupChkUpdate::getUpdateInfo( void )
{
// 	qDebug() << this->pQHttp->readAll ();

	QXmlStreamReader QXmlStreamReader_updateInfo ( this->pQHttp->readAll () );

	while ( ! QXmlStreamReader_updateInfo.atEnd () )
	{
		QXmlStreamReader_updateInfo.readNext ();
	
		QString QString_tag = QXmlStreamReader_updateInfo.qualifiedName ().toString ();
		
		if ( "updateinfo" == QString_tag )
		{
			QString QString_release = QXmlStreamReader_updateInfo.attributes ().value ( "version" ).toString ();

			switch ( QString_release.toInt () )
			{
				default:	return FALSE;
				case 1:		return this->getUpdateInfoV01 ( & QXmlStreamReader_updateInfo );
			}
		}
	}
	
	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool SupChkUpdate::getUpdateInfoV01 ( QXmlStreamReader * pQXmlStreamReader )
{
	bool b_expired = FALSE;
	bool b_curRelease = FALSE;
	bool b_releaseInfo = FALSE;

	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if ( "expired" == QString_tag )
		{
			this->sUpdateInfo.b_expired = static_cast <bool> ( pQXmlStreamReader->readElementText ().toInt () );
			b_expired = TRUE;
		}
		else if ( "curRelease" == QString_tag )
		{
			this->sUpdateInfo.QString_curRelease = pQXmlStreamReader->readElementText ();
			b_curRelease = TRUE;
		}
		else if ( "releaseInfo" == QString_tag )
		{
			this->sUpdateInfo.QString_releaseInfo = pQXmlStreamReader->readElementText ();
			b_releaseInfo = TRUE;
		}
		else if ( pQXmlStreamReader->isEndElement () && ( "updateinfo" == QString_tag ) )
		{
			break;
		}
	}

	if ( b_expired && b_curRelease && b_releaseInfo )
		return TRUE;

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

void SupChkUpdate::showUpdateInfo ( void )
{
	QString QString_updateInfo;
	QPixmap QPixmap_icon;
	
/*	if ( FALSE )
	{
		QPixmap_icon = QPixmap ( ":/main/img/main/updateInfoHigh.png" );

		QString_updateInfo  = QObject::tr ( "Can not download update information." );
	}
	else */
	if ( this->sUpdateInfo.b_expired )
	{
		QPixmap_icon = QPixmap ( ":/main/img/main/updateInfoMedium.png" );

		QString_updateInfo  = QObject::tr ( "An update is beeing available:") + "\n";
		QString_updateInfo += "\n";
		QString_updateInfo += QObject::tr ( "Release") + " " + this->sUpdateInfo.QString_curRelease;
		QString_updateInfo += "\n";
		QString_updateInfo += "\n";
		QString_updateInfo += QObject::tr ( "More..." );
	}
	else
	{
		QPixmap_icon = QPixmap ( ":/main/img/main/updateInfoLow.png" );
		
		QString_updateInfo  = QObject::tr ( "No update is beeing available." );
	}

	QMessageBox QMessageBox_updateInfo;
	QMessageBox_updateInfo.setIconPixmap ( QPixmap_icon );
	QMessageBox_updateInfo.setText ( QString_updateInfo );
	QMessageBox_updateInfo.setWindowTitle ( QObject::tr ( "Update info" ) );
	QMessageBox_updateInfo.exec ();
}

/**
 *****************************************************************************************************************************
 */
