/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PROJECTDIALOG_H
#define PROJECTDIALOG_H

#include <QtGui>
#include <QtCore>

#include "Set.h"

#include "SetDlgPgVer.h"
#include "SetDlgPgPic.h"
#include "SetDlgPgSrc.h"
#include "SetDlgPgApp.h"
#include "EdtHlpViewer.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Project dialog class for editing project settings.
 *
 *	The class provides a dialog for editing the project settings.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class SetDlg : public QDialog
{
		Q_OBJECT

	public:

		/// Constructor. Generates the dialog layout.
		/// \param Set_dlg			Copy of settings changeable by dialog
		/// \param pQWidget_parent		Reference to the Parent widget.
		SetDlg ( Set Set_dlg, QWidget * pQWidget_parent = 0 );

	signals:

		/// Will be emitted when the dialog is about to close.
		/// \param pAppSet_get 		Pointer to application settings.
		/// \param pPrjSet_dlg 		Pointer to project settings.
		void changed ( Set * pSet_dlg );

	private slots:

		/// Handles clicks to the OK button.
		void handleEventOk ( void );

		/// Handles clicks to the Cancel button.
		void handleEventCancel ( void );

		/// Changes the dialog page if a page icon was selected from list.
		/// \param pQListWidgetItem_current	The current widget item
		/// \param pQListWidgetItem_previous	The previous widget item
		void changePage ( QListWidgetItem * pQListWidgetItem_current, QListWidgetItem * pQListWidgetItem_previous );

	private:

		/// Dialog settings
		Set Set_dlg;

		/// Dialog page for versioning
		SetDlgPgVer * pSetDlgPgVer;

		/// Dialog page for editing processor settings.
		SetDlgPgPic * pSetDlgPgPic;

		/// Dialog page for editing source settings.
		SetDlgPgSrc * pSetDlgPgSrc;

		/// Dialog page for editing editor settings.
		SetDlgPgApp * pSetDlgPgApp;

		/// Widget for dialog page navigation.
		QListWidget * pQListWidget_pageNavi;

		/// Widget to manage stacked dialog pages.
		QStackedWidget * pQStackedWidget_pages;
		
		QTextBrowser * pQTextBrowser;
};

#endif
