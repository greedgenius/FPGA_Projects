/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "EdtHlpViewer.h"
#include "EdtHlpViewerNetworkAccessManager.h"

/**
 *****************************************************************************************************************************
 */

EdtHlpViewer::EdtHlpViewer ( QHelpEngine * pQHelpEngine, QWidget * pQWidget_parent ) : QWebView ( pQWidget_parent )
{
	this->pQHelpEngine    = pQHelpEngine;
	this->b_copyAvailable = FALSE;
	
	QWebView::setAcceptDrops ( FALSE );
	
	EdtHlpViewerNetworkAccessManager * pEdtHlpViewerNetworkAccessManager = new EdtHlpViewerNetworkAccessManager ( pQHelpEngine, this );
	
	QWebView::page()->setNetworkAccessManager ( pEdtHlpViewerNetworkAccessManager );

	connect ( 
		this,
		SIGNAL ( titleChanged  ( QString ) ), 
		this, 
		SLOT ( setTitleChanged ( QString ) )
	);
	connect (
		QWebView::pageAction ( QWebPage::Copy ),
		SIGNAL ( changed () ),
		this,
		SLOT ( handleAction () )
	);
}

/**
 *****************************************************************************************************************************
 */

void EdtHlpViewer::setTitleChanged ( QString QString_title )
{
	emit titleChanged ( this, QString_title );
}

/**
 *****************************************************************************************************************************
 */

void EdtHlpViewer::handleAction ( void )
{
	QAction * pQAction = qobject_cast <QAction *> ( QObject::sender () );

	if ( pQAction == QWebView::pageAction ( QWebPage::Copy ) )
	{
		this->b_copyAvailable = pQAction->isEnabled ();
		emit copyAvailable ( this, this->b_copyAvailable );
	}
}

/**
 *****************************************************************************************************************************
 */

bool EdtHlpViewer::getCopyAvailable ( void )
{
	return this->b_copyAvailable;
}

/**
 *****************************************************************************************************************************
 */

void EdtHlpViewer::setCopyAvailable ( bool b_copyAvailable )
{
	this->b_copyAvailable = b_copyAvailable;

	emit copyAvailable ( this, b_copyAvailable );
}

/**
 *****************************************************************************************************************************
 */

void EdtHlpViewer::setSource ( QUrl QUrl_src )
{
// 	qDebug() << QUrl_src;
	QWebView::load ( QUrl_src );
}

/**
 *****************************************************************************************************************************
 */

void EdtHlpViewer::copy ( void )
{
	QWebView::pageAction ( QWebPage::Copy )->trigger();
}

/**
 *****************************************************************************************************************************
 */














