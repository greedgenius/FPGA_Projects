/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "SetDlgPgPic.h"
#include "PicNone.h"
#include "PicPblze.h"
#include "PicPblzeSet.h"

/**
 *****************************************************************************************************************************
 */

SetDlgPgPic::SetDlgPgPic ( SetPrj * pSetPrj_dlg, QWidget * pQWidget_parent ) : QWidget ( pQWidget_parent )
{
	this->pSetPrj_dlg = pSetPrj_dlg;

	// Pic group box
	QGroupBox * pQGroupBox_processor = new QGroupBox ( tr ( "Processor settings" ) );
	{
		// Pic group box layout
		pQVBoxLayout_groupBox = new QVBoxLayout();
		{
			// Pic selection
			QHBoxLayout * pQHBoxLayout_processor = new QHBoxLayout;
			{
				// Set Pic label
				QLabel * pQLabel_processor = new QLabel ( tr ( "Processor:" ), this );
				pQHBoxLayout_processor->addWidget ( pQLabel_processor );

				// Set Pic combo box
				this->pQComboBox_processor = new QComboBox ( this );
				{
					this->pProjectDialogPagePicNone = new SetDlgPgPicNone ( this );

					QStringList QStringList_processor;
					QStringList_processor << PicNone::getName ();
					QStringList_processor << PicPblze::getName ();

					this->pQComboBox_processor->addItems ( QStringList_processor );

					connect (
						pQComboBox_processor,
						SIGNAL ( currentIndexChanged ( const QString ) ),
						this,
						SLOT ( setPic ( const QString ) )
					);
				}
				pQHBoxLayout_processor->addWidget ( this->pQComboBox_processor );
			}
			pQVBoxLayout_groupBox->addLayout ( pQHBoxLayout_processor );
			pQVBoxLayout_groupBox->addWidget ( this->pProjectDialogPagePicNone );
		}
		pQGroupBox_processor->setLayout ( pQVBoxLayout_groupBox );
	}

	// Select processor
	{
		int i_index;
		QString QString_picType;

		QString_picType = this->pSetPrj_dlg->sPic.QString_picType;
		i_index = this->pQComboBox_processor->findText ( QString_picType );

		this->pQComboBox_processor->setCurrentIndex ( i_index );
	}

	// Set Page Layout
	QVBoxLayout * pQVBoxLayout_page = new QVBoxLayout;
	pQVBoxLayout_page->addWidget ( pQGroupBox_processor );
	setLayout ( pQVBoxLayout_page );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgPic::setPic ( const QString QString_processorType )
{
// 	qDebug() << QString_processorType;

	// Tidy up
	if ( this->pProjectDialogPagePicNone )
	{
		delete this->pProjectDialogPagePicNone;
		this->pProjectDialogPagePicNone = NULL;
	}

	if ( QString_processorType == PicNone::getName () )
	{
		this->pProjectDialogPagePicNone = new SetDlgPgPicNone ( this );
		pQVBoxLayout_groupBox->insertWidget ( 1, this->pProjectDialogPagePicNone );

	}
	else if ( QString_processorType == PicPblze::getName () )
	{
		this->pProjectDialogPagePicNone = new SetDlgPgPicPblze ( this->pSetPrj_dlg, this );
		pQVBoxLayout_groupBox->insertWidget ( 1, this->pProjectDialogPagePicNone );

	}
	else
	{
		this->pProjectDialogPagePicNone = new SetDlgPgPicNone ( this );
		pQVBoxLayout_groupBox->insertWidget ( 1, this->pProjectDialogPagePicNone );

		this->pQComboBox_processor->setCurrentIndex ( 0 );

		QString QString_MessageString;

		QString_MessageString  = QString ( "<b>%1</b>" ).arg ( this->pSetPrj_dlg->sPic.QString_picType );
		QString_MessageString += QString ( "<br>%2" ).arg ( QObject::tr ( "The processor type is not supported! Please check the processor settings." ) );

		QMessageBox::warning ( this, tr ( "Select processor" ), QString_MessageString, QMessageBox::Ok, QMessageBox::Ok );
	}

	this->QString_processorType = QString_processorType;
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgPic::getSet ( void )
{
	if ( QString_processorType == PicPblze::getName () )
	{
		SetDlgPgPicPblze * pSetDlgPgPicPblze;

		pSetDlgPgPicPblze = static_cast <SetDlgPgPicPblze *> ( this->pProjectDialogPagePicNone );

		pSetDlgPgPicPblze->getSet ();
	}
	else
	{
		if ( this->pSetPrj_dlg->sPic.pv_picSet )
			delete this->pSetPrj_dlg->sPic.pv_picSet;

		this->pSetPrj_dlg->sPic.pv_picSet  = NULL;
		this->pSetPrj_dlg->sPic.QString_picType = PicNone::getName ();
	}

	// Tidy up
	if ( this->pProjectDialogPagePicNone )
		delete this->pProjectDialogPagePicNone;
}

/**
 *****************************************************************************************************************************
 */

