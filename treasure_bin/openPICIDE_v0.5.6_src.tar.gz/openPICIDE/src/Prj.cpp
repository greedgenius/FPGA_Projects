/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

// #include <iostream>

#include "Prj.h"
#include "SetDlg.h"

/**
 *****************************************************************************************************************************
 */

Prj::Prj ( Mod * pMod, QObject * pQObject_parent ) : QObject ( pQObject_parent )
{
	this->pMod = pMod;
	
	// Create actions and menus
	this->createActions ( );
	this->createMenus ( );
	
	// Set recent files from app settings
	this->setRecent ();
}

/**
 *****************************************************************************************************************************
 */

void Prj::clearRecent ( void )
{
	for ( int i_iterator = 0; i_iterator < 4; i_iterator++ )
	{
		QString QString_filePath;
		QString QString_title;

		QString_title = QString ( "%1: " ).arg ( i_iterator + 1 ) + QObject::tr ( "Empty" );

		this->apQAction_recentFile [ i_iterator ]->setText ( QString_title );
		this->apQAction_recentFile [ i_iterator ]->setData ( QString ( "" ) );
	}

	this->pMod->pSet->App.sPrj.QStringList_recent.clear ();
	this->pMod->pSet->App.setDirty ();
}

/**
 *****************************************************************************************************************************
 */

void Prj::setRecent ( void )
{
	int i_prjRecentCount = pMod->pSet->App.sPrj.QStringList_recent.size ();

	if ( i_prjRecentCount > 4 )
		i_prjRecentCount = 4;

	for ( int i_iterator = 0; i_iterator < i_prjRecentCount; i_iterator++ )
	{
		QString QString_filePath;
		QString QString_title;

		QString_filePath = pMod->pSet->App.sPrj.QStringList_recent.at ( i_iterator );

		if ( QString_filePath.isEmpty () )
			QString_title = QString ( "%1: " ).arg ( i_iterator + 1 ) + QObject::tr ( "Empty" );
		else
			QString_title = QString ( "%1: " ).arg ( i_iterator + 1 ) + QFileInfo ( QString_filePath ).fileName ().section ( QChar ( '.' ), 0, 0 );

		this->apQAction_recentFile [ i_iterator ]->setText ( QString_title );
		this->apQAction_recentFile [ i_iterator ]->setData ( QString_filePath );
	}

	for ( int i_iterator = i_prjRecentCount; i_iterator < 4; i_iterator++ )
	{
		QString QString_filePath;
		QString QString_title;

		QString_title = QString ( "%1: " ).arg ( i_iterator + 1 ) + QObject::tr ( "Empty" );

		this->apQAction_recentFile [ i_iterator ]->setText ( QString_title );
		this->apQAction_recentFile [ i_iterator ]->setData ( QString ( "" ) );
	}
}

/**
 *****************************************************************************************************************************
 */

void Prj::addRecent ( QString QString_prjFilePath )
{
	QStringList QStringList_prjRecent;

	QStringList_prjRecent << QString_prjFilePath;

	int i_iteratorMax = this->pMod->pSet->App.sPrj.QStringList_recent.size ();

	if ( i_iteratorMax > 4 )
		i_iteratorMax = 4;

	for ( int i_iterator = 0; i_iterator < i_iteratorMax; i_iterator++ )
	{
		QString QString_filePath = this->pMod->pSet->App.sPrj.QStringList_recent.at ( i_iterator );

		if ( QStringList_prjRecent.contains ( QString_filePath ) )
			continue;

		if ( QStringList_prjRecent.size () < 4 )
			QStringList_prjRecent << QString_filePath;
	}

	this->pMod->pSet->App.sPrj.QStringList_recent = QStringList_prjRecent;
	this->pMod->pSet->App.setDirty ();

	// Append settings to menus
	this->setRecent ();
}

/**
 *****************************************************************************************************************************
 */

void Prj::createActions ( void )
{
	this->pQAction_newProject = new QAction ( QIcon ( ":/prj/img/prj/document-new.png" ), tr ( "&New" ), this );
	this->pQAction_newProject->setStatusTip ( tr ( "Create a new project" ) );
	connect ( this->pQAction_newProject, SIGNAL ( triggered() ), this, SLOT ( newProject() ) );

	this->pQAction_openProject = new QAction ( QIcon ( ":/prj/img/prj/document-open.png" ), tr ( "&Open..." ), this );
	this->pQAction_openProject->setStatusTip ( tr ( "Open an existing project" ) );
	connect ( this->pQAction_openProject, SIGNAL ( triggered() ), this, SLOT ( openProject() ) );

	this->pQAction_editProject = new QAction ( QIcon ( ":/prj/img/prj/document-edit.png" ), tr ( "&Settings" ), this );
	this->pQAction_editProject->setStatusTip ( tr ( "Edit the opened project" ) );
	connect ( this->pQAction_editProject, SIGNAL ( triggered() ), this, SLOT ( editProject() ) );

	this->pQAction_closePrj = new QAction ( QIcon ( ":/prj/img/prj/document-close.png" ), tr ( "&Close" ), this );
	this->pQAction_closePrj->setStatusTip ( tr ( "Close the project" ) );
	connect ( this->pQAction_closePrj, SIGNAL ( triggered() ), this, SLOT ( closePrj() ) );

	this->pQAction_clearRecent = new QAction ( tr ( "&Clear recent" ), this );
	this->pQAction_clearRecent->setStatusTip ( tr ( "Clear recent" ) );
	connect ( this->pQAction_clearRecent, SIGNAL ( triggered() ), this, SLOT ( clearRecent() ) );

	for ( int i_iterator = 0; i_iterator < 4; i_iterator++ )
	{
		QAction * pQAction = new QAction ( QString ( "" ), this );

		this->apQAction_recentFile [ i_iterator ] = pQAction;

		connect ( pQAction, SIGNAL ( triggered() ), this, SLOT ( openProjectFromAction() ) );
	}

	// Disable actions because no valid project settings loaded
	this->setPrjValid ( FALSE );
}

/**
 *****************************************************************************************************************************
 */

void Prj::createMenus ( void )
{
	this->pQMenu_project = new QMenu ( QObject::tr ( "&Project" ) );
	this->pQMenu_project->addAction ( this->pQAction_newProject );
	this->pQMenu_project->addAction ( this->pQAction_openProject );
	this->pQMenu_project->addAction ( this->pQAction_editProject );
	this->pQMenu_project->addSeparator ();

	this->pQMenu_recent = new QMenu ( QObject::tr ( "&Recent" ) );

	for ( int i_iterator = 0; i_iterator < 4; i_iterator++ )
		this->pQMenu_recent->addAction ( this->apQAction_recentFile [ i_iterator ] );

	this->pQMenu_recent->addSeparator ();
	this->pQMenu_recent->addAction ( this->pQAction_clearRecent );

	this->pQMenu_project->addMenu ( this->pQMenu_recent );

	this->pQMenu_project->addSeparator ();
	this->pQMenu_project->addAction ( this->pQAction_closePrj );
}

/**
 *****************************************************************************************************************************
 */

void Prj::setupMenuBar ( QMenuBar * pQMenuBar_mainWindow )
{
	pQMenuBar_mainWindow->addMenu ( pQMenu_project );
}

/**
 *****************************************************************************************************************************
 */

void Prj::setPrjValid ( bool b_projectValid )
{
// 	pQAction_editProject->setEnabled  ( b_projectValid );
	pQAction_closePrj->setEnabled ( b_projectValid );
}

/**
 *****************************************************************************************************************************
 */

bool Prj::setupPrjDlg ( void )
{
	// Prjup dialog
	SetDlg * pSetDlg = new SetDlg ( * this->pMod->pSet );

	connect (
		pSetDlg,
		SIGNAL ( changed ( Set * ) ),
		this,
		SLOT ( changeSettings ( Set * ) )
	);

	// Show dialog
	pSetDlg->exec();

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

void Prj::changeSettings ( Set * pSet_dlg )
{
	if ( ! pSet_dlg )
		return;

	* this->pMod->pSet = * pSet_dlg;

	// Save settings
	this->pMod->pSet->App.setDirty ();
	
	if ( this->pMod->pSet->Prj.sPrj.b_prjVld )
		this->pMod->pSet->Prj.setDirty ();

	emit settingsChanged ();
}

/**
 *****************************************************************************************************************************
 */

bool Prj::chkPrjForClose ( void )
{
	// Check, if no project is loaded
	if ( ! this->pMod->pSet->Prj.sPrj.b_prjVld )
		return FALSE;

	// Ask user for closing project
	{
		QMessageBox::StandardButton QStandardButton_retVal;

		QStandardButton_retVal = QMessageBox::warning ( this->pMod->pQMainWindow,
		                         QObject::tr ( "Close Project" ),
		                         QObject::tr ( "A Project is still open and will be closed! <br>Do you want to continue?" ),
		                         QMessageBox::Yes | QMessageBox::No,
		                         QMessageBox::No );

		if ( QMessageBox::No == QStandardButton_retVal )
			return TRUE;
	}

	// Close project
	this->closePrj ();

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

void Prj::openProjectFromAction ( void )
{
	QAction * pQAction = qobject_cast <QAction *> ( sender () );

	if ( pQAction &&  ! pQAction->data().toString ().isEmpty () )
		this->openProject ( pQAction->data().toString() );
}

/**
 *****************************************************************************************************************************
 */

void Prj::newProject ( void )
{
	// Check, if project still opened
	if ( this->chkPrjForClose () )
		return;

	// Get file name and path for project
	QFileInfo QFileInfo_prjFilePath;

	if ( ! this->getProjectPathDlgNew ( & QFileInfo_prjFilePath ) )
		return;

	// Opens project
	if ( ! this->pMod->pSet->Prj.openPrj ( QFileInfo_prjFilePath.filePath () ) )
		return;
	
	// Prj dialog
	if ( ! this->setupPrjDlg () )
		this->closePrj();

	// Enable menus
	this->setPrjValid ( TRUE );
	
	// Add file to recent menu
	this->addRecent ( QFileInfo_prjFilePath.filePath () );
}

/**
 *****************************************************************************************************************************
 */
void Prj::openProject ( QString QString_prjFilePath )
{
	// Check, if project still opened
	if ( this->chkPrjForClose() )
		return;

	// Prj file name and path for project
	QFileInfo QFileInfo_prjFilePath;
	{
		// Check, if project file path given by argument
		if ( ! QString_prjFilePath.isEmpty ( ) )
		{
			// Use given file name and path for project
			QFileInfo_prjFilePath.setFile ( QString_prjFilePath );
		}
		else
		{
			// Get file name and path for project from user
			if ( ! this->getProjectPathDlgOpen ( & QFileInfo_prjFilePath ) )
				return;
		}
	}

	// Opens project
	if ( ! this->pMod->pSet->Prj.openPrj ( QFileInfo_prjFilePath.filePath () ) )
		return;

	// Prj dialog
	if ( ! this->setupPrjDlg () )
		this->closePrj();

	// Enable menus
	this->setPrjValid ( TRUE );

	// Add file to recent menu
	this->addRecent ( QFileInfo_prjFilePath.filePath () );
}

/**
 *****************************************************************************************************************************
 */

void Prj::editProject ( void )
{
	// Prj dialog
	this->setupPrjDlg ();
}

/**
 *****************************************************************************************************************************
 */

void Prj::closePrj ( void )
{
	// Check, if project valid
	if ( this->pMod->pSet->Prj.sPrj.b_prjVld && this->pMod->pSet->Prj.closePrj () )
	{
		// Disable menus
		this->setPrjValid ( FALSE );

		emit projectClosed();
	}
}

/**
 *****************************************************************************************************************************
 */

bool Prj::getProjectPathDlgNew ( QFileInfo * pQFileInfo_prjFilePath )
{
	if ( ! pQFileInfo_prjFilePath )
		return FALSE;

	QFileDialog QFileDialog_prjFilePath;
	QFileDialog_prjFilePath.setViewMode ( QFileDialog::Detail );
	QFileDialog_prjFilePath.setDefaultSuffix ( QString ( "openPicIde" ) );
	QFileDialog_prjFilePath.setNameFilter ( tr ( "openPicIde files (*.openPicIde)" ) );

	QFileDialog_prjFilePath.setConfirmOverwrite ( TRUE );
	QFileDialog_prjFilePath.setAcceptMode ( QFileDialog::AcceptSave );
	QFileDialog_prjFilePath.setWindowTitle ( tr ( "New Project File" ) );
	QFileDialog_prjFilePath.setFileMode ( QFileDialog::AnyFile );

	if ( ! QFileDialog_prjFilePath.exec () )
		return FALSE;

	QStringList QStringList_prjFilePathes = QFileDialog_prjFilePath.selectedFiles ();

	if ( QStringList_prjFilePathes.size () != 1 )
		return FALSE;

	// Return project file path
	pQFileInfo_prjFilePath->setFile ( QStringList_prjFilePathes.at ( 0 ) );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool Prj::getProjectPathDlgOpen ( QFileInfo * pQFileInfo_prjFilePath )
{
	if ( ! pQFileInfo_prjFilePath )
		return FALSE;

	// Init dialog
	PrjOpenDlg PrjOpenDlg_prjFilePath;
	{
			PrjOpenDlg_prjFilePath.setSettingsApp ( & this->pMod->pSet->App );
	}

	if ( ! PrjOpenDlg_prjFilePath.exec () )
		return FALSE;

	QString QString_prjFilePath = PrjOpenDlg_prjFilePath.getPrjFilePath ();

	if ( QString_prjFilePath.isEmpty () )
		return FALSE;

	// Return project file path
	pQFileInfo_prjFilePath->setFile ( QString_prjFilePath );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */
