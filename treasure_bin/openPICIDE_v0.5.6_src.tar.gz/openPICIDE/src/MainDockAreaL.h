/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef MAINDOCKAREAL_H
#define MAINDOCKAREAL_H

#include <QtCore>
#include <QtGui>

/**
 *****************************************************************************************************************************
 *
 *      \brief Left dock widget
 *
 *	The widget manages widgets set by \c addWidget via tab widget. With
 *	\c removeWidget() an previos added widget can be removed. With
 *	\c setCurrentWidget() an previous added widget can be set as current
 *	widget.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class MainDockAreaL : public QDockWidget
{
		Q_OBJECT

	public:
		/// Constructor
		/// \param QString_title	Title of the widget
		MainDockAreaL ( QString QString_title, QWidget * pQWidget_parent = 0 );

		/// Adds a widget to the tab page
		/// \param QString_name		Name of the widget, displayed in tab
		/// \param pQWidget		Pointer to the widget to add
		void addWidget ( QString QString_name, QWidget * pQWidget );

		/// Remove the given widget from tab page widget
		/// \param pQWidget		Pointer to the widget to remove
		void removeWidget ( QWidget * pQWidget );

		/// Returns, if widget is beeing shown in dock widget
		/// \param pQWidget		Pointer to the widget to check
		/// \retval bool		TRUE, if widget is beeing shown in dock widget, otherwise FALSE
		bool hasWidget ( QWidget * pQWidget );

	public slots:

		/// Sets the given widget to current widget
		/// \param pQWidget		Pointer to the widget to select
		void setCurrentWidget ( QWidget * pQWidget );

	private slots:

		/// Will be called if the current widget changes.
		/// Sets the width of the tab widget
		/// \param i_index		Index of the current tab page
		void currentWidgetChanged ( int i_index );

	private:

		/// Container for the dock widget instance
		QWidget * pQWidget_dockWidget;

		/// Tab widget
		QTabWidget  * pQTabWidget;
};

#endif
