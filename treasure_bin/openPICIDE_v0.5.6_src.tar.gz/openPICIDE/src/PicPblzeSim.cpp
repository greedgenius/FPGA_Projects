/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeSim.h"
#include "MainDockAreaL.h"
#include "MainDockAreaR.h"
#include "MainDockAreaB.h"
#include "PicPblzeSimIntVectDlg.h"

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Constructor
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

PicPblzeSim::PicPblzeSim ( Mod * pMod, QObject * pQObject_parent ) : PicPblzeAsmParser ( pQObject_parent )
{
	this->pMod = pMod;
	
	this->sHw.pPicPblzeSimCore		= NULL;
	this->sHw.pPicIO			= NULL;
	this->sHw.pPicPblzeSimCoreCallStack	= NULL;

	this->sHw.psCodeLine_pc			= NULL;

	this->eState = e_disabled;
}

/**
 *****************************************************************************************************************************
 */

PicPblzeSim::~PicPblzeSim()
{
	this->removeDockWidgets ();
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Parameter handling
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

void PicPblzeSim::setBase ( int i_base )
{
	if ( this->sHw.pPicPblzeSimCore )
		this->sHw.pPicPblzeSimCore->setBase ( i_base );

	if ( this->sHw.pPicIO )
		this->sHw.pPicIO->setBase ( i_base );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::setBreakpoints ( QMap<QString,QList<int> > QMap_breakpoints )
{
	// Clear breakpionts
	this->clearBreakpoints ();

	// Set new breakpoints
	QMap<QString,QList<int> >::const_iterator QMapIterator_breakpoint = QMap_breakpoints.constBegin ();

	while ( QMapIterator_breakpoint != QMap_breakpoints.constEnd () )
	{
		int i_fileNumber = PicPblzeAsmParser::getFileNumber ( QMapIterator_breakpoint.key () );

		for ( int i_iterator = 0; i_iterator < QMapIterator_breakpoint.value ().count (); i_iterator++ )
			this->setBreakpoint ( i_fileNumber, QMapIterator_breakpoint.value ().at ( i_iterator ) );

		QMapIterator_breakpoint++;
	}
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::clearBreakpoints ( void )
{
	PicPblzeAsmParser::sCodeLine_t * psCodeLine = PicPblzeAsmParser::psCodeLine_start;

	// Clear break points
	while ( psCodeLine )
	{
		psCodeLine->b_breakpoint = FALSE;

		psCodeLine = psCodeLine->psCodeLine_next;
	}
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::setBreakpoint ( int i_fileNumber, int i_lineNumber )
{
	PicPblzeAsmParser::sCodeLine_t * psCodeLine = PicPblzeAsmParser::psCodeLine_start;

	while ( psCodeLine )
	{
		if ( ( psCodeLine->i_fileNumber == i_fileNumber ) && ( psCodeLine->i_lineNumber >= i_lineNumber ) )
		{
			// Search until cmd reached
			while ( psCodeLine->eLineType <= PicPblzeAsmParser::eLineType_cmd )
			{
				psCodeLine = psCodeLine->psCodeLine_next;

				if ( ! psCodeLine )
					return;
			}

			psCodeLine->b_breakpoint = TRUE;

			return;
		}
		psCodeLine = psCodeLine->psCodeLine_next;
	}
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** State handling
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

PicPblzeSim::eState_t PicPblzeSim::getSimStatus ( void )
{
	return this->eState;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Gui handling
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

void PicPblzeSim::createDockWidgets ( void )
{
	// Setup core dock widget
	{
		PicPblzeSimCore::sCfg_t sCfg;
		
		switch ( PicPblzeAsmParser::sCfg.ePicDerivate )
		{
			case PicPblzeSet::ePblzeCpld:
				
				sCfg.b_hwbuildEn	= FALSE;
				sCfg.i_regCountA	= 8;
				sCfg.i_regCountB	= 0;
				sCfg.i_scrpdSize	= this->sCfg.i_scrpdSize;
				break;
				
			case PicPblzeSet::ePblze:
				
				sCfg.b_hwbuildEn	= FALSE;
				sCfg.i_regCountA	= 16;
				sCfg.i_regCountB	= 0;
				sCfg.i_scrpdSize	= this->sCfg.i_scrpdSize;
				break;
				
			case PicPblzeSet::ePblzeII:
				
				sCfg.b_hwbuildEn	= FALSE;
				sCfg.i_regCountA	= 32;
				sCfg.i_regCountB	= 0;
				sCfg.i_scrpdSize	= this->sCfg.i_scrpdSize;
				break;
				
			case PicPblzeSet::ePblze3:
				
				sCfg.b_hwbuildEn	= FALSE;
				sCfg.i_regCountA	= 16;
				sCfg.i_regCountB	= 0;
				sCfg.i_scrpdSize	= this->sCfg.i_scrpdSize;
				break;
				
			case PicPblzeSet::ePblze6:
				
				sCfg.b_hwbuildEn	= TRUE;
				sCfg.i_regCountA	= 16;
				sCfg.i_regCountB	= 16;
				sCfg.i_scrpdSize	= this->sCfg.i_scrpdSize;
				break;
				
			default:
				
				sCfg.b_hwbuildEn	= FALSE;
				sCfg.i_regCountA	= 0;
				sCfg.i_regCountB	= 0;
				sCfg.i_scrpdSize	= this->sCfg.i_scrpdSize;
				break;
		}
		
		this->sHw.pPicPblzeSimCore = new PicPblzeSimCore ( sCfg );
		this->sHw.pPicPblzeSimCore->setMaxPc ( PicPblzeAsmParser::sCfg.i_memBankSize );

		this->pMod->pMainDockAreaL->addWidget ( QString ( "Core" ), this->sHw.pPicPblzeSimCore );
		this->pMod->pMainDockAreaL->show();
	}

	// Setup ports dock widget
	{
		this->sHw.pPicIO = new PicIO;
		this->pMod->pMainDockAreaR->addWidget ( QString ( "IO" ), this->sHw.pPicIO );
		this->pMod->pMainDockAreaR->show();
	}

	// Setup call stack dock widget
	{
		this->sHw.pPicPblzeSimCoreCallStack = new PicPblzeSimCoreCallStack;
		this->pMod->pMainDockAreaB->addWidget ( QString ( "Call stack" ), this->sHw.pPicPblzeSimCoreCallStack );
		this->pMod->pMainDockAreaB->show();
	}
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::removeDockWidgets ( void )
{
	if ( this->sHw.pPicPblzeSimCore )
	{
		this->pMod->pMainDockAreaL->removeWidget ( this->sHw.pPicPblzeSimCore );
		delete this->sHw.pPicPblzeSimCore;
		this->sHw.pPicPblzeSimCore = NULL;
	}

	if ( this->sHw.pPicIO )
	{
		this->pMod->pMainDockAreaR->removeWidget ( this->sHw.pPicIO );
		delete this->sHw.pPicIO;
		this->sHw.pPicIO = NULL;
	}

	if ( this->sHw.pPicPblzeSimCoreCallStack )
	{
		this->pMod->pMainDockAreaB->removeWidget ( this->sHw.pPicPblzeSimCoreCallStack );
		delete this->sHw.pPicPblzeSimCoreCallStack;
		this->sHw.pPicPblzeSimCoreCallStack = NULL;
	}
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Simulation control
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

void PicPblzeSim::setPcFromCodeLine ( QString QString_filePath, int i_lineNumber )
{
	int i_fileNumber = PicPblzeAsmParser::getFileNumber ( QString_filePath );

	if ( i_fileNumber < 0 )
		return;

	this->hwSetPc ( PicPblzeAsmParser::getPcFromCodeLine ( QString_filePath, i_lineNumber ) );
	
	this->selectSrcFromPc ();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::selectSrcFromPc ( void )
{
	if ( ! this->sHw.psCodeLine_pc )
		return;
	
	QUrl QUrl_src;

	QUrl_src.setScheme( "file" );
	QUrl_src.setPath ( PicPblzeAsmParser::msgGetFilePath ( this->sHw.psCodeLine_pc->i_fileNumber ) );
	QUrl_src.setFragment ( QString::number ( this->sHw.psCodeLine_pc->i_lineNumber ) );
	
	emit selectSrc ( QUrl_src );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simStart ( sCfg_t sCfg )
{
	// Set parser parameter. Must be first!
	if ( ! PicPblzeAsmParser::setCfg ( sCfg.sCfg_asmParser ) )
		return FALSE;

	// Parse code.
	if ( ! PicPblzeAsmParser::parse() )
		return FALSE;

	// Setup gui
	{
		this->removeDockWidgets ();
		this->createDockWidgets ();

		this->setBase ( 16 );
	}
	
	// Setup hardware
	{
		// Clear simulator
		this->sHw.pPicIO->clear ();

		this->sHw.pPicPblzeSimCore->clear ();

		this->sHw.QList_callStack.clear();
		this->sHw.pPicPblzeSimCoreCallStack->clear();

		this->sHw.pPicPblzeSimCore->setInt ( PicEdtInterrupt::eIntDisabled );
		
		this->sHw.pPicPblzeSimCore->clearClkCntr ();
		
		// Set program counter
		this->hwSetPc ( PicPblzeAsmParser::sMem.apsCodeLine_memMap[ 0 ] );
	}
	
	this->selectSrcFromPc ();
	
	this->eState = e_idle;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simReload ( sCfg_t sCfg )
{
	// Backup program counter
	QString QString_filePath = PicPblzeAsmParser::msgGetFilePath ( this->sHw.psCodeLine_pc->i_fileNumber );
	int i_lineLumber = this->sHw.psCodeLine_pc->i_lineNumber;

	// Set parser parameter
	if ( ! PicPblzeAsmParser::setCfg ( sCfg.sCfg_asmParser ) )
		return FALSE;

	if ( ! PicPblzeAsmParser::parse() )
		return FALSE;

	this->eState = e_idle;
	
	// Restore program counter
	this->hwSetPc ( PicPblzeAsmParser::getPcFromCodeLine ( QString_filePath, i_lineLumber ) );
	
	this->selectSrcFromPc ();
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::simRst ( void )
{
	// Setup hardware
	{
		// Clear simulator
		this->sHw.pPicIO->clear ();

		this->sHw.pPicPblzeSimCore->clear ();

		this->sHw.QList_callStack.clear();
		this->sHw.pPicPblzeSimCoreCallStack->clear();

		this->sHw.pPicPblzeSimCore->setInt ( PicEdtInterrupt::eIntDisabled );
		
		this->sHw.pPicPblzeSimCore->clearClkCntr ();
		
		// Set program counter
		this->hwSetPc ( PicPblzeAsmParser::psCodeLine_start );
	}

	this->selectSrcFromPc ();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::simRun ( void )
{
	if ( this->eState != e_idle )
		return;
	
	this->eState = e_run;
	
	while ( this->simCmd () )
	{
		// Update gui elements
		QApplication::processEvents ( QEventLoop::AllEvents );
		
		// Check if breakpoint reached
		if ( this->sHw.psCodeLine_pc && this->sHw.psCodeLine_pc->b_breakpoint )
			break;
		
		if ( this->eState == e_idle )
			break;
	}
	
	this->eState = e_idle;
	
	this->selectSrcFromPc ();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::simStop ( void )
{
	this->eState = e_idle;
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::simNextInstruction ( void )
{
	if ( this->eState != e_idle )
		return;

	this->simCmd ();

	this->selectSrcFromPc ();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::simNextLine ( void )
{
	if ( this->eState != e_idle )
		return;
	
	this->eState = e_run;
	
	if ( this->sHw.psCodeLine_pc && ( this->sHw.psCodeLine_pc->eLineType == PicPblzeAsmParser::eLineType_cmdCall ) )
	{
		int i_callStackSize = this->sHw.QList_callStack.count ();

		while ( this->simCmd () )
		{
			// Update gui elements
			QApplication::processEvents ( QEventLoop::AllEvents );
		
			// Check if breakpoint reached
			if ( this->sHw.psCodeLine_pc && this->sHw.psCodeLine_pc->b_breakpoint )
				break;

			if ( this->sHw.QList_callStack.count () <= i_callStackSize )
				break;
			
			if ( this->eState == e_idle )
				break;
		}
	}
	else
	{
		this->simCmd ();
	}
	
	this->eState = e_idle;
	
	this->selectSrcFromPc ();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::simToEndOfCall ( void )
{
	if ( this->eState != e_idle )
		return;
	
	this->eState = e_run;
	
	int i_callStackSize = this->sHw.QList_callStack.count ();
		
	while ( this->simCmd () )
	{
		// Update gui elements
		QApplication::processEvents ( QEventLoop::AllEvents );
	
		// Check if breakpoint reached
		if ( this->sHw.psCodeLine_pc && this->sHw.psCodeLine_pc->b_breakpoint )
			break;

		if ( this->sHw.QList_callStack.count () < i_callStackSize )
			break;
		
		if ( this->eState == e_idle )
			break;
	}
	
	this->eState = e_idle;
	
	this->selectSrcFromPc ();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::simInt ( void )
{
	if ( this->sHw.pPicPblzeSimCore->getInt () == PicEdtInterrupt::eIntEnabled )
		this->sHw.pPicPblzeSimCore->setInt ( PicEdtInterrupt::eIntRequested );

	else if ( this->sHw.pPicPblzeSimCore->getInt () == PicEdtInterrupt::eIntRequested )
		this->sHw.pPicPblzeSimCore->setInt ( PicEdtInterrupt::eIntEnabled );
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Simulate commands
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmd ( void )
{
	// Clears highligting
	this->sHw.pPicPblzeSimCore->clearHighlighted ();
	this->sHw.pPicIO->clearHighlighted ();

	// Checking for interrupt
	if ( ! this->hwChkInt () )
		return FALSE;

	// Check if pc is valid
	if ( ! this->sHw.psCodeLine_pc )
	{
		this->msgEmit ( eMsgType_simNoMoreCmds );
		return FALSE;
	}

	switch ( this->sHw.psCodeLine_pc->eLineType )
	{
		case eLineType_cmdRet:		return this->simCmdReturn  ();		break;
		case eLineType_cmdReti:		return this->simCmdReturnI ();		break;
		case eLineType_cmdAddc:		return this->simCmdAdd     ( TRUE );	break;
		case eLineType_cmdSubc:		return this->simCmdSub     ( TRUE );	break;
		case eLineType_cmdIn:		return this->simCmdInput   ();		break;
		case eLineType_cmdOut:		return this->simCmdOutput  ();		break;
		case eLineType_cmdEint:		return this->simCmdIntEn   ( TRUE );	break;
		case eLineType_cmdDint:		return this->simCmdIntEn   ( FALSE );	break;
		case eLineType_cmdComp:		return this->simCmdCompare ( FALSE );	break;
		case eLineType_cmdCompC:	return this->simCmdCompare ( TRUE );	break;
		case eLineType_cmdAdd:		return this->simCmdAdd     ( FALSE );	break;
		case eLineType_cmdAnd:		return this->simCmdAnd     ();		break;
		case eLineType_cmdCall:		return this->simCmdCall    ();		break;
		case eLineType_cmdHwbld:	return this->simCmdHwbld   ();		break;
		case eLineType_cmdJump:		return this->simCmdJump    ();		break;
		case eLineType_cmdLoad:		return this->simCmdLoad    ();		break;
		case eLineType_cmdOr:		return this->simCmdOr      ();		break;
		case eLineType_cmdRl:		return this->simCmdRL      ();		break;
		case eLineType_cmdRr:		return this->simCmdRR      ();		break;
		case eLineType_cmdSl0:		return this->simCmdSL      ();		break;
		case eLineType_cmdSl1:		return this->simCmdSL      ();		break;
		case eLineType_cmdSlA:		return this->simCmdSL      ();		break;
		case eLineType_cmdSlX:		return this->simCmdSL      ();		break;
		case eLineType_cmdSr0:		return this->simCmdSR      ();		break;
		case eLineType_cmdSr1:		return this->simCmdSR      ();		break;
		case eLineType_cmdSrA:		return this->simCmdSR      ();		break;
		case eLineType_cmdSrX:		return this->simCmdSR      ();		break;
		case eLineType_cmdSub:		return this->simCmdSub     ( FALSE );	break;
		case eLineType_cmdTest:		return this->simCmdTest    ( FALSE );	break;
		case eLineType_cmdTestC:	return this->simCmdTest    ( TRUE );	break;
		case eLineType_cmdXor:		return this->simCmdXOr     ();		break;
		case eLineType_cmdStore:	return this->simCmdStore   ();		break;
		case eLineType_cmdFetch:	return this->simCmdFetch   ();		break;
		case eLineType_cmdStar:		return this->simCmdStar    ();		break;
		case eLineType_cmdRBank:	return this->simCmdRBank   ();		break;
		case eLineType_cmdLoadRet:	return this->simCmdLoadRet ();		break;
	}

	this->msgEmit ( eMsgType_simErr, this->sHw.psCodeLine_pc );
	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdIntEn ( bool b_intEn )
{
	if ( b_intEn )
		this->sHw.pPicPblzeSimCore->setInt ( PicEdtInterrupt::eIntEnabled );
	else
		this->sHw.pPicPblzeSimCore->setInt ( PicEdtInterrupt::eIntDisabled );

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );
		
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdAdd ( bool b_carryEn )
{
	//********************************************************************************************************************
	//* Get first argument
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	int i_value0;

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg, & i_value0 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get second argument
	//********************************************************************************************************************
	int i_value1;

	if ( ! this->simArgRegNum ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ), & i_value1 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get carry
	//********************************************************************************************************************
	int i_carry = 0;

	if ( b_carryEn )
		i_carry = this->sHw.pPicPblzeSimCore->getCarry ();

	//********************************************************************************************************************
	//* Add
	//********************************************************************************************************************
	int i_result = i_value0 + i_value1 + i_carry;

	//********************************************************************************************************************
	//* Set results
	//********************************************************************************************************************
	this->hwSetReg ( QString_reg, QString_regSubst, i_result );

	this->hwSetCarryFromResult ( i_result );
	this->hwSetZeroFromResult ( i_result );

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdAnd ( void )
{
	//********************************************************************************************************************
	//* Get first argument
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	int i_value0;

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg, & i_value0 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get second argument
	//********************************************************************************************************************
	int i_value1;

	if ( ! this->simArgRegNum ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ), & i_value1 ) )
		return FALSE;

	//********************************************************************************************************************
	//* And
	//********************************************************************************************************************
	int i_result = i_value0 & i_value1;

	//********************************************************************************************************************
	//* Set results
	//********************************************************************************************************************
	this->hwSetReg ( QString_reg, QString_regSubst, i_result );

	this->hwSetCarryFromResult ( 0 );
	this->hwSetZeroFromResult ( i_result );

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdCall ( void )
{
	//********************************************************************************************************************
	//* Address only
	//********************************************************************************************************************
	if ( this->sHw.psCodeLine_pc->QStringList_args.count() == 1 )
	{
		PicPblzeAsmParser::sCodeLine_t * psCodeLine;
		
		if ( ! this->hwPushPcToCallstack () )
			return FALSE;

		if ( ! this->simArgMAddr ( this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg ), & psCodeLine ) )
		{
			this->msgEmit ( eMsgType_simWrongAddr, this->sHw.psCodeLine_pc );
			return FALSE;
		}

		this->hwSetPc ( psCodeLine );

		// Add clock counter offset
		this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

		return TRUE;
	}
	
	//********************************************************************************************************************
	//* 
	//********************************************************************************************************************
	QString QString_arg0 = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );
	QString QString_arg1 = this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg );
		
	// Check if register referenced address
	if ( QString_arg0.contains ( "(" ) || QString_arg1.contains ( ")" ) )
	{
		// Remove brackets
		QString_arg0 = QString_arg0.remove ( 0, 1 );
		QString_arg1 = QString_arg1.remove ( QString_arg1.length() - 1, 1 );
		
		int i_addrH;
		int i_addrL;
		int i_addr;

		if ( ! this->simArgRegNum ( QString_arg0, & i_addrH ) )
			return FALSE;

		if ( ! this->simArgRegNum ( QString_arg1, & i_addrL ) )
			return FALSE;
		
		i_addr = ( i_addrH << 8 ) | i_addrL;
		
		PicPblzeAsmParser::sCodeLine_t * psCodeLine;
	
		if ( ! this->hwPushPcToCallstack () )
			return FALSE;

		if ( ! this->simArgMAddr ( QString::number ( i_addr ), & psCodeLine ) )
		{
			this->msgEmit ( eMsgType_simWrongAddr, this->sHw.psCodeLine_pc );
			return FALSE;
		}

		this->hwSetPc ( psCodeLine );
			
		// Add clock counter offset
		this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

		return TRUE;
	}
	else
	{
		if ( this->hwChkBranch ( this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg ) ) )
		{
			PicPblzeAsmParser::sCodeLine_t * psCodeLine;
		
			if ( ! this->hwPushPcToCallstack () )
				return FALSE;

			if ( ! this->simArgMAddr ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ), & psCodeLine ) )
			{
				this->msgEmit ( eMsgType_simWrongAddr, this->sHw.psCodeLine_pc );
				return FALSE;
			}

			this->hwSetPc ( psCodeLine );
		}
		else
		{
			this->hwSetPcNext ();
		}
		
		// Add clock counter offset
		this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

		return TRUE;
	}

	return FALSE;	
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdCompare ( bool b_carryEn )
{
	//********************************************************************************************************************
	//* Get first argument
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	int i_value0;

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg, & i_value0 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get second argument
	//********************************************************************************************************************
	int i_value1;

	if ( ! this->simArgRegNum ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ), & i_value1 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get carry
	//********************************************************************************************************************
	int i_zero  = 1;
	int i_carry = 0;

	if ( b_carryEn )
	{
		i_carry = this->sHw.pPicPblzeSimCore->getCarry ();
		i_zero  = this->sHw.pPicPblzeSimCore->getZero ();
	}
	
	//********************************************************************************************************************
	//* Compare
	//********************************************************************************************************************
	int i_value = i_value0 - i_value1 - i_carry;
	
	if ( i_value <  0 ) { i_carry = 1; } else { i_carry = 0; }
	if ( i_value == 0 ) { i_zero  = i_zero & 1; } else { i_zero  = 0; }
	
	//********************************************************************************************************************
	//* Set results
	//********************************************************************************************************************
	this->sHw.pPicPblzeSimCore->setZero ( i_zero );
	this->sHw.pPicPblzeSimCore->setCarry ( i_carry );

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdFetch ( void )
{
	//********************************************************************************************************************
	//* Get first argument
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg, NULL ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get second argument
	//********************************************************************************************************************
	int i_addr;

	if ( ! this->simArgPSAddr ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ), & i_addr ) )
		return FALSE;

	//********************************************************************************************************************
	//* Fetch
	//********************************************************************************************************************
	int i_value;

	if ( ! this->sHw.pPicPblzeSimCore->getScrpd ( i_addr, & i_value ) )
		return FALSE;

	if ( ! this->sHw.pPicPblzeSimCore->setRegister ( QString_reg, QString_regSubst, i_value ) )
		return FALSE;

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdInput ( void )
{
	//********************************************************************************************************************
	//* Get first argument
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg, NULL ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get second argument
	//********************************************************************************************************************
	int i_addr;
	QString QString_portSubst;

	if ( ! this->simArgPSAddr ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ), & i_addr, & QString_portSubst ) )
		return FALSE;

	//********************************************************************************************************************
	//* Input
	//********************************************************************************************************************
	int i_value;

	if ( ! this->sHw.pPicIO->getValue ( i_addr, QString_portSubst, & i_value ) )
	{
		this->msgEmit ( eMsgType_simInteractReq, this->sHw.psCodeLine_pc );
		return FALSE;
	}
	
	if ( ! this->sHw.pPicPblzeSimCore->setRegister ( QString_reg, QString_regSubst, i_value ) )
		return FALSE;

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdJump ( void )
{
	//********************************************************************************************************************
	//* Address only
	//********************************************************************************************************************
	if ( this->sHw.psCodeLine_pc->QStringList_args.count() == 1 )
	{
		PicPblzeAsmParser::sCodeLine_t * psCodeLine;
		
// 		if ( ! this->hwPushPcToCallstack () )
// 			return FALSE;

		if ( ! this->simArgMAddr ( this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg ), & psCodeLine ) )
		{
			this->msgEmit ( eMsgType_simWrongAddr, this->sHw.psCodeLine_pc );
			return FALSE;
		}

		this->hwSetPc ( psCodeLine );
		
		// Add clock counter offset
		this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

		return TRUE;
	}
	
	//********************************************************************************************************************
	//* 
	//********************************************************************************************************************
	QString QString_arg0 = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );
	QString QString_arg1 = this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg );
		
	// Check if register referenced address
	if ( QString_arg0.contains ( "(" ) || QString_arg1.contains ( ")" ) )
	{
		// Remove brackets
		QString_arg0 = QString_arg0.remove ( 0, 1 );
		QString_arg1 = QString_arg1.remove ( QString_arg1.length() - 1, 1 );
		
		int i_addrH;
		int i_addrL;
		int i_addr;

		if ( ! this->simArgRegNum ( QString_arg0, & i_addrH ) )
			return FALSE;

		if ( ! this->simArgRegNum ( QString_arg1, & i_addrL ) )
			return FALSE;
		
		i_addr = ( i_addrH << 8 ) | i_addrL;
		
		PicPblzeAsmParser::sCodeLine_t * psCodeLine;
	
// 		if ( ! this->hwPushPcToCallstack () )
// 			return FALSE;

		if ( ! this->simArgMAddr ( QString::number ( i_addr ), & psCodeLine ) )
		{
			this->msgEmit ( eMsgType_simWrongAddr, this->sHw.psCodeLine_pc );
			return FALSE;
		}

		this->hwSetPc ( psCodeLine );
			
		// Add clock counter offset
		this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

		return TRUE;
	}
	else
	{
		if ( this->hwChkBranch ( this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg ) ) )
		{
			PicPblzeAsmParser::sCodeLine_t * psCodeLine;
		
// 			if ( ! this->hwPushPcToCallstack () )
// 				return FALSE;

			if ( ! this->simArgMAddr ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ), & psCodeLine ) )
			{
				this->msgEmit ( eMsgType_simWrongAddr, this->sHw.psCodeLine_pc );
				return FALSE;
			}

			this->hwSetPc ( psCodeLine );
		}
		else
		{
			this->hwSetPcNext ();
		}
		
		// Add clock counter offset
		this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdLoad ( void )
{
	//********************************************************************************************************************
	//* Get first argument
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	int i_value0;

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg, & i_value0 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get second argument
	//********************************************************************************************************************
	int i_value1;

	if ( ! this->simArgRegNum ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ), & i_value1 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Load
	//********************************************************************************************************************
	if ( ! this->sHw.pPicPblzeSimCore->setRegister ( QString_reg, QString_regSubst, i_value1 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdOr ( void )
{
	//********************************************************************************************************************
	//* Get first argument
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	int i_value0;

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg, & i_value0 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get second argument
	//********************************************************************************************************************
	int i_value1;

	if ( ! this->simArgRegNum ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ), & i_value1 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Or
	//********************************************************************************************************************
	int i_result = i_value0 | i_value1;

	//********************************************************************************************************************
	//* Set result
	//********************************************************************************************************************
	this->hwSetReg ( QString_reg, QString_regSubst, i_result );

	this->hwSetCarryFromResult ( 0 );
	this->hwSetZeroFromResult ( i_result );

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdOutput ( void )
{
	//********************************************************************************************************************
	//* Check first argument for register 
	//********************************************************************************************************************
	if ( this->checkArgRegSubst ( this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg ) ) )
	{
		//************************************************************************************************************
		//* Get first argument
		//************************************************************************************************************
		QString QString_reg;
		QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

		int i_value;

		if ( ! this->simArgReg ( QString_regSubst, & QString_reg, & i_value ) )
			return FALSE;

		//************************************************************************************************************
		//* Get second argument
		//************************************************************************************************************
		int i_addr;
		
		QString QString_portSubst;

		if ( ! this->simArgPSAddr ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ), & i_addr, & QString_portSubst ) )
			return FALSE;
		
		//************************************************************************************************************
		//* Output
		//************************************************************************************************************
		if ( ! this->sHw.pPicIO->setValue ( i_addr, QString_portSubst, i_value ) )
			return FALSE;
	}
	else
	{
		//************************************************************************************************************
		//* Get first argument
		//************************************************************************************************************
		int i_value;

		if ( ! PicPblzeAsmParser::checkArgNumberConst ( this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg ), & i_value ) )
			return FALSE;
		
		//************************************************************************************************************
		//* Get second argument
		//************************************************************************************************************
		int i_addr;
		
		QString QString_portSubst;

		if ( ! this->simArgPSAddr ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ), & i_addr, & QString_portSubst ) )
			return FALSE;
		
		//************************************************************************************************************
		//* Output
		//************************************************************************************************************
		if ( ! this->sHw.pPicIO->setValue ( i_addr, QString_portSubst, i_value ) )
			return FALSE;
	}
	
	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdReturn ( void )
{
	int i_argCounter = eFrstArg;

	//********************************************************************************************************************
	//* Check branch condition
	//********************************************************************************************************************
	bool b_branchEn = TRUE;

	if ( this->sHw.psCodeLine_pc->QStringList_args.count() == 1 )
	{
		b_branchEn = hwChkBranch ( this->sHw.psCodeLine_pc->QStringList_args.at ( i_argCounter ) );

		i_argCounter = eScndArg;
	}

	//********************************************************************************************************************
	//* Return
	//********************************************************************************************************************
	if ( b_branchEn )
	{
		if ( ! this->hwPullPcFromCallstack () )
			return FALSE;
	}

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdReturnI ( void )
{
	//********************************************************************************************************************
	//* Enable/Disable interrupt
	//********************************************************************************************************************
	if ( this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg ).toUpper () == QString ( "ENABLE" ) )
		this->simCmdIntEn ( TRUE );
	else
		this->simCmdIntEn ( FALSE );

	//********************************************************************************************************************
	//* Restore hardware
	//********************************************************************************************************************
	
	// Restore flags
	this->sHw.pPicPblzeSimCore->setZero ( this->sHw.i_zeroFlagIntBackup );
	this->sHw.pPicPblzeSimCore->setCarry ( this->sHw.i_carryFlagIntBackup );
		
	// Restore pc
	if ( ! this->hwPullPcFromCallstack () )
		return FALSE;

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdRL ( void )
{
	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	int i_value;

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg, & i_value ) )
		return FALSE;

	//********************************************************************************************************************
	//* Rotate
	//********************************************************************************************************************
	int i_carry  = ( i_value >> 7 ) & 0x01;
	int i_result = ( ( i_value << 1 ) | i_carry ) & 0xFF;

	//********************************************************************************************************************
	//* Set results
	//********************************************************************************************************************
	if ( ! this->sHw.pPicPblzeSimCore->setRegister ( QString_reg, QString_regSubst, i_result & 0xFF ) )
		return FALSE;

	this->sHw.pPicPblzeSimCore->setCarry ( i_carry );

	this->hwSetZeroFromResult ( i_result );

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdRR ( void )
{
	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	int i_value;

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg, & i_value ) )
		return FALSE;

	//********************************************************************************************************************
	//* Rotate
	//********************************************************************************************************************
	int i_carry  = i_value & 0x01;
	int i_result = ( ( i_value >> 1 ) | ( i_carry << 7 ) ) & 0xFF;

	//********************************************************************************************************************
	//* Set results
	//********************************************************************************************************************
	if ( ! this->sHw.pPicPblzeSimCore->setRegister ( QString_reg, QString_regSubst, i_result & 0xFF ) )
		return FALSE;

	this->sHw.pPicPblzeSimCore->setCarry ( i_carry );

	this->hwSetZeroFromResult ( i_result );

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdSL ( void )
{
	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	int i_value;

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg, & i_value ) )
		return FALSE;

	//********************************************************************************************************************
	//* Shift
	//********************************************************************************************************************
	int i_carry;
	int i_result;

	switch ( this->sHw.psCodeLine_pc->eLineType )
	{
		case eLineType_cmdSl0:
		{
			i_carry  = ( i_value >> 7 ) & 0x01;
			i_result = ( i_value << 1 );
			break;
		}	
		case eLineType_cmdSl1:
		{
			i_carry  = ( i_value >> 7 ) & 0x01;
			i_result = ( i_value << 1 ) | 0x01;
			break;
		}
		case eLineType_cmdSlA:
		{
			int i_carryCur = this->sHw.pPicPblzeSimCore->getCarry ();

			i_carry  = ( i_value >> 7 ) & 0x01;
			i_result = ( i_value << 1 ) | ( i_carryCur & 0x01 );
			break;
		}
		case eLineType_cmdSlX:
		{
			int i_lsb = i_value & 0x01;

			i_carry  = ( i_value >> 7 ) & 0x01;
			i_result = ( ( i_value << 1 ) | i_lsb ) & 0xFF;
			break;
		}
	}
	
	//********************************************************************************************************************
	//* Set result
	//********************************************************************************************************************
	if ( ! this->sHw.pPicPblzeSimCore->setRegister ( QString_reg, QString_regSubst, i_result & 0xFF ) )
		return FALSE;

	this->sHw.pPicPblzeSimCore->setCarry ( i_carry );

	this->hwSetZeroFromResult ( i_result );

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdSR ( void )
{
	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	int i_value;

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg, & i_value ) )
		return FALSE;

	//********************************************************************************************************************
	//* Shift
	//********************************************************************************************************************
	int i_carry;
	int i_result;

	switch ( this->sHw.psCodeLine_pc->eLineType )
	{
		case eLineType_cmdSr0:
		{
			i_carry  = i_value & 0x01;
			i_result = ( i_value >> 1 ) & 0x7F;
			break;
		}
		case eLineType_cmdSr1:
		{
			i_carry  = i_value & 0x01;
			i_result = ( ( i_value >> 1 ) | 0x80 ) & 0xFF;
			break;
		}
		case eLineType_cmdSrA:
		{
			int i_carryCur = this->sHw.pPicPblzeSimCore->getCarry ();

			i_carry  = i_value & 0x01;
			i_result = ( ( i_value >> 1 ) | ( i_carryCur << 7 ) ) & 0xFF;
			break;
		}
		case eLineType_cmdSrX:
		{
			int i_msb = i_value & 0x80;

			i_carry  = i_value & 0x01;
			i_result = ( ( i_value >> 1 ) | i_msb ) & 0xFF;
			break;
		}
	}

	//********************************************************************************************************************
	//* Set result
	//********************************************************************************************************************
	if ( ! this->sHw.pPicPblzeSimCore->setRegister ( QString_reg, QString_regSubst, i_result & 0xFF ) )
		return FALSE;

	this->sHw.pPicPblzeSimCore->setCarry ( i_carry );

	this->hwSetZeroFromResult ( i_result );

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdStore ( void )
{
	//********************************************************************************************************************
	//* Get first argument
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	int i_value;

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg, & i_value ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get second argument
	//********************************************************************************************************************
	int i_addr;

	if ( ! this->simArgPSAddr ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ), & i_addr ) )
		return FALSE;

	//********************************************************************************************************************
	//* Store
	//********************************************************************************************************************
	if ( ! this->sHw.pPicPblzeSimCore->setScrpd ( i_addr, i_value ) )
		return FALSE;

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdSub ( bool b_carryEn )
{
	//********************************************************************************************************************
	//* Get first argument
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	int i_value0;

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg, & i_value0 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get second argument
	//********************************************************************************************************************
	int i_value1;

	if ( ! this->simArgRegNum ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ), & i_value1 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get carry
	//********************************************************************************************************************
	int i_carry = 0;

	if ( b_carryEn )
		i_carry = this->sHw.pPicPblzeSimCore->getCarry ();

	//********************************************************************************************************************
	//* Sub
	//********************************************************************************************************************
	int i_result = i_value0 - i_value1 - i_carry;

	//********************************************************************************************************************
	//* Set result
	//********************************************************************************************************************
	this->hwSetReg ( QString_reg, QString_regSubst, i_result );

	this->hwSetCarryFromResult ( i_result );
	this->hwSetZeroFromResult ( i_result );

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdTest ( bool b_carryEn )
{
	//********************************************************************************************************************
	//* Get first argument
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	int i_value0;

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg, & i_value0 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get second argument
	//********************************************************************************************************************
	int i_value1;

	if ( ! this->simArgRegNum ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ), & i_value1 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get carry
	//********************************************************************************************************************
	int i_zero  = 1;
	int i_carry = 0;

	if ( b_carryEn )
	{
		i_carry = this->sHw.pPicPblzeSimCore->getCarry ();
		i_zero  = this->sHw.pPicPblzeSimCore->getZero ();
	}
	
	//********************************************************************************************************************
	//* Test
	//********************************************************************************************************************
	int i_result = i_value0 & i_value1;

	// Set zero
	if ( i_result == 0 )	i_zero = i_zero & 1; else i_zero = 0;

	// Set carry
	i_carry ^= i_result & 0x01;        i_result >>= 0x01;   // Bit 0
	i_carry ^= i_result & 0x01;        i_result >>= 0x01;   // Bit 1
	i_carry ^= i_result & 0x01;        i_result >>= 0x01;   // Bit 2
	i_carry ^= i_result & 0x01;        i_result >>= 0x01;   // Bit 3
	i_carry ^= i_result & 0x01;        i_result >>= 0x01;   // Bit 4
	i_carry ^= i_result & 0x01;        i_result >>= 0x01;   // Bit 5
	i_carry ^= i_result & 0x01;        i_result >>= 0x01;   // Bit 6
	i_carry ^= i_result & 0x01;                             // Bit 7

	//********************************************************************************************************************
	//* Set result
	//********************************************************************************************************************
	this->sHw.pPicPblzeSimCore->setCarry ( i_carry );
	this->sHw.pPicPblzeSimCore->setZero  ( i_zero  );

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdXOr ( void )
{
	//********************************************************************************************************************
	//* Get first argument
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	int i_value0;

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg, & i_value0 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get second argument
	//********************************************************************************************************************
	int i_value1;

	if ( ! this->simArgRegNum ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ), & i_value1 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Xor
	//********************************************************************************************************************
	int i_result = i_value0 ^ i_value1;

	//********************************************************************************************************************
	//* Set result
	//********************************************************************************************************************
	this->hwSetReg ( QString_reg, QString_regSubst, i_result );

	this->hwSetCarryFromResult ( 0 );
	this->hwSetZeroFromResult ( i_result );

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdRBank ( void )
{
	//********************************************************************************************************************
	//* Get first argument
	//********************************************************************************************************************
	QString QString_arg = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg ).toUpper ();

	if      ( QString_arg == QString ( "A" ) )	this->sHw.pPicPblzeSimCore->setBank ( PicPblzeSimCoreReg::eBankSel_A );
	else if ( QString_arg == QString ( "B" ) )	this->sHw.pPicPblzeSimCore->setBank ( PicPblzeSimCoreReg::eBankSel_B );
	else						return FALSE;

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdStar ( void )
{
	int i_value;

	//********************************************************************************************************************
	//* Get second argument regarding active bank
	//********************************************************************************************************************
	QString QString_regActive;
	QString QString_regActiveSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg );

	if ( ! this->simArgReg ( QString_regActiveSubst, & QString_regActive, & i_value ) )
		return FALSE;

	//********************************************************************************************************************
	//* Toggle bank
	//********************************************************************************************************************
	this->sHw.pPicPblzeSimCore->toggleBank () ;
	
	//********************************************************************************************************************
	//* Set value to register of first argument
	//********************************************************************************************************************
	QString QString_regInactive;
	QString QString_regInactiveSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	if ( ! this->simArgReg ( QString_regInactiveSubst, & QString_regInactive ) )
		return FALSE;

	//********************************************************************************************************************
	//* Load
	//********************************************************************************************************************
	if ( ! this->sHw.pPicPblzeSimCore->setRegister ( QString_regInactive, QString_regInactiveSubst, i_value ) )
		return FALSE;

	//********************************************************************************************************************
	//* Toggle bank
	//********************************************************************************************************************
	this->sHw.pPicPblzeSimCore->toggleBank () ;
	
	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdLoadRet ( void )
{
	//********************************************************************************************************************
	//* Get first argument
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	int i_value0;

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg, & i_value0 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get second argument
	//********************************************************************************************************************
	int i_value1;

	if ( ! this->simArgRegNum ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ), & i_value1 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Load
	//********************************************************************************************************************
	if ( ! this->sHw.pPicPblzeSimCore->setRegister ( QString_reg, QString_regSubst, i_value1 ) )
		return FALSE;

	//********************************************************************************************************************
	//* Return
	//********************************************************************************************************************
	if ( ! this->hwPullPcFromCallstack () )
		return FALSE;

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();
	
	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simCmdHwbld ( void )
{
	//********************************************************************************************************************
	//* Get first argument
	//********************************************************************************************************************
	QString QString_reg;
	QString QString_regSubst = this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg );

	if ( ! this->simArgReg ( QString_regSubst, & QString_reg ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get hwbld value
	//********************************************************************************************************************
	int i_value;

	if ( ! this->sHw.pPicPblzeSimCore->getHwbld ( & i_value ) )
		return FALSE;

	//********************************************************************************************************************
	//* Set result
	//********************************************************************************************************************
	this->hwSetReg ( QString_reg, QString_regSubst, i_value );

	this->sHw.pPicPblzeSimCore->setCarry ( 1 );
	this->hwSetZeroFromResult ( i_value );

	//********************************************************************************************************************
	//* Set program counter
	//********************************************************************************************************************
	this->hwSetPcNext ();

	// Add clock counter offset
	this->sHw.pPicPblzeSimCore->addClkCntr ( 2 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Set hardware
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeSim::hwChkBranch ( QString QString_arg )
{
	QString_arg = QString_arg.toUpper ();

	if ( QString_arg == "C" )
	{
		if ( this->sHw.pPicPblzeSimCore->getCarry () == 1 )
			return TRUE;
	}
	else if ( QString_arg == "NC" )
	{
		if ( this->sHw.pPicPblzeSimCore->getCarry () == 0 )
			return TRUE;
	}
	else if ( QString_arg == "Z" )
	{
		if ( this->sHw.pPicPblzeSimCore->getZero () == 1 )
			return TRUE;
	}
	else if ( QString_arg == "NZ" )
	{
		if ( this->sHw.pPicPblzeSimCore->getZero () == 0 )
			return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::hwSetCarryFromResult ( int i_result )
{
	// Set carry flag
	if ( ( i_result > 255 ) || ( i_result < 0 ) )
		this->sHw.pPicPblzeSimCore->setCarry ( 1 );
	else
		this->sHw.pPicPblzeSimCore->setCarry ( 0 );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::hwSetZeroFromResult ( int i_result )
{
	if ( ( i_result == 0 ) || ( i_result == 256 ) || ( i_result == -256 ) )
		this->sHw.pPicPblzeSimCore->setZero ( 1 );
	else
		this->sHw.pPicPblzeSimCore->setZero ( 0 );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::hwSetReg ( QString QString_reg, QString QString_regSubst, int i_result )
{
	this->sHw.pPicPblzeSimCore->setRegister ( QString_reg, QString_regSubst, i_result & 0xFF );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::hwSetPc ( PicPblzeAsmParser::sCodeLine_t * psCodeLine )
{
	this->sHw.psCodeLine_pc = psCodeLine;
	
	// Move pc to next valid command line if line contains no command
	while ( this->sHw.psCodeLine_pc )
	{
		if ( this->sHw.psCodeLine_pc->eLineType > PicPblzeAsmParser::eLineType_cmd )
			break;
		
		this->sHw.psCodeLine_pc = this->sHw.psCodeLine_pc->psCodeLine_next;
	}
	
	if ( ! this->sHw.psCodeLine_pc )
		return;
	
	switch ( psCodeLine->eMFlag )
	{
		case eMFlag_shared:	this->sHw.pPicPblzeSimCore->setPc ( psCodeLine->i_addr, "Shared" );	break;
		case eMFlag_bank0:	this->sHw.pPicPblzeSimCore->setPc ( psCodeLine->i_addr, "Bank 0" );	break;
		case eMFlag_bank1:	this->sHw.pPicPblzeSimCore->setPc ( psCodeLine->i_addr, "Bank 1" );	break;
		case eMFlag_bank2:	this->sHw.pPicPblzeSimCore->setPc ( psCodeLine->i_addr, "Bank 2" );	break;
		case eMFlag_bank3:	this->sHw.pPicPblzeSimCore->setPc ( psCodeLine->i_addr, "Bank 3" );	break;
		default:		this->sHw.pPicPblzeSimCore->setPc ( psCodeLine->i_addr, "Unset" );	break;
	}
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::hwSetPcNext ( void )
{
	this->hwSetPc ( this->sHw.psCodeLine_pc->psCodeLine_next );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::hwPushPcToCallstack ( void  )
{
	int i_callStackSize = 0;

	switch ( PicPblzeAsmParser::sCfg.ePicDerivate )
	{
		case PicPblzeSet::ePblzeCpld:	i_callStackSize =  4;
		case PicPblzeSet::ePblze:	i_callStackSize = 15;
		case PicPblzeSet::ePblzeII:	i_callStackSize = 31;
		case PicPblzeSet::ePblze3:	i_callStackSize = 31;
		case PicPblzeSet::ePblze6:	i_callStackSize = 31;
	}

	if ( this->sHw.QList_callStack.count() >= i_callStackSize )
	{
		this->msgEmit ( eMsgType_callStackOverflow, this->sHw.psCodeLine_pc );
		return FALSE;
	}

	this->sHw.QList_callStack << this->sHw.psCodeLine_pc;

	if ( this->sHw.psCodeLine_pc->QStringList_args.count() > 1 )
		this->sHw.pPicPblzeSimCoreCallStack->add ( this->sHw.psCodeLine_pc->QStringList_args.at ( eScndArg ) );
	else
		this->sHw.pPicPblzeSimCoreCallStack->add ( this->sHw.psCodeLine_pc->QStringList_args.at ( eFrstArg ) );
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::hwPullPcFromCallstack ( void  )
{
	if ( this->sHw.QList_callStack.count() <= 0 )
	{
		this->msgEmit ( eMsgType_callStackEmpty, this->sHw.psCodeLine_pc );
		return FALSE;
	}
		
	this->sHw.psCodeLine_pc = this->sHw.QList_callStack.last();
		
	this->sHw.psCodeLine_pc = this->sHw.QList_callStack.last();
	this->sHw.QList_callStack.removeLast();

	this->sHw.pPicPblzeSimCoreCallStack->delLast ();
		
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::hwChkInt ( void )
{
	// Check if interrupt requested
	if ( this->sHw.pPicPblzeSimCore->getInt () != PicEdtInterrupt::eIntRequested )
		return TRUE;
	
	// Set interrupt to active
	this->sHw.pPicPblzeSimCore->setInt ( PicEdtInterrupt::eIntActive );
        
	// Backup zero/carry flag
	this->sHw.i_zeroFlagIntBackup = this->sHw.pPicPblzeSimCore->getZero();
	this->sHw.i_carryFlagIntBackup = this->sHw.pPicPblzeSimCore->getCarry();
	
	// Push current pc to callstack
	this->sHw.QList_callStack << this->sHw.psCodeLine_pc;

	// Show ISR in callstack gui
	this->sHw.pPicPblzeSimCoreCallStack->add ( "ISR" );

	// Get interrupt vector
	int i_intVector = PicPblzeAsmParser::sCfg.i_intVector;
	{
		int i_intVectorOffset = 0;
		
		switch ( this->sHw.psCodeLine_pc->eMFlag )
		{
			default:
			case PicPblzeAsmParser::eMFlag_shared:
			{
				// Check intVector
				if ( i_intVector >= PicPblzeAsmParser::sMem.i_memSize )
				{
					PicPblzeAsmParser::msgEmit ( eMsgType_intVectorOor );
					return FALSE;
				}

				PicPblzeAsmParser::sCodeLine_t * psCodeLine_isr = PicPblzeAsmParser::sMem.apsCodeLine_memMap[ i_intVector ];
				
				if ( ! psCodeLine_isr )
				{
					this->msgEmit ( eMsgType_undefinedIsr );
					return FALSE;
				}

				// Check if isr is being located in shared range
				if ( psCodeLine_isr->eMFlag != PicPblzeAsmParser::eMFlag_shared )
				{
					PicPblzeSimIntVectDlg PicPblzeSimIntVectDlg_inst;
					
					int i_bankSel = PicPblzeSimIntVectDlg_inst.getBankSelection ( PicPblzeAsmParser::sCfg.i_memBankCount );
					
					i_intVectorOffset = i_bankSel * PicPblzeAsmParser::sCfg.i_memBankSize;
				}
				
				break;
			}
			case PicPblzeAsmParser::eMFlag_bank0:	i_intVectorOffset = 0;						break;
			case PicPblzeAsmParser::eMFlag_bank1:	i_intVectorOffset = PicPblzeAsmParser::sCfg.i_memBankSize;	break;
			case PicPblzeAsmParser::eMFlag_bank2:	i_intVectorOffset = PicPblzeAsmParser::sCfg.i_memBankSize * 2;	break;
			case PicPblzeAsmParser::eMFlag_bank3:	i_intVectorOffset = PicPblzeAsmParser::sCfg.i_memBankSize * 3;	break;
		}
		
		i_intVector += i_intVectorOffset;
		
		// Check intVector
		if ( i_intVector >= PicPblzeAsmParser::sMem.i_memSize )
		{
			PicPblzeAsmParser::msgEmit ( eMsgType_intVectorOor );
			return FALSE;
		}
	}

	// Jump to interrupt vector
	this->hwSetPc ( PicPblzeAsmParser::sMem.apsCodeLine_memMap[ i_intVector ] );
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Simulate arguments
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simArgReg ( QString Qstring_arg, QString * pQString_reg, int * pi_value )
{
	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( Qstring_arg, pQString_reg ) )
		return FALSE;

	if ( ! pi_value )
		return TRUE;

	//********************************************************************************************************************
	//* Get register content
	//********************************************************************************************************************
	if ( ! this->sHw.pPicPblzeSimCore->getRegister ( *pQString_reg, Qstring_arg, pi_value ) )
		return FALSE;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simArgRegNum ( QString QString_arg, int * pi_value )
{
	//********************************************************************************************************************
	//* Check for number
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgNumberConst ( QString_arg, pi_value ) )
		return TRUE;

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	QString QString_reg;

	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg, & QString_reg ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get register content
	//********************************************************************************************************************
	if ( ! this->sHw.pPicPblzeSimCore->getRegister ( QString_reg, QString_arg, pi_value ) )
		return FALSE;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simArgPSAddr ( QString QString_arg, int * pi_value, QString * pQString_portSubst )
{
	//********************************************************************************************************************
	//* Check for number
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgNumberConst ( QString_arg, pi_value ) )
	{
		if ( pQString_portSubst )
			*pQString_portSubst = QString_arg;

		return TRUE;
	}

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	QString QString_reg;

	if ( ! PicPblzeAsmParser::checkArgAddrByReg ( QString_arg, & QString_reg, pQString_portSubst ) )
		return FALSE;

	//********************************************************************************************************************
	//* Get register content
	//********************************************************************************************************************
	if ( ! this->sHw.pPicPblzeSimCore->getRegister ( QString_reg, QString_arg, pi_value ) )
		return FALSE;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSim::simArgMAddr ( QString QString_arg, PicPblzeAsmParser::sCodeLine_t ** ppsCodeLine )
{
	//********************************************************************************************************************
	//* Check for address
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgRef ( QString_arg, ppsCodeLine ) )
		return TRUE;

	//********************************************************************************************************************
	//* Check for number
	//********************************************************************************************************************
	int i_addr;

	if ( ! PicPblzeAsmParser::checkArgNumber ( QString_arg, & i_addr, PicPblzeAsmParser::sCfg.i_memBankSize ) )
		return FALSE;

	if ( PicPblzeAsmParser::getCodeLineByAddr ( i_addr, ppsCodeLine ) )
		return TRUE;

	return FALSE;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Message handling
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

void PicPblzeSim::msgEmit ( eMsgType_t eMsgType )
{
	Msg * pMsg = new Msg;
	
	this->msgEmit ( pMsg, eMsgType );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::msgEmit ( eMsgType_t eMsgType, sCodeLine_t * psCodeLine )
{
	Msg * pMsg = new Msg;
	
	pMsg->QUrl_srcUrl.setScheme( "file" );
	pMsg->QUrl_srcUrl.setPath ( "/" + PicPblzeAsmParser::msgGetFilePath ( psCodeLine->i_fileNumber ) );
	pMsg->QUrl_srcUrl.setFragment ( QString::number ( psCodeLine->i_lineNumber ) );
	
	this->msgEmit ( pMsg, eMsgType );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSim::msgEmit ( Msg * pMsg, eMsgType_t eMsgType )
{
	QString QString_hlpFragment;
	
	// Set message text
	switch ( eMsgType )
	{
		// Warnings
		case eMsgType_simInteractReq:
			
			QString_hlpFragment	= "simInteractReq";
			pMsg->eStatus 		= Msg::e_warning;
			pMsg->QString_msg 	= tr ( "Set port value for reading" );
			break;
		
		// Error messages
		case eMsgType_simErr:
			
			QString_hlpFragment	= "simErr";		
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Internal error: Simulation error" );
			break;
			
		case eMsgType_simNoMoreCmds:
			
			QString_hlpFragment	= "simNoMoreCmds";		
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "No more commands to execute" );
			break;
			
		case eMsgType_simWrongAddr:
			
			QString_hlpFragment	= "simWrongAddr";	
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Internal error: Wrong address" );
			break;
			
		case eMsgType_callStackOverflow:
			
			QString_hlpFragment	= "callStackOverflow";	
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Callstack overflow" );
			break;
			
		case eMsgType_callStackEmpty:
			
			QString_hlpFragment	= "callStackEmpty";	
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Callstack empty" );
			break;
			
		case eMsgType_undefinedIsr:
			
			QString_hlpFragment	= "undefinedIsr";	
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Interrupt vector references unused memory space!" );
			break;
	}

	pMsg->QUrl_hlpUrl = QUrl ( "qthelp://openPICIDE/openPICIDE/openPICIDE/800_processors/XilinxPicoBlaze/800_messages/index.html" );

	pMsg->QUrl_hlpUrl.setFragment ( QString_hlpFragment );
	
	emit PicPblzeAsmParser::message ( pMsg );
}

/**
 *****************************************************************************************************************************
 */








