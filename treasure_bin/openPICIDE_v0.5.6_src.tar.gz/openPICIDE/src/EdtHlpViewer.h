/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef EDTHLPVIEWER_H
#define EDTHLPVIEWER_H

#include <QtCore>
#include <QtGui>
#include <QtHelp>
#include <QtWebKit>

#include "EdtHlpViewerNetworkAccessManager.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Text editor widget.
 *
 *	This code
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-09-15
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */

class EdtHlpViewer : public QWebView
{
		Q_OBJECT

	public:
		
		/// Constructor.
		/// \param pQWidget_parent	Reference to parent widget
		EdtHlpViewer ( QHelpEngine * pQHelpEngine, QWidget * pQWidget_parent = 0 );
		
		/// Gets if copy capability available
		/// \retval bool		True, if capability available, otherwise false
		bool getCopyAvailable ( void );
		
		/// Sets source to widget
		/// \param QUrl_src		Url to source
		void setSource ( QUrl QUrl_src );
		
		/// Copy selection to clipboard
		void copy ( void );
		
	signals:
		
		/// Signs copy capability
		/// \param pQWidget		Pointer to the widget
		/// \param b_copyAvailable	TRUE, if capability available
		void copyAvailable ( QWidget * pQWidget, bool b_copyAvailable );
		
		/// Signs title changed
		/// \param pQWidget		Pointer to widget
		/// \param QString_title	Title
		void titleChanged  ( QWidget * pQWidget, QString QString_title );

	private:
		
		/// Copy available status
		bool b_copyAvailable;
		
		/// Help engine
		QHelpEngine * pQHelpEngine;
		
		QTextDocument * pQTextDocument;

		
	private slots:
		
		/// Sets copy available status. Will be called by editor widget.
		void setCopyAvailable ( bool b_copyAvailable );
		
		void setTitleChanged ( QString QString_title );
		
		void handleAction ( void );

};

#endif
