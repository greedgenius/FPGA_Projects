/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef MAINGUIELEMENTS_H
#define MAINGUIELEMENTS_H

#include "MainDockAreaL.h"
#include "MainDockAreaR.h"
#include "MainDockAreaB.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Gui elements
 *
 *	Class for handling a collection of gui elements.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */

class Edt;

class MainGuiElements
{

	public:

		/// Status bar indexes
		enum eStatusBarIndex_t
		{
			E_STATUSBAR_EDT =  0,
			E_STATUSBAR_PIC = 10
		};

		/// Pointer to the main window widget
		QMainWindow   * pQMainWindow;

		/// Pointer to the left dock area widget
		MainDockAreaL * pMainDockAreaL;

		/// Pointer to the bottom dock area widget
		MainDockAreaB * pMainDockAreaB;

		/// Pointer to the right dock area widget
		MainDockAreaR * pMainDockAreaR;

		/// Text editor module
		Edt * pEdt;
};

#endif
