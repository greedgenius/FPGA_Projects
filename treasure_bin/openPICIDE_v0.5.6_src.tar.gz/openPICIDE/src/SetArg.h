/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef SetArg_H
#define SetArg_H

#include <QtCore>
#include <QtGui>

/**
 *****************************************************************************************************************************
 *
 *	\brief SetArg class
 *
 *      Contains application settings.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2010-03-26
 *	\version	0.1.0
 *
 *	Change log
 *
 *	2010-03-26
 *		Initialized
 *
 *****************************************************************************************************************************
 */

class SetArg
{
	
	public:

		// Constructor
		SetArg ();

		/// Reads settings from environment
		void parse ( int i_argc, char * pac_argv[] );

};

#endif
 
 
