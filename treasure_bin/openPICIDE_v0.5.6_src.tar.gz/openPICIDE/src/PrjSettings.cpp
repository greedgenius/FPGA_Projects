/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PrjSettings.h"

#include "PrjSettingsXmlV01.h"
#include "PicNone.h"

/**
 *****************************************************************************************************************************
 */

PrjSettings::PrjSettings ()
{
	// Preset processor page settings
	sSettingsPic.QString_picType = PicNone::getName ();
	sSettingsPic.pv_picSettings  = NULL;

	// Preset source page settings
	sSettingsSources.QStringList_srcFiles = QStringList();

}

/**
 *****************************************************************************************************************************
 */

void PrjSettings::setPrjFilePath ( QFileInfo QFileInfo_prjFilePath )
{
	this->QString_prjFile = QFileInfo_prjFilePath.fileName();
	this->QString_prjPath = QFileInfo_prjFilePath.path() + QString ( "/" );
}

/**
 *****************************************************************************************************************************
 */

bool PrjSettings::readSettings ( QString * pQString_errMsg )
{
	QString QString_msg;

	// Reads file
	QFile QFile_prjSettings ( this->QString_prjPath + this->QString_prjFile );

	// Open file
	if ( ! QFile_prjSettings.open ( QIODevice::ReadOnly | QIODevice::Text ) )
	{
		QString_msg = QObject::tr ( "Can't open project file for read access!" );

		if ( pQString_errMsg )
			* pQString_errMsg = QString_msg;
		else
			QMessageBox::critical ( 0, QObject::tr ( "Project file" ), QString_msg, QMessageBox::Ok, QMessageBox::Ok );

		return FALSE;
	}

	QXmlStreamReader QXmlStreamReader_prjSettings ( & QFile_prjSettings );

	// Parse xml stream
	while ( ! QXmlStreamReader_prjSettings.atEnd () )
	{
		QXmlStreamReader_prjSettings.readNext ();

		if ( "project" == QXmlStreamReader_prjSettings.qualifiedName ().toString () )
		{
			QString QString_version = QXmlStreamReader_prjSettings.attributes ().value ( "version" ).toString ();

			switch ( QString_version.toInt () )
			{
				default:

					QString_msg = QObject::tr ( "The project file seems to be generated with a newer version of openPICIDE and can not be opened." );

					if ( pQString_errMsg )
						* pQString_errMsg = QString_msg;
					else
						QMessageBox::critical ( 0, QObject::tr ( "Project file" ), QString_msg, QMessageBox::Ok, QMessageBox::Ok );

					QFile_prjSettings.close();
					return FALSE;

				case 1:

					PrjSettingsXmlV01 * pPrjSettingsXmlV01 = new PrjSettingsXmlV01;

					pPrjSettingsXmlV01->rdXml ( & QXmlStreamReader_prjSettings, this );

					break;
			}
		}
	}

	// Closes file
	QFile_prjSettings.close();

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PrjSettings::saveSettings ( QString * pQString_errMsg )
{
	QString QString_xml;

	// Generates xml stream
	PrjSettingsXmlV01 PrjSettingsXmlV01_tmp;
	{
		PrjSettingsXmlV01_tmp.wrXml ( & QString_xml, this );
	}

	// Writes xml string to file
	QFile QFile_prjSettings ( QString ( this->QString_prjPath + this->QString_prjFile ) );
	{
		// Write settings to file
		if ( ! QFile_prjSettings.open ( QIODevice::WriteOnly | QIODevice::Text ) )
		{
			QString QString_msg = QObject::tr ( "Can't open project file for write access!" );

			if ( pQString_errMsg )
				* pQString_errMsg = QString_msg;
			else
				QMessageBox::critical ( 0, QObject::tr ( "Project file" ), QString_msg, QMessageBox::Ok, QMessageBox::Ok );

			return FALSE;
		}

		QFile_prjSettings.seek ( 0 );

		QFile_prjSettings.write ( QString_xml.toUtf8().data() );

		QFile_prjSettings.close();
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

void PrjSettings::deleteSettings ( void )
{
	if ( sSettingsPic.pv_picSettings )
	{
		delete sSettingsPic.pv_picSettings;
		sSettingsPic.pv_picSettings = NULL;
	}
}

/**
 *****************************************************************************************************************************
 */

void PrjSettings::printSettings ( void )
{
//      qDebug() << QString_prjPath;
//      qDebug() << QString_prjFile;

	qDebug() << sSettingsPic.QString_picType;
	qDebug() << sSettingsSources.QStringList_srcFiles;
	qDebug() << sSettingsEditor.b_dynamicWordWrapEn;
	qDebug() << sSettingsEditor.i_tabIndent;
}

/**
 *****************************************************************************************************************************
 */

QString PrjSettings::getRelativeFilePath ( QString QString_absoluteFilePath )
{
	QDir QDir_prj ( this->QString_prjPath );

	return QDir_prj.relativeFilePath ( QString_absoluteFilePath );
}

/**
 *****************************************************************************************************************************
 */

QString PrjSettings::getAbsoluteFilePath ( QString QString_relativeFilePath )
{
	QDir QDir_prj ( this->QString_prjPath );

	return QDir_prj.absoluteFilePath ( QString_relativeFilePath );
}

/**
 *****************************************************************************************************************************
 */
