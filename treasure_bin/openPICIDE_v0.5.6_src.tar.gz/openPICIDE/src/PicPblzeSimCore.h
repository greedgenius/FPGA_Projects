/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PicPblzeSimCore_H
#define PicPblzeSimCore_H

#include <QtCore>
#include <QtGui>


#include "PicEdtInteger.h"
#include "PicPblzeSet.h"
#include "PicPblzeSimCoreFlag.h"
#include "PicPblzeSimCoreReg.h"
#include "PicPblzeSimCoreScrpd.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Xilinx PicoBlaze (tm) core widget.
 *
 *	The widget contains Zero and Carry flag, an interrupt status, the registers and the scratch pad.
 *	The widget is located in the left dock widget.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class PicPblzeSimCore : public QWidget
{
		Q_OBJECT

	public:

		/// Core configuration
		struct sCfg_t
		{
			int i_regCountA;
			int i_regCountB;
			int i_scrpdSize;
			bool b_hwbuildEn;
			
		} sCfg;
		
		/// Constructor.
		/// \param i_regCountA		Register count for bank A
		/// \param i_regCountB		Register count for bank B
		/// \param i_scrpdSize		Scratch pad size
		/// \param pQObject_parent	Pointer to parent widget
		PicPblzeSimCore ( sCfg_t sCfg, QWidget * pQWidget_parent = 0 );

		/// Destructor, tidies up
		~PicPblzeSimCore ();

		/// Sets base.
		/// \param i_base	Integer base
		void setBase ( int i_base );

		/// Sets carry bit
		/// \param i_value	Carry bit
		void setCarry ( int i_value );

		/// Gets carry bit
		/// \retval bool	Carry bit
		bool getCarry ( void );

		/// Sets zero bit
		/// \param i_value	Zero bit
		void setZero ( int i_value );

		/// Gets zero bit
		/// \retval bool	Zero bit
		bool getZero ( void );

		/// Sets interrupt status
		/// \param eInt		Interrupt status
		void setInt ( PicEdtInterrupt::eInt_t eInt );

		/// Gets interrupt status
		/// \retval PicEdtInterrupt::eInt_t	Interrupt status
		PicEdtInterrupt::eInt_t getInt ( void );
		
		/// Selects register bank
		/// \param eBankSel		Bank
		/// \retval bool		True if success, otherwise false
		bool setBank ( PicPblzeSimCoreReg::eBankSel_t eBankSel );
		
		/// Toggles register bank
		/// \retval bool		True if success, otherwise false
		bool toggleBank ( void );
		
		/// Sets register
		/// \param QString_regName	Register name
		/// \param QString_regSubst	Register substitute
		/// \param i_value		Register value
		/// \retval bool		True, if success, otherwise false
		bool setRegister ( QString QString_regName, QString QString_regSubst, int i_value );

		/// Gets register
		/// \param QString_regName	Register name
		/// \param QString_regSubst	Register substitute
		/// \param pi_value		Register value
		/// \retval bool		True, if success, otherwise false
		bool getRegister ( QString QString_regName, QString QString_regSubst, int * pi_value );

		/// Sets scratch pad
		/// \param i_addr		Scratch pad address
		/// \param i_value		Scratch pad value
		/// \retval bool		True, if success, otherwise false
		bool setScrpd ( int i_addr, int i_value );

		/// Gets scratch pad
		/// \param i_addr		Scratch pad address
		/// \param pi_value		Scratch pad value
		/// \retval bool		True, if success, otherwise false
		bool getScrpd ( int i_addr, int * pi_value );

		/// Clears highlighting
		void clearHighlighted ( void );

		/// Clears all
		void clear ( void );

		/// Sets program counter
		/// \param i_pc			Program counter
		/// \param QString_memRange	Memory range
		void setPc ( int i_pc, QString QString_memRange );

		/// \param pi_pc		Returned program counter
		/// \return bool		True, if program counter value is valid, otherwise false
		bool getPc ( int * pi_pc );

		/// Sets maximum program counter
		/// \param i_maxPc		Maximum program counter
		void setMaxPc ( int i_maxPc );

		/// Returns minimum size hint
		/// \retval QSize		Minimum size hint
		QSize minimumSizeHint ( void );
		
		/// Sets hwbuild value
		/// \param i_value		HWBuild value
		/// \retval bool		TRUE if hwbuild value is being valid, otherwise false
		bool setHwbld ( int i_value );

		/// Sets hwbuild value
		/// \param pi_value		Reference to return HWBuild value
		/// \retval bool		TRUE if hwbuild value is being valid, otherwise false
		bool getHwbld ( int * pi_value );
		
		/// Sets clock counter value
		/// \param i_clkCntOffset	Clock counter offset value
		void addClkCntr ( int i_clkCntOffset );

	public slots:
		
		/// Clears clock counter value
		void clearClkCntr ( void );
		
	signals:

		/// Signs that content changed
		/// \param pQWidget		Reference to itself
		void contentChanged ( QWidget * pQWidget );

	private:
		
		PicEdtInteger * pPicEdtInteger_clkCntr;

		/// Widget containing carry flag, zero flag and interrupt status
		PicPblzeSimCoreFlag  * pPicPblzeSimCoreFlag;

		/// Widget containting processor register
		PicPblzeSimCoreReg   * pPicPblzeSimCoreReg;

		/// Widget containing scratch pad
		PicPblzeSimCoreScrpd * pPicPblzeSimCoreScrpd;

		/// Sets line between widgets
		/// \retval QFrame*	Line widget
		QFrame * setLine ( void );

		/// Program counter
		PicEdtInteger * pPicEdtInteger_pc;
		
		/// Memory range indicator
		QLabel * pQLabel_memRange;
		
		PicEdtInteger * pPicEdtInteger_hwbld;
};

#endif
