/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblze.h"
#include "PicPblzeSet.h"
#include "Edt.h"
#include "MainDockAreaB.h"
#include "StatusBar.h"
#include "SetPrj.h"
#include "PicPblzeMMViewer.h"

/**
 *****************************************************************************************************************************
 */

QString PicPblze::getName ( void )
{
	return QString ( "Xilinx PicoBlaze family" );
}

/**
 *****************************************************************************************************************************
 */

PicPblze::PicPblze ( Mod * pMod, QObject * pQObject_parent ) : PicNone ( pMod, pQObject_parent )
{
	// Init
	this->pMod             = pMod;
	this->pPicMsgBrowser   = NULL;
	this->pPicPblzeSim     = NULL;

	this->createActions();
	this->createMenus();
	this->createToolBars();
	this->createDockWidgets();

	// Setup status bar
	{
		this->pQWidget_statusBar = new QWidget;
		{
			QHBoxLayout * pQHBoxLayout = new QHBoxLayout;
			{
				this->pQLabel_picDerivate    = new QLabel;
				this->pQLabel_instCountBank0 = new QLabel;
				this->pQLabel_instCountBank1 = new QLabel;
				this->pQLabel_instCountBank2 = new QLabel;
				this->pQLabel_instCountBank3 = new QLabel;
				this->pQLabel_instCountShared = new QLabel;
				{
					this->setGuiInstCount ();
				}

				this->pQLabel_pcFromCursor = new QLabel;
				{
					this->setGuiPcFromCursor ( -1 );
				}
		
				this->pQLabel_simStatus = new QLabel;
				{
					this->setSimStatus ( eDisabled );
				}
				
// 				pQHBoxLayout->addWidget ( this->pMod->pStatusBar->getWidgetFrame ( this->pQLabel_picDerivate ) );
				pQHBoxLayout->addWidget ( this->pQLabel_picDerivate );
				pQHBoxLayout->addSpacing ( 10 );
				pQHBoxLayout->addWidget ( this->pQLabel_instCountBank0 );
				pQHBoxLayout->addSpacing ( 10 );
				pQHBoxLayout->addWidget ( this->pQLabel_instCountBank1 );
				pQHBoxLayout->addSpacing ( 10 );
				pQHBoxLayout->addWidget ( this->pQLabel_instCountBank2 );
				pQHBoxLayout->addSpacing ( 10 );
				pQHBoxLayout->addWidget ( this->pQLabel_instCountBank3 );
				pQHBoxLayout->addSpacing ( 10 );
				pQHBoxLayout->addWidget ( this->pQLabel_instCountShared );
				pQHBoxLayout->addSpacing ( 10 );
				pQHBoxLayout->addWidget ( this->pQLabel_pcFromCursor );
				pQHBoxLayout->addSpacing ( 10 );
				pQHBoxLayout->addWidget ( this->pQLabel_simStatus );
			}
			this->pQWidget_statusBar->setLayout( pQHBoxLayout );
		}
		this->pMod->pStatusBar->insertPermanentWidget ( 1, this->pQWidget_statusBar );
	}
	
	this->changeSettings ();
}

/**
 *****************************************************************************************************************************
 */

PicPblze::~PicPblze()
{
	this->removeMenus();
	this->removeToolBars();

	if ( this->pPicMsgBrowser )
	{
		this->pMod->pMainDockAreaB->removeWidget ( this->pPicMsgBrowser );
		delete this->pPicMsgBrowser;
	}

	if ( this->pPicPblzeSim )
		delete this->pPicPblzeSim;
	
	if ( this->pQWidget_statusBar )
		delete this->pQWidget_statusBar;
	
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::createActions ( void )
{
	// Check code
	this->pQAction_chkSyntax = new QAction ( QIcon ( ":/pic/img/pic/chkDocument.png" ), tr ( "Check syntax" ), this );
	this->pQAction_chkSyntax->setShortcut ( QKeySequence ( QString ( "F7" ) ) );
	this->pQAction_chkSyntax->setStatusTip ( tr ( "Check syntax" ) );
	connect ( this->pQAction_chkSyntax, SIGNAL ( triggered() ), this, SLOT ( chkSyntax() ) );

	// Compile code
	this->pQAction_compileToVhdl = new QAction ( QIcon ( ":/pic/img/pic/output-vhdl.png" ), tr ( "Compile to VHDL" ), this );
	this->pQAction_compileToVhdl->setShortcut ( QKeySequence ( QString ( "F8" ) ) );
	this->pQAction_compileToVhdl->setStatusTip ( tr ( "Compile to VHDL" ) );
	connect ( this->pQAction_compileToVhdl, SIGNAL ( triggered() ), this, SLOT ( compileToVhdl() ) );

	this->pQAction_compileToVerilog = new QAction ( QIcon ( ":/pic/img/pic/output-verilog.png" ), tr ( "Compile to Verilog" ), this );
	this->pQAction_compileToVerilog->setShortcut ( QKeySequence ( QString ( "F9" ) ) );
	this->pQAction_compileToVerilog->setStatusTip ( tr ( "Compile to Verilog" ) );
	connect ( this->pQAction_compileToVerilog, SIGNAL ( triggered() ), this, SLOT ( compileToVerilog() ) );
	
	this->pQAction_compileToMem = new QAction ( QIcon ( ":/pic/img/pic/output-mem.png" ), tr ( "Compile to MEM" ), this );
	this->pQAction_compileToMem->setShortcut ( QKeySequence ( QString ( "F10" ) ) );
	this->pQAction_compileToMem->setStatusTip ( tr ( "Compile to MEM" ) );
	connect ( this->pQAction_compileToMem, SIGNAL ( triggered() ), this, SLOT ( compileToMem() ) );

	this->pQAction_compileToHex = new QAction ( QIcon ( ":/pic/img/pic/output-hex.png" ), tr ( "Compile to HEX" ), this );
	this->pQAction_compileToHex->setShortcut ( QKeySequence ( QString ( "F11" ) ) );
	this->pQAction_compileToHex->setStatusTip ( tr ( "Compile to HEX" ) );
	connect ( this->pQAction_compileToHex, SIGNAL ( triggered() ), this, SLOT ( compileToHex() ) );

	this->pQAction_generateMMFile = new QAction ( QIcon (), tr ( "Generate memory mapping file" ), this );
// 	this->pQAction_generateMMFile->setShortcut ( QKeySequence ( QString ( "F11" ) ) );
	this->pQAction_generateMMFile->setStatusTip ( tr ( "Generate memory mapping file" ) );
	connect ( this->pQAction_generateMMFile, SIGNAL ( triggered() ), this, SLOT ( generateMMFile() ) );

	// Simulator
	{
		this->pQAction_simEn = new QAction ( QIcon ( ":/pic/img/pic/simEn.png" ), tr ( "Enable simulator" ), this );
// 		this->pQAction_simEn->setShortcut ( QKeySequence ( QString ( "F9" ) ) );
		this->pQAction_simEn->setStatusTip ( tr ( "Enable simulator" ) );
		connect ( this->pQAction_simEn, SIGNAL ( triggered() ), this, SLOT ( simEn() ) );
	
		this->pQAction_simRun = new QAction ( QIcon ( ":/pic/img/pic/simRun.png" ), tr ( "Run" ), this );
// 		this->pQAction_simRun->setShortcut ( QKeySequence ( QString ( "F9" ) ) );
		this->pQAction_simRun->setStatusTip ( tr ( "Run" ) );
		this->pQAction_simRun->setEnabled ( FALSE );
		this->pQAction_simRun->setCheckable ( TRUE );
		connect ( this->pQAction_simRun, SIGNAL ( triggered() ), this, SLOT ( simRun() ) );
	
		this->pQAction_simNextLine = new QAction ( QIcon ( ":/pic/img/pic/simNext.png" ), tr ( "Next line" ), this );
// 		this->pQAction_simNextLine->setShortcut ( QKeySequence ( QString ( "F10" ) ) );
		this->pQAction_simNextLine->setStatusTip ( tr ( "Next line" ) );
		this->pQAction_simNextLine->setEnabled ( FALSE );
		this->pQAction_simNextLine->setCheckable ( TRUE );
		connect ( this->pQAction_simNextLine, SIGNAL ( triggered() ), this, SLOT ( simNextLine() ) );

		this->pQAction_simNextInstruction = new QAction ( QIcon ( ":/pic/img/pic/simNextLine.png" ), tr ( "Next instruction" ), this );
// 		this->pQAction_simNextInstruction->setShortcut ( QKeySequence ( QString ( "F11" ) ) );
		this->pQAction_simNextInstruction->setStatusTip ( tr ( "Next instruction" ) );
		this->pQAction_simNextInstruction->setEnabled ( FALSE );
		connect ( this->pQAction_simNextInstruction, SIGNAL ( triggered() ), this, SLOT ( simNextInstruction() ) );
	
		this->pQAction_simToEndOfCall = new QAction ( QIcon ( ":/pic/img/pic/simToEndOfCall.png" ), tr ( "Simulate to end of call" ), this );
// 		this->pQAction_simToEndOfCall->setShortcut ( QKeySequence ( QString ( "F12" ) ) );
		this->pQAction_simToEndOfCall->setStatusTip ( tr ( "Simulate to end of call" ) );
		this->pQAction_simToEndOfCall->setEnabled ( FALSE );
		this->pQAction_simToEndOfCall->setCheckable ( TRUE );
		connect ( this->pQAction_simToEndOfCall, SIGNAL ( triggered() ), this, SLOT ( simToEndOfCall() ) );

		this->pQAction_simInt = new QAction ( QIcon ( ":/pic/img/pic/simInt.png" ), tr ( "Interrupt" ), this );
// 		this->pQAction_simInt->setShortcut ( QKeySequence ( QString ( "F11" ) ) );
		this->pQAction_simInt->setStatusTip ( tr ( "Interrupt" ) );
		this->pQAction_simInt->setEnabled ( FALSE );
		connect ( this->pQAction_simInt, SIGNAL ( triggered() ), this, SLOT ( simInt() ) );
	
		this->pQAction_simRst = new QAction ( QIcon ( ":/pic/img/pic/simRestart.png" ), tr ( "Reset" ), this );
// 		this->pQAction_simRst->setShortcut ( QKeySequence ( QString ( "F12" ) ) );
		this->pQAction_simRst->setStatusTip ( tr ( "Reset" ) );
		this->pQAction_simRst->setEnabled ( FALSE );
		connect ( this->pQAction_simRst, SIGNAL ( triggered() ), this, SLOT ( simRst() ) );

		this->pQAction_simReload = new QAction ( QIcon ( ":/pic/img/pic/simReload.png" ), tr ( "Reload code" ), this );
		this->pQAction_simReload->setStatusTip ( tr ( "Reload code" ) );
		this->pQAction_simReload->setEnabled ( FALSE );
		connect ( this->pQAction_simReload, SIGNAL ( triggered() ), this, SLOT ( simReload() ) );
	
		this->pQAction_setPcFromCursor = new QAction ( QIcon ( ":/pic/img/pic/simSetPc.png" ), tr ( "Set program counter from text cursor" ), this );
		this->pQAction_setPcFromCursor->setStatusTip ( tr ( "Set program counter from text cursor" ) );
		this->pQAction_setPcFromCursor->setEnabled ( FALSE );
		connect ( this->pQAction_setPcFromCursor, SIGNAL ( triggered() ), this, SLOT ( setPcFromCursor() ) );
	}

	// Set format dec
	this->pQAction_setBaseDec = new QAction ( QIcon ( ":/pic/img/pic/baseDec.png" ), tr ( "Dec" ), this );
	this->pQAction_setBaseDec->setStatusTip ( tr ( "Dec" ) );
	this->pQAction_setBaseDec->setEnabled ( FALSE );
	connect ( this->pQAction_setBaseDec, SIGNAL ( triggered() ), this, SLOT ( setBaseDec() ) );

	// Set format hex
	this->pQAction_setBaseHex = new QAction ( QIcon ( ":/pic/img/pic/baseHex.png" ), tr ( "Hex" ), this );
	this->pQAction_setBaseHex->setStatusTip ( tr ( "Hex" ) );
	this->pQAction_setBaseHex->setEnabled ( FALSE );
	connect ( this->pQAction_setBaseHex, SIGNAL ( triggered() ), this, SLOT ( setBaseHex() ) );

	// Set format oct
	this->pQAction_setBaseOct = new QAction ( QIcon ( ":/pic/img/pic/baseOct.png" ), tr ( "Oct" ), this );
	this->pQAction_setBaseOct->setStatusTip ( tr ( "Oct" ) );
	this->pQAction_setBaseOct->setEnabled ( FALSE );
	connect ( this->pQAction_setBaseOct, SIGNAL ( triggered() ), this, SLOT ( setBaseOct() ) );

}

/**
 *****************************************************************************************************************************
 */

void PicPblze::createMenus ( void )
{
	this->pQMenu = new QMenu ( QString ( "Pico&Blaze" ) );
	this->pQMenu->addAction ( this->pQAction_chkSyntax );
	this->pQMenu->addAction ( this->pQAction_compileToVhdl );
	this->pQMenu->addAction ( this->pQAction_compileToVerilog );
	this->pQMenu->addAction ( this->pQAction_compileToMem );
	this->pQMenu->addAction ( this->pQAction_compileToHex );
	this->pQMenu->addAction ( this->pQAction_generateMMFile );
	this->pQMenu->addAction ( this->pQAction_simEn );

	this->pQMenu->addSeparator ();

	this->pQMenu->addAction ( this->pQAction_simRun );
	this->pQMenu->addAction ( this->pQAction_simNextLine );
	this->pQMenu->addAction ( this->pQAction_simNextInstruction );
	this->pQMenu->addAction ( this->pQAction_simToEndOfCall );
	this->pQMenu->addAction ( this->pQAction_simInt );

	this->pQMenu->addSeparator ();

	this->pQMenu->addAction ( this->pQAction_simReload );
	this->pQMenu->addAction ( this->pQAction_simRst );
	this->pQMenu->addAction ( this->pQAction_setPcFromCursor );

	this->pQMenu->addSeparator ();

	this->pQMenu->addAction ( this->pQAction_setBaseDec );
	this->pQMenu->addAction ( this->pQAction_setBaseHex );
	this->pQMenu->addAction ( this->pQAction_setBaseOct );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::removeMenus ( void )
{
	if ( this->pQMenu )
		delete this->pQMenu;

	this->pQMenu = NULL;
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::setupMenuBar ( QMenuBar * pQMenuBar )
{
	pQMenuBar->addMenu ( this->pQMenu );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::createToolBars ( void )
{
	this->pQToolBar = this->pMod->pQMainWindow->addToolBar ( tr ( "Pic" ) );
	this->pQToolBar->addAction ( this->pQAction_chkSyntax );
	this->pQToolBar->addAction ( this->pQAction_compileToVhdl );
	this->pQToolBar->addAction ( this->pQAction_compileToVerilog );
	this->pQToolBar->addAction ( this->pQAction_compileToMem );
	this->pQToolBar->addAction ( this->pQAction_compileToHex );
	this->pQToolBar->addAction ( this->pQAction_simEn );

	this->pQToolBar->addSeparator ();

	this->pQToolBar->addAction ( this->pQAction_simRun );
	this->pQToolBar->addAction ( this->pQAction_simNextLine );
	this->pQToolBar->addAction ( this->pQAction_simNextInstruction );
	this->pQToolBar->addAction ( this->pQAction_simToEndOfCall );
	this->pQToolBar->addAction ( this->pQAction_simInt );

	this->pQToolBar->addSeparator ();

	this->pQToolBar->addAction ( this->pQAction_simReload );
	this->pQToolBar->addAction ( this->pQAction_simRst );
	this->pQToolBar->addAction ( this->pQAction_setPcFromCursor );

	this->pQToolBar->addSeparator ();

	this->pQToolBar->addAction ( this->pQAction_setBaseDec );
	this->pQToolBar->addAction ( this->pQAction_setBaseHex );
	this->pQToolBar->addAction ( this->pQAction_setBaseOct );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::removeToolBars ( void )
{
	this->pMod->pQMainWindow->removeToolBar ( this->pQToolBar );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::createDockWidgets ( void )
{
	// Setup Msg browser dock widget
	this->pPicMsgBrowser = new PicMsgBrowser;
	
	connect ( this->pPicMsgBrowser,  SIGNAL ( lineClicked ( QUrl ) ), this, SLOT ( msgHndlClick ( QUrl ) ) );

	this->pMod->pMainDockAreaB->addWidget ( QString ( "Messages" ), this->pPicMsgBrowser );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::changeSettings ( void )
{
	if ( ! this->pMod->pSet->Prj.sPic.pv_picSet )
		return;

	this->pPicPblzeSet = static_cast<PicPblzeSet *> ( this->pMod->pSet->Prj.sPic.pv_picSet );

	// Set picDerivate name
	this->pQLabel_picDerivate->setText ( "<b>Derivate:</b> " + this->pPicPblzeSet->getDerivateName ( this->pPicPblzeSet->ePicDerivate ) );
	
	// Enable/disable verilog compilation
	if ( this->pPicPblzeSet->ePicDerivate == PicPblzeSet::ePblzeCpld )
		this->pQAction_compileToVerilog->setEnabled ( FALSE );
	else
		this->pQAction_compileToVerilog->setEnabled ( TRUE );

	if ( this->pPicPblzeSet->ePicDerivate == PicPblzeSet::ePblze )
		this->pQAction_compileToVerilog->setEnabled ( FALSE );
	else
		this->pQAction_compileToVerilog->setEnabled ( TRUE );
	
	// Set highlighting rules to editor
	{
		EdtEditorHighlighter::sHighlightingKeyWords_t sHighlightingKeyWords;

		PicPblzeSet::ePicDerivate_t ePicDerivate;

		ePicDerivate   = this->pPicPblzeSet->ePicDerivate;

		sHighlightingKeyWords.QStringList_cmd		= PicPblzeAsmParser::getCmdList         ( ePicDerivate );
		sHighlightingKeyWords.QStringList_directive	= PicPblzeAsmParser::getDirectiveList   ( ePicDerivate );
		sHighlightingKeyWords.QStringList_hwComponent	= PicPblzeAsmParser::getHwComponentList ( ePicDerivate );
		sHighlightingKeyWords.QMap_numberRegExp		= PicPblzeAsmParser::getNumberRegExp    ( ePicDerivate );

		this->pMod->pEdt->setHighlightingParameter ( sHighlightingKeyWords );
	}

	if ( this->pPicPblzeSim )
		this->simEn ();
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::chkSyntax ( void )
{
	this->pMod->pEdt->saveAll ();
	
	this->pPicMsgBrowser->clearMsgList ();
	this->pMod->pEdt->clearLineSelections ();

	this->pMod->pMainDockAreaB->setHidden ( FALSE );

	PicPblzeAsmParser * pPicPblzeAsmParser = new PicPblzeAsmParser;
	{
		connect ( pPicPblzeAsmParser, SIGNAL ( message ( Msg * ) ), this, SLOT ( msgSet ( Msg * ) ) ); }

	bool b_retVal = TRUE;

	// Set parameter
	if ( b_retVal )
	{
		PicPblzeAsmParser::sCfg_t sCfg_asmParser;

		sCfg_asmParser.i_intVector		= this->pPicPblzeSet->i_intVector;
		sCfg_asmParser.i_memBankCount		= this->pPicPblzeSet->i_memBankCount;
		sCfg_asmParser.i_memBankSize		= this->pPicPblzeSet->i_memBankSize;
		sCfg_asmParser.i_scrpdSize		= this->pPicPblzeSet->i_scrpdSize;
		
		sCfg_asmParser.ePicDerivate		= this->pPicPblzeSet->ePicDerivate;
		sCfg_asmParser.eMemSharedLoc		= this->pPicPblzeSet->eMemSharedLoc;
		sCfg_asmParser.QStringList_filePath 	= this->pMod->pSet->Prj.sSrc.QStringList_srcFiles;
		
		b_retVal = pPicPblzeAsmParser->setCfg ( sCfg_asmParser );
	}

	// Parse code lines
	if ( b_retVal )
		b_retVal = pPicPblzeAsmParser->parse();

	// Set memory usage
	this->setGuiInstCount ( pPicPblzeAsmParser->getInstCount () );

	disconnect ( pPicPblzeAsmParser, SIGNAL ( message ( Msg * ) ), this, SLOT ( msgSet ( Msg * ) )
	);

	// Get pc from code line
	{
		QString QString_filePath;
		int i_fileNumber;
		int i_pc;

		if ( this->pMod->pEdt->getLineFromCursor ( & QString_filePath, & i_fileNumber ) )
		{
			pPicPblzeAsmParser->getPcFromCodeLine ( QString_filePath, i_fileNumber, & i_pc );
		
			this->setGuiPcFromCursor ( i_pc );
		}
	}
	
	delete pPicPblzeAsmParser;
}

/**
 *****************************************************************************************************************************
 */

QString PicPblze::getPathViaDialog ( QString QString_title, QString QString_nameFilter, QString QString_defaultSuffix, QString QString_defaultPath )
{
	QFileDialog QFileDialog_path;
	{
		QFileDialog_path.setViewMode ( QFileDialog::Detail );
		QFileDialog_path.setConfirmOverwrite ( TRUE );
		QFileDialog_path.setDefaultSuffix ( QString_defaultSuffix );
		QFileDialog_path.setAcceptMode ( QFileDialog::AcceptSave );
		QFileDialog_path.setWindowTitle ( QString_title );
		QFileDialog_path.setNameFilter ( QString_nameFilter );
		QFileDialog_path.setFileMode ( QFileDialog::AnyFile );
	}

	if ( ! QString_defaultPath.isEmpty () )
	{
		QFileDialog_path.setDirectory ( QString_defaultPath );
		QFileDialog_path.selectFile   ( QString_defaultPath );
	}
	else
	{
		QFileDialog_path.selectFile ( this->pPicPblzeSet->QString_entityName );
	}
	
	if ( ! QFileDialog_path.exec () )
		return QString ();
	
	QStringList QStringList_pathes = QFileDialog_path.selectedFiles ();

	if ( QStringList_pathes.count () != 1 )
		return QString ();

	return QStringList_pathes.at ( 0 );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::compileToVhdl ( void )
{
	this->pMod->pEdt->saveAll ();
	
	// Init dialog
	QFileDialog QFileDialog_outputPath;
	{
		QFileDialog_outputPath.setViewMode ( QFileDialog::Detail );
		QFileDialog_outputPath.setConfirmOverwrite ( TRUE );
		QFileDialog_outputPath.setDefaultSuffix ( QString ( "vhd" ) );
		QFileDialog_outputPath.setAcceptMode ( QFileDialog::AcceptSave );
		QFileDialog_outputPath.setWindowTitle ( tr ( "Select vhdl output file" ) );
		QFileDialog_outputPath.setNameFilter ( tr ( "VHDL files (*.vhd)" ) );
		QFileDialog_outputPath.setFileMode ( QFileDialog::AnyFile );
	}

	if ( ! this->pPicPblzeSet->QString_vhdlOutputFile.isEmpty () )
	{
		QFileDialog_outputPath.setDirectory ( this->pPicPblzeSet->QString_vhdlOutputFile );
		QFileDialog_outputPath.selectFile ( this->pPicPblzeSet->QString_vhdlOutputFile );
	}
	else
	{
		QFileDialog_outputPath.selectFile ( this->pPicPblzeSet->QString_entityName );
	}

	if ( ! QFileDialog_outputPath.exec () )
		return;

	QStringList QStringList_outputPathes = QFileDialog_outputPath.selectedFiles ();

	if ( QStringList_outputPathes.count () != 1 )
		return;

	this->pPicPblzeSet->QString_vhdlOutputFile = QStringList_outputPathes.at ( 0 );
	this->pMod->pSet->Prj.setDirty ();
	
	compile ( PicPblzeCmplr::E_OUT_VHDL, 
		  this->pPicPblzeSet->QString_vhdlOutputFile, 
		  this->pPicPblzeSet->QString_vhdlTemplateFile );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::compileToVerilog ( void )
{
	this->pMod->pEdt->saveAll ();
	
	// Init dialog
	QFileDialog QFileDialog_outputPath;
	{
		QFileDialog_outputPath.setViewMode ( QFileDialog::Detail );
		QFileDialog_outputPath.setConfirmOverwrite ( TRUE );
		QFileDialog_outputPath.setDefaultSuffix ( QString ( "v" ) );
		QFileDialog_outputPath.setAcceptMode ( QFileDialog::AcceptSave );
		QFileDialog_outputPath.setWindowTitle ( tr ( "Select verilog output file" ) );
		QFileDialog_outputPath.setNameFilter ( tr ( "VHDL files (*.v)" ) );
		QFileDialog_outputPath.setFileMode ( QFileDialog::AnyFile );
	}

	if ( ! this->pPicPblzeSet->QString_verilogOutputFile.isEmpty () )
	{
		QFileDialog_outputPath.setDirectory ( this->pPicPblzeSet->QString_verilogOutputFile );
		QFileDialog_outputPath.selectFile ( this->pPicPblzeSet->QString_verilogOutputFile );
	}
	else
	{
		QFileDialog_outputPath.selectFile ( this->pPicPblzeSet->QString_entityName );
	}

	if ( ! QFileDialog_outputPath.exec () )
		return;

	QStringList QStringList_outputPathes = QFileDialog_outputPath.selectedFiles ();

	if ( QStringList_outputPathes.count () != 1 )
		return;

	this->pPicPblzeSet->QString_verilogOutputFile = QStringList_outputPathes.at ( 0 );
	this->pMod->pSet->Prj.setDirty ();

	this->compile ( PicPblzeCmplr::E_OUT_VERILOG, 
			this->pPicPblzeSet->QString_verilogOutputFile,
			this->pPicPblzeSet->QString_verilogTemplateFile );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::compileToMem ( void )
{
	this->pMod->pEdt->saveAll ();
	
	// Init dialog
	QFileDialog QFileDialog_outputPath;
	{
		QFileDialog_outputPath.setViewMode ( QFileDialog::Detail );
		QFileDialog_outputPath.setConfirmOverwrite ( TRUE );
		QFileDialog_outputPath.setDefaultSuffix ( QString ( "mem" ) );
		QFileDialog_outputPath.setAcceptMode ( QFileDialog::AcceptSave );
		QFileDialog_outputPath.setWindowTitle ( tr ( "Select mem output file" ) );
		QFileDialog_outputPath.setNameFilter ( tr ( "MEM files (*.mem)" ) );
		QFileDialog_outputPath.setFileMode ( QFileDialog::AnyFile );
	}
	
	if ( ! this->pPicPblzeSet->QString_memOutputFile.isEmpty () )
	{
		QFileDialog_outputPath.setDirectory ( this->pPicPblzeSet->QString_memOutputFile );
		QFileDialog_outputPath.selectFile ( this->pPicPblzeSet->QString_memOutputFile );
	}

	if ( ! QFileDialog_outputPath.exec () )
		return;

	QStringList QStringList_outputPathes = QFileDialog_outputPath.selectedFiles ();

	if ( QStringList_outputPathes.count () != 1 )
		return;

	this->pPicPblzeSet->QString_memOutputFile = QStringList_outputPathes.at ( 0 );
	this->pMod->pSet->Prj.setDirty ();

	this->compile ( PicPblzeCmplr::E_OUT_MEM, this->pPicPblzeSet->QString_memOutputFile );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::compileToHex ( void )
{
	this->pMod->pEdt->saveAll ();
	
	// Init dialog
	QFileDialog QFileDialog_outputPath;
	{
		QFileDialog_outputPath.setViewMode ( QFileDialog::Detail );
		QFileDialog_outputPath.setConfirmOverwrite ( TRUE );
		QFileDialog_outputPath.setDefaultSuffix ( QString ( "hex" ) );
		QFileDialog_outputPath.setAcceptMode ( QFileDialog::AcceptSave );
		QFileDialog_outputPath.setWindowTitle ( tr ( "Select hex output file" ) );
		QFileDialog_outputPath.setNameFilter ( tr ( "HEX files (*.hex)" ) );
		QFileDialog_outputPath.setFileMode ( QFileDialog::AnyFile );
	}

	if ( ! this->pPicPblzeSet->QString_hexOutputFile.isEmpty () )
	{
		QFileDialog_outputPath.setDirectory ( this->pPicPblzeSet->QString_hexOutputFile );
		QFileDialog_outputPath.selectFile ( this->pPicPblzeSet->QString_hexOutputFile );
	}

	if ( ! QFileDialog_outputPath.exec () )
		return;

	QStringList QStringList_outputPathes = QFileDialog_outputPath.selectedFiles ();

	if ( QStringList_outputPathes.count () != 1 )
		return;

	this->pPicPblzeSet->QString_hexOutputFile = QStringList_outputPathes.at ( 0 );
	this->pMod->pSet->Prj.setDirty ();

	compile ( PicPblzeCmplr::E_OUT_HEX, this->pPicPblzeSet->QString_hexOutputFile );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::compile ( PicPblzeCmplr::eOutputType_t eOutputType, QString QString_outputFilePath, QString QString_templateFilePath )
{
	this->pPicMsgBrowser->clearMsgList ();
	this->pMod->pEdt->clearLineSelections ();

	this->pMod->pMainDockAreaB->setHidden ( FALSE );

	PicPblzeCmplrPblzeCpld * pPicPblzeCmplrPblzeCpld	= NULL;
	PicPblzeCmplrPblze     * pPicPblzeCmplrPblze		= NULL;
	PicPblzeCmplrPblzeII   * pPicPblzeCmplrPblzeII		= NULL;
	PicPblzeCmplrPblze3    * pPicPblzeCmplrPblze3		= NULL;
	PicPblzeCmplrPblze6    * pPicPblzeCmplrPblze6		= NULL;
	PicPblzeCmplr          * pPicPblzeCmplr			= NULL;

	switch ( this->pPicPblzeSet->ePicDerivate )
	{
		case PicPblzeSet::ePblzeCpld:
			pPicPblzeCmplrPblzeCpld	= new PicPblzeCmplrPblzeCpld;
			pPicPblzeCmplr		= static_cast <PicPblzeCmplr *> ( pPicPblzeCmplrPblzeCpld );
			break;

		case PicPblzeSet::ePblze:
			pPicPblzeCmplrPblze	= new PicPblzeCmplrPblze;
			pPicPblzeCmplr		= static_cast <PicPblzeCmplr *> ( pPicPblzeCmplrPblze );
			break;

		case PicPblzeSet::ePblzeII:
			pPicPblzeCmplrPblzeII	= new PicPblzeCmplrPblzeII;
			pPicPblzeCmplr		= static_cast <PicPblzeCmplr *> ( pPicPblzeCmplrPblzeII );
			break;

		case PicPblzeSet::ePblze3:
			pPicPblzeCmplrPblze3	= new PicPblzeCmplrPblze3;
			pPicPblzeCmplr		= static_cast <PicPblzeCmplr *> ( pPicPblzeCmplrPblze3 );
			break;
			
		case PicPblzeSet::ePblze6:
			pPicPblzeCmplrPblze6	= new PicPblzeCmplrPblze6;
			pPicPblzeCmplr		= static_cast <PicPblzeCmplr *> ( pPicPblzeCmplrPblze6 );
			break;
	}

	connect ( pPicPblzeCmplr, SIGNAL ( message ( Msg * ) ), this, SLOT ( msgSet ( Msg * ) ) );

	// Setup and parse code lines
	bool b_retVal = TRUE;

	// Set parameter
	if ( b_retVal )
	{
		PicPblzeCmplr::sCfg_t sCfg_cmplr;

		sCfg_cmplr.sCfg_asmParser.i_intVector		= this->pPicPblzeSet->i_intVector;
		sCfg_cmplr.sCfg_asmParser.i_memBankCount	= this->pPicPblzeSet->i_memBankCount;
		sCfg_cmplr.sCfg_asmParser.i_memBankSize		= this->pPicPblzeSet->i_memBankSize;
		sCfg_cmplr.sCfg_asmParser.i_scrpdSize		= this->pPicPblzeSet->i_scrpdSize;
		sCfg_cmplr.sCfg_asmParser.ePicDerivate		= this->pPicPblzeSet->ePicDerivate;
		sCfg_cmplr.sCfg_asmParser.eMemSharedLoc		= this->pPicPblzeSet->eMemSharedLoc;
		sCfg_cmplr.sCfg_asmParser.QStringList_filePath 	= this->pMod->pSet->Prj.sSrc.QStringList_srcFiles;
		
		sCfg_cmplr.QString_entityName			= this->pPicPblzeSet->QString_entityName;
		sCfg_cmplr.QString_templateFilePath		= QString_templateFilePath;
		sCfg_cmplr.QString_outputFilePath		= QString_outputFilePath;
		sCfg_cmplr.eOutputType				= eOutputType;

		b_retVal = pPicPblzeCmplr->setCfg ( sCfg_cmplr );
	}

	// Compile code
	if ( b_retVal )
	{
		switch ( this->pPicPblzeSet->ePicDerivate )
		{
			case PicPblzeSet::ePblzeCpld:
				b_retVal = pPicPblzeCmplrPblzeCpld->compile ();
				break;
			case PicPblzeSet::ePblze:
				b_retVal = pPicPblzeCmplrPblze->compile ();
				break;
			case PicPblzeSet::ePblzeII:
				b_retVal = pPicPblzeCmplrPblzeII->compile ();
				break;
			case PicPblzeSet::ePblze3:
				b_retVal = pPicPblzeCmplrPblze3->compile ();
				break;
			case PicPblzeSet::ePblze6:
				b_retVal = pPicPblzeCmplrPblze6->compile ();
				break;
		}
	}

	// Set memory usage
	this->setGuiInstCount ( pPicPblzeCmplr->getInstCount () );

	disconnect ( pPicPblzeCmplr, SIGNAL ( message ( Msg * ) ), this->pPicMsgBrowser, SLOT ( msgSet ( Msg * ) ) );

	if ( pPicPblzeCmplrPblzeCpld )
		delete pPicPblzeCmplrPblzeCpld;

	if ( pPicPblzeCmplrPblze )
		delete pPicPblzeCmplrPblze;

	if ( pPicPblzeCmplrPblzeII )
		delete pPicPblzeCmplrPblzeII;

	if ( pPicPblzeCmplrPblze3 )
		delete pPicPblzeCmplrPblze3;
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::generateMMFile ( void )
{
	this->pMod->pEdt->saveAll ();
	
	// Get file path for output file
/*	QString QString_outputFilePath;
	{
		QFileDialog QFileDialog_outputPath;
		{
			QFileDialog_outputPath.setViewMode ( QFileDialog::Detail );
			QFileDialog_outputPath.setConfirmOverwrite ( TRUE );
			QFileDialog_outputPath.setDefaultSuffix ( QString ( "txt" ) );
			QFileDialog_outputPath.setAcceptMode ( QFileDialog::AcceptSave );
			QFileDialog_outputPath.setWindowTitle ( tr ( "Select text output file" ) );
			QFileDialog_outputPath.setNameFilter ( tr ( "Text files (*.txt)" ) );
			QFileDialog_outputPath.setFileMode ( QFileDialog::AnyFile );
		}

		QFileDialog_outputPath.selectFile ( this->pPicPblzeSet->QString_entityName );

		if ( ! QFileDialog_outputPath.exec () )
			return;

		QStringList QStringList_outputPathes = QFileDialog_outputPath.selectedFiles ();

		if ( QStringList_outputPathes.count () != 1 )
			return;

		QString_outputFilePath = QStringList_outputPathes.at ( 0 );
	}*/
	
	// Get generator instance
	PicPblzeMMViewer * pPicPblzeMMViewer = new PicPblzeMMViewer;
	
	// Clear and set environment
	{
		this->pPicMsgBrowser->clearMsgList ();
		this->pMod->pEdt->clearLineSelections ();

		this->pMod->pMainDockAreaB->setHidden ( FALSE );
		
		connect ( pPicPblzeMMViewer, SIGNAL ( message ( Msg * ) ), this, SLOT ( msgSet ( Msg * ) ) );

	}

	// Setup and parse code lines
	bool b_retVal = TRUE;

	// Set configuraiton
	if ( b_retVal )
	{
		PicPblzeMMViewer::sCfg_t sCfg_mmViewer;

		sCfg_mmViewer.sCfg_asmParser.i_intVector		= this->pPicPblzeSet->i_intVector;
		sCfg_mmViewer.sCfg_asmParser.i_memBankCount		= this->pPicPblzeSet->i_memBankCount;
		sCfg_mmViewer.sCfg_asmParser.i_memBankSize		= this->pPicPblzeSet->i_memBankSize;
		sCfg_mmViewer.sCfg_asmParser.i_scrpdSize		= this->pPicPblzeSet->i_scrpdSize;
		sCfg_mmViewer.sCfg_asmParser.ePicDerivate		= this->pPicPblzeSet->ePicDerivate;
		sCfg_mmViewer.sCfg_asmParser.eMemSharedLoc		= this->pPicPblzeSet->eMemSharedLoc;
		sCfg_mmViewer.sCfg_asmParser.QStringList_filePath 	= this->pMod->pSet->Prj.sSrc.QStringList_srcFiles;
		
// 		sCfg_mmViewer.QString_outputFilePath			= QString_outputFilePath;

		b_retVal = pPicPblzeMMViewer->setCfg ( sCfg_mmViewer );
	}

	// Generate memory map file
/*	if ( b_retVal )
		b_retVal = pPicPblzeMMViewer->generateMemMapFile ();*/
	
/*	if ( b_retVal )
		this->pMod->pEdt->openSrcFile ( QString_outputFilePath );*/
		
	if ( b_retVal )
	{
		QString QString_memMap;
		QString QString_tabName = "Memory map";
		QString QString_filePath = "";
		
		if ( pPicPblzeMMViewer->generateMemMap( & QString_memMap) )
			this->pMod->pEdt->setupSrcFile ( & QString_tabName, & QString_filePath, & QString_memMap );
	}
	
	

	disconnect ( pPicPblzeMMViewer, SIGNAL ( message ( Msg * ) ), this->pPicMsgBrowser, SLOT ( msgSet ( Msg * ) ) );

	if ( pPicPblzeMMViewer )
		delete pPicPblzeMMViewer;
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::simEn ( void )
{
	// Check if simulator instantiated/enabled
	if ( this->pPicPblzeSim )
	{
		if ( this->pPicPblzeSim->getSimStatus () != PicPblzeSim::e_idle )
		{
			this->pPicPblzeSim->simStop ();
			return;
		}

		this->pQAction_simEn->setStatusTip ( tr ( "Enable simulator" ) );
		this->pQAction_simEn->setText ( tr ( "Enable simulator" ) );
		this->pMod->pMainDockAreaB->setHidden ( TRUE );

		disconnect ( this->pPicPblzeSim, SIGNAL ( message ( Msg * ) ), this, SLOT ( msgSet ( Msg * ) ) );

		disconnect (
		    this->pPicPblzeSim,
		    SIGNAL ( selectSrc ( QUrl ) ),
		    this->pMod->pEdt,
		    SLOT ( setupDocument ( QUrl ) )
		);

		disconnect (
		    this->pMod->pEdt,
		    SIGNAL ( breakpointChanged () ),
		    this,
		    SLOT ( setbreakpoints () )
		);

		delete this->pPicPblzeSim;
		this->pPicPblzeSim = NULL;

		this->setSimStatus ( eDisabled );
		this->pMod->pEdt->clearLineSelections ();

		return;
	}

	this->pMod->pEdt->saveAll ();
	
	this->pPicMsgBrowser->clearMsgList ();

	// Initialize simulator
	this->pPicPblzeSim = new PicPblzeSim ( this->pMod );
	{
		connect ( this->pPicPblzeSim, SIGNAL ( message ( Msg * ) ), this, SLOT ( msgSet ( Msg * ) ) );

		connect (
			this->pPicPblzeSim,
			SIGNAL ( selectSrc ( QUrl ) ),
			this->pMod->pEdt,
			SLOT ( setupDocument ( QUrl ) )
		);

		connect (
			this->pMod->pEdt,
			SIGNAL ( breakpointChanged () ),
			this,
			SLOT ( setbreakpoints () )
		);
	}

	// Setup simulator configuration
	PicPblzeSim::sCfg_t sCfg_sim;
	{
		sCfg_sim.sCfg_asmParser.i_intVector		= this->pPicPblzeSet->i_intVector;
		sCfg_sim.sCfg_asmParser.i_memBankCount		= this->pPicPblzeSet->i_memBankCount;
		sCfg_sim.sCfg_asmParser.i_memBankSize		= this->pPicPblzeSet->i_memBankSize;
		sCfg_sim.sCfg_asmParser.i_scrpdSize		= this->pPicPblzeSet->i_scrpdSize;
		sCfg_sim.sCfg_asmParser.ePicDerivate		= this->pPicPblzeSet->ePicDerivate;
		sCfg_sim.sCfg_asmParser.eMemSharedLoc		= this->pPicPblzeSet->eMemSharedLoc;
		sCfg_sim.sCfg_asmParser.QStringList_filePath 	= this->pMod->pSet->Prj.sSrc.QStringList_srcFiles;
	}
	
	// Configure simulator and parse code base
	if ( ! this->pPicPblzeSim->simStart ( sCfg_sim ) )
	{
		delete this->pPicPblzeSim;
		
		this->pPicPblzeSim = NULL;
		
		return;
	}

	this->setbreakpoints ();
	
	// Must be called before setSimStatus
	this->setBaseHex ();
	
	this->setSimStatus ( eIdle );

	this->setGuiInstCount ( this->pPicPblzeSim->getInstCount () );

	this->pQAction_simEn->setStatusTip ( tr ( "Disable simulator" ) );
	this->pQAction_simEn->setText ( tr ( "Disable simulator" ) );
	this->pMod->pMainDockAreaB->setHidden ( FALSE );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::simReload ( void )
{
	if ( ! this->pPicPblzeSim )
		return;

	this->pPicPblzeSim->simStop ();

	this->pPicMsgBrowser->clearMsgList ();
	this->pMod->pMainDockAreaB->setHidden ( FALSE );

	// Setup simulator configuration
	PicPblzeSim::sCfg_t sCfg_sim;
	{
		sCfg_sim.sCfg_asmParser.i_intVector		= this->pPicPblzeSet->i_intVector;
		sCfg_sim.sCfg_asmParser.i_memBankCount		= this->pPicPblzeSet->i_memBankCount;
		sCfg_sim.sCfg_asmParser.i_memBankSize		= this->pPicPblzeSet->i_memBankSize;
		sCfg_sim.sCfg_asmParser.i_scrpdSize		= this->pPicPblzeSet->i_scrpdSize;
		sCfg_sim.sCfg_asmParser.ePicDerivate		= this->pPicPblzeSet->ePicDerivate;
		sCfg_sim.sCfg_asmParser.eMemSharedLoc		= this->pPicPblzeSet->eMemSharedLoc;
		sCfg_sim.sCfg_asmParser.QStringList_filePath 	= this->pMod->pSet->Prj.sSrc.QStringList_srcFiles;
	}
	
	// Configure simulator and parse code lines
	if ( ! this->pPicPblzeSim->simReload ( sCfg_sim ) )
	{
		this->setSimStatus ( eBlocked );
		return;
	}

	this->setbreakpoints ();
	this->setSimStatus ( eIdle );
	this->setGuiInstCount ( this->pPicPblzeSim->getInstCount () );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::setbreakpoints ( void )
{
	QMap<QString,QList<int> > QMap_breakpoints;

	this->pMod->pEdt->getBreakpoints ( & QMap_breakpoints );

	this->pPicPblzeSim->setBreakpoints ( QMap_breakpoints );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::setBaseDec ( void )
{
	this->pPicPblzeSim->setBase ( 10 );

	this->pQAction_setBaseDec->setEnabled ( FALSE );
	this->pQAction_setBaseHex->setEnabled ( TRUE );
	this->pQAction_setBaseOct->setEnabled ( TRUE );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::setBaseHex ( void )
{
	this->pPicPblzeSim->setBase ( 16 );

	this->pQAction_setBaseDec->setEnabled ( TRUE );
	this->pQAction_setBaseHex->setEnabled ( FALSE );
	this->pQAction_setBaseOct->setEnabled ( TRUE );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::setBaseOct ( void )
{
	this->pPicPblzeSim->setBase ( 8 );

	this->pQAction_setBaseDec->setEnabled ( TRUE );
	this->pQAction_setBaseHex->setEnabled ( TRUE );
	this->pQAction_setBaseOct->setEnabled ( FALSE );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::simRun ( void )
{
	this->pMod->pEdt->clearLineSelections ();

	if ( ! this->pPicPblzeSim )
		return;

	if ( this->pPicPblzeSim->getSimStatus () != PicPblzeSim::e_idle )
	{
		this->pPicPblzeSim->simStop ();
		return;
	}

	this->pQAction_simRun->setChecked ( TRUE );

	this->setSimStatus ( eRun );

	this->pPicPblzeSim->simRun();

	this->setSimStatus ( eIdle );

	this->pQAction_simRun->setChecked ( FALSE );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::simRst ( void )
{
	if ( ! this->pPicPblzeSim )
		return;

	this->pPicPblzeSim->simRst();
	this->setSimStatus ( eIdle );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::simNextInstruction ( void )
{
	this->pMod->pEdt->clearLineSelections ();

	if ( ! this->pPicPblzeSim )
		return;

	this->pPicPblzeSim->simNextInstruction();
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::simNextLine ( void )
{
	this->pMod->pEdt->clearLineSelections ();

	if ( ! this->pPicPblzeSim )
		return;

	if ( this->pPicPblzeSim->getSimStatus () != PicPblzeSim::e_idle )
	{
		this->pPicPblzeSim->simStop ();
		return;
	}

	this->pQAction_simNextLine->setChecked ( TRUE );

	this->setSimStatus ( eRunNextLine );

	this->pPicPblzeSim->simNextLine();

	this->setSimStatus ( eIdle );

	this->pQAction_simNextLine->setChecked ( FALSE );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::simToEndOfCall ( void )
{
	this->pMod->pEdt->clearLineSelections ();

	if ( ! this->pPicPblzeSim )
		return;

	if ( this->pPicPblzeSim->getSimStatus () != PicPblzeSim::e_idle )
	{
		this->pPicPblzeSim->simStop ();
		return;
	}

	this->pQAction_simToEndOfCall->setChecked ( TRUE );

	this->setSimStatus ( eRunToEndOfCall );

	this->pPicPblzeSim->simToEndOfCall();

	this->setSimStatus ( eIdle );

	this->pQAction_simToEndOfCall->setChecked ( FALSE );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::simInt ( void )
{
	if ( ! this->pPicPblzeSim )
		return;

	this->pPicPblzeSim->simInt();
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::setGuiInstCount ( PicPblzeAsmParser::sInstCount_t * psInstCount )
{
	QString QString_bank0  = "<b>Bank 0:</b> ";
	QString QString_bank1  = "<b>Bank 1:</b> ";
	QString QString_bank2  = "<b>Bank 2:</b> ";
	QString QString_bank3  = "<b>Bank 3:</b> ";
	QString QString_shared = "<b>Shared:</b> ";
	
	if ( ! psInstCount )
	{
		QString_bank0  += "Unknown";
		QString_bank1  += "Unknown";
		QString_bank2  += "Unknown";
		QString_bank3  += "Unknown";
		QString_shared += "Unknown";
	}
	else
	{
		if ( psInstCount->i_bank0 <= 0 )
			QString_bank0 += "Unused";
		else
			QString_bank0 += QString ( "%1 Instructions" ).arg ( psInstCount->i_bank0 );
		
		
		if ( psInstCount->i_bank1 <= 0 )
			QString_bank1 += "Unused";
		else
			QString_bank1 += QString ( "%1 Instructions" ).arg ( psInstCount->i_bank1 );
		
		
		if ( psInstCount->i_bank2 <= 0 )
			QString_bank2 += "Unused";
		else
			QString_bank2 += QString ( "%1 Instructions" ).arg ( psInstCount->i_bank2 );
		
		
		if ( psInstCount->i_bank3 <= 0 )
			QString_bank3 += "Unused";
		else
			QString_bank3 += QString ( "%1 Instructions" ).arg ( psInstCount->i_bank3 );
		
		if ( psInstCount->i_shared <= 0 )
			QString_shared += "Unused";
		else
			QString_shared += QString ( "%1 Instructions" ).arg ( psInstCount->i_shared );
	}

	this->pQLabel_instCountBank0->setText  ( QString_bank0 );
	this->pQLabel_instCountBank1->setText  ( QString_bank1 );
	this->pQLabel_instCountBank2->setText  ( QString_bank2 );
	this->pQLabel_instCountBank3->setText  ( QString_bank3 );
	this->pQLabel_instCountShared->setText ( QString_shared );
}

/**bank0
 *****************************************************************************************************************************
 */

void PicPblze::setGuiPcFromCursor ( int i_pc )
{
	if ( i_pc < 0 )
		this->pQLabel_pcFromCursor->setText ( QObject::tr ( "<b>PC from Cursor:</b> " ) + QObject::tr ( " Unset" ) );
	else
		this->pQLabel_pcFromCursor->setText ( QObject::tr ( "<b>PC from Cursor:</b> 0x" ) + QString::number ( i_pc, 16 ) );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::setSimStatus ( eSimStatus_t eSimStatus )
{
	QString QString_msg;

	switch ( eSimStatus )
	{
		case eDisabled:

			QString_msg = QObject::tr ( "Disabled" );

			this->pQAction_simReload->setEnabled          ( FALSE );
			this->pQAction_simRun->setEnabled             ( FALSE );
			this->pQAction_simNextInstruction->setEnabled ( FALSE );
			this->pQAction_simNextLine->setEnabled        ( FALSE );
			this->pQAction_simToEndOfCall->setEnabled     ( FALSE );
			this->pQAction_simInt->setEnabled             ( FALSE );
			this->pQAction_simRst->setEnabled             ( FALSE );
			this->pQAction_setPcFromCursor->setEnabled    ( FALSE );

			this->pQAction_setBaseDec->setEnabled         ( FALSE );
			this->pQAction_setBaseHex->setEnabled         ( FALSE );
			this->pQAction_setBaseOct->setEnabled         ( FALSE );

			break;

		case eBlocked:
			
			QString_msg = QObject::tr ( "Blocked" );

			this->pQAction_simReload->setEnabled          ( TRUE );
			this->pQAction_simRun->setEnabled             ( FALSE );
			this->pQAction_simNextInstruction->setEnabled ( FALSE );
			this->pQAction_simNextLine->setEnabled        ( FALSE );
			this->pQAction_simToEndOfCall->setEnabled     ( FALSE );
			this->pQAction_simInt->setEnabled             ( FALSE );
			this->pQAction_simRst->setEnabled             ( FALSE );
			this->pQAction_setPcFromCursor->setEnabled    ( FALSE );

			this->pQAction_setBaseDec->setEnabled         ( FALSE );
			this->pQAction_setBaseHex->setEnabled         ( FALSE );
			this->pQAction_setBaseOct->setEnabled         ( FALSE );

			break;
			
		case eIdle:

			QString_msg = QObject::tr ( "Idle" );

			this->pQAction_simReload->setEnabled          ( TRUE );
			this->pQAction_simRun->setEnabled             ( TRUE );
			this->pQAction_simNextInstruction->setEnabled ( TRUE );
			this->pQAction_simNextLine->setEnabled        ( TRUE );
			this->pQAction_simToEndOfCall->setEnabled     ( TRUE );
			this->pQAction_simInt->setEnabled             ( TRUE );
			this->pQAction_simRst->setEnabled             ( TRUE );
			this->pQAction_setPcFromCursor->setEnabled    ( TRUE );


			break;

		case eRun:

			QString_msg = QObject::tr ( "Running" );

			this->pQAction_simReload->setEnabled          ( FALSE );
			this->pQAction_simRun->setEnabled             ( TRUE  );
			this->pQAction_simNextInstruction->setEnabled ( FALSE );
			this->pQAction_simNextLine->setEnabled        ( FALSE );
			this->pQAction_simToEndOfCall->setEnabled     ( FALSE );
			this->pQAction_simRst->setEnabled             ( FALSE );
			this->pQAction_setPcFromCursor->setEnabled    ( FALSE );


			break;

		case eRunNextInstruction:

			QString_msg = QObject::tr ( "Running to next Instruction" );

			this->pQAction_simReload->setEnabled          ( FALSE );
			this->pQAction_simRun->setEnabled             ( FALSE );
			this->pQAction_simNextInstruction->setEnabled ( TRUE );
			this->pQAction_simNextLine->setEnabled        ( FALSE );
			this->pQAction_simToEndOfCall->setEnabled     ( FALSE );
			this->pQAction_simRst->setEnabled             ( FALSE );

			break;

		case eRunNextLine:

			QString_msg = QObject::tr ( "Running to next line" );

			this->pQAction_simReload->setEnabled          ( FALSE );
			this->pQAction_simRun->setEnabled             ( FALSE );
			this->pQAction_simNextInstruction->setEnabled ( FALSE );
			this->pQAction_simNextLine->setEnabled        ( TRUE );
			this->pQAction_simToEndOfCall->setEnabled     ( FALSE );
			this->pQAction_simRst->setEnabled             ( FALSE );
			this->pQAction_setPcFromCursor->setEnabled    ( FALSE );


			break;


		case eRunToEndOfCall:

			QString_msg = QObject::tr ( "Running to end of call" );


			this->pQAction_simReload->setEnabled          ( FALSE );
			this->pQAction_simRun->setEnabled             ( FALSE );
			this->pQAction_simNextInstruction->setEnabled ( FALSE );
			this->pQAction_simNextLine->setEnabled        ( FALSE );
			this->pQAction_simToEndOfCall->setEnabled     ( TRUE  );
			this->pQAction_simRst->setEnabled             ( FALSE );
			this->pQAction_setPcFromCursor->setEnabled    ( FALSE );


			break;
	}

	this->pQLabel_simStatus->setText ( QObject::tr ( "<b>Simulator:</b> " ) + QString_msg );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::setPcFromCursor ( void )
{
	if ( ! this->pPicPblzeSim )
		return;


	QString QString_filePath;
	int i_fileNumber;

	if ( this->pMod->pEdt->getLineFromCursor ( & QString_filePath, & i_fileNumber ) )
		this->pPicPblzeSim->setPcFromCodeLine ( QString_filePath, i_fileNumber );
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Message handling
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

void PicPblze::msgSet ( Msg * pMsg )
{
	if ( ! pMsg->QUrl_srcUrl.isEmpty() )
		pMsg->QUrl_srcUrl.setPath( this->pMod->pSet->Prj.getRelativeFilePath ( pMsg->QUrl_srcUrl.path() ) );
	
	this->pPicMsgBrowser->setMessage ( pMsg );
}

/**
 *****************************************************************************************************************************
 */

void PicPblze::msgHndlClick ( QUrl QUrl_doc )
{
	if ( QUrl_doc.scheme() == "file" )
		QUrl_doc.setPath( this->pMod->pSet->Prj.getAbsoluteFilePath ( QUrl_doc.path() ) );
// qDebug() << QUrl_doc;
	this->pMod->pEdt->setupDocument ( QUrl_doc );
}

/**
 *****************************************************************************************************************************
 */










