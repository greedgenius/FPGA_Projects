/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/
#ifndef SetDlgPGVERSION_H
#define SetDlgPGVERSION_H

#include <QtGui>
#include <QtCore>

#include "SetPrj.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Project dialog page class for versioning.
 *
 *	The class provides a dialog page for handling project versioning.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-09-27
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class SetDlgPgVer : public QWidget
{
		Q_OBJECT

	public:

		/// Constructor. Generates the editor dialog page layout.
		/// \param pSetPrj_dlg	Reference to the dialog project settings
		/// \param pQWidgetParent	Reference to the parent widget.
		SetDlgPgVer ( SetPrj * pSetPrj_dlg, QWidget * pQWidgetParent = 0 );

		/// Initializes the copy of the settings from gui to dialog project settings.
		void getSet ( void );

	private:

		/// Reference to the dialog project settings
		SetPrj * pSetPrj_dlg;

		/// Version
		QLineEdit * pQLineEdit_version;

		/// Title
		QLineEdit * pQLineEdit_title;

		/// Comment
		QTextEdit * pQTextEdit_comment;
};

#endif
