/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "EdtFindReplaceWidget.h"

/**
 *****************************************************************************************************************************
 */

EdtFindReplaceWidget::EdtFindReplaceWidget ( QWidget * pQWidget_parent ) : QWidget ( pQWidget_parent )
{
	QGridLayout * pQGridLayout_widget = new QGridLayout;
	{
		// Close button
		{
			this->pQPushButton_close = new QPushButton;
			{
				this->pQPushButton_close->setIcon ( QIcon ( ":/main/img/main/closeWidget.png" ) );

				connect ( this->pQPushButton_close, SIGNAL ( clicked () ), this, SLOT ( hide () ) );
			}
			pQGridLayout_widget->addWidget ( this->pQPushButton_close, 0, 0, 1, 1 );
		}
		
		// Find string
		{
			QLabel * pQLabel_title = new QLabel;
			{
				pQLabel_title->setText ( QObject::tr ( "Find:" ) );
			}
			this->pQLineEdit_find = new QLineEdit;
			{
				connect (
					this->pQLineEdit_find,
					SIGNAL ( textChanged ( QString ) ),
					this,
					SLOT ( chkFindStringVld ( QString ) )
				);
			}
			pQGridLayout_widget->addWidget ( pQLabel_title,          0, 1, 1, 1 );
			pQGridLayout_widget->addWidget ( this->pQLineEdit_find,  0, 2, 1, 1 );
		}
		
		// Find clear button
		{
			this->pQPushButton_clearFind = new QPushButton;
			{
				this->pQPushButton_clearFind->setIcon ( QIcon ( ":/edt/img/edt/editClearLocationbarRtl.png" ) );

				connect (
					this->pQPushButton_clearFind,
					SIGNAL ( clicked () ),
					this->pQLineEdit_find,
					SLOT ( clear () )
				);
			}
			pQGridLayout_widget->addWidget ( this->pQPushButton_clearFind, 0, 3, 1, 1 );
		}

		// Find next button
		{
			this->pQPushButton_findNext = new QPushButton;
			{
				this->pQPushButton_findNext->setText ( QObject::tr ( "&Next" ) );
				this->pQPushButton_findNext->setEnabled ( FALSE );
				
				connect ( this->pQPushButton_findNext, SIGNAL ( clicked () ), this, SLOT ( findNext () ) );

			}
			pQGridLayout_widget->addWidget ( this->pQPushButton_findNext, 0, 4, 1, 1 );
		}

		// Find previous button
		{
			this->pQPushButton_findPrev = new QPushButton;
			{
				this->pQPushButton_findPrev->setText ( QObject::tr ( "&Previous" ) );
				this->pQPushButton_findPrev->setEnabled ( FALSE );
				
				connect ( this->pQPushButton_findPrev, SIGNAL ( clicked () ), this, SLOT ( findPrev () ) );
			}
			pQGridLayout_widget->addWidget ( this->pQPushButton_findPrev, 0, 5, 1, 1 );
		}

		// Toggle mode button
		{
			this->pQPushButton_mode = new QPushButton;
			{
				this->pQPushButton_mode->setFlat ( TRUE );
			
				connect ( this->pQPushButton_mode, SIGNAL ( clicked () ), this, SLOT ( toggleMode () ) );
			}
			pQGridLayout_widget->addWidget ( this->pQPushButton_mode, 0, 6, 1, 1 );
		}

		// Replace string
		{
			this->pQLabel_replace = new QLabel;
			{
				this->pQLabel_replace->setText ( QObject::tr ( "Replace:" ) );
			}
			this->pQLineEdit_replace = new QLineEdit;
			{
				connect (
					this->pQLineEdit_replace,
					SIGNAL ( textChanged ( QString ) ),
					this,
					SLOT ( chkReplaceStringVld ( QString ) )
				);
			}
			pQGridLayout_widget->addWidget ( this->pQLabel_replace,    1, 1, 1, 1 );
			pQGridLayout_widget->addWidget ( this->pQLineEdit_replace, 1, 2, 1, 1 );
		}
		
		// Replace clear button
		{
			this->pQPushButton_replaceClr = new QPushButton;
			{
				this->pQPushButton_replaceClr->setIcon ( QIcon ( ":/edt/img/edt/editClearLocationbarRtl.png" ) );

				connect (
					this->pQPushButton_replaceClr,
					SIGNAL ( clicked () ),
					this->pQLineEdit_replace,
					SLOT ( clear () )
				);
			}
			pQGridLayout_widget->addWidget ( this->pQPushButton_replaceClr, 1, 3, 1, 1 );
		}
		
		// Replace button
		{
			this->pQPushButton_replace = new QPushButton;
			{
				this->pQPushButton_replace->setText ( QObject::tr ( "&Replace" ) );
				this->pQPushButton_replace->setEnabled ( FALSE );

				connect ( this->pQPushButton_replace, SIGNAL ( clicked () ), this, SLOT ( replace () ) );
			}
			pQGridLayout_widget->addWidget ( this->pQPushButton_replace, 1, 4, 1, 1 );
		}

		// ReplaceAll button
		{
			this->pQPushButton_replaceAll = new QPushButton;
			{
				this->pQPushButton_replaceAll->setText ( QObject::tr ( "Replace &all" ) );
				this->pQPushButton_replaceAll->setEnabled ( FALSE );

				connect ( this->pQPushButton_replaceAll, SIGNAL ( clicked () ), this, SLOT ( replaceAll () ) );
			}
			pQGridLayout_widget->addWidget ( this->pQPushButton_replaceAll, 1, 5, 1, 1 );
		}
		
		// Line
		{
			QFrame * pQFrame = new QFrame;
			{
				pQFrame->setFrameStyle ( QFrame::Plain | QFrame::HLine );
				pQFrame->setLineWidth ( 1 );
				
			}
			pQGridLayout_widget->addWidget ( pQFrame, 2, 1, 1, 5 );
		}
		
		// Options
		QHBoxLayout * pQHBoxLayout_options = new QHBoxLayout;
		{
			pQHBoxLayout_options->addStretch ();
			
			// Option: Case sensitive
			{
				QHBoxLayout * pQHBoxLayout = new QHBoxLayout;
				{
					QLabel * pQLabel = new QLabel;
					{
						pQLabel->setText ( QObject::tr ( "Case sensitive" ) );
					}
					this->pQCheckBox_caseSensitive = new QCheckBox;
					{
					
					}
					pQHBoxLayout->addWidget ( pQLabel );
					pQHBoxLayout->addWidget ( this->pQCheckBox_caseSensitive );
				}
				pQHBoxLayout_options->addLayout ( pQHBoxLayout );
			}
			
			// Option: Whole words
			{
				QHBoxLayout * pQHBoxLayout = new QHBoxLayout;
				{
					QLabel * pQLabel = new QLabel;
					{
						pQLabel->setText ( QObject::tr ( "Whole words" ) );
					}
					this->pQCheckBox_wholeWords = new QCheckBox;
					{
					
					}
					pQHBoxLayout->addWidget ( pQLabel );
					pQHBoxLayout->addWidget ( this->pQCheckBox_wholeWords );
				}
				pQHBoxLayout_options->addLayout ( pQHBoxLayout );
			}
			
			// Option: From cursor
/*			{
				QHBoxLayout * pQHBoxLayout = new QHBoxLayout;
				{
					QLabel * pQLabel = new QLabel;
					{
						pQLabel->setText ( QObject::tr ( "From cursor" ) );
					}
					this->pQCheckBox_fromCursor = new QCheckBox;
					{
					
					}
					pQHBoxLayout->addWidget ( pQLabel );
					pQHBoxLayout->addWidget ( this->pQCheckBox_fromCursor );
				}
				pQHBoxLayout_options->addLayout ( pQHBoxLayout );
			}		*/
			pQGridLayout_widget->addLayout ( pQHBoxLayout_options, 3, 1, 1, 5 );
		}
		
		QWidget::setLayout ( pQGridLayout_widget );
	}
	
	this->setMode ( eModeReplace );
}

/**
 *****************************************************************************************************************************
 */

void EdtFindReplaceWidget::fetchParameter ( void )
{
	this->sFRParam.b_fndCaseSensitive = ( this->pQCheckBox_caseSensitive->checkState() == Qt::Checked ) ? TRUE : FALSE;
	this->sFRParam.b_fndWholeWords    = ( this->pQCheckBox_wholeWords->checkState()    == Qt::Checked ) ? TRUE : FALSE;
// 	this->sFRParam.b_findFromCursor   = ( this->pQCheckBox_fromCursor->checkState()    == Qt::Checked ) ? TRUE : FALSE;
	
	this->sFRParam.QString_find       = this->pQLineEdit_find->text();
	this->sFRParam.QString_replace    = this->pQLineEdit_replace->text();
}

/**
 *****************************************************************************************************************************
 */

void EdtFindReplaceWidget::findNext ( void )
{
	this->fetchParameter ();

	emit findNext ( & this->sFRParam );
}

/**
 *****************************************************************************************************************************
 */

void EdtFindReplaceWidget::findPrev ( void )
{
	this->fetchParameter ();

	emit findPrev ( & this->sFRParam );
}

/**
 *****************************************************************************************************************************
 */

void EdtFindReplaceWidget::replace ( void )
{
	this->fetchParameter ();
	
	emit replace ( & this->sFRParam );
}

/**
 *****************************************************************************************************************************
 */

void EdtFindReplaceWidget::replaceAll ( void )
{
	this->fetchParameter ();
	
	emit replaceAll ( & this->sFRParam );
}

/**
 *****************************************************************************************************************************
 */

void EdtFindReplaceWidget::chkFindStringVld ( QString QString_gui )
{

	if ( ! QString_gui.isEmpty() )
	{
		this->pQPushButton_findNext->setEnabled   ( TRUE );
		this->pQPushButton_findPrev->setEnabled   ( TRUE );
	}
	else
	{
		this->pQPushButton_findNext->setEnabled   ( FALSE );
		this->pQPushButton_findPrev->setEnabled   ( FALSE );
	}
}

/**
 *****************************************************************************************************************************
 */

void EdtFindReplaceWidget::chkReplaceStringVld ( QString QString_gui )
{
	if ( ! QString_gui.isEmpty() )
	{
		this->pQPushButton_replace->setEnabled    ( TRUE );
		this->pQPushButton_replaceAll->setEnabled ( TRUE );
	}
	else
	{
		this->pQPushButton_replace->setEnabled    ( FALSE );
		this->pQPushButton_replaceAll->setEnabled ( FALSE );
	}
}

/**
 *****************************************************************************************************************************
 */

void EdtFindReplaceWidget::setMode ( eMode_t eMode )
{
	this->eMode = eMode;
	
	switch ( eMode )
	{
		case eModeFind:
			
			this->pQLabel_replace->hide ();
			this->pQLineEdit_replace->hide ();
			this->pQPushButton_replaceClr->hide ();
			this->pQPushButton_replace->hide ();
			this->pQPushButton_replaceAll->hide ();

			this->pQPushButton_mode->setIcon ( QIcon ( ":/edt/img/edt/arrow-up-double.png" ) );
			
/*			QWidget::setTabOrder ( this->pQPushButton_close, 	this->pQLineEdit_find );
			QWidget::setTabOrder ( this->pQLineEdit_find, 		this->pQPushButton_clearFind );
			
this->pQPushButton_close
this->pQLineEdit_find
this->pQPushButton_clearFind
this->pQPushButton_findNext
this->pQPushButton_findPrev
this->pQPushButton_mode
this->pQLineEdit_replace
this->pQPushButton_replaceClr
this->pQPushButton_replace
this->pQPushButton_replaceAll
this->pQCheckBox_caseSensitive
this->pQCheckBox_wholeWords
			
			*/
			break;
			
		case eModeReplace:
			
			this->pQLabel_replace->show ();
			this->pQLineEdit_replace->show ();
			this->pQPushButton_replaceClr->show ();
			this->pQPushButton_replace->show ();
			this->pQPushButton_replaceAll->show ();
			
			this->pQPushButton_mode->setIcon ( QIcon ( ":/edt/img/edt/arrow-down-double.png" ) );

			break;
	}
}

/**
 *****************************************************************************************************************************
 */

void EdtFindReplaceWidget::toggleMode ( void )
{
	switch ( eMode )
	{
		case eModeFind:

			this->setMode ( eModeReplace );
			break;
	
		case eModeReplace:
			
			this->setMode ( eModeFind );
			break;
	}
}

/**
 *****************************************************************************************************************************
 */

void EdtFindReplaceWidget::setInitFocus ( QString QString_find )
{
	this->pQLineEdit_find->setFocus ();
	
	if ( QString_find.isEmpty () )	
	{
		this->pQLineEdit_find->selectAll ();
		this->pQLineEdit_replace->clear ();
	}
	else
	{
		this->pQLineEdit_find->setText ( QString_find );
		this->pQLineEdit_replace->setText ( QString_find );
	}
}

/**
 *****************************************************************************************************************************
 */
