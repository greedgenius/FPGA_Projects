/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PICEDTINTEGER_H
#define PICEDTINTEGER_H

#include <QtCore>
#include <QtGui>

/**
 *****************************************************************************************************************************
 *
 *      \brief Integer widget.
 *
 *
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */

/*
 *****************************************************************************************************************************
 * Change log
 *
 * 2009-08-30
 *	Freeze for first release
 *
 * 2009-09-11
 *	Remove typedef
 *
 *****************************************************************************************************************************
 */

class PicEdtInteger : public QLineEdit
{

		Q_OBJECT

	public:

		/// Constructor
		/// \param pQLineEdit_parent		Pointer to parent widget
		PicEdtInteger ( QLineEdit * pQLineEdit_parent = 0 );

		/// Sets base of integer.
		/// \param i_base			Integer base
		void setBase ( int i_base );

		/// Sets integer value
		/// \param i_value			Integer value
		bool setValue ( int i_value );

		/// Gets integer value
		/// \param pi_value			Returned integer value
		/// \return bool			True, if integer value is valid, otherwise false
		bool getValue ( int * pi_value );

		/// Sets integer highlighted
		/// \param b_highlighted		True, if highlighted, false, if normal mode
		void setHighlighted ( bool b_highlighted );

		/// Sets maximum value
		/// \param i_value			Maximum value
		void setMaxValue ( int i_value );

	private slots:

		/// Checks given value for validity. Will be called, if gui content changes.
		/// \param QString_value		Value
		/// \retval bool			True, if value valid, otherwise false
		bool checkValue ( QString QString_value );

		/// Keeps focus if value invalid.
		void keepFocus ( void );

	signals:

		/// Will be emitted, if the value was changed via gui.
		/// \param i_value			Value
		void valueChanged ( int i_value );

	private:

		/// Background color for invalid value
		QColor QColor_bgInvalid;

		/// Background color for valid value
		QColor QColor_bgValid;

		/// Foreground color for highlighted value
		QColor QColor_fgHighlighted;

		/// Nominal foreground color
		QColor QColor_fgNormal;

		/// Integer base
		int i_base;

		/// Sets value valid/invalid
		/// \param b_valid			True, if value valid, otherwise false
		void setValid ( bool b_valid );

		/// Maximum value
		int i_maxVal;

		/// Maximum length
		int i_maxLen;
		
	protected:
	
		/// Sets contents margins
		/// \param[in]	int i_left		Left margin
		/// \param[in]	int i_top		Top margin
		/// \param[in]	int i_right		Right margin
		/// \param[in]	int i_bottom		Bottom margin
		void setContentsMargins ( int i_left, int i_top, int i_right, int i_bottom );
		
		/// Sets contents margins
		/// \param[in]	QMargins_margins	Margins
// 		void setContentsMargins ( const QMargins & QMargins_margins );
};

#endif
