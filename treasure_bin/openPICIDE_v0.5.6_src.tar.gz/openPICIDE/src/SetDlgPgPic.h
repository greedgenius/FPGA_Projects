/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PROJECTDIALOGPAGEPROCESSOR_H
#define PROJECTDIALOGPAGEPROCESSOR_H

#include <QtGui>
#include <QtCore>

#include "SetPrj.h"

#include "SetDlgPgPicNone.h"
#include "SetDlgPgPicPblze.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Project dialog page class for editing processor settings.
 *
 *	The class manages widgets for each supported processor type.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class SetDlgPgPic : public QWidget
{

		Q_OBJECT

	public:

		/// Constructor. Generates the editor dialog page layout.
		/// \param pSetPrj_dlg	Reference to the dialog project settings
		/// \param pQWidgetParent	Reference to the parent widget.
		SetDlgPgPic ( SetPrj * pSetPrj_dlg, QWidget * pQWidget_parent = 0 );

		/// Initializes the copy of the settings from gui to dialog project settings.
		void getSet ( void );

	private slots:

		/// Sets the tab page(s) for the selected processor.
		/// \param QString_processorType processor type
		void setPic( const QString QString_processorType );

	private:

		/// Reference to the dialog project settings
		SetPrj * pSetPrj_dlg;

		/// Widget for processor type.
		QComboBox * pQComboBox_processor;

		/// Widget for processor settings.
		SetDlgPgPicNone * pProjectDialogPagePicNone;

		/// Layout handling processor settings.
		QVBoxLayout * pQVBoxLayout_groupBox;

		/// Current processor type
		QString QString_processorType;
};

#endif
