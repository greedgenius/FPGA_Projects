/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicEdtBit.h"

/**
 *****************************************************************************************************************************
 */

PicEdtBit::PicEdtBit ( QWidget * pQWidget_parent ) : QLabel ( pQWidget_parent )
{
	this->QColor_fgHighlighted = Qt::red;
	this->QColor_fgNormal      = Qt::black;

	QLabel::setForegroundRole ( QPalette::Text );
	QLabel::setSizePolicy ( QSizePolicy ( QSizePolicy::Fixed, QSizePolicy::Fixed ) );
	QLabel::setTextFormat ( Qt::RichText );
	QLabel::setText ( QString ( "0" ) );
	QLabel::setAutoFillBackground ( TRUE );

	this->setHighlighted ( FALSE );
}

/**
 *****************************************************************************************************************************
 */

void PicEdtBit::toggleBit ( void )
{
	QString QString_value = QLabel::text ();

	if ( QString_value == QString ( "0" ) )
	{
		QLabel::setText ( "1" );
		emit valueChanged ( TRUE );
	}
	else
	{
		QLabel::setText ( "0" );
		emit valueChanged ( FALSE );
	}
}

/**
 *****************************************************************************************************************************
 */

void PicEdtBit::setValue ( bool b_bitEn )
{
	if ( b_bitEn )
	{
		QLabel::setText ( "1" );
	}
	else
	{
		QLabel::setText ( "0" );
	}
}

/**
 *****************************************************************************************************************************
 */

bool PicEdtBit::event ( QEvent * pQEvent )
{
	if ( pQEvent->type() == QEvent::MouseButtonPress )
	{
		QMouseEvent * pQMouseEvent = static_cast <QMouseEvent *> ( pQEvent );

		if ( pQMouseEvent->button() == Qt::LeftButton )
		{
			this->toggleBit();
			return TRUE;
		}
		else if ( pQMouseEvent->button() == Qt::RightButton )
		{
			return FALSE;
		}

		return TRUE;
	}

	return QWidget::event ( pQEvent );
}

/**
 *****************************************************************************************************************************
 */

bool PicEdtBit::getValue ( void )
{
	if ( QString ( "0" ) == QLabel::text () )
	{
		return FALSE;
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

void PicEdtBit::setHighlighted ( bool b_highlighted )
{
	QPalette QPalette_actual = QLabel::palette();

	if ( b_highlighted )
	{
		QPalette_actual.setColor ( QPalette::Active,   QPalette::Text, this->QColor_fgHighlighted );
		QPalette_actual.setColor ( QPalette::Inactive, QPalette::Text, this->QColor_fgHighlighted );
	}
	else
	{
		QPalette_actual.setColor ( QPalette::Active,   QPalette::Text, this->QColor_fgNormal );
		QPalette_actual.setColor ( QPalette::Inactive, QPalette::Text, this->QColor_fgNormal );
	}

	QLabel::setPalette ( QPalette_actual );
}

/**
 *****************************************************************************************************************************
 */
