/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PicPblzeSimIntVectDlg_H
#define PicPblzeSimIntVectDlg_H

#include <QtCore>
#include <QtGui>


/**
 *****************************************************************************************************************************
 *
 *      \brief Xilinx PicoBlaze (tm) core widget.
 *
 *	The widget contains Zero and Carry flag, an interrupt status, the registers and the scratch pad.
 *	The widget is located in the left dock widget.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class PicPblzeSimIntVectDlg : public QDialog
{
		Q_OBJECT

	public:

		/// Constructor. Generates the dialog layout.
		/// \param pQWidget_parent		Reference to the Parent widget.
		PicPblzeSimIntVectDlg ( QWidget * pQWidget_parent = 0 );

		int getBankSelection ( int i_bankCount );
		
	private:
		
// 		int i_bankSel;
		
		QTreeView * pQTreeView;
		QStandardItemModel * pQStandardItemModel;
		
	private slots:
		
		void hndlClick ( QModelIndex QModelIndex_clicked );
		void hndlDblClick ( QModelIndex QModelIndex_clicked );
		
		/// Handles clicks to the OK button.
		void handleEventOk ( void );
};

#endif
