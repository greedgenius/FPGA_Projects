/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef EdtDlgFilter_H
#define EdtDlgFilter_H

#include <QtGui>
#include <QtCore>
#include "EdtEditorWidget.h"
#include "PicPblzeAsmImportMetrx.h"
#include "PicPblzeAsmImportOpenPICIDE.h"
#include "PicPblzeAsmImportXilinx.h"

/**
 *****************************************************************************************************************************
 *
 *	\brief Filter dialog class
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-12-08
 *	\version	0.1.0
 *
 *	Change log
 *
 *	2009-12-08
 *		Generated
 *
 *****************************************************************************************************************************
 */

class EdtDlgFilter : public QWidget
{
		Q_OBJECT

	public:

		/// Constructor. Generates the dialog layout.
		/// \param pQWidget_parent	Pointer to the parent widget
		EdtDlgFilter ( QWidget * pQWidgetParent = 0 );
		
		void setHighlightingParameter ( EdtEditorHighlighter::sHighlightingParameter_t sHighlightingParameter );
		
		
		void setPath ( QString QString_path );
		
	signals:
		
		/// Document converted
		void fileFiltered ( QString QString_documentText );
		
	private slots:

		/// Shows a file selection dialog for source file selection.
		void srcFileSelect ( QString QString_srcFile = QString() );

		/// Convert selected source file with given rules
		void convertAll ( void );

		/// Restarts convert next line
		void convertNxtRestart ( void );
		
		/// Convert selected source file with given rules
		void convertNxt ( void );

		/// Sets source highlighing parameter
		void setHighlightingParameterSrc ( void );

		void useDstFile ( void );

	private:

		enum eSyntax_t {
			eSyntaxOpenPICIDE_v0_3_0,
			eSyntaxMediatronix,
			eSyntaxXilinx
		};

		int i_lineCntr;
		
		enum eRetVal_t
		{
			eRetValUnchanged,	// Must be the first one: eRetValUnchanged = FALSE
			eRetValChanged,
			eRetValErr
		};
		
		/// Path for file dialog
		QString QString_path;
		
		/// Highlighting parameter
		EdtEditorHighlighter::sHighlightingParameter_t sHighlightingParameter;
		
		/// Widget for handling source path
		QLineEdit * pQLineEdit_srcFilePath;
		
		/// Widget for handling source file syntax
		QComboBox * pQComboBox_srcSyntax;
		
		/// Widget for handling source editor tab space
		QSpinBox * pQSpinBox_tabSpaceSrc;
		
		/// Widget for displaying source file
		EdtEditorWidget * pEdtEditorWidget_src;
		
		/// Widget for handling destination editor tab space
		QSpinBox * pQSpinBox_tabSpaceDst;
		
		/// Widget for displaying destination file
		EdtEditorWidget * pEdtEditorWidget_dst;
		
		/// Check settings
		bool chkSettings ( void );
		
	private:
		
		struct sLineFragments_t
		{
			QString QString_0_reference;
			QString QString_1_spacer;
			QString QString_2_text;		// Cmd
			QString QString_3_spacer;
			QString QString_4_text;		// Arg0
			QString QString_5_spacer;
			QString QString_6_text;		// Arg1
			QString QString_7_spacer;
			QString QString_8_comment;
		};

		QString convertLine ( QString QString_line );
	
		PicPblzeAsmImportMetrx * pPicPblzeAsmImportMetrx;
		PicPblzeAsmImportOpenPICIDE * pPicPblzeAsmImportOpenPICIDE;
		PicPblzeAsmImportXilinx * pPicPblzeAsmImportXilinx;

};

#endif
