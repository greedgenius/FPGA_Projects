/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeSet.h"

/**
 *****************************************************************************************************************************
 */

PicPblzeSet::PicPblzeSet()
{
	this->ePicDerivate   = ePblze3;
	this->i_memBankSize  = 1024;
	this->i_memBankCount = 1;
	this->eMemSharedLoc  = eMemSharedLocLowAddr;
}

/**
 *****************************************************************************************************************************
 */

QString PicPblzeSet::getDerivateName ( ePicDerivate_t ePicDerivate )
{
	switch ( ePicDerivate )
	{
		case ePblzeCpld:	return QString ( "PicoBlaze CPLD" );
		case ePblze:		return QString ( "PicoBlaze" );
		case ePblzeII:		return QString ( "PicoBlaze II" );
		case ePblze3:		return QString ( "PicoBlaze 3" );
		case ePblze6:		return QString ( "PicoBlaze 6" );
	}

	return QString ();
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Read and write configuration xml stream
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

void PicPblzeSet::rdXml ( QXmlStreamReader * pQXmlStreamReader, QString QString_prjPath )
{
	if ( ! pQXmlStreamReader->attributes ().hasAttribute ( "version" ) )
		this->rdXmlV00 ( pQXmlStreamReader, QString_prjPath );
	
	switch ( pQXmlStreamReader->attributes ().value ( "version" ).toString().toInt () )
	{
		case 1:	this->rdXmlV01 ( pQXmlStreamReader, QString_prjPath );
	}
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSet::rdXmlV00 ( QXmlStreamReader * pQXmlStreamReader, QString QString_prjPath )
{
	QDir QDir_prjPath ( QString_prjPath );
	
	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if ( "picDerivate" == QString_tag )
		{
			int i_derivate = pQXmlStreamReader->readElementText ().toInt ();

			this->ePicDerivate = static_cast<PicPblzeSet::ePicDerivate_t> ( i_derivate );
		}
		else if ( "clkFreq" == QString_tag )
		{
			this->i_clkFreq = pQXmlStreamReader->readElementText ().toInt ();
		}
		else if ( "memSize" == QString_tag )
		{
			this->i_memBankSize = pQXmlStreamReader->readElementText ().toInt ();
		}
		else if ( "entityName" == QString_tag )
		{
			this->QString_entityName = pQXmlStreamReader->readElementText ();
		}
		else if ( "vhdlTemplateFile" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();
			QString QString_absFilePath = QDir_prjPath.absoluteFilePath ( QString_relFilePath );

			this->QString_vhdlTemplateFile = QString_absFilePath;
		}
		else if ( "vhdlOutputFile" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();
			QString QString_absFilePath = QDir_prjPath.absoluteFilePath ( QString_relFilePath );
			
			this->QString_vhdlOutputFile = QString_absFilePath;
		}
		else if ( "verilogTemplateFile" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();
			QString QString_absFilePath = QDir_prjPath.absoluteFilePath ( QString_relFilePath );

			this->QString_verilogTemplateFile = QString_absFilePath;
		}
		else if ( "verilogOutputFile" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();
			QString QString_absFilePath = QDir_prjPath.absoluteFilePath ( QString_relFilePath );

			this->QString_verilogOutputFile = QString_absFilePath;
		}
		else if ( "memOutputFile" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();
			QString QString_absFilePath = QDir_prjPath.absoluteFilePath ( QString_relFilePath );

			this->QString_memOutputFile = QString_absFilePath;
		}
		else if ( "hexOutputFile" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();
			QString QString_absFilePath = QDir_prjPath.absoluteFilePath ( QString_relFilePath );

			this->QString_hexOutputFile = QString_absFilePath;
		}
		else if ( pQXmlStreamReader->isEndElement () && ( "settings" == QString_tag ) )
		{
			break;
		}
	}
}


/**
 *****************************************************************************************************************************
 */

void PicPblzeSet::rdXmlV01 ( QXmlStreamReader * pQXmlStreamReader, QString QString_prjPath )
{
	QDir QDir_prjPath ( QString_prjPath );
	
	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if ( "picDerivate" == QString_tag )
		{
			int i_derivate = pQXmlStreamReader->readElementText ().toInt ();

			this->ePicDerivate = static_cast<PicPblzeSet::ePicDerivate_t> ( i_derivate );
		}
		else if ( "clkFreq" == QString_tag )
		{
			this->i_clkFreq = pQXmlStreamReader->readElementText ().toInt ();
		}
		else if ( "memBankSize" == QString_tag )
		{
			this->i_memBankSize = pQXmlStreamReader->readElementText ().toInt ();
		}
		else if ( "memBankCount" == QString_tag )
		{
			this->i_memBankCount = pQXmlStreamReader->readElementText ().toInt ();
		}
		else if ( "memSharedLoc" == QString_tag )
		{
			this->eMemSharedLoc = static_cast <eMemSharedLoc_t> ( pQXmlStreamReader->readElementText ().toInt () );
		}
		else if ( "scrpdSize" == QString_tag )
		{
			this->i_scrpdSize = pQXmlStreamReader->readElementText ().toInt ();
		}
		else if ( "intVector" == QString_tag )
		{
			this->i_intVector = pQXmlStreamReader->readElementText ().toInt ();
		}
		else if ( "entityName" == QString_tag )
		{
			this->QString_entityName = pQXmlStreamReader->readElementText ();
		}
		else if ( "vhdlTemplateFile" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();
			QString QString_absFilePath = QDir_prjPath.absoluteFilePath ( QString_relFilePath );

			this->QString_vhdlTemplateFile = QString_absFilePath;
		}
		else if ( "vhdlOutputFile" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();
			QString QString_absFilePath = QDir_prjPath.absoluteFilePath ( QString_relFilePath );
			
			this->QString_vhdlOutputFile = QString_absFilePath;
		}
		else if ( "verilogTemplateFile" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();
			QString QString_absFilePath = QDir_prjPath.absoluteFilePath ( QString_relFilePath );

			this->QString_verilogTemplateFile = QString_absFilePath;
		}
		else if ( "verilogOutputFile" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();
			QString QString_absFilePath = QDir_prjPath.absoluteFilePath ( QString_relFilePath );

			this->QString_verilogOutputFile = QString_absFilePath;
		}
		else if ( "memOutputFile" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();
			QString QString_absFilePath = QDir_prjPath.absoluteFilePath ( QString_relFilePath );

			this->QString_memOutputFile = QString_absFilePath;
		}
		else if ( "hexOutputFile" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();
			QString QString_absFilePath = QDir_prjPath.absoluteFilePath ( QString_relFilePath );

			this->QString_hexOutputFile = QString_absFilePath;
		}
		else if ( pQXmlStreamReader->isEndElement () && ( "settings" == QString_tag ) )
		{
			break;
		}
	}
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSet::wrXml ( QXmlStreamWriter * pQXmlStreamWriter, QString QString_prjPath )
{
	QDir QDir_prjPath ( QString_prjPath );

	// Writes processor settings section
	pQXmlStreamWriter->writeStartElement ( "settings"  );
	{
		pQXmlStreamWriter->writeAttribute ( QXmlStreamAttribute ( "version", "1" ) );

		// Writes instructionWith
		{
			int i_derivate = static_cast <int> ( this->ePicDerivate );

			pQXmlStreamWriter->writeTextElement ( "picDerivate", QString ( "%1" ).arg ( i_derivate ) );
		}

		// Writes instructionWith
		pQXmlStreamWriter->writeTextElement ( "clkFreq", QString ( "%1" ).arg ( this->i_clkFreq ) );

		// Writes memBankSize
		pQXmlStreamWriter->writeTextElement ( "memBankSize", QString ( "%1" ).arg ( this->i_memBankSize ) );

		// Writes memBankCount
		pQXmlStreamWriter->writeTextElement ( "memBankCount", QString ( "%1" ).arg ( this->i_memBankCount ) );

		// Writes memSharedLoc
		pQXmlStreamWriter->writeTextElement ( "memSharedLoc", QString ( "%1" ).arg ( this->eMemSharedLoc ) );
		
		// Writes scrpdSize
		pQXmlStreamWriter->writeTextElement ( "scrpdSize", QString ( "%1" ).arg ( this->i_scrpdSize ) );
		
		// Writes intVector
		pQXmlStreamWriter->writeTextElement ( "intVector", QString ( "%1" ).arg ( this->i_intVector ) );

		// Writes entityName
		pQXmlStreamWriter->writeTextElement ( "entityName", this->QString_entityName );

		// Writes vhdlTemplateFile
		pQXmlStreamWriter->writeTextElement ( "vhdlTemplateFile", QDir_prjPath.relativeFilePath ( this->QString_vhdlTemplateFile ) );
		
		// Writes vhdlOutputFile
		pQXmlStreamWriter->writeTextElement ( "vhdlOutputFile", QDir_prjPath.relativeFilePath ( this->QString_vhdlOutputFile ) );

		// Writes verilogTemplateFile
		pQXmlStreamWriter->writeTextElement ( "verilogTemplateFile", QDir_prjPath.relativeFilePath ( this->QString_verilogTemplateFile ) );
		
		// Writes verilogOutputFile
		pQXmlStreamWriter->writeTextElement ( "verilogOutputFile", QDir_prjPath.relativeFilePath ( this->QString_verilogOutputFile ) );

		// Writes memOutputFile
		pQXmlStreamWriter->writeTextElement ( "memOutputFile", QDir_prjPath.relativeFilePath ( this->QString_memOutputFile ) );

		// Writes hexOutputFile
		pQXmlStreamWriter->writeTextElement ( "hexOutputFile", QDir_prjPath.relativeFilePath ( this->QString_hexOutputFile ) );

		pQXmlStreamWriter->writeEndElement ();
	}
}

/**
 *****************************************************************************************************************************
 */

