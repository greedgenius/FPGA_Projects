/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "SetPrjRdWrV01.h"
#include "PicPblze.h"

/**
 *****************************************************************************************************************************
 */

SetPrjRdWrV01::SetPrjRdWrV01 ( )
{
	
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWrV01::rdXml ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader )
{
	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if      ( QString_tag == "versioning" )	this->rdXmlVersioning ( pSetPrj, pQXmlStreamReader );
		else if ( QString_tag == "processor" )	this->rdXmlProcessor  ( pSetPrj, pQXmlStreamReader );
		else if ( QString_tag == "sources" )	this->rdXmlSources    ( pSetPrj, pQXmlStreamReader );
	}
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWrV01::rdXmlVersioning ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader )
{
	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if ( "version" == QString_tag )
		{
			pSetPrj->sVer.QString_version = pQXmlStreamReader->readElementText ();
		}
		else if ( "comment" == QString_tag )
		{
			pSetPrj->sVer.QString_comment = pQXmlStreamReader->readElementText ();
		}
		else if ( pQXmlStreamReader->isEndElement () && ( "versioning" == QString_tag ) )
		{
			break;
		}
	}
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWrV01::rdXmlProcessor ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader )
{
	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if ( "type" == QString_tag )
		{
			pSetPrj->sPic.QString_picType = pQXmlStreamReader->readElementText ();
		}
		else if ( "settings" == QString_tag )
		{
			if ( pSetPrj->sPic.QString_picType == PicPblze::getName () )
			{
				this->rdXmlProcessorPBlze ( pSetPrj, pQXmlStreamReader );
			}
		}
		else if ( pQXmlStreamReader->isEndElement () && ( "processor" == QString_tag ) )
		{
			break;
		}
	}
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWrV01::rdXmlProcessorPBlze ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader )
{
	PicPblzeSet * pPicPblzeSet = new PicPblzeSet;

	pSetPrj->sPic.pv_picSet = pPicPblzeSet;

	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if ( "picDerivate" == QString_tag )
		{
			int i_derivate = pQXmlStreamReader->readElementText ().toInt ();

			pPicPblzeSet->ePicDerivate = static_cast<PicPblzeSet::ePicDerivate_t> ( i_derivate );
		}
		else if ( "clkFreq" == QString_tag )
		{
			pPicPblzeSet->i_clkFreq = pQXmlStreamReader->readElementText ().toInt ();
		}
		else if ( "memSize" == QString_tag )
		{
			pPicPblzeSet->i_memBankSize = pQXmlStreamReader->readElementText ().toInt ();
		}
		else if ( "entityName" == QString_tag )
		{
			pPicPblzeSet->QString_entityName = pQXmlStreamReader->readElementText ();
		}
		else if ( "vhdlTemplateFile" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();
			QString QString_absFilePath = pSetPrj->sPrj.QString_prjPath + QString_relFilePath;

			pPicPblzeSet->QString_vhdlTemplateFile = QString_absFilePath;
		}
		else if ( "vhdlOutputFile" == QString_tag )
		{
			pPicPblzeSet->QString_vhdlOutputFile = pQXmlStreamReader->readElementText ();
		}
		else if ( "verilogTemplateFile" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();
			QString QString_absFilePath = pSetPrj->sPrj.QString_prjPath + QString_relFilePath;

			pPicPblzeSet->QString_verilogTemplateFile = QString_absFilePath;
		}
		else if ( "verilogOutputFile" == QString_tag )
		{
			pPicPblzeSet->QString_verilogOutputFile = pQXmlStreamReader->readElementText ();
		}
		else if ( "memOutputFile" == QString_tag )
		{
			pPicPblzeSet->QString_memOutputFile = pQXmlStreamReader->readElementText ();
		}
		else if ( "hexOutputFile" == QString_tag )
		{
			pPicPblzeSet->QString_hexOutputFile = pQXmlStreamReader->readElementText ();
		}
		else if ( pQXmlStreamReader->isEndElement () && ( "settings" == QString_tag ) )
		{
			break;
		}
	}
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWrV01::rdXmlSources ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader )
{
	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if ( "files" == QString_tag )
		{
			this->rdXmlSourcesFiles ( pSetPrj, pQXmlStreamReader );
		}
		else if ( pQXmlStreamReader->isEndElement () && ( "sources" == QString_tag ) )
		{
			break;
		}
	}
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWrV01::rdXmlSourcesFiles ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader )
{
	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if ( "file" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();

			if ( QString_relFilePath.isEmpty () )
				continue;

			QString QString_absFilePath = pSetPrj->sPrj.QString_prjPath + QString_relFilePath;

			pSetPrj->sSrc.QStringList_srcFiles << QString_absFilePath;
		}
		else if ( pQXmlStreamReader->isEndElement () && ( "files" == QString_tag ) )
		{
			break;
		}
	}
}

/**
 *****************************************************************************************************************************
 */

void SetPrjRdWrV01::rdXmlLoadedFiles ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader )
{
	while ( ! pQXmlStreamReader->atEnd () )
	{
		pQXmlStreamReader->readNext ();

		QString QString_tag =  pQXmlStreamReader->qualifiedName ().toString ();

		if ( "file" == QString_tag )
		{
			QString QString_relFilePath = pQXmlStreamReader->readElementText ();

			if ( QString_relFilePath.isEmpty () )
				continue;

			QString QString_absFilePath = pSetPrj->sPrj.QString_prjPath + QString_relFilePath;

// 			pSetPrj-> sSetEditor.QStringList_loadedFiles << QString_absFilePath;
		}
		else if ( pQXmlStreamReader->isEndElement () && ( "loadedFiles" == QString_tag ) )
		{
			break;
		}
	}
}

/**
 *****************************************************************************************************************************
 */
