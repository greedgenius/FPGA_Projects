/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PROJECTSETTINGS_H
#define PROJECTSETTINGS_H

#include <QtGui>
#include <QtCore>
#include <QtXml>

/**
 *****************************************************************************************************************************
 *
 *      \brief Project settings handler class.
 *
 *	The class provides handling, reading and writing of project settings.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.1
 *
 *	Change log
 *
 *	2009-08-30
 *		Freeze for first release
 *
 *	2009-09-09
 *		Adding seek funktionality to saveSettings ()
 *		Removing typedef in front of structs
 *
 *****************************************************************************************************************************
 */


class PrjSettings
{

	public:

		/// Constructor. Initialize the settings to valid default values.
		PrjSettings ();

		/// Sets up project file path.
		/// The project file path will be splitted into project dir path
		/// and project file name.
		/// \param QFileInfo_prjFilePath	Project file path
		void setPrjFilePath ( QFileInfo QFileInfo_prjFilePath );

		/// Saves the project settings.
		/// \param pQString_errMsg		Returned error message
		/// \retval bool			True, if success, otherwise false
		bool saveSettings ( QString * pQString_errMsg = NULL );

		/// Reads the project settings.
		/// \param pQString_errMsg		Returned error message
		/// \retval bool			True, if success, otherwise false
		bool readSettings ( QString * pQString_errMsg = NULL );

		/// Deletes the currently loaded settings.
		void deleteSettings ( void );

		/// Print settings to STDOUT for debugging.
		void printSettings ( void );

		/// Gets relative file path to project dir path from given absolute file path
		/// \param QString_absoluteFilePath	Absolute file path
		QString getRelativeFilePath ( QString QString_absoluteFilePath );

		/// Gets absolute file path from given relative file path
		/// \param QString_relativeFilePath	Relative file path
		QString getAbsoluteFilePath ( QString QString_relativeFilePath );

		/// Project file.
		QString  QString_prjFile;

		/// Project path.
		QString  QString_prjPath;

		/// Structure, containing settings for versioning.
		struct sSettingsVersioning_t
		{
			QString QString_version;
			QString QString_comment;
		} sSettingsVersioning;

		/// Structure, containing type and settings for processor.
		struct sSettingsPic_t
		{
			/// Processor type
			QString QString_picType;

			/// A void pointer to processor specific settings.
			void * pv_picSettings;

		} sSettingsPic;

		/// Structure, source settings.
		struct sSettingsSources_t
		{
			/// Source file list
			QStringList QStringList_srcFiles;

		} sSettingsSources;

		/// Structure, containing editor settings.
		struct sSettingsEditor_t
		{
			int  i_tabIndent;				/// The Tabulator indent of the text editor.
			bool b_dynamicWordWrapEn;			/// Enables/disables dynamic word wrap of the text editor.
			QColor QColor_bgCursor;				/// Background color for cursor
			QColor QColor_bgHighlight;			/// Background color for highlighted lines

			QFont QFont_std;
			QTextCharFormat QTextCharFormat_cmd;		/// Highlighting format for assemlber commands
			QTextCharFormat QTextCharFormat_directive;	/// Highlighting format for preassemlber commands
			QTextCharFormat QTextCharFormat_hw;		/// Highlighting format for register
			QTextCharFormat QTextCharFormat_hexNumber;	/// Highlighting format for hexadecimal numbers
			QTextCharFormat QTextCharFormat_decNumber;	/// Highlighting format for decimal numbers
			QTextCharFormat QTextCharFormat_octNumber;	/// Highlighting format for octal numbers
			QTextCharFormat QTextCharFormat_comment;	/// Highlighting format for single line comments
			QTextCharFormat QTextCharFormat_separator;	/// Highlighting format for multiline comments
			QTextCharFormat QTextCharFormat_fct;		/// Highlighting format for functions

			QStringList QStringList_loadedFiles;
		} sSettingsEditor;
};

#endif
