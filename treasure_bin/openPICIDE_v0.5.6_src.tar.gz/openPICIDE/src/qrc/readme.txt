Most icons are used from KDE and KDevelop projects. 
