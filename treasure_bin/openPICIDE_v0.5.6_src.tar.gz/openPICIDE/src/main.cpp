/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include <QtCore>
#include <QtGui>

#include "OpenPicIde.h"
#include <QtGui>
#include <QtCore>

/**
 *****************************************************************************************************************************
 *
 *      \brief Main application of openPICIDE.
 *
 *	Initializes the main window.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.1
 *
 *****************************************************************************************************************************
 */

/*
 *****************************************************************************************************************************
 * Change log
 *
 * 2009-08-30
 *	Freeze for first release
 *
 * 2009-09-09
 *	Adding qt versioning check
 *
 *****************************************************************************************************************************
 */

// Q_IMPORT_PLUGIN ( qsqlite )

int main ( int argc, char *argv[] )
{
// 	Q_INIT_RESOURCE ( "./qrc/resources.qrc" );

	QApplication * pQApplication;

	if ( ! ( pQApplication = new QApplication ( argc, argv ) ) )
	        return -1;

	// Set library path
// 	{
// 		QFileInfo QFileInfo_app ( QCoreApplication::applicationFilePath () );
// 	
// 		if ( QFileInfo_app.isSymLink() )
// 			QFileInfo_app.setFile ( QFileInfo_app.symLinkTarget () );
// 		
// 		pQApplication->addLibraryPath ( QFileInfo_app.path ()  + "/lib");
// 		qDebug() << QFileInfo_app.path ();
// 	}

	OpenPicIde * pOpenPicIde;

	if ( ! ( pOpenPicIde = new OpenPicIde ( argc, argv ) ) )
		return -1;

	if ( QString ( qVersion () ) != QString ( QT_VERSION_STR ) )
	{
		QString QString_title;
		QString_title = QString ( "openPICIDE" );

		QString QString_msg;
		QString_msg  = QObject::tr ( "Missing required Qt version." );

		QString_msg += "\n" + QObject::tr ( "Required: " );
		QString_msg += QT_VERSION_STR;

		QString_msg += "\n" + QObject::tr ( "Available: " );
		QString_msg += qVersion ();

		QString_msg += "\n" + QObject::tr ( "You can continue by clicking \"Ignore\". " );
		QString_msg +=  QObject::tr ( "If you do so openPICIDE may crash or damage your files." );

		if ( QMessageBox::Cancel == QMessageBox::warning ( 0, QString_title, QString_msg,
	                                 QMessageBox::Cancel | QMessageBox::Ignore,
	                                 QMessageBox::Cancel ) )
			return 1;
	}

	pOpenPicIde->show();

	return pQApplication->exec();
}

