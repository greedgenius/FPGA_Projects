/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PicMsgBrowser_H
#define PicMsgBrowser_H

#include <QtCore>
#include <QtGui>

#include "Msg.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Message browser widget
 *
 *
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */

/*
 *****************************************************************************************************************************
 * Change log
 *
 * 2009-08-30
 *	Freeze for first release
 *
 * 2009-09-11
 *	Remove typedef
 *	Change relative file path to file path
 *
 *****************************************************************************************************************************
 */
Q_DECLARE_METATYPE ( Msg * )

class PicMsgBrowser : public QWidget
{
		Q_OBJECT

	public:

		/// Constructor
		/// \param pQWidget_parent	Pointer to parent widget
		PicMsgBrowser ( QWidget * pQWidget_parent = 0 );

		/// Status types
// 		enum eStatus_t
// 		{
// 			e_ok,
// 			e_warning,
// 			e_error
// 		};
		
	signals:

		/// Will be emitted, if a line was selected
		/// \param pMsg				Message
		void lineClicked ( QUrl QUrl_doc );

		/// Signs that content changed
		/// \param pQWidget		Reference to itself
		void contentChanged ( QWidget * pQWidget );

	public slots:

		/// Adds a message to gui
		/// \param QString_message	Message to display
		/// \param QString_filePath	Relative file path
		/// \param i_lineNumber		Line number
		/// \param i_status		Status
		void setMessage ( QString QString_message, QString QString_filePath, int i_lineNumber, Msg::eStatus_t eStatus );

		/// Adds a message to gui
		/// \param sMsg_t		Message to display
		void setMessage ( Msg * pMsg );
		
		
		
		
		
		/// Clears the message list
		void clearMsgList ( void );

		/// Hide the widget
		void hide ( void );

		/// Will be called, if a message was selected in gui. Emitts \c lineSelected.
		void handleClick ( QModelIndex QModelIndex_selected );

	private:

		/// Item model for the message list
		QStandardItemModel QStandardItemModel_msg;

		/// Gui for displaying the message list
		QTreeView * pQTreeView_msg;

		/// Holds the row count
		int i_tableRowCount;
		
		struct sMsgList_t
		{
			Msg * pMsg;
			
			int i_row;
			sMsgList_t * psMsgList_nxt;
		};
		
		sMsgList_t * psMsgList_start;
		sMsgList_t * psMsgList_stop;
};

#endif
