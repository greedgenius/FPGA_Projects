/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PicPblzeSimCoreReg_H
#define PicPblzeSimCoreReg_H

#include <QtCore>
#include <QtGui>
#include "PicEdtInteger.h"
#include "PicPblzeSet.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Xilinx PicoBlaze (tm) core register widget.
 *
 *	
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class PicPblzeSimCoreReg : public QWidget
{

		Q_OBJECT

	public:

		/// Constructor.
		/// \param i_regCountA		Register count for bank A
		/// \param i_regCountB		Register count for bank B
		/// \param pQObject_parent	Pointer to parent widget
		PicPblzeSimCoreReg ( int i_regCountA, int i_regCountB, QWidget * pQWidget_parent = 0 );

		/// Destructor, tidies up
		~PicPblzeSimCoreReg ();

	public:

		/// Sets base.
		/// \param i_base			Integer base
		void setBase ( int i_base );

		/// Sets register
		/// \param QString_regName	Register name
		/// \param QString_regSubst	Register substitute
		/// \param i_value		Register value
		/// \retval bool		True, if success, otherwise false
		bool setRegister ( QString QString_regName, QString QString_regSubst, int i_value );

		/// Gets register
		/// \param QString_regName	Register name
		/// \param QString_regSubst	Register substitute
		/// \param pi_value		Register value
		/// \retval bool		True, if success, otherwise false
		bool getRegister ( QString QString_regName, QString QString_regSubst, int * pi_value );

		/// Clears highlighting
		void clearHighlighted ( void );

		/// Clears all
		void clear ( void );
		
		/// Bank definitions
		enum eBankSel_t
		{
			eBankSel_A,
			eBankSel_B
		};
		
		/// Selects register bank
		/// \param eBankSel		Bank
		/// \retval bool		True if success, otherwise false
		bool setBank ( eBankSel_t eBankSel );
		
		/// Toggles register bank
		/// \retval bool		True if success, otherwise false
		bool toggleBank ( void );

		/// Returns register bank
		/// \retval eBankSel_t		Register bank
		eBankSel_t getBank ( void );

	private:

		/// Doubly connected register list element
		struct sRegValue_t
		{
			QLabel QLabel_regName;
			QLabel QLabel_regSubst;
			PicEdtInteger PicEdtInteger_value;

// 			sRegValue_t * psRegValue_nxt;
		};

		struct sReg_t
		{
			QComboBox * pQComboBox_bankSel;
			
			int i_regCountA;
			int i_regCountB;
			
			sRegValue_t * asRegValue_bankA;
			sRegValue_t * asRegValue_bankB;
			
			QStackedWidget * pQStackedWidget;
		} sReg;
		
		QWidget * setupBank ( eBankSel_t eBankSel, int i_regCount, int i_regNameLen );
		
		void resetTabOrder ( void );

};

#endif
