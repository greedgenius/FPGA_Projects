/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicIOPort8Bit.h"

/**
 *****************************************************************************************************************************
 */

PicIOPort8Bit::PicIOPort8Bit ( QWidget * pQWidget_parent ) : QWidget ( pQWidget_parent )
{
	this->QColor_bgNormal      = Qt::black;
	this->QColor_bgHighlighted = Qt::red;

	QFont QFont_bold;
	QFont_bold.setBold ( TRUE );

	QVBoxLayout * pQVBoxLayout_main = new QVBoxLayout;
	{
		QFrame * pQFrame = new QFrame;
		{
			QHBoxLayout * pQHBoxLayout_frame = new QHBoxLayout;
			{
				QVBoxLayout * pQVBoxLayout_content = new QVBoxLayout;
				{
					this->pQWidget_addr = new QWidget;
					{
						QHBoxLayout * pQHBoxLayout_addr = new QHBoxLayout;
						{
							QLabel * pQLabel_addrTitle = new QLabel;
							{
								QPalette QPalette_actual = pQLabel_addrTitle->palette();
								QPalette_actual.setColor ( QPalette::Foreground, Qt::white );
								pQLabel_addrTitle->setPalette ( QPalette_actual );

								pQLabel_addrTitle->setFont ( QFont_bold );
								pQLabel_addrTitle->setText ( "Addr:" );
							}

							this->pPicEdtInteger_addr = new PicEdtInteger;
							{
								this->pPicEdtInteger_addr->setToolTip ( QObject::tr ( "Address" ) );
							}

							this->pQLabel_addrSymbol = new QLabel;
							{
								QPalette QPalette_actual = pQLabel_addrSymbol->palette();
								QPalette_actual.setColor ( QPalette::Foreground, Qt::white );
								this->pQLabel_addrSymbol->setPalette ( QPalette_actual );

								this->pQLabel_addrSymbol->setToolTip ( QObject::tr ( "Address substitute" ) );
							}

							pQHBoxLayout_addr->addWidget ( pQLabel_addrTitle );
							pQHBoxLayout_addr->addWidget ( this->pPicEdtInteger_addr );
							pQHBoxLayout_addr->addWidget ( pQLabel_addrSymbol );
							pQHBoxLayout_addr->addStretch ();
							pQHBoxLayout_addr->setContentsMargins ( 2, 2, 2, 2 );
						}

						this->pQWidget_addr->setLayout ( pQHBoxLayout_addr );

						// Set background color
						QPalette QPalette_actual = this->pQWidget_addr->palette();
						QPalette_actual.setColor ( QPalette::Window, QColor_bgNormal );
						this->pQWidget_addr->setPalette ( QPalette_actual );
						this->pQWidget_addr->setAutoFillBackground ( TRUE );
						this->pQWidget_addr->setContentsMargins ( 0, 0, 0, 0 );
					}

					QHBoxLayout * pQHBoxLayout_data = new QHBoxLayout;
					{
						this->pPicEdtInteger_value = new PicEdtInteger;
						{
							this->pPicEdtInteger_value->setToolTip ( QObject::tr ( "Value" ) );

							connect ( this->pPicEdtInteger_value, SIGNAL ( valueChanged ( int ) ), this, SLOT ( setValue ( int ) ) );
						}

						this->pPicEdtBitField8_value = new PicEdtBitField8;
						{
							this->pPicEdtBitField8_value->setToolTip ( QObject::tr ( "Value bit field" ) );

							connect ( this->pPicEdtBitField8_value, SIGNAL ( valueChanged ( int ) ), this, SLOT ( setValue ( int ) ) );
						}

						this->pQComboBox_direction = new QComboBox;
						{
							this->pQComboBox_direction->setToolTip ( QObject::tr ( "Direction" ) );

							this->pQComboBox_direction->addItem ( QString ( "I" ) );
							this->pQComboBox_direction->addItem ( QString ( "O" ) );
							this->pQComboBox_direction->addItem ( QString ( "IO" ) );
						}

						pQHBoxLayout_data->addWidget ( this->pPicEdtInteger_value );
						pQHBoxLayout_data->addWidget ( this->pPicEdtBitField8_value );
						pQHBoxLayout_data->addWidget ( this->pQComboBox_direction );
// 						pQHBoxLayout_data->addWidget ( pQPushButton_close );

						pQHBoxLayout_data->setContentsMargins ( 2, 2, 2, 2 );
					}
					pQVBoxLayout_content->addWidget ( this->pQWidget_addr );
					pQVBoxLayout_content->addLayout ( pQHBoxLayout_data );

					pQVBoxLayout_content->setSpacing ( 0 );
					pQVBoxLayout_content->setContentsMargins ( 0, 0, 0, 0 );
				}
				
				QWidget * pQWidget_ioType = new QWidget;
				{
					QVBoxLayout * pQVBoxLayout_ioType = new QVBoxLayout;
					{
						QPushButton * pQPushButton_close = new QPushButton;
						{
							pQPushButton_close->setToolTip ( QObject::tr ( "Close device" ) );
							pQPushButton_close->setFlat ( TRUE );
							pQPushButton_close->setIcon ( QIcon ( ":/main/img/main/closeWidget.png" ) );

							connect ( pQPushButton_close, SIGNAL ( clicked() ), this, SLOT ( closePort() ) );
						}

	// 					pQVBoxLayout_ioType->addStretch ();
						pQVBoxLayout_ioType->addWidget ( pQPushButton_close );
						pQVBoxLayout_ioType->setAlignment ( Qt::AlignTop );
						
						pQVBoxLayout_ioType->setSpacing ( 0 );
						pQVBoxLayout_ioType->setContentsMargins ( 0, 0, 0, 0 );
					}
					pQWidget_ioType->setLayout ( pQVBoxLayout_ioType );
					
					QPalette QPalette_actual = pQWidget_ioType->palette();
					QPalette_actual.setColor ( QPalette::Window, Qt::darkGreen );
					pQWidget_ioType->setPalette ( QPalette_actual );
					pQWidget_ioType->setAutoFillBackground ( TRUE );
				}
				
				pQHBoxLayout_frame->addLayout ( pQVBoxLayout_content );
				pQHBoxLayout_frame->addWidget ( pQWidget_ioType );

				pQHBoxLayout_frame->setSpacing ( 0 );
				pQHBoxLayout_frame->setContentsMargins ( 0, 0, 0, 0 );
			}

			QPalette QPalette_actual = pQFrame->palette();
			QPalette_actual.setColor ( QPalette::Foreground, Qt::black );
			pQFrame->setPalette ( QPalette_actual );

			pQFrame->setFrameShape ( QFrame::Box );
			pQFrame->setFrameShadow ( QFrame::Plain );

			pQFrame->setLayout ( pQHBoxLayout_frame );
		}
		pQVBoxLayout_main->addWidget ( pQFrame );
		pQVBoxLayout_main->setContentsMargins ( 0, 0, 0, 0 );
	}
	QWidget::setLayout ( pQVBoxLayout_main );
}

/**
 *****************************************************************************************************************************
 */

void PicIOPort8Bit::setValue ( int i_value )
{
	this->pPicEdtInteger_value->setValue ( i_value );
	this->pPicEdtBitField8_value->setValue ( i_value );

	this->pPicEdtInteger_value->setHighlighted ( TRUE );
	this->pPicEdtBitField8_value->setHighlighted ( TRUE );
}

/**
 *****************************************************************************************************************************
 */

bool PicIOPort8Bit::getValue ( int * pi_value )
{
	return this->pPicEdtInteger_value->getValue ( pi_value );
}

/**
 *****************************************************************************************************************************
 */

void PicIOPort8Bit::setBase ( int i_base )
{
	this->pPicEdtInteger_addr->setBase ( i_base );
	this->pPicEdtInteger_value->setBase ( i_base );
}

/**
 *****************************************************************************************************************************
 */

void PicIOPort8Bit::closePort ( void )
{
	emit closeRequest ( this );
}

/**
 *****************************************************************************************************************************
 */

void PicIOPort8Bit::setAddr ( int i_addr )
{
	this->pPicEdtInteger_addr->setValue ( i_addr );
}

/**
 *****************************************************************************************************************************
 */

void PicIOPort8Bit::setAddrSymbol ( QString QString_addrSymbol )
{
	this->pQLabel_addrSymbol->setText ( QString_addrSymbol );
}

/**
 *****************************************************************************************************************************
 */

bool PicIOPort8Bit::chkAddr ( int i_value )
{
	int i_addr;

	if ( ! this->pPicEdtInteger_addr->getValue ( & i_addr ) )
		return FALSE;

	if ( i_value != i_addr )
		return FALSE;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicIOPort8Bit::setDirection ( PicIOCommon::eDirection_t eDirection )
{
	if ( static_cast < int > ( eDirection > 2 ) )
		return FALSE;

	this->pQComboBox_direction->setCurrentIndex ( static_cast < int > ( eDirection ) );
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicIOPort8Bit::chkDirection ( PicIOCommon::eDirection_t eDirection_chk )
{
	PicIOCommon::eDirection_t eDirection_port = static_cast < PicIOCommon::eDirection_t > ( this->pQComboBox_direction->currentIndex() );

	if ( ( eDirection_chk == eDirIn ) && ( ( eDirection_port == eDirIn ) || ( eDirection_port == eDirInOut ) ) )
	{
		return TRUE;
	}
	else if ( ( eDirection_chk == eDirOut ) && ( ( eDirection_port == eDirOut ) || ( eDirection_port == eDirInOut ) ) )
	{
		return TRUE;
	}
	else if ( ( eDirection_chk == eDirInOut ) && ( eDirection_port == eDirInOut ) )
	{
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

void PicIOPort8Bit::setHighlighted ( bool b_highlighted )
{
	QPalette QPalette_actual = this->pQWidget_addr->palette();

	if ( b_highlighted )
		QPalette_actual.setColor ( QPalette::Window, this->QColor_bgHighlighted );

	else
		QPalette_actual.setColor ( QPalette::Window, this->QColor_bgNormal );

	this->pQWidget_addr->setPalette ( QPalette_actual );
}

/**
 *****************************************************************************************************************************
 */

void PicIOPort8Bit::clearHighlighted ( void )
{
	this->setHighlighted ( FALSE );
	this->pPicEdtInteger_value->setHighlighted ( FALSE );
	this->pPicEdtBitField8_value->setHighlighted ( FALSE );
}

/**
 *****************************************************************************************************************************
 */

void PicIOPort8Bit::clear ( void )
{



}

/**
 *****************************************************************************************************************************
 */





