/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "Edt.h"
#include "MainDockAreaL.h"
#include "MainDockAreaR.h"
#include "EdtNaviTagList.h"

/**
 *****************************************************************************************************************************
 */

Edt::Edt ( Mod * pMod, QWidget * pQWidget_parent ) : QWidget ( pQWidget_parent )
{
	// Init
	this->pMod               = pMod;
	this->pQToolBar_file     = NULL;
	this->pQToolBar_edit     = NULL;
	this->i_untitledCounter  = 1;

	// Set layout
	QVBoxLayout * pQVBoxLayout_editor = new QVBoxLayout;
	{    
		this->pQTabWidget_editor = new QTabWidget ( this );
		{
			QPushButton * pQPushButton_cornerWidget = new QPushButton;
			{
				pQPushButton_cornerWidget->setFlat ( TRUE );
				pQPushButton_cornerWidget->setIcon ( QIcon ( ":/edt/img/edt/tab-close.png" ) );

				connect ( pQPushButton_cornerWidget, SIGNAL ( clicked ( ) ), this, SLOT ( closeFile ( ) ) );
				
				this->pQTabWidget_editor->setCornerWidget ( pQPushButton_cornerWidget, Qt::TopRightCorner );
			}

			connect ( pQTabWidget_editor, SIGNAL ( currentChanged ( int ) ), this, SLOT ( currentFileChanged ( int ) ) );
			
			pQVBoxLayout_editor->addWidget ( this->pQTabWidget_editor );
		}

		this->pEdtFindReplaceWidget = new EdtFindReplaceWidget;
		{
			// Preset settings
			// 	this->findPreset ( );

			connect (
				this->pEdtFindReplaceWidget,
				 SIGNAL ( findPrev ( EdtFindReplaceWidget::sFRParam_t * ) ),
				 this,
				 SLOT ( findPrev ( EdtFindReplaceWidget::sFRParam_t * ) )
			);
			
			connect (
				this->pEdtFindReplaceWidget,
				 SIGNAL ( findNext ( EdtFindReplaceWidget::sFRParam_t * ) ),
				 this,
				 SLOT ( findNext ( EdtFindReplaceWidget::sFRParam_t * ) )
			);
			
			connect (
				this->pEdtFindReplaceWidget,
				 SIGNAL ( replace ( EdtFindReplaceWidget::sFRParam_t * ) ),
				 this,
				 SLOT ( replace ( EdtFindReplaceWidget::sFRParam_t * ) )
			);
			
			connect (
				this->pEdtFindReplaceWidget,
				 SIGNAL ( replaceAll ( EdtFindReplaceWidget::sFRParam_t * ) ),
				 this,
				 SLOT ( replaceAll ( EdtFindReplaceWidget::sFRParam_t * ) )
			);

			this->pEdtFindReplaceWidget->hide();

			pQVBoxLayout_editor->addWidget ( this->pEdtFindReplaceWidget );
		}

		QWidget::setLayout ( pQVBoxLayout_editor );
	}

	// Setup navi dock widget
	{
		this->pEdtNavi = new EdtNavi;
		connect ( this->pEdtNavi, SIGNAL ( selectTag ( QString, QString ) ), this, SLOT ( selectTag ( QString, QString ) ) );

		this->pMod->pMainDockAreaL->addWidget ( QString ( "Navigator" ), this->pEdtNavi );
		this->pMod->pMainDockAreaL->show();
	}

	// Setup help index widget
	this->initHlpEngine ();

	// Init file system watcher
	this->pQFileSystemWatcher = new QFileSystemWatcher();
	{
		connect (
			this->pQFileSystemWatcher,
			SIGNAL ( fileChanged ( QString ) ),
			this,
			SLOT ( watcherHandleEvent ( QString ) )
		);
	}

	this->createActions ( );
	this->createMenus ( );
	this->createToolBars ( );
}

/**
 *****************************************************************************************************************************
 */

Edt::~Edt ( void )
{
    this->pMod->pEdt = NULL;
    this->pMod->pMainDockAreaL->removeWidget ( this->pEdtNavi );
    this->removeMenus();
    this->removeToolBars();
}

/**
 *****************************************************************************************************************************
 */

void Edt::initHlpEngine ( void )
{
	this->pQHelpEngine = new QHelpEngine ( this->pMod->pSet->App.sSup.QString_hlpCollectionFile );

	if ( ! this->pQHelpEngine->setupData() )
		qDebug() << "Cannot setup help data!";
	
	this->pEdtHlpIndexWidget = new EdtHlpIndex ( this->pQHelpEngine );

	connect (
		this->pEdtHlpIndexWidget, 
		SIGNAL ( linkActivated ( const QUrl & ) ), 
		this, 
		SLOT ( setupHlpDocument ( const QUrl & ) ) 
	);
		
	if ( this->pMod->pSet->App.sSup.b_showHlpCtrlOnRightSide )
	{
		this->pMod->pMainDockAreaR->addWidget ( QString ( "Help" ), this->pEdtHlpIndexWidget );
		this->pMod->pMainDockAreaR->show();
	}
	else
	{
		this->pMod->pMainDockAreaL->addWidget ( QString ( "Help" ), this->pEdtHlpIndexWidget );
		this->pMod->pMainDockAreaL->show();
	}
}

/**
 *****************************************************************************************************************************
 */

void Edt::setupHlpEngine ( void )
{
	if ( this->pMod->pMainDockAreaL->hasWidget ( this->pEdtHlpIndexWidget ) )
		this->pMod->pMainDockAreaL->removeWidget ( this->pEdtHlpIndexWidget );

	if ( this->pMod->pMainDockAreaR->hasWidget ( this->pEdtHlpIndexWidget ) )
		this->pMod->pMainDockAreaR->removeWidget ( this->pEdtHlpIndexWidget );
	
	if ( this->pEdtHlpIndexWidget )
		delete this->pEdtHlpIndexWidget;
	
	if ( this->pQHelpEngine )
		delete this->pQHelpEngine;
	
	this->initHlpEngine ();
}

/**
 *****************************************************************************************************************************
 */
void Edt::createActions ( void )
{
	// File menu actions
	pQAction_newSrcFile = new QAction ( QIcon ( ":/edt/img/edt/document-new.png" ), tr ( "&New" ), this );
	pQAction_newSrcFile->setShortcut ( QKeySequence::New );
	pQAction_newSrcFile->setStatusTip ( tr ( "Create a new document" ) );
	connect ( pQAction_newSrcFile, SIGNAL ( triggered() ), this, SLOT ( newSrcFile() ) );

	pQAction_openSrcFile = new QAction ( QIcon ( ":/edt/img/edt/document-open.png" ), tr ( "&Open..." ), this );
	pQAction_openSrcFile->setShortcut ( QKeySequence::Open );
	pQAction_openSrcFile->setStatusTip ( tr ( "Open an existing document" ) );
	connect ( pQAction_openSrcFile, SIGNAL ( triggered() ), this, SLOT ( openSrcFile() ) );

	pQAction_reloadSrcFile = new QAction ( QIcon ( ":/edt/img/edt/document-revert.png" ), tr ( "&Reload..." ), this );
	pQAction_reloadSrcFile->setShortcut ( QKeySequence::Refresh );
	pQAction_reloadSrcFile->setStatusTip ( tr ( "Reload an existing document" ) );
	connect ( pQAction_reloadSrcFile, SIGNAL ( triggered() ), this, SLOT ( reloadSrcFile( ) ) );

	pQAction_saveSrcFile = new QAction ( QIcon ( ":/edt/img/edt/document-save.png" ), tr ( "&Save" ), this );
	pQAction_saveSrcFile->setShortcut ( QKeySequence::Save );
	pQAction_saveSrcFile->setStatusTip ( tr ( "Save the document to disk" ) );
	pQAction_saveSrcFile->setEnabled ( FALSE );
	connect ( pQAction_saveSrcFile, SIGNAL ( triggered() ), this, SLOT ( saveSrcFile() ) );

	pQAction_saveSrcFileAs = new QAction ( QIcon ( ":/edt/img/edt/document-save-as.png" ), tr ( "Save &As..." ), this );
	pQAction_saveSrcFileAs->setStatusTip ( tr ( "Save the document under a new name" ) );
	pQAction_saveSrcFileAs->setEnabled ( FALSE );
	connect ( pQAction_saveSrcFileAs, SIGNAL ( triggered() ), this, SLOT ( saveSrcFileAs() ) );

	pQAction_saveAll = new QAction ( tr ( "Save all" ), this );
	pQAction_saveAll->setStatusTip ( tr ( "Save all unsaved documents" ) );
	pQAction_saveAll->setEnabled ( TRUE );
	connect ( pQAction_saveAll, SIGNAL ( triggered() ), this, SLOT ( saveAll() ) );
	
	pQAction_closeFile = new QAction ( QIcon ( ":/edt/img/edt/document-close.png" ), tr ( "&Close" ), this );
	pQAction_closeFile->setShortcut ( QKeySequence::Close );
	pQAction_closeFile->setStatusTip ( tr ( "Close the document" ) );
	pQAction_closeFile->setEnabled ( FALSE );
	connect ( pQAction_closeFile, SIGNAL ( triggered() ), this, SLOT ( closeFile() ) );

	pQAction_filterFile = new QAction ( QIcon ( ":/edt/img/edt/document-import.png" ), tr ( "Import file" ), this );
// 	pQAction_filterFile->setShortcut ( QKeySequence::Close );
	pQAction_filterFile->setStatusTip ( tr ( "Import file" ) );
	pQAction_filterFile->setEnabled ( TRUE );
	connect ( pQAction_filterFile, SIGNAL ( triggered() ), this, SLOT ( filterFileInit() ) );

	pQAction_print = new QAction ( QIcon ( ":/edt/img/edt/printer.png" ), tr ( "Print" ), this );
	pQAction_print->setShortcut ( QKeySequence::Print );
	pQAction_print->setStatusTip ( tr ( "Print" ) );
	pQAction_print->setEnabled ( TRUE );
	connect ( pQAction_print, SIGNAL ( triggered() ), this, SLOT ( print() ) );
    
 	// Help menu actions
	pQAction_forward = new QAction ( QIcon ( ":/edt/img/edt/go-next.png" ), tr ( "Go forward in help view" ), this );
	pQAction_forward->setShortcut ( QKeySequence::Forward );
	pQAction_forward->setStatusTip ( tr ( "Navigates forward" ) );
	pQAction_forward->setEnabled ( TRUE );
	connect ( pQAction_forward, SIGNAL ( triggered() ), this, SLOT ( navHlpForward() ) );

	pQAction_backward = new QAction ( QIcon ( ":/edt/img/edt/go-previous.png" ), tr ( "Go back in help view" ), this );
	pQAction_backward->setShortcut ( QKeySequence::Back );
	pQAction_backward->setStatusTip ( tr ( "Navigates backward" ) );
	pQAction_backward->setEnabled ( TRUE );
	connect ( pQAction_backward, SIGNAL ( triggered() ), this, SLOT ( navHlpBackward() ) );
	
    
    
    
	// Edit menu actions
	pQAction_undo = new QAction ( QIcon ( ":/edt/img/edt/edit-undo.png" ), tr ( "&Undo" ), this );
	pQAction_undo->setShortcut ( QKeySequence::Undo );
	pQAction_undo->setStatusTip ( tr ( "Undo last change" ) );
	pQAction_undo->setEnabled ( FALSE );
	connect ( pQAction_undo, SIGNAL ( triggered() ), this, SLOT ( undo() ) );

	pQAction_redo = new QAction ( QIcon ( ":/edt/img/edt/edit-redo.png" ), tr ( "&Redo" ), this );
	pQAction_redo->setShortcut ( QKeySequence::Redo );
	pQAction_redo->setStatusTip ( tr ( "Redo last change" ) );
	pQAction_redo->setEnabled ( FALSE );
	connect ( pQAction_redo, SIGNAL ( triggered() ), this, SLOT ( redo() ) );

    
	pQAction_cut = new QAction ( QIcon ( ":/edt/img/edt/edit-cut.png" ), tr ( "Cu&t" ), this );
	pQAction_cut->setShortcut ( QKeySequence::Cut );
	pQAction_cut->setStatusTip ( tr ( "Cut the current selection's contents to the clipboard" ) );
//         pQAction_cut->setEnabled ( FALSE );
	connect ( pQAction_cut, SIGNAL ( triggered() ), this, SLOT ( cutToClipboard() ) );

	pQAction_copy = new QAction ( QIcon ( ":/edt/img/edt/edit-copy.png" ), tr ( "&Copy" ), this );
	pQAction_copy->setShortcut ( QKeySequence::Copy );
	pQAction_copy->setStatusTip ( tr ( "Copy the current selection's contents to the clipboard" ) );
//         pQAction_copy->setEnabled ( FALSE );
	connect ( pQAction_copy, SIGNAL ( triggered() ), this, SLOT ( copyToClipboard() ) );

	pQAction_paste = new QAction ( QIcon ( ":/edt/img/edt/edit-paste.png" ), tr ( "&Paste" ), this );
	pQAction_paste->setShortcut ( QKeySequence::Paste );
	pQAction_paste->setStatusTip ( tr ( "Paste the clipboard's contents into the current selection" ) );
//         pQAction_paste->setEnabled ( FALSE );
	connect ( pQAction_paste, SIGNAL ( triggered() ), this, SLOT ( pasteFromClipboard() ) );

    
    
    
	pQAction_find = new QAction ( QIcon ( ":/edt/img/edt/document-preview.png" ), tr ( "&Find" ), this );
	pQAction_find->setShortcut ( QKeySequence::Find );
	pQAction_find->setStatusTip ( tr ( "Find..." ) );
	pQAction_find->setEnabled ( FALSE );
	connect ( pQAction_find, SIGNAL ( triggered() ), this, SLOT ( findInit () ) );

	pQAction_findPrev = new QAction ( QIcon ( ":/edt/img/edt/document-preview.png" ), tr ( "Find previous" ), this );
	pQAction_findPrev->setShortcut ( QKeySequence::FindPrevious );
	pQAction_findPrev->setStatusTip ( tr ( "Find previous" ) );
	pQAction_findPrev->setEnabled ( FALSE );
	connect ( pQAction_findPrev, SIGNAL ( triggered() ), this->pEdtFindReplaceWidget, SLOT ( findPrev () ) );

	pQAction_findNext = new QAction ( QIcon ( ":/edt/img/edt/document-preview.png" ), tr ( "Find next" ), this );
	pQAction_findNext->setShortcut ( QKeySequence::FindNext );
	pQAction_findNext->setStatusTip ( tr ( "Find next" ) );
	pQAction_findNext->setEnabled ( FALSE );
	connect ( pQAction_findNext, SIGNAL ( triggered() ), this->pEdtFindReplaceWidget, SLOT ( findNext () ) );

	pQAction_replace = new QAction ( QIcon ( ), tr ( "&Replace" ), this );
	pQAction_replace->setShortcut ( QKeySequence::Replace );
	pQAction_replace->setStatusTip ( tr ( "Replace..." ) );
	pQAction_replace->setEnabled ( FALSE );
	connect ( pQAction_replace, SIGNAL ( triggered() ), this, SLOT ( replaceInit () ) );

	pQAction_hideFindReplaceDlg = new QAction ( QIcon ( ), tr ( "Hide find and replace Dialog" ), this );
	pQAction_hideFindReplaceDlg->setShortcut ( Qt::Key_Escape );
	pQAction_hideFindReplaceDlg->setEnabled ( FALSE );
	connect ( pQAction_hideFindReplaceDlg, SIGNAL ( triggered() ), this, SLOT ( hideFindReplaceWidget () ) );
    
    
    
    
	pQAction_commentOut = new QAction ( QIcon ( ), tr ( "Comment out" ), this );
	pQAction_commentOut->setShortcut ( QKeySequence ( "Alt+C" ) );
	pQAction_commentOut->setStatusTip ( tr ( "Comment out line" ) );
	pQAction_commentOut->setEnabled ( FALSE );
	connect ( pQAction_commentOut, SIGNAL ( triggered() ), this, SLOT ( commentOut () ) );

	pQAction_commentIn = new QAction ( QIcon ( ), tr ( "Comment in" ), this );
	pQAction_commentIn->setShortcut ( QKeySequence ( "Shift+Alt+C" ) );
	pQAction_commentIn->setStatusTip ( tr ( "Comment in line" ) );
	pQAction_commentIn->setEnabled ( FALSE );
	connect ( pQAction_commentIn, SIGNAL ( triggered() ), this, SLOT ( commentIn () ) );

	pQAction_duplicateLine = new QAction ( QIcon ( ), tr ( "Duplicate line" ), this );
	pQAction_duplicateLine->setShortcut ( QKeySequence ( "Ctrl+D" ) );
	pQAction_duplicateLine->setStatusTip ( tr ( "Duplicate line" ) );
	pQAction_duplicateLine->setEnabled ( FALSE );
	connect ( pQAction_duplicateLine, SIGNAL ( triggered() ), this, SLOT ( duplicateLine () ) );

    
    
    
	pQAction_indent = new QAction ( QIcon ( ), tr ( "Indent" ), this );
	pQAction_indent->setShortcut ( QKeySequence ( "Tab" ) );
	pQAction_indent->setStatusTip ( tr ( "Indent" ) );
	pQAction_indent->setEnabled ( TRUE );
	connect ( pQAction_indent, SIGNAL ( triggered() ), this, SLOT ( indent () ) );
    
	pQAction_deindent = new QAction ( QIcon ( ), tr ( "Deindent" ), this );
	pQAction_deindent->setShortcut ( QKeySequence ( "Shift+Tab" ) );
	pQAction_deindent->setStatusTip ( tr ( "Deindent" ) );
	pQAction_deindent->setEnabled ( TRUE );
	connect ( pQAction_deindent, SIGNAL ( triggered() ), this, SLOT ( deindent () ) );
     
    
    
    
    
    
    
    
	pQAction_clearBreakpoints = new QAction ( QIcon ( ":/edt/img/edt/clearBreakpoints.png" ), tr ( "Clears all breakpoints" ), this );
	pQAction_clearBreakpoints->setStatusTip ( tr ( "Clears all breakpoints" ) );
	connect ( pQAction_clearBreakpoints, SIGNAL ( triggered() ), this, SLOT ( clearBreakpoints () ) );
}

/**
 *****************************************************************************************************************************
 */

void Edt::createMenus ( void )
{
    this->pQMenu_file = new QMenu ( tr ( "&File" ) );
    this->pQMenu_file->addAction ( this->pQAction_newSrcFile );
    this->pQMenu_file->addAction ( this->pQAction_openSrcFile );
    this->pQMenu_file->addAction ( this->pQAction_reloadSrcFile );
    this->pQMenu_file->addAction ( this->pQAction_filterFile );
    this->pQMenu_file->addAction ( this->pQAction_saveSrcFile );
    this->pQMenu_file->addAction ( this->pQAction_saveSrcFileAs );
    this->pQMenu_file->addAction ( this->pQAction_saveAll );
    this->pQMenu_file->addSeparator();
    this->pQMenu_file->addAction ( this->pQAction_print );
    this->pQMenu_file->addSeparator();
    this->pQMenu_file->addAction ( this->pQAction_closeFile );

    this->pQMenu_file->setEnabled ( this->pMod->pSet->Prj.sPrj.b_prjVld );

    this->pQMenu_edit = new QMenu ( tr ( "&Edit" ) );
    this->pQMenu_edit->addAction ( this->pQAction_undo );
    this->pQMenu_edit->addAction ( this->pQAction_redo );
    this->pQMenu_edit->addSeparator();
    this->pQMenu_edit->addAction ( this->pQAction_cut );
    this->pQMenu_edit->addAction ( this->pQAction_copy );
    this->pQMenu_edit->addAction ( this->pQAction_paste );
    this->pQMenu_edit->addSeparator();
    this->pQMenu_edit->addAction ( this->pQAction_find );
    this->pQMenu_edit->addAction ( this->pQAction_findPrev );
    this->pQMenu_edit->addAction ( this->pQAction_findNext );
    this->pQMenu_edit->addAction ( this->pQAction_replace );
    this->pQMenu_edit->addAction ( this->pQAction_hideFindReplaceDlg );
    this->pQMenu_edit->addSeparator();
    this->pQMenu_edit->addAction ( this->pQAction_commentOut );
    this->pQMenu_edit->addAction ( this->pQAction_commentIn );
    this->pQMenu_edit->addAction ( this->pQAction_duplicateLine ); 
    this->pQMenu_edit->addAction ( this->pQAction_indent );
    this->pQMenu_edit->addAction ( this->pQAction_deindent );
    this->pQMenu_edit->addSeparator();
    this->pQMenu_edit->addAction ( this->pQAction_clearBreakpoints );
    
    this->pQMenu_edit->setEnabled ( this->pMod->pSet->Prj.sPrj.b_prjVld );
}

/**
 *****************************************************************************************************************************
 */

void Edt::setupMenuBar ( QMenuBar * pQMenuBar )
{
    pQMenuBar->addMenu ( this->pQMenu_file );
    pQMenuBar->addMenu ( this->pQMenu_edit );
}

/**
 *****************************************************************************************************************************
 */

void Edt::removeMenus ( void )
{
    delete this->pQMenu_file;
    delete this->pQMenu_edit;
}

/**
 *****************************************************************************************************************************
 */

void Edt::createToolBars ( void )
{
	this->pQToolBar_file = this->pMod->pQMainWindow->addToolBar ( tr ( "File" ) );
	this->pQToolBar_file->addAction ( this->pQAction_newSrcFile );
	this->pQToolBar_file->addAction ( this->pQAction_openSrcFile );
	this->pQToolBar_file->addAction ( this->pQAction_saveSrcFile );
	this->pQToolBar_file->addAction ( this->pQAction_saveSrcFileAs );
	this->pQToolBar_file->addAction ( this->pQAction_closeFile );

	this->pQToolBar_file->setEnabled ( this->pMod->pSet->Prj.sPrj.b_prjVld );

	this->pQToolBar_help = this->pMod->pQMainWindow->addToolBar ( tr ( "Help" ) );
	this->pQToolBar_help->addAction ( this->pQAction_backward );
	this->pQToolBar_help->addAction ( this->pQAction_forward );
	
	this->pQToolBar_edit = this->pMod->pQMainWindow->addToolBar ( tr ( "Edit" ) );
	this->pQToolBar_edit->addAction ( this->pQAction_undo );
	this->pQToolBar_edit->addAction ( this->pQAction_redo );
	this->pQToolBar_edit->addSeparator ( );
	this->pQToolBar_edit->addAction ( this->pQAction_cut );
	this->pQToolBar_edit->addAction ( this->pQAction_copy );
	this->pQToolBar_edit->addAction ( this->pQAction_paste );
	this->pQToolBar_edit->addSeparator ( );
	this->pQToolBar_edit->addAction ( this->pQAction_find );
	this->pQToolBar_edit->addSeparator ( );
	this->pQToolBar_edit->addAction ( this->pQAction_clearBreakpoints );
	
	this->pQToolBar_edit->setEnabled ( this->pMod->pSet->Prj.sPrj.b_prjVld );

	
	/*	this->pQToolBar_file->setIconSize ( QSize ( this->pMod->pSet->App.sGui.i_iconSize, this->pMod->pSet->App.sGui.i_iconSize ) );
	this->pQToolBar_edit->setIconSize ( QSize ( this->pMod->pSet->App.sGui.i_iconSize, this->pMod->pSet->App.sGui.i_iconSize ) );*/
}

/**
 *****************************************************************************************************************************
 */

void Edt::removeToolBars ( void )
{
    this->pMod->pQMainWindow->removeToolBar ( pQToolBar_edit );
    this->pMod->pQMainWindow->removeToolBar ( pQToolBar_file );
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

void Edt::currentFileChanged ( int i_moduleIndex )
{
	QWidget * pQWidget_current = this->pQTabWidget_editor->widget ( i_moduleIndex );

	if ( ! this->QMapModuleType.contains ( pQWidget_current ) )
		return;

	if ( this->QMapModuleType[ pQWidget_current ] == eModuleTypeEditor )
	{
		EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( pQWidget_current );

		if ( ! pEdtEditorWidget )
			return;

		this->pQAction_undo->setEnabled ( pEdtEditorWidget->getUndoAvailable() );
		this->pQAction_redo->setEnabled ( pEdtEditorWidget->getRedoAvailable() );
		this->pQAction_copy->setEnabled ( pEdtEditorWidget->getCopyAvailable() );
		this->pQAction_cut->setEnabled  ( pEdtEditorWidget->getCopyAvailable() );

		this->pQAction_paste->setEnabled ( TRUE );
		this->pQAction_reloadSrcFile->setEnabled ( TRUE );
		this->pQAction_saveSrcFile->setEnabled ( TRUE );
		this->pQAction_saveSrcFileAs->setEnabled ( TRUE );
		this->pQAction_replace->setEnabled ( TRUE );
		this->pQAction_hideFindReplaceDlg->setEnabled ( TRUE );
		this->pQAction_commentOut->setEnabled ( TRUE );
		this->pQAction_commentIn->setEnabled ( TRUE );
		this->pQAction_duplicateLine->setEnabled ( TRUE ); 
		this->pQAction_indent->setEnabled ( TRUE );
		this->pQAction_deindent->setEnabled ( TRUE );

		this->setTagList();
	}
	else
	{
		EdtHlpViewer * pEdtHlpViewer = static_cast<EdtHlpViewer *> ( pQWidget_current );

		if ( ! pEdtHlpViewer )
			return;
		
		this->pQAction_undo->setEnabled ( FALSE );
		this->pQAction_redo->setEnabled ( FALSE );
		this->pQAction_copy->setEnabled ( pEdtHlpViewer->getCopyAvailable() );
		this->pQAction_cut->setEnabled ( FALSE );
		
		this->pQAction_paste->setEnabled ( FALSE );
		this->pQAction_reloadSrcFile->setEnabled ( FALSE );
		this->pQAction_saveSrcFile->setEnabled ( FALSE );
		this->pQAction_saveSrcFileAs->setEnabled ( FALSE );
		this->pQAction_replace->setEnabled ( FALSE );
		this->pQAction_hideFindReplaceDlg->setEnabled ( FALSE );
		this->pQAction_commentOut->setEnabled ( FALSE );
		this->pQAction_commentIn->setEnabled ( FALSE );
		this->pQAction_duplicateLine->setEnabled ( FALSE ); 
		this->pQAction_indent->setEnabled ( FALSE );
		this->pQAction_deindent->setEnabled ( FALSE );
	}
}

/**
 *****************************************************************************************************************************
 */

void Edt::setCopyAvailable ( QWidget * pQWidget_module, bool b_copyAvailable )
{
	if ( this->pQTabWidget_editor->currentWidget() != pQWidget_module )
		return;

	if ( ! this->QMapModuleType.contains ( pQWidget_module ) )
		return;

	if ( this->QMapModuleType[ pQWidget_module ] == eModuleTypeEditor )
	{
		pQAction_copy->setEnabled ( b_copyAvailable );
		pQAction_cut->setEnabled  ( b_copyAvailable );
	}
	else
	{
		pQAction_copy->setEnabled ( b_copyAvailable );
	}
}

/**
 *****************************************************************************************************************************
 */

void Edt::setUndoAvailable ( QWidget * pQWidget_module, bool b_undoAvailable )
{
	if ( this->pQTabWidget_editor->currentWidget() != pQWidget_module )
		return;
	
	pQAction_undo->setEnabled ( b_undoAvailable );
}

/**
 *****************************************************************************************************************************
 */

void Edt::setRedoAvailable ( QWidget * pQWidget_module, bool b_redoAvailable )
{
	if ( this->pQTabWidget_editor->currentWidget() != pQWidget_module )
		return;
	
	pQAction_redo->setEnabled ( b_redoAvailable );
}

/**
 *****************************************************************************************************************************
 */

void Edt::navHlpForward ( void )
{
	EdtHlpViewer * pEdtHlpViewer = NULL;

	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget ();
	
	if ( ( ! pQWidget ) || ( this->QMapModuleType[ pQWidget ] != eModuleTypeHtmlViewer ) )
		return;
		
	pEdtHlpViewer = static_cast<EdtHlpViewer *> ( pQWidget );

	pEdtHlpViewer->forward();
}

/**
 *****************************************************************************************************************************
 */

void Edt::navHlpBackward ( void )
{
	EdtHlpViewer * pEdtHlpViewer = NULL;

	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget ();
	
	if ( ( ! pQWidget ) || ( this->QMapModuleType[ pQWidget ] != eModuleTypeHtmlViewer ) )
		return;

	pEdtHlpViewer = static_cast<EdtHlpViewer *> ( pQWidget );

	pEdtHlpViewer->back();
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

QString Edt::getTabName ( QString QString_filePath )
{
	// If no file path set
	if ( QString_filePath.isEmpty() )
		return QString ( "Untitled %1" ).arg ( i_untitledCounter++ );

	// Get tab name from file path
	return this->pMod->pSet->Prj.getRelativeFilePath ( QString_filePath );
}

/**
 *****************************************************************************************************************************
 */

void Edt::newSrcFile ( void )
{
    QString QString_filePath     = QString ( "" );
    QString QString_documentText = QString ( "" );
    QString QString_tabName      = getTabName ( QString ( "" ) );

    this->setupSrcFile ( & QString_tabName, & QString_filePath, & QString_documentText );
}

/**
 *****************************************************************************************************************************
 */

bool Edt::openSrcFile ( QString QString_filePath )
{
	QStringList QStringList_filePath;

	if ( QString_filePath.isEmpty () )
	{
		// Init dialog
		QFileDialog QFileDialog_file;
		{
			QFileDialog_file.setViewMode ( QFileDialog::Detail );
			QFileDialog_file.setDefaultSuffix ( QString ( "psm" ) );
			QFileDialog_file.setNameFilter ( tr ( "Assembler files (*.psm)" ) );
			QFileDialog_file.setConfirmOverwrite ( TRUE );
			QFileDialog_file.setAcceptMode ( QFileDialog::AcceptOpen );
			QFileDialog_file.setWindowTitle ( tr ( "Open document" ) );
			QFileDialog_file.setFileMode ( QFileDialog::AnyFile );

			QFileDialog_file.setDirectory ( this->pMod->pSet->Prj.sPrj.QString_prjPath );
		}

		if ( ! QFileDialog_file.exec () )
			return FALSE;

		QStringList_filePath = QFileDialog_file.selectedFiles ();

		if ( QStringList_filePath.count () <= 0 )
			return FALSE;

		QString_filePath = QStringList_filePath.at ( 0 );
	}

	// Check, if file exists
	if ( ! QFileInfo ( QString_filePath ).isReadable () )
	{
		QString QString_msg = QObject::tr ( "Can't read file:" ) + QString ( "\n" ) + QString_filePath;

		QMessageBox::critical ( 0, QObject::tr ( "File dialog" ), QString_msg, QMessageBox::Ok, QMessageBox::Ok );

		return FALSE;
	}

	// Check, if still opened
	for ( int i_iterator = 0; i_iterator < this->pQTabWidget_editor->count (); i_iterator++ )
	{
		EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->widget ( i_iterator ) );

		if ( pEdtEditorWidget &&  ( this->QMapModuleType[ pEdtEditorWidget ] != eModuleTypeEditor ) )
			continue;

		if ( pEdtEditorWidget->getFilePath () == QString_filePath )
			return TRUE;
	}

	// Set status bar information
	this->setStatusBar ( tr ( "Opening document, please wait..." ) );

	QString QString_documentText = QString ( );
	QString QString_tabName      = this->getTabName ( QString_filePath );

	// Check project membership
	this->handlePrjMembership ( QString_filePath );

	// Read document
	if ( this->readSrcFile ( QString_filePath, & QString_documentText ) )
	{
		// Setup document
		this->setupSrcFile ( & QString_tabName, & QString_filePath, & QString_documentText );

		// Watch file for changes
		this->pQFileSystemWatcher->addPath ( QString_filePath );
	}

	// Clear status bar information
	this->clearStatusBar ();

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

void Edt::reloadSrcFile ( QString QString_filePath )
{
	EdtEditorWidget * pEdtEditorWidget = NULL;

	if ( QString_filePath.isEmpty() )
	{
		// Get current document path
		pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->currentWidget() );
		
		if ( ! pEdtEditorWidget )
			return;
			
		QString_filePath = pEdtEditorWidget->getFilePath ();
	}
	else
	{
		// Find document widget by file path
		for ( int i_iterator = 0; i_iterator < this->pQTabWidget_editor->count(); i_iterator++ )
		{
			pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->widget ( i_iterator ) );

			if ( ! pEdtEditorWidget )
				continue;

			if ( pEdtEditorWidget->getFilePath () == QString_filePath )
				break;
		}
	}
	
	// Reload document
	QString QString_documentText;

	if ( this->readSrcFile ( pEdtEditorWidget->getFilePath(), & QString_documentText ) )
	{
		pEdtEditorWidget->setText ( QString_documentText );
		pEdtEditorWidget->clearDocumentChanged();
	}

	// Rebuild tag list
	this->setTagList();
}

/**
 *****************************************************************************************************************************
 */

bool Edt::saveSrcFile ( void )
{
    // Set status bar information
    this->setStatusBar ( tr ( "Saving document..." ) );

    // Get current document
    EdtEditorWidget * pEdtEditorWidget_current = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->currentWidget() );

    if ( ! pEdtEditorWidget_current )
        return FALSE;

    // Check, if document has a path
    if ( pEdtEditorWidget_current->getFilePath().isEmpty() )
        return this->clearStatusBar ( this->saveSrcFileAs ( ) );

    // Store document
    if ( this->writeSrcFile ( pEdtEditorWidget_current->getFilePath(), pEdtEditorWidget_current->toPlainText() ) )
        pEdtEditorWidget_current->clearDocumentChanged();

    // Rebuild tag list
    this->setTagList();

    return this->clearStatusBar ( TRUE );
}

/**
 *****************************************************************************************************************************
 */

bool Edt::saveSrcFileAs ( void )
{
    // Set status bar information
    this->setStatusBar ( tr ( "Saving document..." ) );

    // Get current document
    EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->currentWidget() );

    if ( ! pEdtEditorWidget )
        return FALSE;

    // Init dialog
    QFileDialog QFileDialog_saveSrcFile;
    {
        QFileDialog_saveSrcFile.setViewMode ( QFileDialog::Detail );
        QFileDialog_saveSrcFile.setDefaultSuffix ( QString ( "psm" ) );
        QFileDialog_saveSrcFile.setNameFilter ( tr ( "Assembler files (*.psm)" ) );
        QFileDialog_saveSrcFile.setConfirmOverwrite ( TRUE );
        QFileDialog_saveSrcFile.setAcceptMode ( QFileDialog::AcceptSave );
        QFileDialog_saveSrcFile.setWindowTitle ( tr ( "Save document" ) );
        QFileDialog_saveSrcFile.setFileMode ( QFileDialog::AnyFile );
	QFileDialog_saveSrcFile.setDirectory ( this->pMod->pSet->Prj.sPrj.QString_prjPath );
    }

    if ( ! QFileDialog_saveSrcFile.exec () )
        return this->clearStatusBar ( FALSE );

    QStringList QStringList_prjFilePathes = QFileDialog_saveSrcFile.selectedFiles ();

    if ( QStringList_prjFilePathes.count () != 1 )
        return this->clearStatusBar ( FALSE );

    QString QString_filePath;
    QString_filePath = QStringList_prjFilePathes.at ( 0 );

    this->handlePrjMembership ( QString_filePath );

    if ( this->writeSrcFile ( QString_filePath, pEdtEditorWidget->toPlainText() ) )
    {
        // Set document path to document
        pEdtEditorWidget->setFilePath ( QString_filePath );

        // Set membership to document
        this->setSetEditor ( pEdtEditorWidget );

        // Set tab text
        this->pQTabWidget_editor->setTabText ( this->pQTabWidget_editor->currentIndex (), this->getTabName ( QString_filePath ) );

        // Store document
        if ( this->writeSrcFile ( pEdtEditorWidget->getFilePath (), pEdtEditorWidget->toPlainText () ) )
            pEdtEditorWidget->clearDocumentChanged();

        // Watch file for changes
        this->pQFileSystemWatcher->addPath ( QString_filePath );
    }

    // Rebuild tag list
    this->setTagList();

    // Clear status bar information
    return this->clearStatusBar ( TRUE );
}

/**
 *****************************************************************************************************************************
 */

bool Edt::closeSrcFile ( EdtEditorWidget * pEdtEditorWidget )
{
	if ( ! pEdtEditorWidget )
		return FALSE;

	// Check, if document has a path
	if ( ! pEdtEditorWidget->getFilePath ().isEmpty () )
		this->pQFileSystemWatcher->removePath ( pEdtEditorWidget->getFilePath() );

	// Remove opened document from opened list
	this->pMod->pSet->Prj.sEdt.QStringList_loadedFiles.removeOne ( pEdtEditorWidget->getFilePath() );
	this->pMod->pSet->Prj.setDirty ();
	
	// Check, if document was changed
	if ( pEdtEditorWidget->getDocumentChanged () )
		this->saveSrcFile();

	// Remove tab page and close document
	this->pQTabWidget_editor->removeTab ( this->pQTabWidget_editor->currentIndex () );
	delete pEdtEditorWidget;

	// Check, no more documents opened
	if ( this->pQTabWidget_editor->count() <= 0 )
		this->setActionsEn ( FALSE );

	// Rebuild tag list
	this->setTagList();

	this->QMapModuleType.remove ( static_cast<QWidget *> ( pEdtEditorWidget ) );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool Edt::readSrcFile ( QString QString_filePath, QString * pQString_documentText )
{
    QFile QFile_temp ( QString_filePath );

    if ( ! QFile_temp.open ( QIODevice::ReadOnly | QIODevice::Text ) )
        return FALSE;

    *pQString_documentText = QString ( QFile_temp.readAll() );

    QFile_temp.close();

    return TRUE;
}

/**
 *****************************************************************************************************************************
 */
bool Edt::writeSrcFile ( QString QString_filePath, QString QString_documentText )
{
	this->pQFileSystemWatcher->removePath ( QString_filePath );
	
	QFile QFile_temp ( QString_filePath );

	if ( ! QFile_temp.open ( QIODevice::WriteOnly | QIODevice::Text ) )
		return FALSE;

	QFile_temp.write ( QString_documentText.toUtf8().data() );
	QFile_temp.close();

	this->pQFileSystemWatcher->addPath ( QString_filePath );
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

void Edt::setupSrcFile ( QString * pQString_tabName, QString * pQString_filePath, QString * pQString_documentText )
{
	EdtEditorWidget * pEdtEditorWidget = new EdtEditorWidget ( this );

	if ( ! pEdtEditorWidget )
	return;

	this->setSetEditor ( pEdtEditorWidget );
	
	pEdtEditorWidget->setHighlightingParameter ( this->sHighlightingParameter );
	pEdtEditorWidget->setFilePath ( * pQString_filePath );

	pEdtEditorWidget->setText ( * pQString_documentText );

	pEdtEditorWidget->clearDocumentChanged ( );

	this->QMapModuleType[ pEdtEditorWidget ] = eModuleTypeEditor;

	this->pQTabWidget_editor->addTab ( pEdtEditorWidget, * pQString_tabName );
	this->pQTabWidget_editor->setCurrentWidget ( pEdtEditorWidget );

	this->setActionsEn ( TRUE );

	this->setTagList();

	if ( ! this->pMod->pSet->Prj.sEdt.QStringList_loadedFiles.contains ( * pQString_filePath ) )
	{
		this->pMod->pSet->Prj.sEdt.QStringList_loadedFiles << * pQString_filePath;
		this->pMod->pSet->Prj.setDirty ();
	}

	connect ( pEdtEditorWidget, SIGNAL ( documentChanged ( QWidget *, bool ) ), this, SLOT ( signDocumentStatus ( QWidget *, bool ) ) );
	connect ( pEdtEditorWidget, SIGNAL ( copyAvailable ( QWidget *, bool ) ),   this, SLOT ( setCopyAvailable ( QWidget *, bool ) ) );
	connect ( pEdtEditorWidget, SIGNAL ( undoAvailable ( QWidget *, bool ) ),   this, SLOT ( setUndoAvailable ( QWidget *, bool ) ) );
	connect ( pEdtEditorWidget, SIGNAL ( redoAvailable ( QWidget *, bool ) ),   this, SLOT ( setRedoAvailable ( QWidget *, bool ) ) );
	connect ( pEdtEditorWidget, SIGNAL ( breakpointChanged () ),                this, SLOT ( emitBreakpointChanged () ) );
}

/**
 *****************************************************************************************************************************
 */

void Edt::setupHlpDocument ( const QUrl & QUrl_src )
{
	EdtHlpViewer * pEdtHlpViewer = NULL;

	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget ();
	
	if ( pQWidget && ( this->QMapModuleType[ pQWidget ] == eModuleTypeHtmlViewer ) )
		pEdtHlpViewer = static_cast<EdtHlpViewer *> ( pQWidget );

	if ( ! pEdtHlpViewer )
	{
		pEdtHlpViewer = new EdtHlpViewer ( this->pQHelpEngine, this );

		if ( ! pEdtHlpViewer )
			return;

		connect ( pEdtHlpViewer, SIGNAL ( copyAvailable ( QWidget *, bool ) ),    this, SLOT ( setCopyAvailable ( QWidget *, bool ) ) );
		connect ( pEdtHlpViewer, SIGNAL ( titleChanged  ( QWidget *, QString ) ), this, SLOT ( setHtmlTabText   ( QWidget *, QString ) ) );
    
		this->QMapModuleType[ pEdtHlpViewer ] = eModuleTypeHtmlViewer;

		this->pQTabWidget_editor->addTab ( pEdtHlpViewer, "Untitled" );
		this->pQTabWidget_editor->setCurrentWidget ( pEdtHlpViewer );
	}
	
	pEdtHlpViewer->setSource ( QUrl_src );
// 	this->pQTabWidget_editor->setTabText ( this->pQTabWidget_editor->indexOf ( pQWidget ), "Untitled" );
}

/**
 *****************************************************************************************************************************
 */

void Edt::setupHtmlDocument ( QString QString_filePath )
{
	QString QString_html;
	{
		QFile QFile_html ( QString_filePath );

		if ( ! QFile_html.open ( QIODevice::ReadOnly | QIODevice::Text ) )
			return;

		QString_html = QFile_html.readAll();

		QFile_html.close ();
	}

	EdtHlpViewer * pEdtHlpViewer = NULL;

	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget ();
	
	if ( pQWidget && ( this->QMapModuleType[ pQWidget ] == eModuleTypeHtmlViewer ) )
		pEdtHlpViewer = static_cast<EdtHlpViewer *> ( pQWidget );

	if ( ! pEdtHlpViewer )
	{
		pEdtHlpViewer = new EdtHlpViewer ( this->pQHelpEngine, this );

		if ( ! pEdtHlpViewer )
			return;

		connect ( pEdtHlpViewer, SIGNAL ( copyAvailable ( QWidget *, bool ) ),    this, SLOT ( setCopyAvailable ( QWidget *, bool ) ) );
		connect ( pEdtHlpViewer, SIGNAL ( titleChanged  ( QWidget *, QString ) ), this, SLOT ( setHtmlTabText   ( QWidget *, QString ) ) );
    
		this->QMapModuleType[ pEdtHlpViewer ] = eModuleTypeHtmlViewer;

		this->pQTabWidget_editor->addTab ( pEdtHlpViewer, "Untitled" );
		this->pQTabWidget_editor->setCurrentWidget ( pEdtHlpViewer );
	}

	pEdtHlpViewer->setHtml ( QString_html );
}

/**
 *****************************************************************************************************************************
 */

void Edt::setHtmlTabText ( QWidget * pQWidget, QString QString_title )
{
	if ( ! pQWidget )
		return;

	if (this->QMapModuleType[ pQWidget ] != eModuleTypeHtmlViewer )
		return;
	
	this->pQTabWidget_editor->setTabText ( this->pQTabWidget_editor->indexOf ( pQWidget ), QString_title );
	
}

/**
 *****************************************************************************************************************************
 */

bool Edt::closeFile ( void )
{
	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget ();

	if ( ! pQWidget )
		return FALSE;
		
	if ( ! this->QMapModuleType.contains ( pQWidget ) )
		return FALSE;

	if ( this->QMapModuleType[ pQWidget ] == eModuleTypeEditor )
	{
		EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( pQWidget );

		if ( ! this->closeSrcFile ( pEdtEditorWidget ) )
			return FALSE;

		if ( ! this->pQTabWidget_editor->count () )
			this->pEdtFindReplaceWidget->hide ();

		return TRUE;
	}
	else
	{
		// Remove tab page and close document
		this->pQTabWidget_editor->removeTab ( this->pQTabWidget_editor->currentIndex () );
		delete pQWidget;

		// Check, no more documents opened
		if ( this->pQTabWidget_editor->count() <= 0 )
			this->setActionsEn ( FALSE );

		// Rebuild tag list
// 		this->setTagList();

		this->QMapModuleType.remove ( static_cast<QWidget *> ( pQWidget ) );		
	}

    return FALSE;
}

/**
 *****************************************************************************************************************************
 */

void Edt::setActionsEn ( bool b_en )
{
    this->pQAction_saveSrcFile->setEnabled ( b_en );
    this->pQAction_saveSrcFileAs->setEnabled ( b_en );
    this->pQAction_closeFile->setEnabled ( b_en );
    this->pQAction_find->setEnabled ( b_en );
    this->pQAction_findPrev->setEnabled ( b_en );
    this->pQAction_findNext->setEnabled ( b_en );
    this->pQAction_replace->setEnabled ( b_en );
    this->pQAction_commentOut->setEnabled ( b_en );
    this->pQAction_commentIn->setEnabled ( b_en );
    this->pQAction_duplicateLine->setEnabled ( b_en );
}

/**
 *****************************************************************************************************************************
 */

void Edt::handlePrjMembership ( QString QString_filePath )
{
    // Check, if path located within project folder
    if ( ! QString_filePath.contains ( this->pMod->pSet->Prj.sPrj.QString_prjPath ) )
    {
        QString QString_message;
        QString_message  = QString_filePath;
        QString_message += QString ( ": \n\n" );
        QString_message += QString ( tr ( "This file is not located beneath the project folder and therefore could not be added to project." ) );

        QMessageBox::warning ( this, tr ( "Opening file" ), QString_message, QMessageBox::Ok, QMessageBox::Ok );
        return;
    }

    // Check, if file not available in project
    if ( ! this->chkPrjMembership ( QString_filePath ) )
    {
        QString QString_message;
        QString_message  = QString_filePath;
        QString_message += QString ( ": \n\n" );
        QString_message += QString ( tr ( "This file is not a member of the project. Do you want to add it?" ) );

        int i_retVal = QMessageBox::warning ( this, tr ( "Adding file to project" ), QString_message, QMessageBox::Yes | QMessageBox::No, QMessageBox::No );

        if ( QMessageBox::Yes != i_retVal )
            return;

        this->pMod->pSet->Prj.sSrc.QStringList_srcFiles << QString_filePath;
	this->pMod->pSet->Prj.setDirty();
    }
}

/**
 *****************************************************************************************************************************
 */

bool Edt::chkPrjMembership ( QString QString_filePath )
{
	if ( ! this->pMod->pSet->Prj.sSrc.QStringList_srcFiles.contains ( QString_filePath ) )
		return FALSE;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

void Edt::signDocumentStatus ( QWidget * pQWidget_EdtEditorWidget, bool b_documentChanged )
{
	int i_tabIndex = this->pQTabWidget_editor->indexOf ( pQWidget_EdtEditorWidget );

	if ( i_tabIndex == -1 )
	return;

	if ( b_documentChanged )
		this->pQTabWidget_editor->setTabIcon ( i_tabIndex, QIcon ( ":/edt/img/edt/fileSaveSmall.png" ) );
	else
		this->pQTabWidget_editor->setTabIcon ( i_tabIndex, QIcon ( "" ) );
}

/**
 *****************************************************************************************************************************
 */

void Edt::copyToClipboard ( void )
{
	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget ();
	
	if ( this->QMapModuleType[ pQWidget ] == eModuleTypeEditor )
	{
		EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->currentWidget() );
		
		if ( ! pEdtEditorWidget )
			return;
		
		pEdtEditorWidget->copy();
	}
	else
	{
		EdtHlpViewer * pEdtHlpViewer = static_cast<EdtHlpViewer *> ( this->pQTabWidget_editor->currentWidget() );
		
		if ( ! pEdtHlpViewer )
			return;
		
		pEdtHlpViewer->copy();
	}
}

/**
 *****************************************************************************************************************************
 */

void Edt::cutToClipboard ( void )
{
	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget ();
	
	if ( this->QMapModuleType[ pQWidget ] == eModuleTypeEditor )
	{
		EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->currentWidget() );
		
		if ( ! pEdtEditorWidget )
			return;
		
		pEdtEditorWidget->cut();
	}
	else
	{
		EdtHlpViewer * pEdtHlpViewer = static_cast<EdtHlpViewer *> ( this->pQTabWidget_editor->currentWidget() );
		
		if ( ! pEdtHlpViewer )
			return;
		
		pEdtHlpViewer->copy();
	}
}

/**
 *****************************************************************************************************************************
 */

void Edt::pasteFromClipboard ( void )
{
	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget ();
	
	if ( this->QMapModuleType[ pQWidget ] == eModuleTypeEditor )
	{
		EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->currentWidget() );
		
		if ( ! pEdtEditorWidget )
			return;
		
		pEdtEditorWidget->paste();
	}
}

/**
 *****************************************************************************************************************************
 */

void Edt::undo ( void )
{
	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget ();
	
	if ( this->QMapModuleType[ pQWidget ] == eModuleTypeEditor )
	{
		EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->currentWidget() );
		
		if ( ! pEdtEditorWidget )
			return;
		
		pEdtEditorWidget->undo();
	}
}

/**
 *****************************************************************************************************************************
 */

void Edt::redo ( void )
{
	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget ();
	
	if ( this->QMapModuleType[ pQWidget ] == eModuleTypeEditor )
	{
		EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->currentWidget() );
		
		if ( ! pEdtEditorWidget )
			return;
		
		pEdtEditorWidget->redo();
	}
}

/**
 *****************************************************************************************************************************
 */

void Edt::indent ( void )
{
	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget ();
	
	if ( this->QMapModuleType[ pQWidget ] == eModuleTypeEditor )
	{
		EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->currentWidget() );
		
		if ( ! pEdtEditorWidget )
			return;
		
		pEdtEditorWidget->indent ();
	}
}

/**
 *****************************************************************************************************************************
 */

void Edt::deindent ( void )
{
	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget ();
	
	if ( this->QMapModuleType[ pQWidget ] == eModuleTypeEditor )
	{
		EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->currentWidget() );
		
		if ( ! pEdtEditorWidget )
			return;
		
		pEdtEditorWidget->deindent ();
	}
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

void Edt::findInit ( void )
{
	EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->currentWidget () );
	
	if ( ! pEdtEditorWidget )
		return;
	
	this->pEdtFindReplaceWidget->setMode ( EdtFindReplaceWidget::eModeFind );
	this->pEdtFindReplaceWidget->show ();
	this->pEdtFindReplaceWidget->setInitFocus ( pEdtEditorWidget->getSelection () );
	this->pQAction_hideFindReplaceDlg->setEnabled ( TRUE );
	
}

/**
 *****************************************************************************************************************************
 */

void Edt::findPrev ( EdtFindReplaceWidget::sFRParam_t * psFRParam )
{
	// Get current document
	EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->currentWidget () );

	if ( ! pEdtEditorWidget )
		return;

	EdtEditorWidget::sSetFndRepl_t sSetFndRepl;
	
	sSetFndRepl.b_fndFromCursor          = TRUE;
	sSetFndRepl.b_fndBackwards           = TRUE;
	sSetFndRepl.b_fndCaseSensitive       = psFRParam->b_fndCaseSensitive;
	sSetFndRepl.b_fndWholeWords          = psFRParam->b_fndWholeWords;

	sSetFndRepl.QString_find             = psFRParam->QString_find;

    
	if ( ! pEdtEditorWidget->find ( & sSetFndRepl ) )
	{
		QMessageBox::warning ( this, tr ( "Find" ), QString ( tr ( "End of file reached." ) ), QMessageBox::Ok, QMessageBox::Ok );
		return;
	}

	return;
}


/**
 *****************************************************************************************************************************
 */

void Edt::findNext ( EdtFindReplaceWidget::sFRParam_t * psFRParam )
{
	// Get current document
	EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->currentWidget () );

	if ( ! pEdtEditorWidget )
		return;

	EdtEditorWidget::sSetFndRepl_t sSetFndRepl;
	
	sSetFndRepl.b_fndFromCursor          = TRUE;
	sSetFndRepl.b_fndBackwards           = FALSE;
	sSetFndRepl.b_fndCaseSensitive       = psFRParam->b_fndCaseSensitive;
	sSetFndRepl.b_fndWholeWords          = psFRParam->b_fndWholeWords;
	
	sSetFndRepl.QString_find             = psFRParam->QString_find;

    
	if ( ! pEdtEditorWidget->find ( & sSetFndRepl ) )
	{
		QMessageBox::warning ( this, tr ( "Find" ), QString ( tr ( "End of file reached." ) ), QMessageBox::Ok, QMessageBox::Ok );
		return;
	}

	return;
}

/**
 *****************************************************************************************************************************
 */

void Edt::replaceInit ( void )
{
	EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->currentWidget () );
	
	if ( ! pEdtEditorWidget )
		return;
	
	this->pEdtFindReplaceWidget->setMode ( EdtFindReplaceWidget::eModeReplace );
	this->pEdtFindReplaceWidget->show ();
	this->pEdtFindReplaceWidget->setInitFocus ( pEdtEditorWidget->getSelection () );
	this->pQAction_hideFindReplaceDlg->setEnabled ( TRUE );
}

/**
 *****************************************************************************************************************************
 */

void Edt::replace ( EdtFindReplaceWidget::sFRParam_t * psFRParam )
{
	// Get current document
	EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->currentWidget () );

	if ( ! pEdtEditorWidget )
		return;

	EdtEditorWidget::sSetFndRepl_t sSetFndRepl;
	
	sSetFndRepl.b_fndFromCursor          = TRUE;
	sSetFndRepl.b_fndBackwards           = FALSE;
	sSetFndRepl.b_fndCaseSensitive       = psFRParam->b_fndCaseSensitive;
	sSetFndRepl.b_fndWholeWords          = psFRParam->b_fndWholeWords;
	
	sSetFndRepl.QString_find             = psFRParam->QString_find;
	sSetFndRepl.QString_replace          = psFRParam->QString_replace;

	if ( ! pEdtEditorWidget->replace ( & sSetFndRepl ) )
	{
		QMessageBox::warning ( this, tr ( "Find" ), QString ( tr ( "End of file reached." ) ), QMessageBox::Ok, QMessageBox::Ok );
		return;
	}

	return;
}

/**
 *****************************************************************************************************************************
 */

void Edt::replaceAll ( EdtFindReplaceWidget::sFRParam_t * psFRParam )
{
	// Get current document
	EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( this->pQTabWidget_editor->currentWidget () );

	if ( ! pEdtEditorWidget )
		return;

	EdtEditorWidget::sSetFndRepl_t sSetFndRepl;
	
	sSetFndRepl.b_fndFromCursor          = FALSE;
	sSetFndRepl.b_fndBackwards           = FALSE;
	sSetFndRepl.b_fndCaseSensitive       = psFRParam->b_fndCaseSensitive;
	sSetFndRepl.b_fndWholeWords          = psFRParam->b_fndWholeWords;
	
	sSetFndRepl.QString_find             = psFRParam->QString_find;
	sSetFndRepl.QString_replace          = psFRParam->QString_replace;

	pEdtEditorWidget->replaceAll ( & sSetFndRepl );

	return;
}

/**
 *****************************************************************************************************************************
 */

void Edt::hideFindReplaceWidget ( void )
{
	this->pEdtFindReplaceWidget->hide ();
	
	this->pQAction_hideFindReplaceDlg->setEnabled ( FALSE );
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

void Edt::changeSettings ( void )
{
	// Set help widget
	if ( this->pMod->pMainDockAreaR->hasWidget ( this->pEdtHlpIndexWidget ) )
		this->pMod->pMainDockAreaR->removeWidget ( this->pEdtHlpIndexWidget );

	else if ( this->pMod->pMainDockAreaL->hasWidget ( this->pEdtHlpIndexWidget ) )
		this->pMod->pMainDockAreaL->removeWidget ( this->pEdtHlpIndexWidget );

	if ( this->pMod->pSet->App.sSup.b_showHlpCtrlOnRightSide )
	{
		this->pMod->pMainDockAreaR->addWidget ( QString ( "Help" ), this->pEdtHlpIndexWidget );
		this->pMod->pMainDockAreaR->show();
	}
	else
	{
		this->pMod->pMainDockAreaL->addWidget ( QString ( "Help" ), this->pEdtHlpIndexWidget );
		this->pMod->pMainDockAreaL->show();
	}

	// Setup help engine
	if ( this->pMod->pSet->App.sSup.QString_hlpCollectionFile != this->pQHelpEngine->collectionFile() )
		this->setupHlpEngine ();
	
	// Store editor settings
	this->sHighlightingParameter.formats.QTextCharFormat_cmd         = this->pMod->pSet->App.sEdt.QTextCharFormat_cmd;
	this->sHighlightingParameter.formats.QTextCharFormat_directive   = this->pMod->pSet->App.sEdt.QTextCharFormat_directive;
	this->sHighlightingParameter.formats.QTextCharFormat_hw          = this->pMod->pSet->App.sEdt.QTextCharFormat_hw;
	this->sHighlightingParameter.formats.QTextCharFormat_hexNumber   = this->pMod->pSet->App.sEdt.QTextCharFormat_hexNumber;
	this->sHighlightingParameter.formats.QTextCharFormat_decNumber   = this->pMod->pSet->App.sEdt.QTextCharFormat_decNumber;
	this->sHighlightingParameter.formats.QTextCharFormat_octNumber   = this->pMod->pSet->App.sEdt.QTextCharFormat_octNumber;
	this->sHighlightingParameter.formats.QTextCharFormat_comment     = this->pMod->pSet->App.sEdt.QTextCharFormat_comment;
	this->sHighlightingParameter.formats.QTextCharFormat_separator   = this->pMod->pSet->App.sEdt.QTextCharFormat_separator;
	this->sHighlightingParameter.formats.QTextCharFormat_fct         = this->pMod->pSet->App.sEdt.QTextCharFormat_fct;
	this->sHighlightingParameter.formats.QTextCharFormat_doc         = this->pMod->pSet->App.sEdt.QTextCharFormat_doc;
	this->sHighlightingParameter.formats.QTextCharFormat_navi        = this->pMod->pSet->App.sEdt.QTextCharFormat_navi;

	// Load files stored in settings
	int i_loadedFilesCount = this->pMod->pSet->Prj.sEdt.QStringList_loadedFiles.count ();

	for ( int i_iterator = 0; i_iterator < i_loadedFilesCount; i_iterator++ )
	{
		QString QString_filePath = this->pMod->pSet->Prj.sEdt.QStringList_loadedFiles.at ( i_iterator );

		if ( ! this->openSrcFile ( QString_filePath ) )
			this->pMod->pSet->Prj.sEdt.QStringList_loadedFiles.removeOne ( QString_filePath );
	}

	// Set settings to editors
	this->setSetEditorAll ();

	// Enable/disable menus
	this->pQMenu_file->setEnabled ( this->pMod->pSet->Prj.sPrj.b_prjVld );
	this->pQMenu_edit->setEnabled ( this->pMod->pSet->Prj.sPrj.b_prjVld );
	
	this->pQToolBar_file->setEnabled ( this->pMod->pSet->Prj.sPrj.b_prjVld );
	this->pQToolBar_edit->setEnabled ( this->pMod->pSet->Prj.sPrj.b_prjVld );
}

/**
 *****************************************************************************************************************************
 */

void Edt::setSetEditor ( EdtEditorWidget * pEdtEditorWidget )
{
	pEdtEditorWidget->setFont              ( this->pMod->pSet->App.sEdt.QFont_std );
	pEdtEditorWidget->setTabStopWidth      ( this->pMod->pSet->App.sEdt.i_tabIndent );
	pEdtEditorWidget->setDynamicWordWrapEn ( this->pMod->pSet->App.sEdt.b_dynamicWordWrapEn );
	pEdtEditorWidget->setBgColorCursor     ( this->pMod->pSet->App.sEdt.QColor_bgCursor );
	pEdtEditorWidget->setBgColorHighlight  ( this->pMod->pSet->App.sEdt.QColor_bgHighlight );

	pEdtEditorWidget->setHighlightingParameter ( this->sHighlightingParameter );

	if ( this->chkPrjMembership ( pEdtEditorWidget->getFilePath () ) )
		pEdtEditorWidget->setBreakpointEn ( TRUE );
	else
		pEdtEditorWidget->setBreakpointEn ( FALSE );
}

/**
 *****************************************************************************************************************************
 */

void Edt::setSetEditorAll ( void )
{
	int i_tabPageCount = this->pQTabWidget_editor->count ();

	for ( int i_iterator = 0; i_iterator < i_tabPageCount; i_iterator++ )
	{
		QWidget * pQWidget = this->pQTabWidget_editor->widget ( i_iterator );

		if ( this->QMapModuleType[ pQWidget ] == eModuleTypeEditor )
		{
			if ( pQWidget )
				this->setSetEditor ( static_cast<EdtEditorWidget *> ( pQWidget ) );
		}
	}
}

/**
 *****************************************************************************************************************************
 */

void Edt::watcherHandleEvent ( QString QString_filePath )
{
	this->pQFileSystemWatcher->removePath ( QString_filePath );
	
	QString QString_file;
	{
		QString_file = "<b>" + this->pMod->pSet->Prj.getRelativeFilePath ( QString_filePath ) + "</b>";
	}
	
	QString QString_msg;
	{
		QString_msg = QObject::tr ( "The file %1 was changed outside of the editor. Do you want to reload the file?" ).arg ( QString_file );
	}
	
	int i_retVal = QMessageBox::warning ( this, 
					      tr ( "File monitoring" ), 
					      QString_msg, 
					      QMessageBox::Yes | QMessageBox::No, QMessageBox::No );

	if ( i_retVal == QMessageBox::Yes )
		this->reloadSrcFile ( QString_filePath );

	this->pQFileSystemWatcher->addPath ( QString_filePath );
}

/**
 *****************************************************************************************************************************
 */

void Edt::setStatusBar ( QString QString_message = QString ( ) )
{
    this->pMod->pQMainWindow->statusBar()->showMessage ( QString_message );
    this->pMod->pQMainWindow->statusBar()->repaint();
}


/**
 *****************************************************************************************************************************
 */

bool Edt:: clearStatusBar ( bool b_retVal )
{
    this->pMod->pQMainWindow->statusBar()->clearMessage();

    return b_retVal;
}

/**
 *****************************************************************************************************************************
 */

void Edt::setTagList ( void )
{
	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget();

	if ( this->QMapModuleType[ pQWidget ] != eModuleTypeEditor )
		return;
			
	EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( pQWidget );

	if ( ! pEdtEditorWidget )
	{
		this->pEdtNavi->clearTagList();
		return;
	}

	EdtNaviTagList * pEdtNaviTagList = new EdtNaviTagList;
	{
		int i_tabIndex = this->pQTabWidget_editor->indexOf ( pEdtEditorWidget );

		if ( i_tabIndex == -1 )
			return;

		QString QString_tabName = this->pQTabWidget_editor->tabText ( i_tabIndex );

		pEdtEditorWidget->getTagList ( pEdtNaviTagList );

		this->pEdtNavi->setTagList ( QString_tabName, pEdtNaviTagList );
	}
}

/**
 *****************************************************************************************************************************
 */

void Edt::selectTag ( QString QString_tabName, QString QString_tag )
{
	for ( int i_iterator = 0; i_iterator < this->pQTabWidget_editor->count(); i_iterator++ )
	{
		if ( QString_tabName == this->pQTabWidget_editor->tabText ( i_iterator ) )
		{
			QWidget * pQWidget = this->pQTabWidget_editor->widget ( i_iterator );

			if ( ! pQWidget )
				return;

			if ( this->QMapModuleType[ pQWidget ] != eModuleTypeEditor )
				return;
			
			EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( pQWidget );

			pEdtEditorWidget->selectTag ( QString_tag );

			this->pQTabWidget_editor->setCurrentWidget ( pQWidget );
			break;
		}
	}
}

/**
 *****************************************************************************************************************************
 */

void Edt::commentOut ( void )
{
	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget();

	if ( ! pQWidget )
		return;
	
	if ( this->QMapModuleType[ pQWidget ] != eModuleTypeEditor )
		return;

	EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( pQWidget );

	pEdtEditorWidget->commentOut ();
}

/**
 *****************************************************************************************************************************
 */

void Edt::commentIn ( void )
{
	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget();

	if ( ! pQWidget )
		return;

	if ( this->QMapModuleType[ pQWidget ] != eModuleTypeEditor )
		return;

	EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( pQWidget );

	pEdtEditorWidget->commentIn ();
}

/**
 *****************************************************************************************************************************
 */

void Edt::duplicateLine ( void )
{
	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget();

	if ( ! pQWidget )
		return;

	if ( this->QMapModuleType[ pQWidget ] != eModuleTypeEditor )
		return;

	EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( pQWidget );

	pEdtEditorWidget->duplicateLine( );
}

/**
 *****************************************************************************************************************************
 */



void Edt::clearLineSelections ( void )
{
	for ( int i_iterator = 0; i_iterator < this->pQTabWidget_editor->count(); i_iterator++ )
	{
		QWidget * pQWidget = this->pQTabWidget_editor->widget ( i_iterator );
		
		if ( ! pQWidget )
			continue;

		if ( this->QMapModuleType[ pQWidget ] != eModuleTypeEditor )
			continue;

		EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( pQWidget );

		pEdtEditorWidget->clearLineHighlighting ();
	}
}

/**
 *****************************************************************************************************************************
 */

void Edt::getBreakpoints ( QMap<QString,QList<int> > * pQMap_breakpoints )
{
	for ( int i_iterator = 0; i_iterator < this->pQTabWidget_editor->count (); i_iterator++ )
	{
		QWidget * pQWidget = this->pQTabWidget_editor->widget ( i_iterator );
		
		if ( ! pQWidget )
			continue;
		
		if ( this->QMapModuleType[ pQWidget ] != eModuleTypeEditor )
			continue;

		EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( pQWidget );

		QList<int> QListI_breakpoints;

		pEdtEditorWidget->getbreakpoints ( & QListI_breakpoints );

		( * pQMap_breakpoints )[ pEdtEditorWidget->getFilePath () ] = QListI_breakpoints;
	}
}

/**
 *****************************************************************************************************************************
 */

void Edt::clearBreakpoints ( void )
{
	for ( int i_iterator = 0; i_iterator < this->pQTabWidget_editor->count (); i_iterator++ )
	{
		QWidget * pQWidget = this->pQTabWidget_editor->widget ( i_iterator );
		
		if ( ! pQWidget )
			continue;
		
		if ( this->QMapModuleType[ pQWidget ] != eModuleTypeEditor )
			continue;

		EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( pQWidget );

		pEdtEditorWidget->clearBreakpoints ();
	}
}

/**
 *****************************************************************************************************************************
 */

void Edt::emitBreakpointChanged ( void )
{
    emit breakpointChanged ();
}

/**
 *****************************************************************************************************************************
 */

void Edt::setHighlightingParameter ( EdtEditorHighlighter::sHighlightingKeyWords_t sHighlightingKeyWords )
{
    this->sHighlightingParameter.keyWords = sHighlightingKeyWords;

    this->sHighlightingParameter.keyWords.QStringList_navi = EdtNaviTagList::getCmdList();
    
    this->setSetEditorAll ();
}

/**
 *****************************************************************************************************************************
 */

bool Edt::getLineFromCursor ( QString * pQString_filePath, int * pi_lineNumber )
{
	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget ();
		
	if ( ! pQWidget )
		return FALSE;
	
	if ( this->QMapModuleType[ pQWidget ] == eModuleTypeEditor )
	{
		EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( pQWidget );

		*pQString_filePath = pEdtEditorWidget->getFilePath ();
		*pi_lineNumber     = pEdtEditorWidget->getLineFromCursor ();

		return TRUE;
	}
	else
	{
		// To implement
	}
	
	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

void Edt::filterFileInit ( void )
{
	EdtDlgFilter * pEdtDlgFilter = new EdtDlgFilter;

	pEdtDlgFilter->setPath ( this->pMod->pSet->Prj.sPrj.QString_prjPath );
	pEdtDlgFilter->setHighlightingParameter ( this->sHighlightingParameter );
	
	this->QMapModuleType[ pEdtDlgFilter ] = eModuleTypeFilter;

	this->pQTabWidget_editor->addTab ( pEdtDlgFilter, "Import filter" );
	this->pQTabWidget_editor->setCurrentWidget ( pEdtDlgFilter );
	
	connect (
		pEdtDlgFilter,
		SIGNAL ( fileFiltered ( QString ) ),
		this,
		SLOT ( filterFileShow ( QString ) )
	);
}

/**
 *****************************************************************************************************************************
 */

void Edt::filterFileShow ( QString QString_documentText )
{
    QString QString_filePath = QString ( "" );
    QString QString_tabName  = getTabName ( QString ( "" ) );

    this->setupSrcFile ( & QString_tabName, & QString_filePath, & QString_documentText );
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Printing
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

void Edt::print ( void )
{
	// Get current document
	QWidget * pQWidget = this->pQTabWidget_editor->currentWidget ();

	if ( ! pQWidget )
		return;
	
	// Check document type
	if ( this->QMapModuleType[ pQWidget ] == eModuleTypeEditor )
		this->printEditorWidget ( static_cast <EdtEditorWidget *> ( pQWidget ) );
	
	else if ( this->QMapModuleType[ pQWidget ] == eModuleTypeHtmlViewer )
		this->printHlpViewer    ( static_cast <EdtHlpViewer *>    ( pQWidget ) );
	
	else
		qDebug() << "Nothing to print!";
}

/**
 *****************************************************************************************************************************
 */

void Edt::printEditorWidget ( EdtEditorWidget * pEdtEditorWidget )
{
	if ( ! pEdtEditorWidget )
		return;
	
	// Setup printer
	QPrinter * pQPrinter = new QPrinter ( QPrinter::HighResolution );
	
	// Setup print dialog
	QPrintDialog * pQPrintDialog = new QPrintDialog( pQPrinter, this );
	{
		pQPrintDialog->setWindowTitle ( QObject::tr ( "Print Document" ) );
	
		if ( pEdtEditorWidget->textCursor().hasSelection() )
			pQPrintDialog->addEnabledOption ( QAbstractPrintDialog::PrintSelection );
	}
	
	// Show print dialog and print
	if ( pQPrintDialog->exec() == QDialog::Accepted )
		pEdtEditorWidget->print ( pQPrinter );
	
	// Tidy up
	delete pQPrintDialog;
	delete pQPrinter;
}

/**
 *****************************************************************************************************************************
 */

void Edt::printHlpViewer ( EdtHlpViewer * pEdtHlpViewer )
{
	if ( ! pEdtHlpViewer )
		return;
	
	// Setup printer
	QPrinter * pQPrinter = new QPrinter ( QPrinter::HighResolution );
	
	// Setup print dialog
	QPrintDialog * pQPrintDialog = new QPrintDialog( pQPrinter, this );
	{
		pQPrintDialog->setWindowTitle ( QObject::tr ( "Print Document" ) );
	
// 		if ( pEdtHlpViewer->textCursor().hasSelection() )
// 			pQPrintDialog->addEnabledOption ( QAbstractPrintDialog::PrintSelection );
	}
	
	// Show print dialog and print
	if ( pQPrintDialog->exec() == QDialog::Accepted )
		pEdtHlpViewer->print ( pQPrinter );
	
	// Tidy up
	delete pQPrintDialog;
	delete pQPrinter;
}

/**
 *****************************************************************************************************************************
 */

QWidget * Edt::getModuleFromUrl ( eModuleType_t eModuleType, QUrl QUrl_doc )
{
	switch ( eModuleType )
	{
		case eModuleTypeEditor:
		{
			for ( int i_iterator = 0; i_iterator < this->pQTabWidget_editor->count(); i_iterator++ )
			{
				QWidget * pQWidget = this->pQTabWidget_editor->widget ( i_iterator );
				
				if ( ! pQWidget )
					continue;

				if ( this->QMapModuleType[ pQWidget ] == eModuleTypeEditor )
				{
					EdtEditorWidget * pEdtEditorWidget = static_cast <EdtEditorWidget *> ( pQWidget );
					
					if ( pEdtEditorWidget->getFilePath() == QUrl_doc.path() )
					{
						this->pQTabWidget_editor->setCurrentWidget ( pQWidget );
						return pQWidget;
					}
				}
			}
			break;
		}
		case eModuleTypeHtmlViewer:
		{
			for ( int i_iterator = 0; i_iterator < this->pQTabWidget_editor->count(); i_iterator++ )
			{
				QWidget * pQWidget = this->pQTabWidget_editor->widget ( i_iterator );
				
				if ( ! pQWidget )
					continue;

				if ( this->QMapModuleType[ pQWidget ] == eModuleTypeHtmlViewer )
				{
					EdtHlpViewer * pEdtHlpViewer = static_cast <EdtHlpViewer *> ( pQWidget );
					
					if ( pEdtHlpViewer->url() == QUrl_doc )
					{
						this->pQTabWidget_editor->setCurrentWidget ( pQWidget );
						return pQWidget;
					}
				}
			}
			break;
		}
	}

	return NULL;
}

/**
 *****************************************************************************************************************************
 */

void Edt::setupDocument ( QUrl QUrl_doc )
{
	qDebug() << QUrl_doc;
	
	// Check if url is set
	if ( QUrl_doc.isEmpty() )
		return;
	
	if ( QUrl_doc.scheme() == "file" )
	{
		// Check if document still opened
		QWidget * pQWidget = this->getModuleFromUrl ( eModuleTypeEditor, QUrl_doc );

		if ( ! pQWidget )
		{
			this->openSrcFile ( QUrl_doc.path() );

			pQWidget = this->getModuleFromUrl ( eModuleTypeEditor, QUrl_doc );

			if ( ! pQWidget )
				return;
		}

		EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( pQWidget );
	
		pEdtEditorWidget->selectLine ( QUrl_doc.fragment().toInt() );
	}
	else if ( QUrl_doc.scheme() == "qthelp" )
	{
		// Check if document still opened
		QWidget * pQWidget = this->getModuleFromUrl ( eModuleTypeHtmlViewer, QUrl_doc );

		if ( pQWidget )
		{
			EdtHlpViewer * pEdtHlpViewer = static_cast<EdtHlpViewer *> ( pQWidget );
	
			pEdtHlpViewer->setSource ( QUrl_doc );
		}
		else
		{
			this->setupHlpDocument ( QUrl_doc );

// 			pQWidget = this->getModuleFromUrl ( eModuleTypeHtmlViewer, QUrl_doc );

// 			if ( ! pQWidget )
// 				return;
		}
	}
}

/**
 *****************************************************************************************************************************
 */

void Edt::saveAll ( void )
{
	for ( int i_iterator = 0; i_iterator < this->pQTabWidget_editor->count (); i_iterator++ )
	{
		QWidget * pQWidget = this->pQTabWidget_editor->widget ( i_iterator );
		
		if ( ! this->QMapModuleType.contains ( pQWidget ) )
			continue;
		
		if ( this->QMapModuleType[ pQWidget ] != eModuleTypeEditor )
			continue;
		
		EdtEditorWidget * pEdtEditorWidget = static_cast<EdtEditorWidget *> ( pQWidget );
		
		if ( pEdtEditorWidget->getDocumentChanged () )
		{
			this->pQTabWidget_editor->setCurrentWidget ( pQWidget );
			this->saveSrcFile();
		}
	}
	
	
}

/**
 *****************************************************************************************************************************
 */

void Edt::closeAllWithoutMemory ( void )
{
	this->saveAll ();
	
	for ( int i_iterator = 0; i_iterator < this->pQTabWidget_editor->count (); i_iterator++ )
	{
		QWidget * pQWidget = this->pQTabWidget_editor->widget ( i_iterator );

		// Remove tab page and close document
		this->pQTabWidget_editor->removeTab ( i_iterator );
		
		if ( ! this->QMapModuleType.contains ( pQWidget ) )
		{
			printf ( "Edt::closeAllWithoutMemory - Widget to close not in list!\n" );
			continue;
		}
		
		switch ( this->QMapModuleType[ pQWidget ] )
		{
			case eModuleTypeEditor:		delete static_cast<EdtEditorWidget *> ( pQWidget );	break;
			case eModuleTypeHtmlViewer:	delete static_cast<EdtHlpViewer *>    ( pQWidget );	break;
			case eModuleTypeFilter:		delete static_cast<EdtDlgFilter *>    ( pQWidget );	break;
		}
	}
	
	this->setActionsEn ( FALSE );
}

/**
 *****************************************************************************************************************************
 */





