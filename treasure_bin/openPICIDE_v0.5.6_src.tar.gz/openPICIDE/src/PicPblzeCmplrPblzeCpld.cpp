/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeCmplrPblzeCpld.h"

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Constructor/destructor
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

PicPblzeCmplrPblzeCpld::PicPblzeCmplrPblzeCpld ( QObject * pQObject_parent ) : PicPblzeCmplr ( pQObject_parent )
{
	this->QMap_reg [ "s0" ] = 0x0;
	this->QMap_reg [ "s1" ] = 0x1;
	this->QMap_reg [ "s2" ] = 0x2;
	this->QMap_reg [ "s3" ] = 0x3;
	this->QMap_reg [ "s4" ] = 0x4;
	this->QMap_reg [ "s5" ] = 0x5;
	this->QMap_reg [ "s6" ] = 0x6;
	this->QMap_reg [ "s7" ] = 0x7;
}

/**
 *****************************************************************************************************************************
 */

PicPblzeCmplrPblzeCpld::~PicPblzeCmplrPblzeCpld()
{
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Compile
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compile ( void )
{
	// Parse code
	if ( ! PicPblzeAsmParser::parse () )
		return FALSE;

	// Allocate new pic memory
	PicPblzeCmplr::asMemCell = new sMemCell_t[ PicPblzeAsmParser::sMem.i_memSize ];

	// Preset pic memory with zero
	memset ( PicPblzeCmplr::asMemCell, NULL, ( PicPblzeAsmParser::sMem.i_memSize * sizeof ( PicPblzeCmplr::sMemCell_t ) ) );
	
	// Compile
	for ( int i_iterator = 0; i_iterator < this->sMem.i_memSize; ++i_iterator )
	{
		unsigned int ui_memCell;
		
		sCodeLine_t * psCodeLine = PicPblzeAsmParser::sMem.apsCodeLine_memMap[ i_iterator ];
		
		if ( ! psCodeLine )
			continue;
		
		if ( psCodeLine->eLineType > PicPblzeAsmParser::eLineType_cmd )
		{
			// Get memory line
			if ( ! this->compileCmd ( psCodeLine, & ui_memCell ) )
			{
				PicPblzeCmplr::msgEmit ( PicPblzeCmplr::eMsgType_compError );
				return FALSE;
			}

			// Store memory line
			PicPblzeCmplr::asMemCell [ i_iterator ].b_valid  = TRUE;
			PicPblzeCmplr::asMemCell [ i_iterator ].ui_value = ui_memCell;
		}
		else
		{
			PicPblzeCmplr::msgEmit ( PicPblzeCmplr::eMsgType_compError );
			return FALSE;
		}
	}

	// Write output file
	return this->writeOutputFile ();
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Compile commands
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	switch ( psCodeLine->eLineType )
	{
		case eLineType_cmdRet:		return this->compileCmdReturn  ( psCodeLine, pui_memCell );
		case eLineType_cmdReti:		return this->compileCmdReturnI ( psCodeLine, pui_memCell );
		case eLineType_cmdAddc:		return this->compileCmdAddCy   ( psCodeLine, pui_memCell );
		case eLineType_cmdSubc:		return this->compileCmdSubCy   ( psCodeLine, pui_memCell );
		case eLineType_cmdIn:		return this->compileCmdInput   ( psCodeLine, pui_memCell );
		case eLineType_cmdOut:		return this->compileCmdOutput  ( psCodeLine, pui_memCell );
		case eLineType_cmdEint:		return this->compileCmdIntEn   ( psCodeLine, pui_memCell );
		case eLineType_cmdDint:		return this->compileCmdIntDis  ( psCodeLine, pui_memCell );
// 		case eLineType_cmdComp:		return this->compileCmdCompare ( psCodeLine, pui_memCell );
		case eLineType_cmdAdd:		return this->compileCmdAdd     ( psCodeLine, pui_memCell );
		case eLineType_cmdAnd:		return this->compileCmdAnd     ( psCodeLine, pui_memCell );
		case eLineType_cmdCall:		return this->compileCmdCall    ( psCodeLine, pui_memCell );
		case eLineType_cmdJump:		return this->compileCmdJump    ( psCodeLine, pui_memCell );
		case eLineType_cmdLoad:		return this->compileCmdLoad    ( psCodeLine, pui_memCell );
		case eLineType_cmdOr:		return this->compileCmdOr      ( psCodeLine, pui_memCell );
		case eLineType_cmdRl:		return this->compileCmdRl      ( psCodeLine, pui_memCell );
		case eLineType_cmdRr:		return this->compileCmdRr      ( psCodeLine, pui_memCell );
		case eLineType_cmdSl0:		return this->compileCmdSl0     ( psCodeLine, pui_memCell );
		case eLineType_cmdSl1:		return this->compileCmdSl1     ( psCodeLine, pui_memCell );
		case eLineType_cmdSlA:		return this->compileCmdSla     ( psCodeLine, pui_memCell );
		case eLineType_cmdSlX:		return this->compileCmdSlx     ( psCodeLine, pui_memCell );
		case eLineType_cmdSr0:		return this->compileCmdSr0     ( psCodeLine, pui_memCell );
		case eLineType_cmdSr1:		return this->compileCmdSr1     ( psCodeLine, pui_memCell );
		case eLineType_cmdSrA:		return this->compileCmdSra     ( psCodeLine, pui_memCell );
		case eLineType_cmdSrX:		return this->compileCmdSrx     ( psCodeLine, pui_memCell );
		case eLineType_cmdSub:		return this->compileCmdSub     ( psCodeLine, pui_memCell );
// 		case eLineType_cmdTest:		return this->compileCmdTest    ( psCodeLine, pui_memCell );
		case eLineType_cmdXor:		return this->compileCmdXor     ( psCodeLine, pui_memCell );
// 		case eLineType_cmdStore:	return this->compileCmdStore   ( psCodeLine, pui_memCell );
// 		case eLineType_cmdFetch:	return this->compileCmdFetch   ( psCodeLine, pui_memCell );
	}

	PicPblzeAsmParser::msgEmit ( PicPblzeAsmParser::eMsgType_ivldCmd, psCodeLine );

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdAdd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x2000, 0x6000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdAddCy ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x2800, 0x6800, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdAnd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x0800, 0x4800, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdCall ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();
	QString QString_addr;

	//********************************************************************************************************************
	//* Check for jump type
	//********************************************************************************************************************
	if ( QString_arg0 == QString ( "C" ) )		// CALL C
	{
		*pui_memCell = 0xDE00;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "NC" ) )	// CALL NC
	{
		*pui_memCell = 0xDF00;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "NZ" ) )	// CALL NZ
	{
		*pui_memCell = 0xDD00;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "Z" ) )	// CALL Z
	{
		*pui_memCell = 0xDC00;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else
	{
		*pui_memCell = 0xD800;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	}

	//********************************************************************************************************************
	//* Check for address
	//********************************************************************************************************************
	{
		sCodeLine_t * psCodeLine_addr;

		if ( ! PicPblzeAsmParser::checkArgRef ( QString_addr, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell |= compileArgMAddr ( psCodeLine_addr->i_addr );
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdIntDis ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	*pui_memCell = 0xF000;
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdIntEn ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	*pui_memCell = 0xF001;
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdInput ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegPAddr ( psCodeLine, 0x8000, 0xC000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdJump ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();
	QString QString_addr;

	//********************************************************************************************************************
	//* Check for jump type
	//********************************************************************************************************************
	if ( QString_arg0 == QString ( "C" ) )		// JUMP C
	{
		*pui_memCell = 0xD600;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "NC" ) )	// JUMP NC
	{
		*pui_memCell = 0xD700;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "NZ" ) )	// JUMP NZ
	{
		*pui_memCell = 0xD500;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "Z" ) )	// JUMP Z
	{
		*pui_memCell = 0xD400;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else
	{
		*pui_memCell = 0xD000;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	}

	//********************************************************************************************************************
	//* Check for address
	//********************************************************************************************************************
	{
		sCodeLine_t * psCodeLine_addr;

		if ( ! PicPblzeAsmParser::checkArgRef ( QString_addr, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell |= compileArgMAddr ( psCodeLine_addr->i_addr );
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdLoad ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x0000, 0x4000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdOr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x1000, 0x5000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdOutput ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegPAddr ( psCodeLine, 0x8800, 0xC800, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdReturn ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0;

	if ( psCodeLine->QStringList_args.count () > 0 )
		QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();

	//********************************************************************************************************************
	//* Check for jump type
	//********************************************************************************************************************
	if ( QString_arg0 == QString ( "C" ) )		// RETURN C
	{
		*pui_memCell  = 0x9600;
	}
	else if ( QString_arg0 == QString ( "NC" ) )	// RETURN NC
	{
		*pui_memCell  = 0x9700;
	}
	else if ( QString_arg0 == QString ( "NZ" ) )	// RETURN NZ
	{
		*pui_memCell  = 0x9500;
	}
	else if ( QString_arg0 == QString ( "Z" ) )	// RETURN Z
	{
		*pui_memCell  = 0x9400;
	}
	else
	{
		*pui_memCell  = 0x9000;
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdReturnI ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();

	if ( QString_arg0 == QString ( "DISABLE" ) )
		*pui_memCell = 0xB000;

	else if ( QString_arg0 == QString ( "ENABLE" ) )
		*pui_memCell = 0xB001;

	else
		return FALSE;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdRl ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xA004, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdRr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xA00C, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdSl0 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xA006, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdSl1 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xA007, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdSla ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xA000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdSlx ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xA002, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdSr0 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xA00E, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdSr1 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xA00F, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdSra ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xA008, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdSrx ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0xA00A, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdSub ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x3000, 0x7000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdSubCy ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x3800, 0x7800, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileCmdXor ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x1800, 0x5800, pui_memCell );
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Compile arguments
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileArgMemRegVsRegConst ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memConst, int i_memReg, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QStirng_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	QString QString_regDst;
	QString QString_regSrc;
	int i_constant;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	//********************************************************************************************************************
	//* Check for constant
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgNumberConst ( QStirng_arg1, & i_constant ) )
	{
		*pui_memCell = i_memConst | compileArgRegDst ( QString_regDst ) | compileArgConst ( i_constant );
		return TRUE;
	}

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgRegSubst ( QStirng_arg1, & QString_regSrc ) )
	{
		*pui_memCell = i_memReg | compileArgRegDst ( QString_regDst ) | compileArgRegSrc ( QString_regSrc );
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileArgMemRegVsRegPAddr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memPAddr, int i_memReg, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QStirng_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	QString QString_regDst;
	QString QString_regSrc;
	int i_pAddr;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	//********************************************************************************************************************
	//* Check for port address
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgNumberConst ( QStirng_arg1, & i_pAddr ) )
	{
		*pui_memCell = i_memPAddr | compileArgRegDst ( QString_regDst ) | compileArgPAddr ( i_pAddr );
		return TRUE;
	}

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgAddrByReg ( QStirng_arg1, & QString_regSrc ) )
	{
		*pui_memCell = i_memReg | compileArgRegDst ( QString_regDst ) | compileArgRegSrc ( QString_regSrc );
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::compileArgMemReg ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_mem, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );

	QString QString_regDst;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	*pui_memCell = i_mem | compileArgRegDst ( QString_regDst );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblzeCpld::compileArgRegDst ( QString QString_regDst )
{
	return ( this->QMap_reg [ QString_regDst ] & 0x7 ) << 8;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblzeCpld::compileArgRegSrc ( QString QString_regSrc )
{
	return ( this->QMap_reg [ QString_regSrc ] & 0x7 ) << 5;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblzeCpld::compileArgConst ( int i_const )
{
	return i_const & 0xFF;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblzeCpld::compileArgMAddr ( int i_addr )
{
	return i_addr & 0xFF;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblzeCpld::compileArgPAddr ( int i_addr )
{
	return i_addr & 0xFF;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Write output files
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::writeOutputFile ( void )
{
	switch ( this->sCfg.eOutputType )
	{
		case E_OUT_VHDL:	return this->writeOutputFileVhdl ();
		case E_OUT_VERILOG:	return this->writeOutputFileVerilog ();
		case E_OUT_MEM:		return PicPblzeCmplr::writeOutputFileMem ();
		case E_OUT_HEX:		return PicPblzeCmplr::writeOutputFileHex ();
	}	
	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::writeOutputFileVhdl ( void )
{
	// Open destination file
	QFile QFile_output ( this->sCfg.QString_outputFilePath );

	if ( ! QFile_output.open ( QIODevice::ReadWrite | QIODevice::Text ) )
	{
		this->msgEmit ( eMsgType_outputFileIO );
		return FALSE;
	}

	// Set file size to zero
	QFile_output.resize ( 0 );

	QTextStream QTextStream_output ( & QFile_output );

	QTextStream_output << "library ieee;\n";
	QTextStream_output << "use ieee.std_logic_1164.all;\n";
	QTextStream_output << "use ieee.std_logic_unsigned.all;\n";
	QTextStream_output << "\n";
	QTextStream_output << "entity " + PicPblzeCmplr::sCfg.QString_entityName + " is\n";
	QTextStream_output << "	port( address : in std_logic_vector(7 downto 0);\n";
	QTextStream_output << "		clk : in std_logic;\n";
	QTextStream_output << "		dout : out std_logic_vector(15 downto 0));\n";
	QTextStream_output << "	end;\n";
	QTextStream_output << "\n";
	QTextStream_output << "architecture v1 of " + PicPblzeCmplr::sCfg.QString_entityName + " is\n";
	QTextStream_output << "\n";
	QTextStream_output << "	constant ROM_WIDTH: INTEGER:= 16;\n";
	QTextStream_output << "	constant ROM_LENGTH: INTEGER:= 256;\n";
	QTextStream_output << "\n";
	QTextStream_output << "	subtype rom_word is std_logic_vector(ROM_WIDTH-1 downto 0);\n";
	QTextStream_output << "	type rom_table is array (0 to ROM_LENGTH-1) of rom_word;\n";
	QTextStream_output << "\n";
	QTextStream_output << "constant rom: rom_table := rom_table'(\n";

	int i_lastMemCell = PicPblzeAsmParser::sMem.i_memSize - 1;
	
	for ( int i_iterator = 0; i_iterator < PicPblzeAsmParser::sMem.i_memSize; i_iterator++ )
	{
		PicPblzeCmplr::sMemCell_t sMemCell = PicPblzeCmplr::asMemCell[ i_iterator ];
		
		if ( sMemCell.b_valid )
			QTextStream_output << "	\"" + QString ( "%1" ).arg ( sMemCell.ui_value, 16, 2, QChar ( '0' ) ) + "\"";
		else
			QTextStream_output << "	\"" + QString ( "%1" ).arg ( 0, 16, 2, QChar ( '0' ) ) + "\"";
		
		if ( i_iterator < i_lastMemCell )
			QTextStream_output << ",\n";
		else
			QTextStream_output << ");\n";
	}

	QTextStream_output << "\n";
	QTextStream_output << "begin\n";
	QTextStream_output << "\n";
	QTextStream_output << "process (clk)\n";
	QTextStream_output << "begin\n";
	QTextStream_output << "	if clk'event and clk = '1' then\n";
	QTextStream_output << "		dout <= rom(conv_integer(address));\n";
	QTextStream_output << "	end if;\n";
	QTextStream_output << "end process;\n";
	QTextStream_output << "end v1;\n";

	QFile_output.close();

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeCpld::writeOutputFileVerilog ( void )
{
	// Open destination file
	QFile QFile_output ( this->sCfg.QString_outputFilePath );

	if ( ! QFile_output.open ( QIODevice::ReadWrite | QIODevice::Text ) )
	{
		this->msgEmit ( eMsgType_outputFileIO );
		return FALSE;
	}

	// Set file size to zero
	QFile_output.resize ( 0 );

	QTextStream QTextStream_output ( & QFile_output );

	QTextStream_output << "library ieee;\n";
	QTextStream_output << "use ieee.std_logic_1164.all;\n";
	QTextStream_output << "use ieee.std_logic_unsigned.all;\n";
	QTextStream_output << "\n";
	QTextStream_output << "entity " + PicPblzeCmplr::sCfg.QString_entityName +" is\n";
	QTextStream_output << "	port( address : in std_logic_vector(7 downto 0);\n";
	QTextStream_output << "		clk : in std_logic;\n";
	QTextStream_output << "		dout : out std_logic_vector(15 downto 0));\n";
	QTextStream_output << "	end " + PicPblzeCmplr::sCfg.QString_entityName + ";\n";
	QTextStream_output << "\n";
	QTextStream_output << "architecture v1 of " + PicPblzeCmplr::sCfg.QString_entityName + " is\n";
	QTextStream_output << "\n";
	QTextStream_output << "	constant ROM_WIDTH: INTEGER:= 16;\n";
	QTextStream_output << "	constant ROM_LENGTH: INTEGER:= 256;\n";
	QTextStream_output << "\n";
	QTextStream_output << "	subtype rom_word is std_logic_vector(ROM_WIDTH-1 downto 0);\n";
	QTextStream_output << "	type rom_table is array (0 to ROM_LENGTH-1) of rom_word;\n";
	QTextStream_output << "\n";
	QTextStream_output << "constant rom: rom_table := rom_table'(\n";

	for ( int i_iterator = 0; i_iterator < PicPblzeAsmParser::sMem.i_memSize; i_iterator++ )
	{
		PicPblzeCmplr::sMemCell_t sMemCell = PicPblzeCmplr::asMemCell[ i_iterator ];
		
		if ( sMemCell.b_valid )
			QTextStream_output << "	\"" + QString ( "%1" ).arg ( sMemCell.ui_value, 16, 2, QChar ( '0' ) ) + "\",\n";
		else
			QTextStream_output << "	\"" + QString ( "%1" ).arg ( 0, 16, 2, QChar ( '0' ) ) + "\",\n";
	}

	QTextStream_output << "\n";
	QTextStream_output << "begin\n";
	QTextStream_output << "\n";
	QTextStream_output << "process (clk)\n";
	QTextStream_output << "begin\n";
	QTextStream_output << "	if clk'event and clk = '1' then\n";
	QTextStream_output << "		dout <= rom(conv_integer(address));\n";
	QTextStream_output << "	end if;\n";
	QTextStream_output << "end process;\n";
	QTextStream_output << "end v1;\n";

	QFile_output.close();

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */
