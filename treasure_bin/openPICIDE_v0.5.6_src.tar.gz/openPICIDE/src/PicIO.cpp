/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicIO.h"

/**
 *****************************************************************************************************************************
 */

PicIO::PicIO ( QWidget * pQWidget_parent ) : QWidget ( pQWidget_parent )
{
	this->sDevElement_start = NULL;
	this->sDevElement_stop  = NULL;
	this->eDirection_last   = PicIOCommon::eDirIn;
	this->i_base            = 16;

	QVBoxLayout * pQVBoxLayout_main = new QVBoxLayout;
	{
		QHBoxLayout * pQHBoxLayout_element = new QHBoxLayout;
		{
			this->pQComboBox_device = new QComboBox;
			{
				this->pQComboBox_device->addItem ( QString ( "Port" ) );
				this->pQComboBox_device->addItem ( QString ( "Fifo" ) );
				this->pQComboBox_device->addItem ( QString ( "Memory block" ) );
			}

			QPushButton * pQPushButton_add = new QPushButton;
			{
				pQPushButton_add->setText ( QString ( tr ( "Add" ) ) );
				connect ( pQPushButton_add, SIGNAL ( clicked () ), this, SLOT ( addDevFromMenu () ) );
			}

			QPushButton * pQPushButton_removeAll = new QPushButton;
			{
				pQPushButton_removeAll->setText ( QString ( tr ( "Remove all" ) ) );
				connect ( pQPushButton_removeAll, SIGNAL ( clicked () ), this, SLOT ( closeAllDev () ) );
			}

			pQHBoxLayout_element->addStretch();
			pQHBoxLayout_element->addWidget ( this->pQComboBox_device );
			pQHBoxLayout_element->addWidget ( pQPushButton_add );
			pQHBoxLayout_element->addWidget ( pQPushButton_removeAll );
		}

		this->pQScrollArea_devLst = new QScrollArea;
		{
			QWidget * pQWidget = new QWidget;
			{
				this->pQVBoxLayout_devLst = new QVBoxLayout;
				{

					this->pQVBoxLayout_devLst->setContentsMargins ( 0, 0, 0, 0 );
					this->pQVBoxLayout_devLst->addStretch ();
				}

				pQWidget->setLayout ( this->pQVBoxLayout_devLst );

//                                 QPalette QPalette_actual = pQWidget->palette();
//                                 QPalette_actual.setColor ( QPalette::Normal, QPalette::Window, Qt::red );
//                                 pQWidget->setPalette ( QPalette_actual );
				pQWidget->setAutoFillBackground ( TRUE );
			}

//                         this->pPicIOEventFilter = new PicIOEventFilter ( this );

//                         this->pQScrollArea_devLst->setSizePolicy ( QSizePolicy ( QSizePolicy::Fixed, QSizePolicy::Fixed ) );
//                         this->pQScrollArea_devLst->setBaseSize ( 0, 0 );
			this->pQScrollArea_devLst->setHorizontalScrollBarPolicy ( Qt::ScrollBarAlwaysOff );
			this->pQScrollArea_devLst->setVerticalScrollBarPolicy ( Qt::ScrollBarAlwaysOn );

			this->pQScrollArea_devLst->setContentsMargins ( 0, 0, 0, 0 );
			this->pQScrollArea_devLst->setWidgetResizable ( TRUE );
			this->pQScrollArea_devLst->setWidget ( pQWidget );

//                         this->pQScrollArea_devLst->installEventFilter ( this->pPicIOEventFilter );
		}

//                 pQVBoxLayout_main->setContentsMargins ( 0, 0, 0, 0 );
		pQVBoxLayout_main->addLayout ( pQHBoxLayout_element );
		pQVBoxLayout_main->addWidget ( this->pQScrollArea_devLst );
//                 pQVBoxLayout_main->addStretch ();
	}

	QWidget::setLayout ( pQVBoxLayout_main );
}

/**
 *****************************************************************************************************************************
 */

PicIO::~PicIO()
{
	this->closeAllDev();
}

/**
 *****************************************************************************************************************************
 */

void PicIO::setBase ( int i_base )
{
	this->i_base = i_base;

	sDevElement_t * psDevElement = this->sDevElement_start;

	while ( psDevElement )
	{
		switch ( psDevElement->eIOType )
		{
			case ePort: static_cast <PicIOPort8Bit *> ( psDevElement->pQWidget )->setBase ( i_base ); break;
			case eFifo: static_cast <PicIOFifo8Bit *> ( psDevElement->pQWidget )->setBase ( i_base ); break;
			case eMem:  static_cast <PicIOMem *>      ( psDevElement->pQWidget )->setBase ( i_base ); break;
		}
		psDevElement = psDevElement->psDevElement_next;
	}
	emit contentChanged ( this );
}

/**
 *****************************************************************************************************************************
 */

PicIO::sDevElement_t * PicIO::addDevFromMenu ( void )
{
	switch ( this->pQComboBox_device->currentIndex() )
	{
		case 0: return this->addDev ( ePort, this->eDirection_last ); break;
		case 1: return this->addDev ( eFifo, this->eDirection_last ); break;
		case 2: return this->addDev ( eMem,  this->eDirection_last );  break;
	}
}

/**
 *****************************************************************************************************************************
 */

PicIO::sDevElement_t * PicIO::addDev ( eIOType_t eIOType, PicIOCommon::eDirection_t eDirection )
{
	// Note direction
	this->eDirection_last = eDirection;
	
	// Add element to chain
	sDevElement_t * psDevElement = new sDevElement_t;

	if ( ! this->sDevElement_stop )
	{
		psDevElement->psDevElement_prev = NULL;
		psDevElement->psDevElement_next = NULL;

		this->sDevElement_start = psDevElement;
		this->sDevElement_stop  = psDevElement;
	}
	else
	{
		psDevElement->psDevElement_prev = this->sDevElement_stop;
		psDevElement->psDevElement_next = NULL;

		this->sDevElement_stop->psDevElement_next = psDevElement;
		this->sDevElement_stop = psDevElement;
	}

	// Set io type
	psDevElement->eIOType = eIOType;

	// Set io widget
	if ( eIOType == ePort )
	{
		PicIOPort8Bit * pPicIOPort8Bit = new PicIOPort8Bit;

		connect (
			pPicIOPort8Bit,
			SIGNAL ( closeRequest ( QWidget * ) ),
			this,
			SLOT ( closeDev ( QWidget * ) )
		);

		pPicIOPort8Bit->setHighlighted ( TRUE );
		pPicIOPort8Bit->setBase ( this->i_base );
		pPicIOPort8Bit->setDirection ( eDirection );

		psDevElement->pQWidget = static_cast <QWidget *> ( pPicIOPort8Bit );
	}
	else if ( eIOType == eFifo )
	{
		PicIOFifo8Bit * pPicIOFifo8Bit = new PicIOFifo8Bit;

		connect (
			pPicIOFifo8Bit,
			SIGNAL ( closeRequest ( QWidget * ) ),
			this,
			SLOT ( closeDev ( QWidget * ) )
		);

		pPicIOFifo8Bit->setHighlighted ( TRUE );
		pPicIOFifo8Bit->setBase ( this->i_base );
		pPicIOFifo8Bit->setDirection ( eDirection );

		psDevElement->pQWidget = static_cast <QWidget *> ( pPicIOFifo8Bit );
	}
	else if ( eIOType == eMem )
	{
		PicIOMem * pPicIOMem = new PicIOMem;

		connect (
			pPicIOMem,
			SIGNAL ( closeRequest ( QWidget * ) ),
			this,
			SLOT ( closeDev ( QWidget * ) )
		);

		pPicIOMem->setHighlighted ( TRUE );
		pPicIOMem->setBase ( this->i_base );
		pPicIOMem->setDirection ( eDirection );

		psDevElement->pQWidget = static_cast <QWidget *> ( pPicIOMem );
	}

	this->pQVBoxLayout_devLst->insertWidget ( 0, psDevElement->pQWidget );

	// Set minimum width
	{
		int i_minimumWidth;
		
		i_minimumWidth  = this->pQScrollArea_devLst->widget()->width();
		i_minimumWidth += this->pQScrollArea_devLst->verticalScrollBar()->sizeHint().width();
		
		this->pQScrollArea_devLst->setMinimumWidth ( i_minimumWidth );
	}

	return psDevElement;
}

/**
 *****************************************************************************************************************************
 */

void PicIO::closeDev ( QWidget * pQWidget )
{
	sDevElement_t * psDevElement = this->sDevElement_start;

	while ( psDevElement )
	{
		if ( static_cast < QWidget * > ( psDevElement->pQWidget ) == pQWidget )
		{
			this->pQVBoxLayout_devLst->removeWidget ( pQWidget );

			// Check for last element
			if ( ! psDevElement->psDevElement_prev && ! psDevElement->psDevElement_next )
			{
				this->sDevElement_start = NULL;
				this->sDevElement_stop  = NULL;
			}
			// Check for first element
			else if ( ! psDevElement->psDevElement_prev )
			{
				this->sDevElement_start = psDevElement->psDevElement_next;
				this->sDevElement_start->psDevElement_prev = NULL;
			}
			// Check for last element
			else if ( ! psDevElement->psDevElement_next )
			{
				this->sDevElement_stop = psDevElement->psDevElement_prev;
				this->sDevElement_stop->psDevElement_next = NULL;
			}
			else
			{
				psDevElement->psDevElement_prev->psDevElement_next = psDevElement->psDevElement_next;
				psDevElement->psDevElement_next->psDevElement_prev = psDevElement->psDevElement_prev;
			}

			delete psDevElement->pQWidget;
			delete psDevElement;

			return;
		}

		psDevElement = psDevElement->psDevElement_next;
	}
}

/**
 *****************************************************************************************************************************
 */

void PicIO::closeAllDev ( void )
{
	sDevElement_t * psDevElement = this->sDevElement_start;
	sDevElement_t * sDevElement_del;

	while ( psDevElement )
	{
		sDevElement_del = psDevElement;
		psDevElement = psDevElement->psDevElement_next;

		delete sDevElement_del->pQWidget;
		delete sDevElement_del;
	}

	this->sDevElement_start = NULL;
	this->sDevElement_stop  = NULL;
}

/**
 *****************************************************************************************************************************
 */

bool PicIO::setValue ( int i_addr, QString QString_addrSymbol, int i_value )
{
	sDevElement_t * psDevElement = this->sDevElement_start;

	while ( psDevElement )
	{
		if ( psDevElement->eIOType == ePort )
		{
			PicIOPort8Bit * pPicIOPort8Bit = static_cast <PicIOPort8Bit *> ( psDevElement->pQWidget );

			if ( pPicIOPort8Bit->chkAddr ( i_addr ) && pPicIOPort8Bit->chkDirection ( PicIOCommon::eDirOut ) )
			{
				pPicIOPort8Bit->setValue ( i_value );
				pPicIOPort8Bit->setAddrSymbol ( QString_addrSymbol );
				return TRUE;
			}
		}
		else if ( psDevElement->eIOType == eFifo )
		{
			PicIOFifo8Bit * pPicIOFifo8Bit = static_cast <PicIOFifo8Bit *> ( psDevElement->pQWidget );

			if ( pPicIOFifo8Bit->chkAddr ( i_addr ) && pPicIOFifo8Bit->chkDirection ( PicIOCommon::eDirOut ) )
			{
				pPicIOFifo8Bit->setValue ( i_value );
				pPicIOFifo8Bit->setAddrSymbol ( QString_addrSymbol );
				return TRUE;
			}
		}
		else if ( psDevElement->eIOType == eMem )
		{
			PicIOMem * pPicIOMem = static_cast <PicIOMem *> ( psDevElement->pQWidget );

			if ( pPicIOMem->chkAddr ( i_addr ) && pPicIOMem->chkDirection ( PicIOCommon::eDirOut ) )
			{
				pPicIOMem->setValue ( i_value );
				pPicIOMem->setAddrSymbol ( QString_addrSymbol );
				return TRUE;
			}
		}

		psDevElement = psDevElement->psDevElement_next;
	}

	// Port not found, so add port
	psDevElement = this->addDev ( eFifo, PicIOCommon::eDirOut );
	{
		PicIOFifo8Bit * pPicIOFifo8Bit = static_cast <PicIOFifo8Bit *> ( psDevElement->pQWidget );

		pPicIOFifo8Bit->setValue ( i_value );
		pPicIOFifo8Bit->setAddr ( i_addr );
		pPicIOFifo8Bit->setAddrSymbol ( QString_addrSymbol );
	}

	emit contentChanged ( this );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicIO::getValue ( int i_addr, QString QString_addrSymbol, int * pi_value )
{
	sDevElement_t * psDevElement = this->sDevElement_start;

	while ( psDevElement )
	{
		if ( psDevElement->eIOType == ePort )
		{
			PicIOPort8Bit * pPicIOPort8Bit = static_cast <PicIOPort8Bit *> ( psDevElement->pQWidget );

			if ( pPicIOPort8Bit->chkAddr ( i_addr ) && pPicIOPort8Bit->chkDirection ( PicIOCommon::eDirIn ) )
			{
				pPicIOPort8Bit->setAddrSymbol ( QString_addrSymbol );
				return pPicIOPort8Bit->getValue ( pi_value );
			}
		}
		else if ( psDevElement->eIOType == eFifo )
		{
			PicIOFifo8Bit * pPicIOFifo8Bit = static_cast <PicIOFifo8Bit *> ( psDevElement->pQWidget );

			if ( pPicIOFifo8Bit->chkAddr ( i_addr ) && pPicIOFifo8Bit->chkDirection ( PicIOCommon::eDirIn ) )
			{
				pPicIOFifo8Bit->setAddrSymbol ( QString_addrSymbol );
				return pPicIOFifo8Bit->getValue ( pi_value );
			}

		}
		else if ( psDevElement->eIOType == eMem )
		{
			PicIOMem * pPicIOMem = static_cast <PicIOMem *> ( psDevElement->pQWidget );

			if ( pPicIOMem->chkAddr ( i_addr ) && pPicIOMem->chkDirection ( PicIOCommon::eDirIn ) )
			{
				pPicIOMem->setAddrSymbol ( QString_addrSymbol );
				return pPicIOMem->getValue ( pi_value );
			}

		}

		psDevElement = psDevElement->psDevElement_next;
	}

	// Port not found, so add port
	psDevElement = this->addDev ( ePort, PicIOCommon::eDirIn );
	{
		PicIOPort8Bit * pPicIOPort8Bit = static_cast <PicIOPort8Bit *> ( psDevElement->pQWidget );

		pPicIOPort8Bit->setAddr ( i_addr );
		pPicIOPort8Bit->setAddrSymbol ( QString_addrSymbol );
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

void PicIO::clearHighlighted ( void )
{
	sDevElement_t * psDevElement = this->sDevElement_start;

	while ( psDevElement )
	{
		switch ( psDevElement->eIOType )
		{
			case ePort: static_cast <PicIOPort8Bit *> ( psDevElement->pQWidget )->clearHighlighted (); break;
			case eFifo: static_cast <PicIOFifo8Bit *> ( psDevElement->pQWidget )->clearHighlighted (); break;
			case eMem:  static_cast <PicIOMem      *> ( psDevElement->pQWidget )->clearHighlighted (); break;
		}
		psDevElement = psDevElement->psDevElement_next;
	}
}

/**
 *****************************************************************************************************************************
 */

void PicIO::clear ( void )
{
	sDevElement_t * psDevElement = this->sDevElement_start;

	while ( psDevElement )
	{
		switch ( psDevElement->eIOType )
		{
			case ePort: static_cast <PicIOPort8Bit *> ( psDevElement->pQWidget )->clear (); break;
			case eFifo: static_cast <PicIOFifo8Bit *> ( psDevElement->pQWidget )->clear (); break;
			case eMem:  static_cast <PicIOMem      *> ( psDevElement->pQWidget )->clear (); break;
		}
		psDevElement = psDevElement->psDevElement_next;
	}
}

/**
 *****************************************************************************************************************************
 */
