/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PRJOPENDLG_H
#define PRJOPENDLG_H

#include <QtGui>
#include <QtCore>

#include "SetApp.h"
#include "PrjOpenDlgLstElement.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Project open dialog
 *
 *	Manages a project collection list.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-10-04
 *	\version	0.1.1
 *
 *	Change log
 *
 *	2009-10-04	Generated
 *
 *****************************************************************************************************************************
 */

class PrjOpenDlg : public QDialog
{
		Q_OBJECT

	public:

		/// Constructor. Generates the dialog layout.
		/// \param pQWidgetParent		Reference to the Parent widget.
		PrjOpenDlg ( QWidget * pQWidgetParent = 0 );

		/// Returns selected project file path
		QString getPrjFilePath ( void );

		/// Sets settings from application data
		/// \param pSetApp			Application settings
		void setSettingsApp ( SetApp * pSetApp );

	private slots:

		/// Selects project file and views in \c pQLineEdit_prjFilePath.
		void selectPrjFile ( void );

		/// Opens project viewed in \c pQLineEdit_prjFilePath.
		void hndlButtonOpen ( void );

		/// Handles adds project viewed in \c pQLineEdit_prjFilePath to collection list.
		void hndlOpenAdd ( void );

		/// Cancels open dialog
		void hndlOpenCancel ( void );

		/// Removes given project from collection list
		/// \param pPrjOpenDlgLstElement	Project collection list element
		void hndlListEventRemove ( PrjOpenDlgLstElement * pPrjOpenDlgLstElement );

		/// Opens given project from collection list
		/// \param pPrjOpenDlgLstElement	Project collection list element
		void hndlListEventOpen ( PrjOpenDlgLstElement * pPrjOpenDlgLstElement );

	private:

		/// Application settings.
		SetApp * pSetApp;

		/// Project file path returned to open.
		QString QString_prjFilePath;

		/// Viewed project file path
		QLineEdit * pQLineEdit_prjFilePath;

		/// Scroll area to handle project file list
		QScrollArea * pQScrollArea_prjList;

		/// Layout for managing project collection list elements.
		QVBoxLayout * pQVBoxLayout_prjList;

		/// Adds given project to project collection list
		/// \param QString_prjFilePath		Project file path
		void addListElement ( QString QString_prjFilePath );
};

#endif
