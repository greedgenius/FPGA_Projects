/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PROJECTDIALOGPAGEPROCESSORXILINXPICOBLAZE_H
#define PROJECTDIALOGPAGEPROCESSORXILINXPICOBLAZE_H

#include <QtGui>
#include <QtCore>

#include "SetPrj.h"
#include "SetDlgPgPicNone.h"
#include "PicPblzeSet.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Project dialog widget for Xilnix Picoblaze (tm) processor.
 *
 *	The class provides a dialog page for editing the Xilinx Picoblaze (tm) processor settings.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class SetDlgPgPicPblze : public SetDlgPgPicNone
{
		Q_OBJECT

	public:

		/// Constructor. Sets up the widget.
		/// \param pSetPrj_dlg	Reference to the dialog project settings
		/// \param pQWidget_parent	Reference to the parent widget.
		SetDlgPgPicPblze ( SetPrj * pSetPrj_dlg, QWidget * pQWidget_parent );

		/// Destructor, tidies up.
		~SetDlgPgPicPblze ( void );

		/// Initializes the copy of the settings from gui to dialog project settings.
		void getSet ( void );

	private:

		/// Reference to the dialog project settings
		SetPrj * pSetPrj_dlg;

	// About
	private:
		
		/// Sets up the about tab page
		/// \retval	QWidget		Tab page widget
		QWidget * setupTabPageAbout ( void );

	// Processor
	private:
		
		/// Sets up the assembler settings tab page.
		/// \retval	QWidget		Tab page widget
		QWidget * setupTabPagePic ( void );

		/// Derivate selection widget
		QComboBox * pQComboBox_derivate;

		/// Derivate about text
// 		QLabel * pQLabel_derivateAbout;

		/// Processor clock frequency
		QSpinBox * pQSpinBox_clkFreq;
		
		/// Scratchpad size
		QComboBox * pQComboBox_scrpdSize;
		
		/// Processor clock frequency
		QSpinBox * pQSpinBox_intVector;
		
		/// Widget for the memory bank size
		QComboBox * pQComboBox_memBankSize;
		
		/// Widget for the memory bank count
		QSpinBox * pQSpinBox_memBankCount;
		
		/// Widget for the shared memory location
		QComboBox * pQComboBox_sharedLoc;
		
	// Compiler
	private:
		
		/// Sets up the assembler settings tab page.
		/// \retval	QWidget		Tab page widget
// 		QWidget * setupTabPageAsm ( void );

		/// Sets up the VHDL settings tab page.
		/// \retval	QWidget		Tab page widget
		QWidget * setupTabPageCompiler ( void );

		/// Widget for the entity name
		QLineEdit * pQLineEdit_entityName;

		/// Widget for the VHDL output file
		QLineEdit * pQLineEdit_vhdlTemplateFile;

		/// Widget for the VHDL output file
		QLineEdit * pQLineEdit_verilogTemplateFile;

	// JTAG
	private:
		
		/// Sets up the JTAG settings tab page.
		/// \retval	QWidget		Tab page widget
		QWidget * setupTabPageJTAG ( void );

		
	private slots:

		/// Initializes a file dialog for vhdl template file selection.
		/// The file path will be stored in gui.
		void selectVhdlTemplateFile ( void );

		/// Initializes a file dialog for verilog template file selection.
		/// The file path will be stored in gui.
		void selectVerilogTemplateFile ( void );

		/// Opens the given url. Will be connected to gui text with
		/// active links contained.
		/// \param QString_url			Given url
		void openUrl ( QString QString_url );

		/// Sets derivate 
		/// \param QString_derivate		Selected derivate
		void setDerivate ( QString QString_derivate );

	private:

		/// Copies the settings from dialog project settings object
		/// to the gui.
		void setSet ( void );

		/// Gets the combobox index from value. If value not found return zero.
		/// \param pQComboBox			Combobox to set
		/// \param i_value			Value to search for
		void setCurrentIndexFromValue ( QComboBox * pQComboBox, int i_value );
		
		/// Gets the combobox index from value. If value not found return zero.
		/// \param pQComboBox			Combobox to set
		/// \retval i_value			Value
		int getCurrentValueFromIndex ( QComboBox * pQComboBox );
		
		/// Sets derivate dependend settings
		/// \param ePicDerivate			Derivate
		void setDerivateDependendSet ( PicPblzeSet::ePicDerivate_t ePicDerivate );

};

#endif
