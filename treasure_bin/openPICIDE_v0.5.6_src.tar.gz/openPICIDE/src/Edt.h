/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef EDT_H
#define EDT_H

#include <QtGui>
#include <QtCore>

#include "Set.h"
#include "Mod.h"

#include "EdtEditorWidget.h"
#include "EdtHlpViewer.h"

#include "EdtFindReplaceWidget.h"
#include "EdtNavi.h"
#include "EdtHlpIndex.h"
#include "EdtDlgFilter.h"

/**
 *****************************************************************************************************************************
 *
 *	\brief Editor module class
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *	Change log
 *		2009-08-30	Freeze for first release		Christoph Fauck <christoph.fauck@fauck.com>
 *		2009-09-13	Breakpoints added			Christoph Fauck <christoph.fauck@fauck.com>
 *****************************************************************************************************************************
 */

class Edt : public QWidget
{
		Q_OBJECT

	public:

		/// Constructor. Sets up editor main widget. The widget contains a tab widget which manages the
		/// document editor widgets.
		/// \param pMod				Pointer collection to root elements
		/// \param pQWidget_parent		Pointer to the parent widget
		Edt ( Mod * pMod, QWidget * pQWidget_parent = 0 );

		/// Destructor. Tidy up.
		~Edt ( void );

		/// Adds menu entries to the given menubar.
		/// \param	pQMenuBar		Pointer to the menubar
		void setupMenuBar ( QMenuBar * pQMenuBar );

		/// Sets the project settings to the editors. The method will be called if the project settings changed.
		void changeSettings ( void );

		/// Sets the highlighting rules for texts editor widgets
		/// \param	sHighlightingParameter	Highlighting rules
		void setHighlightingParameter ( EdtEditorHighlighter::sHighlightingKeyWords_t sHighlightingKeyWords );

		/// Initializes document text editor widget with given document and adds to tab widget. Will be called by 
		/// \c newSrcFile and \c openSrcFile.
		/// \param	pQString_tabName		Tab name for tab widget
		/// \param	pQString_filePath		Document file path
		/// \param	pQString_documentText		Document
		void setupSrcFile ( QString * pQString_tabName, QString * pQString_filePath, QString * pQString_documentText );

public slots:

		/// Save all
		void saveAll ( void );

		/// Close all without memory
		void closeAllWithoutMemory ( void );

		/// Signs in the tab if the document was changed. The method will be called by document editor widgets
		/// after changing the document text.
		/// \param	pQWidget_EdtEditorWidget	Pointer to calling editor widget
		/// \param	b_documentChanged	True if document changed, otherwise false
		void signDocumentStatus ( QWidget * pQWidget_EdtEditorWidget, bool b_documentChanged );

		/// Enables/disables the copy and cut actions. The method will be called by document editor widgets
		/// after changing the document text.
		/// \param	pQWidget_module		Pointer to calling module
		/// \param	b_copyAvailable		True if copy/cut available, otherwise false
		void setCopyAvailable ( QWidget * pQWidget_module, bool b_copyAvailable );

		/// Enables/disables the undo action. The method will be called by document editor widgets
		/// after changing the document text.
		/// \param	pQWidget_module		Pointer to calling module
		/// \param	b_undoAvailable		True if undo available, otherwise false
		void setUndoAvailable ( QWidget * pQWidget_module, bool b_undoAvailable );

		/// Enables/disables the redo action. The method will be called by document editor widgets
		/// after changing the document text.
		/// \param	pQWidget_module		Pointer to calling module
		/// \param	b_redoAvailable		True if redo available, otherwise false
		void setRedoAvailable ( QWidget * pQWidget_module, bool b_redoAvailable );

		/// Initializes and sets up the find dialog box.
		void findInit ( void );

		/// Configures find previos and calls \c find().
		void findPrev ( EdtFindReplaceWidget::sFRParam_t * psFRParam );

		/// Configures find next and calls \c find().
		void findNext ( EdtFindReplaceWidget::sFRParam_t * psFRParam );

		/// Initializes and sets up the replace dialog box.
		void replaceInit ( void );

		/// Starts replace algorithm in document editor widgets.
		void replace ( EdtFindReplaceWidget::sFRParam_t * psFRParam );

		/// Starts replace algorithm in document editor widgets.
		void replaceAll ( EdtFindReplaceWidget::sFRParam_t * psFRParam );

		/// Starts replace algorithm in document editor widgets.
		void hideFindReplaceWidget ( void );
		
		/// Initializes the scrolling within the given document to the given tag name. The method will be
		/// called by the navi.
		/// \param	QString_tabName			Tab name to select the document
		/// \param	QString_tag			Tag name to scroll to
		void selectTag ( QString QString_tabName, QString QString_tag );

		/// Clears line selections
		void clearLineSelections ( void );

		/// Gets break points.
		/// \param pQListI_lineNumber	Reference to return line number list
		void getBreakpoints ( QMap<QString,QList<int> > * pQMap_breakpoints );

		/// Clears the break point list.
		void clearBreakpoints ( void );

		/// Gets line from cursor
		/// \param pQString_filePath		File path
		/// \param pi_lineNumber		Line number
		/// \retval bool			TRUE if successful, otherwise FALSE
		bool getLineFromCursor ( QString * pQString_filePath, int * pi_lineNumber );

		/// Init im-/export filter dialog.
		/// \param QString_documentText		Document text
		void filterFileShow ( QString QString_documentText );
		
		/// Initializes html viewer widget with given document and adds to tab widget.
		/// \param QString_filePath		Document file path
		void setupHtmlDocument ( QString QString_filePath );

		/// Initializes html viewer widget with given document and adds to tab widget.
		/// \param QUrl_src			Url to source
		void setupHlpDocument ( const QUrl & QUrl_src );

		/// Sets title for Html document
		/// \param pQWidget			Widget to set title for
		/// \param QString_title		Title to set
		void setHtmlTabText ( QWidget * pQWidget, QString QString_title );
		
		/// Sets up document
		/// \param QUrl_doc			Document path
		void setupDocument ( QUrl QUrl_doc );
				
	private slots:

		/// Reloads the given file from disk.
		/// \param	QString_filePath		File path
		void reloadSrcFile ( QString QString_filePath = QString() );

		/// Changes action states of copy, cut, undo and redo and rebuilds the navi tag list.
		/// Will be called by the tab widget if the user changes the current doument.
		/// \param	i_documentIndex			Selected tab page index
		void currentFileChanged ( int i_documentIndex );

		/// Generates a new empty document and calls \c setupSrcFile for setting up the document editor widget.
		void newSrcFile ( void );

		/// Reads an existing settings object from disk and calls \c setupSrcFile() for setting up settings dialog.
		/// \param QString_filePath			File path
		/// \retval bool				TRUE, if success, otherwise FALSE
		bool openSrcFile ( QString QString_filePath = QString() );

		/// Saves a document. If no file path is valid \c saveSrcFileAs will be called.
		bool saveSrcFile ( void );
		
		/// Saves a document by asking for a new name.
		bool saveSrcFileAs ( void );

		/// Closes an opened file.
		bool closeSrcFile ( EdtEditorWidget * pEdtEditorWidget = NULL );
		
		/// Closes an opned file
		bool closeFile ( void );

		/// Executes "copy" action.
		void copyToClipboard ( void );

		/// Executes "cut" action.
		void cutToClipboard ( void );

		/// Executes "paste" action.
		void pasteFromClipboard ( void );

		/// Executes "undo" action.
		void undo ( void );

		/// Executes "redo" action.
		void redo ( void );

		/// Watches given document for changes and opens a warning dialog box if so.
		/// \param	QString_filePath	File path to watch for
		void watcherHandleEvent ( QString QString_filePath );

		/// Executes "comment out" action.
		void commentOut ( void );

		/// Executes "comment in" action.
		void commentIn ( void );

		/// Indent lines in current editor
		void indent ( void );
		
		/// Deindent lines in current editor
		void deindent ( void );

		/// Executes "duplicate line" action.
		void duplicateLine ( void );

		/// Emits breakpoint changed
		void emitBreakpointChanged ( void );
		
		/// Init im-/export filter dialog.
		void filterFileInit ( void );

		/// Navigates forwards in help widget
		void navHlpForward ( void );
		
		/// Navigates backwards in help widget
		void navHlpBackward ( void );
		
	signals:

		/// Break point changed
		void breakpointChanged ( void );
		
	private:

		enum eModuleType_t {
		
			eModuleTypeEditor,
			eModuleTypeHtmlViewer,
			eModuleTypeFilter
		};
		
		QHelpEngine * pQHelpEngine;
		
		QMap<QWidget *,eModuleType_t> QMapModuleType;
		
		/// Initializes help engine
		void initHlpEngine ( void );
		
		/// Sets up help engine
		void setupHlpEngine ( void );
		
		/// Highlighting parameter
		EdtEditorHighlighter::sHighlightingParameter_t sHighlightingParameter;

		/// Gets the module from url
		/// \param eModuleType			Module type to parse
		/// \param QUrl_doc			Url to search for
		/// \retval QWidget *			Reference to module widget
		QWidget * getModuleFromUrl ( eModuleType_t eModuleType, QUrl QUrl_doc );

		/// Sets the project settings to the given editor.
		/// \param	pSet_changed	Pointer to the given project settings
		void setSetEditor ( EdtEditorWidget * pEdtEditorWidget );

		/// Sets the project settings to the editors.
		void setSetEditorAll ( void );

		/// Sets temporary messages to status bar
		/// \param	QString_message		Message string
		void setStatusBar ( QString QString_message );

		/// Clears temporary messages from status bar
		bool clearStatusBar ( bool b_retVal = FALSE );

		/// Checks if given filePath already added to project. If not asks user to add.
		/// \param	QString_filePath		Given file path
		void handlePrjMembership ( QString QString_filePath );

		/// Checks if given filePath already added to project.
		/// \param	QString_filePath		Given file path
		bool chkPrjMembership ( QString QString_filePath );

		/// Reads given document from disk into given container. Will be called by \c openSrcFile and \c reloadSrcFile
		/// \param	QString_filePath		Given file path
		/// \param	pQString_documentText		Container for read document
		bool readSrcFile ( QString QString_filePath, QString * pQString_documentText );

		/// Writes given document to disk. Will be called by \c saveSrcFile and \c saveSrcFileAs
		/// \param	QString_filePath		Given file path
		/// \param	QString_documentText		Given document
		bool writeSrcFile ( QString QString_filePath, QString QString_documentText );


		/// Initializes html viewer widget with given document and adds to tab widget.
		/// \param	pQString_tabName		Tab name for tab widget
		/// \param	pQString_filePath		Document file path
		/// \param	pQString_documentText		Document
// 		void setupHtmlFile ( QString * pQString_tabName, QString * pQString_filePath, QString * pQString_documentText );
		
		
		
		/// Gets tag list from currently viewd document and sets to navi.
		void setTagList ( void );

		/// Gets tab name from given file path.
		/// \param	QString_filePath		Given file path
		/// \retval	QString				Tab name
		QString getTabName ( QString QString_filePath );

		/// Switches action states between document loaded and no document loaded.
		/// \param	b_en		TRUE if document loaded, otherwise false
		void setActionsEn ( bool b_en );

		/// Pointer collection to root elements
		Mod * pMod;

		/// Holds the project editor settings.
// 		EdtEditorWidget::sSet_t sSet_EdtEditorWidget;

		/// Holds the project settings.
// 		Set * pSet;

		/// Container for holding the navi instance.
		EdtNavi * pEdtNavi;

		/// Container for holding the navi instance.
		EdtHlpIndex * pEdtHlpIndexWidget;
		
//		/// Gets current tab widget from type
		


		/// Find/Replace dialog instance
		EdtFindReplaceWidget * pEdtFindReplaceWidget;

		
		/// Container for holding the replace control dialog instance.
// 		EdtDlgReplaceCtrl    * pEdtDlgReplaceCtrl;

		/// Container for holding the tab widget instance
		QTabWidget  * pQTabWidget_editor;

		/// Container for holding the find dialog and replace dialog parameter.
// 		struct sSetFndRepl_t
// 		{
// 
// 			bool b_ctrlSetValid;
// 			bool b_ctrlActivateSelectedText;
// 
// 			bool b_fndCaseSensitively;
// 			bool b_fndBackwards;
// 			bool b_fndWholeWords;
// 			bool b_fndFromCursor;
// 			bool b_fndWithinSelectedText;
// 			bool b_fndWithinWholeProject;
// 
// 			bool b_rplAskBefore;
// 
// 			QString QString_find;
// 			QString QString_replace;
// 
// 			QStringList QStringList_find;
// 			QStringList QStringList_replace;
// 
// 		} sSetFndRepl;

		/// Counter, need for enumerating untitled documents.
		int i_untitledCounter;

		/// Watching opened files
		QFileSystemWatcher * pQFileSystemWatcher;

		/// File menu
		QMenu    * pQMenu_file;

		/// Edit menu
		QMenu    * pQMenu_edit;

		/// File toolbar
		QToolBar * pQToolBar_file;

		/// Edit toolbar
		QToolBar * pQToolBar_edit;

		/// Edit toolbar
		QToolBar * pQToolBar_help;
		// File actions
		
		/// New file action
		QAction  * pQAction_newSrcFile;

		/// Open file action
		QAction  * pQAction_openSrcFile;

		/// Reload file action
		QAction  * pQAction_reloadSrcFile;

		/// Save file action
		QAction  * pQAction_saveSrcFile;

		/// Save file as action
		QAction  * pQAction_saveSrcFileAs;

		/// Close file action
		QAction  * pQAction_closeFile;
		
		/// Filter file action. Need for im/export.
		QAction * pQAction_filterFile;

		/// Save all
		QAction * pQAction_saveAll;

		// Edit actions
		
		/// Cut action
		QAction  * pQAction_cut;

		/// Copy action
		QAction  * pQAction_copy;

		/// Paste action
		QAction  * pQAction_paste;

		// ---
		
		/// Undo action
		QAction  * pQAction_undo;

		/// Redo action
		QAction  * pQAction_redo;

		
		// ---
		
		/// Forward action
		QAction  * pQAction_forward;

		/// Backwards action
		QAction  * pQAction_backward;
		
		// ---
		
		/// Find action
		QAction  * pQAction_find;

		/// Find previos action
		QAction  * pQAction_findPrev;

		/// Find next action
		QAction  * pQAction_findNext;

		/// Replace action
		QAction  * pQAction_replace;

		// ---
		
		/// Comment out action
		QAction  * pQAction_commentOut;

		/// Comment in action
		QAction  * pQAction_commentIn;

		// ---

		/// Indent
		QAction  * pQAction_indent;

		/// Deindent
		QAction  * pQAction_deindent;

		
		/// Duplicate line action
		QAction  * pQAction_duplicateLine;

		/// Clear all break points
		QAction  * pQAction_clearBreakpoints;

		/// Closes find/replace dialog
		QAction  * pQAction_hideFindReplaceDlg;
		
		/// Closes find/replace dialog
		QAction  * pQAction_print;
		
		
		
		/// Create actions
		void createActions ( void );

		/// Create menus from actions
		void createMenus ( void );

		/// Remove menus
		void removeMenus ( void );

		/// Create toolbars from actions
		void createToolBars ( void );

		/// Remove toolbars
		void removeToolBars ( void );

		/// Create status bar
		void createStatusBar ( void );
		
	// Printing
	private slots:

		/// Prints current document
		void print ( void );
	
	private:
		
		/// Prints document in editor widget
		void printEditorWidget ( EdtEditorWidget * pEdtEditorWidget );
		
		/// Prints document in help viewer
		void printHlpViewer ( EdtHlpViewer * pEdtHlpViewer );

};

#endif
