/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   The original code of this file was copied from nokia qt 4.6.0 examples and then modified for openPICIDE.                *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicIOFifoEditor.h"

/**
 *****************************************************************************************************************************
 */

PicIOFifoEditor::PicIOFifoEditor ( QWidget * pQWidget_parent ) : QPlainTextEdit ( pQWidget_parent )
{
	this->pPicIOFifoEditorLeftMargin = new PicIOFifoEditorLeftMargin ( this );

	connect ( this, SIGNAL ( blockCountChanged ( int ) ),            this, SLOT ( updateLeftMarginWidth ( int ) ) );
	connect ( this, SIGNAL ( updateRequest ( const QRect &, int ) ), this, SLOT ( updateLeftMargin ( const QRect &, int ) ) );
	connect ( this, SIGNAL ( cursorPositionChanged() ),              this, SLOT ( highlightCurrentLine() ) );

	QColor QColor_cursor ( 0xEEF6FF );
	QColor_cursor.setAlpha ( 0x7F );

	this->ExtraSelection_cursor.format.setBackground (  QColor_cursor );
	this->ExtraSelection_cursor.format.setProperty ( QTextFormat::FullWidthSelection, TRUE );
	this->ExtraSelection_cursor.cursor.clearSelection();

	this->updateLeftMarginWidth ( 0 );
	this->highlightCurrentLine();

	this->i_valuePtr = 0;
	this->i_base     = 16;

	QPlainTextEdit::setFrameShape ( QFrame::NoFrame );
}

/**
 *****************************************************************************************************************************
 */

int PicIOFifoEditor::leftMarginWidth ( void )
{
	int i_digits = 1;
	int i_max = qMax ( 1, QPlainTextEdit::blockCount() );

	while ( i_max >= 10 )
	{
		i_max /= 10;
		i_digits++;
	}

	int i_space = 16 + QPlainTextEdit::fontMetrics().width ( QLatin1Char ( '9' ) ) * i_digits;

	return i_space;
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifoEditor::updateLeftMarginWidth ( int i_newBlockCount )
{
	QPlainTextEdit::setViewportMargins ( leftMarginWidth(), 0, 0, 0 );
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifoEditor::updateLeftMargin ( const QRect & QRect_area, int i_pixelScrolledVertical )
{
	if ( this->i_valuePtr >= QPlainTextEdit::blockCount() )
		this->i_valuePtr = QPlainTextEdit::blockCount() - 1;

	if ( i_pixelScrolledVertical )
		this->pPicIOFifoEditorLeftMargin->scroll ( 0, i_pixelScrolledVertical );
	else
		this->pPicIOFifoEditorLeftMargin->update ( 0, QRect_area.y(), this->pPicIOFifoEditorLeftMargin->width(), QRect_area.height() );

	if ( QRect_area.contains ( viewport ()->rect () ) )
		this->updateLeftMarginWidth ( 0 );
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifoEditor::resizeEvent ( QResizeEvent * pQResizeEvent )
{
	QPlainTextEdit::resizeEvent ( pQResizeEvent );

	QRect cr = contentsRect();
	this->pPicIOFifoEditorLeftMargin->setGeometry ( QRect ( cr.left(), cr.top(), leftMarginWidth(), cr.height() ) );
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifoEditor::setBgColorCursor ( QColor QColor_bgCursor )
{
	this->ExtraSelection_cursor.format.setBackground (  QColor_bgCursor );

	this->setLineHighlights ();
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifoEditor::setBgColorHighlight ( QColor QColor_bgHighlight )
{
// 	this->ExtraSelection_highlight.format.setBackground (  QColor_bgHighlight );

	this->setLineHighlights ();
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifoEditor::highlightCurrentLine ()
{
	this->ExtraSelection_cursor.cursor = QPlainTextEdit::textCursor();

	this->setLineHighlights ();
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifoEditor::setLineHighlight ( QTextCursor QTextCursor_highlight )
{
	QTextEdit::ExtraSelection ExtraSelection_error;

	ExtraSelection_error.format.setBackground (  QColor ( 0xF5CACA ) );
	ExtraSelection_error.format.setProperty ( QTextFormat::FullWidthSelection, TRUE );
	ExtraSelection_error.cursor = QTextCursor_highlight;
	ExtraSelection_error.cursor.clearSelection();

	this->QListExtraSelection_highlight.append ( ExtraSelection_error );

	this->setLineHighlights ();
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifoEditor::clearLineHighlight ( void )
{
	this->QListExtraSelection_highlight.clear ();

	this->setLineHighlights ();
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifoEditor::setLineHighlights ( void )
{
	QList<QTextEdit::ExtraSelection> QListExtraSelection_highlight;

	QListExtraSelection_highlight = this->QListExtraSelection_highlight;

	QListExtraSelection_highlight.append ( ExtraSelection_cursor );

	QPlainTextEdit::setExtraSelections ( QListExtraSelection_highlight );

	QPlainTextEdit::update ();
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifoEditor::leftMarginPaintEvent ( QPaintEvent * pQPaintEvent )
{
	QPainter QPainter_lineNumberArea ( this->pPicIOFifoEditorLeftMargin );

	QPainter_lineNumberArea.fillRect ( pQPaintEvent->rect(), QColor ( 0xEAE9E8 ) );//Qt::lightGray );
	QPainter_lineNumberArea.setPen ( Qt::black );

	QTextBlock QTextBlock_run = QPlainTextEdit::firstVisibleBlock();

	int i_blockNumber = QTextBlock_run.blockNumber();

	int i_top    = static_cast <int> ( QPlainTextEdit::blockBoundingGeometry ( QTextBlock_run ).translated ( QPlainTextEdit::contentOffset() ).top() );
	int i_bottom = static_cast <int> ( QPlainTextEdit::blockBoundingRect     ( QTextBlock_run ).height() ) + i_top;

	while ( QTextBlock_run.isValid () && i_top <= pQPaintEvent->rect().bottom() )
	{
		if ( i_blockNumber == this->i_valuePtr )
			QPainter_lineNumberArea.drawImage ( QPointF ( 0, i_top ), QImage ( ":/pic/img/pic/fifoPointer.png" ) );

		if ( QTextBlock_run.isVisible() && i_bottom >= pQPaintEvent->rect().top() )
		{
			QString QString_number = QString::number ( i_blockNumber + 1 );
			QPainter_lineNumberArea.drawText ( 0, i_top, this->pPicIOFifoEditorLeftMargin->width(), QPlainTextEdit::fontMetrics().height(), Qt::AlignRight, QString_number );
		}

		QTextBlock_run = QTextBlock_run.next();
		i_top    = i_bottom;
		i_bottom =  static_cast <int> (  QPlainTextEdit::blockBoundingRect ( QTextBlock_run ).height() ) + i_top;
		i_blockNumber++;
	}
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifoEditor::leftMarginLineFromPos ( int i_posY )
{
	QTextBlock QTextBlock_run = QPlainTextEdit::firstVisibleBlock();

	while ( QTextBlock_run.isValid () && QTextBlock_run.isVisible () )
	{
		QRectF QRectF_textBlock = QPlainTextEdit::blockBoundingGeometry ( QTextBlock_run ).translated ( QPlainTextEdit::contentOffset() );

		if ( QRectF_textBlock.contains ( 0, i_posY ) )
		{
			this->i_valuePtr = QTextBlock_run.blockNumber();
			emit valuesChanged ();
		}
		QTextBlock_run = QTextBlock_run.next();
	}
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifoEditor::setValue ( QString QString_value )
{
	QTextBlock QTextBlock_run = QPlainTextEdit::document ()->begin ();

	while ( QTextBlock_run.isValid () )
	{
		if ( this->i_valuePtr == QTextBlock_run.blockNumber() )
		{
			break;
		}

		QTextBlock_run = QTextBlock_run.next();
	}

	QTextCursor QTextCursor_value ( QTextBlock_run );
	QTextCursor_value.select ( QTextCursor::LineUnderCursor );
	QTextCursor_value.removeSelectedText ();
	QTextCursor_value.insertText ( QString_value );

	this->i_valuePtr++;

	if ( QPlainTextEdit::document ()->blockCount () <= this->i_valuePtr )
	{
		QTextCursor_value.movePosition ( QTextCursor::End );
		QTextCursor_value.insertBlock ();
	}

	QPlainTextEdit::update ();
}

/**
 *****************************************************************************************************************************
 */

bool PicIOFifoEditor::getRdValue ( QString * pQString_valueCur, QString * pQString_valueNxt, bool b_incPtr )
{
	QTextBlock QTextBlock_run = QPlainTextEdit::document ()->begin ();

	pQString_valueCur->clear ();
	pQString_valueNxt->clear ();

	int i_valuePtrCur = this->i_valuePtr;
	int i_valuePtrNxt = this->i_valuePtr + 1;

	bool b_retVal = FALSE;

	// Get value
	while ( QTextBlock_run.isValid () )
	{
		if ( i_valuePtrCur == QTextBlock_run.blockNumber () )
		{
			*pQString_valueCur = QTextBlock_run.text ();

			if ( ! QTextBlock_run.text ().isEmpty () )
				b_retVal = TRUE;

			// Increment ptr
			if ( b_incPtr )
				this->i_valuePtr++;
		}
		else if ( i_valuePtrNxt == QTextBlock_run.blockNumber() )
		{
			*pQString_valueNxt = QTextBlock_run.text ();
			break;
		}

		QTextBlock_run = QTextBlock_run.next();
	}

	if ( QPlainTextEdit::document ()->blockCount () <= this->i_valuePtr  )
	{
		QTextCursor QTextCursor_value ( QTextBlock_run );
		QTextCursor_value.movePosition ( QTextCursor::End );
		QTextCursor_value.insertBlock ();
	}

	QPlainTextEdit::update ();

	return b_retVal;
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifoEditor::getWrValue ( QString * pQString_valueCur, QString * pQString_valueLst )
{
	QTextBlock QTextBlock_run = QPlainTextEdit::document ()->begin ();

	pQString_valueCur->clear ();
	pQString_valueLst->clear ();

	int i_valuePtrLst = this->i_valuePtr - 2;
	int i_valuePtrCur = this->i_valuePtr - 1;

	// Get value
	while ( QTextBlock_run.isValid () )
	{
		if ( i_valuePtrLst == QTextBlock_run.blockNumber() )
		{
			*pQString_valueLst = QTextBlock_run.text ();
		}
		else if ( i_valuePtrCur == QTextBlock_run.blockNumber() )
		{
			*pQString_valueCur = QTextBlock_run.text ();
			return;
		}

		QTextBlock_run = QTextBlock_run.next();
	}
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifoEditor::setBase ( int i_base )
{
	QTextBlock QTextBlock_run = QPlainTextEdit::document ()->firstBlock ();

	int i_value;
	bool b_success;
	
	while ( QTextBlock_run.isValid () )
	{
		i_value = QTextBlock_run.text ().toInt ( & b_success, this->i_base );
		
		if ( b_success )
		{
			QTextCursor QTextCursor_value ( QTextBlock_run );
			QTextCursor_value.select ( QTextCursor::LineUnderCursor );
			QTextCursor_value.removeSelectedText ();
			QTextCursor_value.insertText ( QString ( "%1" ).arg ( i_value, 0, i_base ) );
		}
	
		QTextBlock_run = QTextBlock_run.next();
	}

	this->i_base = i_base;
}

/**
 *****************************************************************************************************************************
 */
