/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PicPblzeAsmImportOpenPICIDE_H
#define PicPblzeAsmImportOpenPICIDE_H

#include <QtGui>
#include <QtCore>

#include "PicImport.h"

/**
 *****************************************************************************************************************************
 *
 *	\brief Filter for converting openPICIDE v0.1 to v0.3 assembler dialects to openPICIDE v0.4 dialect.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-12-08
 *	\version	0.1.0
 *
 *	Change log
 *
 *	2009-12-08
 *		Generated
 *
 *****************************************************************************************************************************
 */

class PicPblzeAsmImportOpenPICIDE : PicImport
{
	public:

		/// Constructor. Generates the dialog layout.
		PicPblzeAsmImportOpenPICIDE ();

		PicImport::eRetVal_t convertLine ( QString * pQString_line );
		
		QStringList getCmdList ( void );
		QStringList getDirectiveList ( void );
		QStringList getHwComponentList ( void );
		QMap<QString, QStringList> getNumberRegExp ( void );
		
	private:

		PicImport::eRetVal_t lineSubst       ( PicImport::sLineFragments_t * psLineFragments );

		PicImport::eRetVal_t chkInstRet      ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chkInstInt      ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chkInstRegVari  ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chkInstBranch   ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chInstReg       ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chkInstAddr     ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chkInstRegIO    ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chkInstConstant ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chkInstNamereg  ( PicImport::sLineFragments_t * psLineFragments );
};

#endif
