/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeCmplr.h"
#include "string.h"

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Constructor
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

PicPblzeCmplr::PicPblzeCmplr ( QObject * pQObject_parent ) : PicPblzeAsmParser ( pQObject_parent )
{
	this->asMemCell = NULL;
}

/**
 *****************************************************************************************************************************
 */

PicPblzeCmplr::~PicPblzeCmplr ( void )
{
	// Delete memory lines
	{
		if ( this->asMemCell )
			delete[] this->asMemCell;
	
		this->asMemCell = NULL;
	}
	
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Parameter handling
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplr::setCfg ( sCfg_t sCfg )
{
	this->sCfg = sCfg;
	
	// Set parser parameter
	if ( ! PicPblzeAsmParser::setCfg ( this->sCfg.sCfg_asmParser ) )
		return FALSE;

	// Check files
	{
		QFileInfo QFileInfo_check;
		
		// Check template file
		{
			QFileInfo_check.setFile ( this->sCfg.QString_templateFilePath );
			
			if ( ( this->sCfg.eOutputType == E_OUT_VHDL ) || ( this->sCfg.eOutputType == E_OUT_VERILOG ) )
			{
				QFileInfo QFileInfo_check ( this->sCfg.QString_templateFilePath );

				if ( ! QFileInfo_check.isReadable () )
				{
					this->msgEmit ( eMsgType_templateFileIO );	
					return FALSE;
				}
			}
		}
		
		// Check output file
		{
			QFileInfo_check.setFile ( this->sCfg.QString_outputFilePath );
			
			// Check, if file exists and is writable
			if ( QFileInfo_check.exists () && ( ! QFileInfo_check.isWritable () ) )
			{
				this->msgEmit ( eMsgType_outputFileIO );	
				return FALSE;
			}
		}
	}

	// Check entity name
	{
		if ( this->sCfg.QString_entityName.isEmpty () )
		{
			this->msgEmit ( eMsgType_entityName );	
			return FALSE;
		}
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Write file
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplr::writeOutputFile ( void )
{
	switch ( this->sCfg.eOutputType )
	{
		case E_OUT_VHDL:	return this->writeOutputFileVhdlVerilog ();
		case E_OUT_VERILOG:	return this->writeOutputFileVhdlVerilog ();
		case E_OUT_MEM:		return this->writeOutputFileMem ();
		case E_OUT_HEX:		return this->writeOutputFileHex ();
	}	
	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplr::writeOutputFileVhdlVerilog ( void )
{
	// Define template file
	QFile QFile_template ( this->sCfg.QString_templateFilePath );

	// Open template file
	if ( ! QFile_template.open ( QIODevice::ReadOnly | QIODevice::Text ) )
	{
		this->msgEmit ( eMsgType_templateFileIO );
		return FALSE;
	}

	// Open destination file
	QFile QFile_output ( this->sCfg.QString_outputFilePath );

	if ( ! QFile_output.open ( QIODevice::ReadWrite | QIODevice::Text ) )
	{
		this->msgEmit ( eMsgType_outputFileIO );
		QFile_template.close();
		return FALSE;
	}

	// Set file size to zero
	QFile_output.resize ( 0 );

	QTextStream QTextStream_output ( & QFile_output );

	// Parse template file
	{
		bool b_showStuffingMsgEn = TRUE;
		
		QString QString_line;

		// Find start of VHDL
		while ( ! QFile_template.atEnd() )
		{
			QString_line = QFile_template.readLine();

			if ( QString_line.contains ( QString ( "{begin template}" ) ) )
				break;
		}

		QTextStream_output << "\n";

		while ( ! QFile_template.atEnd() )
		{
			QString_line = QFile_template.readLine();

// 			QString_line.replace ( QString ( "\n" ), QString ( "\r\n" ) );

			// ***************************************************************************************************
			// * 1K prom
			// ***************************************************************************************************
			if ( QString_line.contains ( QString ( "{INIT_" ) ) )
			{
				for ( int i_iterator = 0; i_iterator <= 0xFF; i_iterator++ )	// Four banksf
				{
					QString QString_tag = QString ( "{INIT_%1}" ).arg ( i_iterator, 2, 16, QChar ( '0' ) ).toUpper();
					
					if ( ! QString_line.contains ( QString_tag ) )
						continue;
					
					QString QString_fragment;

					if ( ! this->getVhdlInit ( i_iterator, & QString_fragment ) && b_showStuffingMsgEn )
					{
						b_showStuffingMsgEn = FALSE;
						
						this->msgEmit ( eMsgType_tmemStuffing );
// 						return FALSE;
					}
					
					QString_line.replace ( QString_tag, QString_fragment );
				}
			}
			
			else if ( QString_line.contains ( QString ( "{INITP_" ) ) )
			{
				for ( int i_iterator = 0; i_iterator <= 0x1F; i_iterator++ )
				{
					QString QString_tag = QString ( "{INITP_%1}" ).arg ( i_iterator, 2, 16, QChar ( '0' ) ).toUpper();

					if ( ! QString_line.contains ( QString_tag ) )
						continue;
					
					QString QString_fragment;
					
					if ( ! this->getVhdlInitP ( i_iterator, & QString_fragment ) && b_showStuffingMsgEn )
					{
						b_showStuffingMsgEn = FALSE;
						
						this->msgEmit ( eMsgType_tmemStuffing );
// 						return FALSE;
					}
					
					QString_line.replace ( QString_tag, QString_fragment );
				}
			}
			
			// ***************************************************************************************************
			// * 2K prom
			// ***************************************************************************************************
			else if ( QString_line.contains ( QString ( "{[17:9]_INIT_" ) ) )
			{
				for ( int i_iterator = 0; i_iterator <= 0x7F; i_iterator++ )
				{
					QString QString_tag = QString ( "{[17:9]_INIT_%1}" ).arg ( i_iterator, 2, 16, QChar ( '0' ) ).toUpper();
					
					if ( ! QString_line.contains ( QString_tag ) )
						continue;
					
					QString QString_fragment;

					if ( ! this->getVhdlInitH ( i_iterator, & QString_fragment ) && b_showStuffingMsgEn )
					{
						b_showStuffingMsgEn = FALSE;
						
						this->msgEmit ( eMsgType_tmemStuffing );
// 						return FALSE;
					}
					
					QString_line.replace ( QString_tag, QString_fragment );
				}
			}

			else if ( QString_line.contains ( QString ( "{[8:0]_INIT_" ) ) )
			{
				for ( int i_iterator = 0; i_iterator <= 0x7F; i_iterator++ )
				{
					QString QString_tag = QString ( "{[8:0]_INIT_%1}" ).arg ( i_iterator, 2, 16, QChar ( '0' ) ).toUpper();
					
					if ( ! QString_line.contains ( QString_tag ) )
						continue;
					
					QString QString_fragment;

					if ( ! this->getVhdlInitL ( i_iterator, & QString_fragment ) && b_showStuffingMsgEn )
					{
						b_showStuffingMsgEn = FALSE;
						
						this->msgEmit ( eMsgType_tmemStuffing );
// 						return FALSE;
					}
					
					QString_line.replace ( QString_tag, QString_fragment );
				}
			}

			else if ( QString_line.contains ( QString ( "{[17:9]_INITP_" ) ) )
			{
				for ( int i_iterator = 0; i_iterator <= 0x7F; i_iterator++ )
				{
					QString QString_tag = QString ( "{[17:9]_INITP_%1}" ).arg ( i_iterator, 2, 16, QChar ( '0' ) ).toUpper();
					
					if ( ! QString_line.contains ( QString_tag ) )
						continue;
					
					QString QString_fragment;

					if ( ! this->getVhdlInitPH ( i_iterator, & QString_fragment ) && b_showStuffingMsgEn )
					{
						b_showStuffingMsgEn = FALSE;
						
						this->msgEmit ( eMsgType_tmemStuffing );
// 						return FALSE;
					}
					
					QString_line.replace ( QString_tag, QString_fragment );
				}
			}
			
			else if ( QString_line.contains ( QString ( "{[8:0]_INITP_" ) ) )
			{
				for ( int i_iterator = 0; i_iterator <= 0x0F; i_iterator++ )
				{
					QString QString_tag = QString ( "{[8:0]_INITP_%1}" ).arg ( i_iterator, 2, 16, QChar ( '0' ) ).toUpper();

					if ( ! QString_line.contains ( QString_tag ) )
						continue;
					
					QString QString_fragment;
					
					if ( ! this->getVhdlInitPL ( i_iterator, & QString_fragment ) && b_showStuffingMsgEn )
					{
						b_showStuffingMsgEn = FALSE;
						
						this->msgEmit ( eMsgType_tmemStuffing );
// 						return FALSE;
					}
					
					QString_line.replace ( QString_tag, QString_fragment );
				}
			}
			
			// ***************************************************************************************************
			// * Misc
			// ***************************************************************************************************
			else if ( QString_line.contains ( QString ( "{name}" ) ) )
			{
				QString_line.replace ( QString ( "{name}" ), this->sCfg.QString_entityName );
			}
			
			else if ( QString_line.contains ( QString ( "{timestamp}" ) ) )
			{
				QDateTime QDateTime_timestamp;

				QString QString_timestamp = QDateTime_timestamp.toString ( "yyyy-MM-dd hh:mm:ss" );

				QString_line.replace ( QString ( "{timestamp}" ), QString_timestamp );
			}

			QTextStream_output << QString_line;
		}
	}

	// Check if all memory cells used
/*	for ( int i_iterator = 0; i_iterator < this->sMem.i_memSize; ++i_iterator )
	{
		if ( ! this->asMemCell[ i_iterator ].b_used )
		{
			this->msgEmit ( eMsgType_tmemSizeToSmall );
			return FALSE;
		}
	}*/
	
	// Close files
	QFile_template.close();
	QFile_output.close();
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplr::getVhdlInit (int i_fragmentAddr, QString * pQString_fragment )
{
	int i_fragmentAddrStart = i_fragmentAddr * 16;
	int i_fragmentAddrStop  = i_fragmentAddrStart + 15;

	if ( i_fragmentAddrStop >= PicPblzeAsmParser::sMem.i_memSize )
	{
		*pQString_fragment += QString ( "0000000000000000000000000000000000000000000000000000000000000000" );
		return FALSE;
	}
 
	for ( int i_iterator = i_fragmentAddrStop; i_iterator >= i_fragmentAddrStart; i_iterator-- )
	{
		unsigned int ui_byte;
		
		ui_byte = this->asMemCell [ i_iterator ].ui_value & 0xFFFF;
		
		*pQString_fragment += QString ( "%1" ).arg ( ui_byte, 4, 16, QChar ( '0' ) ).toUpper ();
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplr::getVhdlInitP ( int i_fragmentAddr, QString * pQString_fragment )
{
	int i_fragmentAddrStart = i_fragmentAddr * 128;
	int i_fragmentAddrStop  = i_fragmentAddrStart + 127;

	if ( i_fragmentAddrStop >= PicPblzeAsmParser::sMem.i_memSize )
	{
		*pQString_fragment += QString ( "0000000000000000000000000000000000000000000000000000000000000000" );
		return FALSE;
	}

	for ( int i_iterator = i_fragmentAddrStop; i_iterator >= i_fragmentAddrStart; i_iterator-- )
	{
		unsigned int ui_nibble;

// 		ui_nibble  = ( this->asMemCell [ i_iterator-- ].ui_value & 0x30000 ) >> 14;
// 		ui_nibble |= ( this->asMemCell [ i_iterator   ].ui_value & 0x30000 ) >> 16;

		ui_nibble  = ( this->asMemCell [ i_iterator-- ].ui_value >> 14 ) & 0xC;
		ui_nibble |= ( this->asMemCell [ i_iterator   ].ui_value >> 16 ) & 0x3;
		
		*pQString_fragment += QString ( "%1" ).arg ( ui_nibble, 1, 16, QChar ( '0' ) ).toUpper ();
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplr::getVhdlInitL (int i_fragmentAddr, QString * pQString_fragment )
{
	int i_fragmentAddrStart = i_fragmentAddr * 32;
	int i_fragmentAddrStop  = i_fragmentAddrStart + 31;

	if ( i_fragmentAddrStop >= PicPblzeAsmParser::sMem.i_memSize )
	{
		*pQString_fragment += QString ( "0000000000000000000000000000000000000000000000000000000000000000" );
		return FALSE;
	}
 
	for ( int i_iterator = i_fragmentAddrStop; i_iterator >= i_fragmentAddrStart; i_iterator-- )
	{
		unsigned int ui_byte;
		
		ui_byte = this->asMemCell [ i_iterator ].ui_value & 0xFF;
		
		*pQString_fragment += QString ( "%1" ).arg ( ui_byte, 2, 16, QChar ( '0' ) ).toUpper ();
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplr::getVhdlInitPL ( int i_fragmentAddr, QString * pQString_fragment )
{
	int i_fragmentAddrStart = i_fragmentAddr * 256;
	int i_fragmentAddrStop  = i_fragmentAddrStart + 255;

	if ( i_fragmentAddrStop >= PicPblzeAsmParser::sMem.i_memSize )
	{
		*pQString_fragment += QString ( "0000000000000000000000000000000000000000000000000000000000000000" );
		return FALSE;
	}

	for ( int i_iterator = i_fragmentAddrStop; i_iterator >= i_fragmentAddrStart; i_iterator-- )
	{
		unsigned int ui_nibble;

		if ( i_iterator < 3 )
			return FALSE;
		
		ui_nibble  = ( this->asMemCell [ i_iterator-- ].ui_value >> 5 ) & 0x8;
		ui_nibble |= ( this->asMemCell [ i_iterator-- ].ui_value >> 6 ) & 0x4;
		ui_nibble |= ( this->asMemCell [ i_iterator-- ].ui_value >> 7 ) & 0x2;
		ui_nibble |= ( this->asMemCell [ i_iterator   ].ui_value >> 8 ) & 0x1;

		*pQString_fragment += QString ( "%1" ).arg ( ui_nibble, 1, 16, QChar ( '0' ) ).toUpper ();
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplr::getVhdlInitH (int i_fragmentAddr, QString * pQString_fragment )
{
	int i_fragmentAddrStart = i_fragmentAddr * 32;
	int i_fragmentAddrStop  = i_fragmentAddrStart + 31;

	if ( i_fragmentAddrStop >= PicPblzeAsmParser::sMem.i_memSize )
	{
		*pQString_fragment += QString ( "0000000000000000000000000000000000000000000000000000000000000000" );
		return FALSE;
	}
 
	for ( int i_iterator = i_fragmentAddrStop; i_iterator >= i_fragmentAddrStart; i_iterator-- )
	{
		unsigned int ui_byte;
		
		ui_byte = ( this->asMemCell [ i_iterator ].ui_value >> 9 ) & 0xFF;
		
		*pQString_fragment += QString ( "%1" ).arg ( ui_byte, 2, 16, QChar ( '0' ) ).toUpper ();
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplr::getVhdlInitPH ( int i_fragmentAddr, QString * pQString_fragment )
{
	int i_fragmentAddrStart = i_fragmentAddr * 256;
	int i_fragmentAddrStop  = i_fragmentAddrStart + 255;

	if ( i_fragmentAddrStop >= PicPblzeAsmParser::sMem.i_memSize )
	{
		*pQString_fragment += QString ( "0000000000000000000000000000000000000000000000000000000000000000" );
		return FALSE;
	}

	for ( int i_iterator = i_fragmentAddrStop; i_iterator >= i_fragmentAddrStart; i_iterator-- )
	{
		unsigned int ui_nibble;

		if ( i_iterator < 3 )
			return FALSE;
		
		ui_nibble  = ( this->asMemCell [ i_iterator-- ].ui_value >> 14 ) & 0x8;
		ui_nibble |= ( this->asMemCell [ i_iterator-- ].ui_value >> 15 ) & 0x4;
		ui_nibble |= ( this->asMemCell [ i_iterator-- ].ui_value >> 16 ) & 0x2;
		ui_nibble |= ( this->asMemCell [ i_iterator   ].ui_value >> 17 ) & 0x1;

		*pQString_fragment += QString ( "%1" ).arg ( ui_nibble, 1, 16, QChar ( '0' ) ).toUpper ();
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplr::writeOutputFileMem ( void )
{
	// Open destination file
	QFile QFile_output ( this->sCfg.QString_outputFilePath );

	if ( ! QFile_output.open ( QIODevice::ReadWrite | QIODevice::Text ) )
	{
		this->msgEmit ( eMsgType_outputFileIO );
		return FALSE;
	}

	// Set file size to zero
	QFile_output.resize ( 0 );

	QTextStream QTextStream_output ( & QFile_output );

	bool b_printAddr = TRUE;
	
	for ( int i_iterator = 0; i_iterator < PicPblzeAsmParser::sMem.i_memSize; i_iterator++ )
	{
		sMemCell_t sMemCell = this->asMemCell[ i_iterator ];

// 		if ( ! sMemCell.b_valid )
// 		{
//			// Do not work with xilinx bmem
// 			b_printAddr = TRUE;
// 			continue;
// 		}

		if ( b_printAddr )
		{
			QTextStream_output << QString ( "@%1\r\n" ).arg ( i_iterator );
			b_printAddr = FALSE;
		}
		
		QTextStream_output << QString ( "%1\r\n" ).arg ( sMemCell.ui_value, 5, 16, QChar ( '0' ) ).toUpper ();
	}

	QFile_output.close();

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplr::writeOutputFileHex ( void )
{
	// Open destination file
	QFile QFile_output ( this->sCfg.QString_outputFilePath );

	if ( ! QFile_output.open ( QIODevice::ReadWrite | QIODevice::Text ) )
	{
		this->msgEmit ( eMsgType_outputFileIO );
		return FALSE;
	}

	// Set file size to zero
	QFile_output.resize ( 0 );

	QTextStream QTextStream_output ( & QFile_output );

	for ( int i_iterator = 0; i_iterator < PicPblzeAsmParser::sMem.i_memSize; i_iterator++ )
	{
		sMemCell_t sMemCell = this->asMemCell[ i_iterator ];

		if ( sMemCell.b_valid )
			QTextStream_output << QString ( "%1\r\n" ).arg ( sMemCell.ui_value, 5, 16, QChar ( '0' ) ).toUpper ();
		else
			QTextStream_output << QString ( "%1\r\n" ).arg ( 0, 5, 16, QChar ( '0' ) ).toUpper ();
	}

	QFile_output.close();

	return TRUE;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Message handling
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

void PicPblzeCmplr::msgEmit ( eMsgType_t eMsgType )
{
	Msg * pMsg = new Msg;
	
	this->msgEmit ( pMsg, eMsgType );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeCmplr::msgEmit ( eMsgType_t eMsgType, sCodeLine_t * psCodeLine )
{
	Msg * pMsg = new Msg;
	
	pMsg->QUrl_srcUrl.setScheme( "file" );
	pMsg->QUrl_srcUrl.setPath ( PicPblzeAsmParser::msgGetFilePath ( psCodeLine->i_fileNumber ) );
	pMsg->QUrl_srcUrl.setFragment ( QString::number ( psCodeLine->i_lineNumber ) );
	
	this->msgEmit ( pMsg, eMsgType );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeCmplr::msgEmit ( Msg * pMsg, eMsgType_t eMsgType )
{
	QString QString_hlpFragment;
	
	// Set message text
	switch ( eMsgType )
	{
		// Warnings
		case eMsgType_tmemStuffing:
			
			QString_hlpFragment 	= "tmemStuffing";
			pMsg->eStatus 		= Msg::e_warning;
			pMsg->QString_msg 	= tr ( "Template memory size bigger than expected: Stuffing with zeros" );
			break;

		// Error messages
		case eMsgType_templateFileIO:
			
			QString_hlpFragment 	= "templateFileIO";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Template file I/O error" );
			break;
			
		case eMsgType_outputFileIO:
			
			QString_hlpFragment 	= "outputFileIO";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Output file I/O error" );
			break;
			
		case eMsgType_entityName:
			
			QString_hlpFragment 	= "entityName";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Entity name not set" );
			break;
			
		case eMsgType_compError:
			
			QString_hlpFragment 	= "compError";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Compile error" );
			break;
			
		case eMsgType_tmemSizeToSmall:
			
			QString_hlpFragment 	= "tmemSizeToSmall";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Template memory size too small" );
			break;
	}

	pMsg->QUrl_hlpUrl = QUrl ( "qthelp://openPICIDE/openPICIDE/openPICIDE/800_processors/XilinxPicoBlaze/800_messages/index.html" );

	pMsg->QUrl_hlpUrl.setFragment ( QString_hlpFragment );
	
	emit PicPblzeAsmParser::message ( pMsg );
}

/**
 *****************************************************************************************************************************
 */
