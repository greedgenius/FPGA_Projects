/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "SetDlgPgApp.h"

#include "SupDlg.h"

/**
 *****************************************************************************************************************************
 */

SetDlgPgApp::SetDlgPgApp ( SetApp * pSetApp_dlg, QWidget * pQWidgetParent ) : QWidget ( pQWidgetParent )
{
	this->pSetApp_dlg = pSetApp_dlg;

	QVBoxLayout * pQVBoxLayout = new QVBoxLayout ( this );
	{
		// Files group box
		QGroupBox * pQGroupBox = new QGroupBox ( QObject::tr ( "Application settings" ) );
		{
			// Layout files group box
			QVBoxLayout * pQVBoxLayout_groupBox = new QVBoxLayout;
			{
				QTabWidget * pQTabWidget = new QTabWidget ( this );
				{
					pQTabWidget->addTab ( this->edtSetupTabPage (), QObject::tr ( "Editor" ) );
					pQTabWidget->addTab ( this->supSetupTabPage(),  QObject::tr ( "Support" ) );
				}
				pQVBoxLayout_groupBox->addWidget ( pQTabWidget );
			}
			pQGroupBox->setLayout ( pQVBoxLayout_groupBox );
		}
		pQVBoxLayout->addWidget ( pQGroupBox );
	}
	QWidget::setLayout ( pQVBoxLayout );

	this->setSet ();
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgApp::getSet ( void )
{
	this->edtGetSet ();
	this->supGetSet ();
}

/**
 *****************************************************************************************************************************
 */

QFrame * SetDlgPgApp::setLine ( void )
{
	QFrame * pQFrame = new QFrame;
	{
		pQFrame->setFrameStyle ( QFrame::Plain | QFrame::HLine );
		pQFrame->setLineWidth ( 1 );
	}

	return pQFrame;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

QWidget * SetDlgPgApp::edtSetupTabPage ( void )
{
	QWidget * pQWidget_tabPage = new QWidget ( this );
	{
		// Tab page layout
		QVBoxLayout * pQVBoxLayout_tabPage = new QVBoxLayout ( pQWidget_tabPage );
		{
			// Layout tab indent
			QHBoxLayout * pQHBoxLayout_tabIndent = new QHBoxLayout;
			{
				// Set label
				QLabel * pQLabel = new QLabel ( QObject::tr ( "Tab indent:" ) );

				// Set spin box
				this->sEdt.pQSpinBox_tabIndent = new QSpinBox();
				{
					this->sEdt.pQSpinBox_tabIndent->setRange ( 1, 100 );
					this->sEdt.pQSpinBox_tabIndent->setAlignment ( Qt::AlignRight );
				}
				pQHBoxLayout_tabIndent->addWidget ( pQLabel );
				pQHBoxLayout_tabIndent->addWidget ( this->sEdt.pQSpinBox_tabIndent );
			}

			// Layout dynamic word wrap
			QHBoxLayout * pQHBoxLayout_dynamicWordWrap = new QHBoxLayout;
			{
				// Set label
				QLabel * pQLabel = new QLabel ( QObject::tr ( "Dynamic word wrap:" ) );

				// Set check box
				this->sEdt.pQCheckBox_dynamicWordWrap = new QCheckBox();

				// Set layout
				pQHBoxLayout_dynamicWordWrap->addWidget ( pQLabel );
				pQHBoxLayout_dynamicWordWrap->addWidget ( this->sEdt.pQCheckBox_dynamicWordWrap );
			}

			// Layout cursor background color
			QHBoxLayout * pQHBoxLayout_bgCursor = new QHBoxLayout;
			{
				// Set label
				QLabel * pQLabel = new QLabel ( QObject::tr ( "Cursor background color:" ) );

				this->sEdt.pQPushButton_bgCursor = new QPushButton;
				{
					connect (
						this->sEdt.pQPushButton_bgCursor,
						SIGNAL ( clicked ( ) ),
						this,
						SLOT ( getBgCursorColor ( ) )
					);
				}
				pQHBoxLayout_bgCursor->addWidget ( pQLabel );
				pQHBoxLayout_bgCursor->addWidget ( this->sEdt.pQPushButton_bgCursor );
			}

			// Layout highlighting background color
			QHBoxLayout * pQHBoxLayout_bgHighlight = new QHBoxLayout;
			{
				// Set label
				QLabel * pQLabel = new QLabel ( QObject::tr ( "Line highlighting background color:" ) );

				this->sEdt.pQPushButton_bgHighlight = new QPushButton;
				{
					connect (
						this->sEdt.pQPushButton_bgHighlight,
						SIGNAL ( clicked ( ) ),
						this,
						SLOT ( getBgHighlightColor ( ) )
					);
				}
				pQHBoxLayout_bgHighlight->addWidget ( pQLabel );
				pQHBoxLayout_bgHighlight->addWidget ( this->sEdt.pQPushButton_bgHighlight );
			}
			
			// Set font selection
			QHBoxLayout * pQHBoxLayout_font = new QHBoxLayout;
			{
				// Set font family
				{
					QLabel * pQLabel_title = new QLabel ( "Font:" );

					this->sEdt.pQComboBox_fontFamily = new QComboBox;
					{
						QStringList QStringList_fontFamily = this->sEdt.QFontDatabase_system.families ( QFontDatabase::Latin );
					  
						foreach ( QString QString_fontFamily, QStringList_fontFamily )
						{
							if ( this->sEdt.QFontDatabase_system.pointSizes ( QString_fontFamily ).count () > 0 )
								this->sEdt.pQComboBox_fontFamily->addItem ( QString_fontFamily );
						}

						connect (
							this->sEdt.pQComboBox_fontFamily,
							SIGNAL ( currentIndexChanged ( const QString & ) ),
							this,
							SLOT ( hndlFontFamilySel ( const QString & ) )
						);
					}
					pQHBoxLayout_font->addWidget ( pQLabel_title );
					pQHBoxLayout_font->addWidget ( this->sEdt.pQComboBox_fontFamily );
				}

				// Set font size
				{
					QLabel * pQLabel_title = new QLabel ( "Font size:" );

					this->sEdt.pQComboBox_fontSize = new QComboBox;
					{
						connect (
							this->sEdt.pQComboBox_fontSize,
							SIGNAL ( currentIndexChanged ( const QString & ) ),
							this,
							SLOT ( hndlFontSizeSel ( const QString & ) )
						);
					}
					pQHBoxLayout_font->addWidget ( pQLabel_title );
					pQHBoxLayout_font->addWidget ( this->sEdt.pQComboBox_fontSize );
				}

				pQHBoxLayout_font->addWidget ( this->sEdt.pQComboBox_fontSize );
			}
			
			// Set font styles
			this->sEdt.pQTreeView_fonts = new QTreeView;
			{
				this->sEdt.pQTreeView_fonts->setModel ( & this->sEdt.QStandardItemModel_fonts );
				this->sEdt.pQTreeView_fonts->setRootIsDecorated ( FALSE );
				this->sEdt.pQTreeView_fonts->setAlternatingRowColors ( TRUE );
				this->sEdt.pQTreeView_fonts->setSelectionMode ( QAbstractItemView::NoSelection );

				connect (
					& this->sEdt.QStandardItemModel_fonts,
					SIGNAL ( itemChanged ( QStandardItem * ) ),
					this,
					SLOT ( setFontParameter ( QStandardItem * ) )
				);

				connect (
					this->sEdt.pQTreeView_fonts,
					SIGNAL ( clicked ( const QModelIndex & ) ),
					this,
					SLOT ( getFontColor ( const QModelIndex & ) )
				);
			}
			pQVBoxLayout_tabPage->addLayout ( pQHBoxLayout_tabIndent );
			pQVBoxLayout_tabPage->addLayout ( pQHBoxLayout_dynamicWordWrap );
			pQVBoxLayout_tabPage->addLayout ( pQHBoxLayout_bgCursor );
			pQVBoxLayout_tabPage->addLayout ( pQHBoxLayout_bgHighlight );
			pQVBoxLayout_tabPage->addWidget ( this->setLine () );
			pQVBoxLayout_tabPage->addLayout ( pQHBoxLayout_font );
			pQVBoxLayout_tabPage->addWidget ( this->sEdt.pQTreeView_fonts );
			pQVBoxLayout_tabPage->addStretch ( 1 );
		}
		pQWidget_tabPage->setLayout ( pQVBoxLayout_tabPage );
	}

	return pQWidget_tabPage;
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgApp::setSet ( void )
{
	SetApp::sEdt_t * psEdt = & ( this->pSetApp_dlg->sEdt );

	this->sEdt.pQSpinBox_tabIndent->setValue ( psEdt->i_tabIndent );

	if ( psEdt->b_dynamicWordWrapEn )
		this->sEdt.pQCheckBox_dynamicWordWrap->setCheckState ( Qt::Checked );
	else
		this->sEdt.pQCheckBox_dynamicWordWrap->setCheckState ( Qt::Unchecked );

	this->setBgColor ( this->sEdt.pQPushButton_bgCursor,    psEdt->QColor_bgCursor );
	this->setBgColor ( this->sEdt.pQPushButton_bgHighlight, psEdt->QColor_bgHighlight );

	// Set font family
	{
	    int i_fontIndex = this->sEdt.pQComboBox_fontFamily->findText( psEdt->QFont_std.family (), Qt::MatchExactly );
	
	    if ( i_fontIndex < 0 )
	      i_fontIndex = 0;
	  
	    this->sEdt.pQComboBox_fontFamily->setCurrentIndex ( i_fontIndex );
	    this->hndlFontFamilySel ( this->sEdt.pQComboBox_fontFamily->currentText () );
	}
	
	// Set font size
	{
	  QString QString_fontSize = QString::number ( psEdt->QFont_std.pointSize () );
	    
	    int i_sizeIndex = this->sEdt.pQComboBox_fontSize->findText( QString_fontSize, Qt::MatchExactly );
	  
	    if ( i_sizeIndex < 0 )
	      i_sizeIndex = 0;
	  
	    this->sEdt.pQComboBox_fontSize->setCurrentIndex ( i_sizeIndex );
	    this->hndlFontSizeSel ( this->sEdt.pQComboBox_fontSize->currentText () );
	}
	
	// Set settings font
	this->sEdt.QStandardItemModel_fonts.clear();

	this->sEdt.QStandardItemModel_fonts.setColumnCount ( 3 );
	this->sEdt.QStandardItemModel_fonts.setRowCount ( 0 );

	this->sEdt.QStandardItemModel_fonts.setHeaderData ( 0, Qt::Horizontal, QString ( QObject::tr ( "Context" ) ) );
	this->sEdt.QStandardItemModel_fonts.setHeaderData ( 1, Qt::Horizontal, QString ( QObject::tr ( "Bold" ) ) );
	this->sEdt.QStandardItemModel_fonts.setHeaderData ( 2, Qt::Horizontal, QString ( QObject::tr ( "Italic" ) ) );

	this->edtSetFont ( QObject::tr ( "Commands" ),          psEdt->QTextCharFormat_cmd       );
	this->edtSetFont ( QObject::tr ( "Directives" ),        psEdt->QTextCharFormat_directive );
	this->edtSetFont ( QObject::tr ( "Hardware keywords" ), psEdt->QTextCharFormat_hw        );
	this->edtSetFont ( QObject::tr ( "Hex numbers" ),       psEdt->QTextCharFormat_hexNumber );
	this->edtSetFont ( QObject::tr ( "Dec numbers" ),       psEdt->QTextCharFormat_decNumber );
	this->edtSetFont ( QObject::tr ( "Oct numbers" ),       psEdt->QTextCharFormat_octNumber );
	this->edtSetFont ( QObject::tr ( "Comments" ),          psEdt->QTextCharFormat_comment   );
	this->edtSetFont ( QObject::tr ( "Separators" ),        psEdt->QTextCharFormat_separator );
	this->edtSetFont ( QObject::tr ( "Functions" ),         psEdt->QTextCharFormat_fct       );
	this->edtSetFont ( QObject::tr ( "Documentation" ),     psEdt->QTextCharFormat_doc       );
	this->edtSetFont ( QObject::tr ( "Navi commands" ),     psEdt->QTextCharFormat_navi      );

// 	this->sEdt.pQTreeView_fonts->setItemDelegateForColumn ( 1, new QCheckBox () );

	this->sEdt.pQTreeView_fonts->resizeColumnToContents ( 0 );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgApp::edtSetFont ( QString QString_context, QTextCharFormat QTextCharFormat_font )
{
	QStandardItem * pQStandardItem_context = new QStandardItem;
	{
		pQStandardItem_context->setEditable ( FALSE );
		pQStandardItem_context->setText ( QString_context );
		pQStandardItem_context->setForeground ( QBrush ( QTextCharFormat_font.foreground ().color (), Qt::SolidPattern ) );
		pQStandardItem_context->setFont ( QTextCharFormat_font.font () );
	}

	QStandardItem * pQStandardItem_bold = new QStandardItem;
	{
		pQStandardItem_bold->setEditable ( FALSE );
		pQStandardItem_bold->setCheckable ( TRUE );
		pQStandardItem_bold->setTextAlignment ( Qt::AlignHCenter );

		if ( QTextCharFormat_font.fontWeight () > 50 )
			pQStandardItem_bold->setCheckState ( Qt::Checked );
		else
			pQStandardItem_bold->setCheckState ( Qt::Unchecked );
	}

	QStandardItem * pQStandardItem_italic = new QStandardItem;
	{
		pQStandardItem_italic->setEditable ( FALSE );
		pQStandardItem_italic->setCheckable ( TRUE );
		pQStandardItem_italic->setTextAlignment ( Qt::AlignHCenter );

		if ( QTextCharFormat_font.fontItalic () )
			pQStandardItem_italic->setCheckState ( Qt::Checked );
		else
			pQStandardItem_italic->setCheckState ( Qt::Unchecked );
	}

	QList<QStandardItem *> QStandardItemList;

	QStandardItemList << pQStandardItem_context;
	QStandardItemList << pQStandardItem_bold;
	QStandardItemList << pQStandardItem_italic;

	this->sEdt.QStandardItemModel_fonts.appendRow ( QStandardItemList );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgApp::edtGetSet ( void )
{
	SetApp::sEdt_t * psEdt = & ( this->pSetApp_dlg->sEdt );

	psEdt->i_tabIndent = this->sEdt.pQSpinBox_tabIndent->value();

	if ( this->sEdt.pQCheckBox_dynamicWordWrap->checkState() == Qt::Checked )
		psEdt->b_dynamicWordWrapEn = TRUE;
	else
		psEdt->b_dynamicWordWrapEn = FALSE;


	psEdt->QColor_bgCursor    = getBgColor ( this->sEdt.pQPushButton_bgCursor );
	psEdt->QColor_bgHighlight = getBgColor ( this->sEdt.pQPushButton_bgHighlight );

	psEdt->QFont_std.setFamily ( this->sEdt.pQComboBox_fontFamily->currentText () );
	psEdt->QFont_std.setPointSize ( this->sEdt.pQComboBox_fontSize->currentText ().toInt () );

	this->getSetFont (  0, & ( psEdt->QTextCharFormat_cmd ) );
	this->getSetFont (  1, & ( psEdt->QTextCharFormat_directive ) );
	this->getSetFont (  2, & ( psEdt->QTextCharFormat_hw ) );
	this->getSetFont (  3, & ( psEdt->QTextCharFormat_hexNumber ) );
	this->getSetFont (  4, & ( psEdt->QTextCharFormat_decNumber ) );
	this->getSetFont (  5, & ( psEdt->QTextCharFormat_octNumber ) );
	this->getSetFont (  6, & ( psEdt->QTextCharFormat_comment ) );
	this->getSetFont (  7, & ( psEdt->QTextCharFormat_separator ) );
	this->getSetFont (  8, & ( psEdt->QTextCharFormat_fct ) );
	this->getSetFont (  9, & ( psEdt->QTextCharFormat_doc ) );
	this->getSetFont ( 10, & ( psEdt->QTextCharFormat_navi ) );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgApp::getSetFont ( int i_row, QTextCharFormat * pQTextCharFormat_font )
{
	QColor QColor_font = this->sEdt.QStandardItemModel_fonts.item ( i_row, 0 )->foreground ().color ();

	pQTextCharFormat_font->setForeground ( QColor_font );

	if ( this->sEdt.QStandardItemModel_fonts.item ( i_row, 1 )->checkState () == Qt::Checked )
		pQTextCharFormat_font->setFontWeight ( QFont::Bold );
	else
		pQTextCharFormat_font->setFontWeight ( QFont::Normal );

	if ( this->sEdt.QStandardItemModel_fonts.item ( i_row, 2 )->checkState () == Qt::Checked )
		pQTextCharFormat_font->setFontItalic ( TRUE );
	else
		pQTextCharFormat_font->setFontItalic ( FALSE );
}

/**
 *****************************************************************************************************************************
 */

QColor SetDlgPgApp::getColor ( QColor QColor_preset )
{
	QColorDialog::setCustomColor ( 0, 0xEEF6FF );
	QColorDialog::setCustomColor ( 1, 0xF5CACA );
	return QColorDialog::getColor ( QColor_preset );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgApp::getBgCursorColor ( void )
{
	QColor QColor_get;

	QColor_get = this->getColor ( this->getBgColor ( this->sEdt.pQPushButton_bgCursor ) );

	if ( QColor_get.isValid () )
		this->setBgColor ( this->sEdt.pQPushButton_bgCursor, QColor_get );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgApp::getBgHighlightColor ( void )
{
	QColor QColor_get;

	QColor_get = this->getColor ( this->getBgColor ( this->sEdt.pQPushButton_bgHighlight ) );

	if ( QColor_get.isValid () )
		this->setBgColor ( this->sEdt.pQPushButton_bgHighlight, QColor_get );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgApp::setBgColor ( QWidget * pQWidget, QColor QColor_bg )
{
/*	QPalette QPalette_bg = pQWidget->palette();
	{
		QPalette_bg.setColor ( QPalette::Active,   QPalette::Button, QColor_bg );
		QPalette_bg.setColor ( QPalette::Inactive, QPalette::Button, QColor_bg );
		QPalette_bg.setColor ( QPalette::Normal,   QPalette::Button, QColor_bg );
		QPalette_bg.setColor ( QPalette::Disabled, QPalette::Button, QColor_bg );

		pQWidget->setPalette ( QPalette_bg );
	}*/
	
	pQWidget->setStyleSheet( QString ( "QPushButton { background: %1 }" ).arg ( QColor_bg.name() ) );
}

/**
 *****************************************************************************************************************************
 */

QColor SetDlgPgApp::getBgColor ( QWidget * pQWidget )
{
	QPalette QPalette_bg = pQWidget->palette();

	return QPalette_bg.color ( QPalette::Active, QPalette::Button );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgApp::setFontParameter ( QStandardItem * pQStandardItem )
{
	int i_row = pQStandardItem->row ();

	QStandardItem * pQStandardItem_context = this->sEdt.QStandardItemModel_fonts.item ( i_row, 0 );
	QStandardItem * pQStandardItem_bold    = this->sEdt.QStandardItemModel_fonts.item ( i_row, 1 );
	QStandardItem * pQStandardItem_italic  = this->sEdt.QStandardItemModel_fonts.item ( i_row, 2 );

	QFont QFont_tmp = pQStandardItem_context->font ();

	// Set bold
	if ( pQStandardItem_bold->checkState () == Qt::Checked )
		QFont_tmp.setBold ( TRUE );
	else
		QFont_tmp.setBold ( FALSE );

	// Set italic
	if ( pQStandardItem_italic->checkState () == Qt::Checked )
		QFont_tmp.setItalic ( TRUE );
	else
		QFont_tmp.setItalic ( FALSE );

	pQStandardItem_context->setFont ( QFont_tmp );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgApp::getFontColor ( const QModelIndex & QModelIndex_item )
{
	int i_row = QModelIndex_item.row ();

	if ( QModelIndex_item.column () != 0 )
		return;

	QStandardItem * pQStandardItem_context = this->sEdt.QStandardItemModel_fonts.item ( i_row, 0 );

	QColor QColor_font;

	QColor_font = getColor ( pQStandardItem_context->foreground ().color () );

	if ( QColor_font.isValid () )
		pQStandardItem_context->setForeground ( QBrush ( QColor_font, Qt::SolidPattern ) );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgApp::hndlFontFamilySel ( const QString & QString_fontFamily )
{
	QString QString_fontSize = this->sEdt.pQComboBox_fontSize->currentText ();
  
	this->sEdt.pQComboBox_fontSize->clear ();

	foreach ( int i_size, this->sEdt.QFontDatabase_system.pointSizes ( QString_fontFamily ) )
	{
		this->sEdt.pQComboBox_fontSize->addItem ( QString::number ( i_size ), i_size );
	}
	
	this->showFontSelection ();
	
	int i_sizeIndex = this->sEdt.pQComboBox_fontSize->findText ( QString_fontSize, Qt::MatchExactly );
	
	if ( i_sizeIndex >= 0 )
		this->sEdt.pQComboBox_fontSize->setCurrentIndex ( i_sizeIndex );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgApp::hndlFontSizeSel ( const QString & QString_fontFamily )
{
	this->showFontSelection ();  
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgApp::showFontSelection ( void )
{
	bool b_success;
	
	int i_fontSize = this->sEdt.pQComboBox_fontSize->currentText ().toInt ( & b_success );

	if ( ! b_success )
		return;
	
	QString QString_fontFamily = this->sEdt.pQComboBox_fontFamily->currentText ();

	for ( int i_row = 0; i_row < this->sEdt.QStandardItemModel_fonts.rowCount (); i_row++ )
	{
		QStandardItem * pQStandardItem = this->sEdt.QStandardItemModel_fonts.item ( i_row, 0 );
	    
		QFont QFont_tmp;

		QFont_tmp = pQStandardItem->font ();
	    
		QFont_tmp.setFamily ( QString_fontFamily );
	    
		QFont_tmp.setPointSize ( i_fontSize );
	    
		pQStandardItem->setFont ( QFont_tmp );
	}
	
	this->sEdt.pQTreeView_fonts->resizeColumnToContents ( 0 );
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

QWidget * SetDlgPgApp::supSetupTabPage ( void )
{
	QWidget * pQWidget = new QWidget;
	{
		QVBoxLayout * pQVBoxLayout_groupBox = new QVBoxLayout;
		{
			QGridLayout * pQGridLayout = new QGridLayout;
			{
				// Show start info
				QHBoxLayout * pQHBoxLayout_showStartInfo = new QHBoxLayout;
				{
					// Set label
					QLabel * pQLabel = new QLabel ( QObject::tr ( "Show release notes:" ) );

					this->sSup.pQCheckBox_showStartInfo = new QCheckBox;
					{
						if ( this->pSetApp_dlg->sSup.b_showStartInfo )
							this->sSup.pQCheckBox_showStartInfo->setCheckState ( Qt::Checked );
						else
							this->sSup.pQCheckBox_showStartInfo->setCheckState ( Qt::Unchecked );
					}
					pQGridLayout->addWidget ( pQLabel,                             1, 0, 1, 1 );
					pQGridLayout->addWidget ( this->sSup.pQCheckBox_showStartInfo, 1, 1, 1, 2 );

	/*				pQHBoxLayout_showStartInfo->addWidget ( pQLabel );
					pQHBoxLayout_showStartInfo->addWidget ( this->pQCheckBox_showStartInfo );
					pQHBoxLayout_showStartInfo->addStretch ();*/
				}

				// Show help side
				QHBoxLayout * pQHBoxLayout_showHelpSide = new QHBoxLayout;
				{
					QLabel * pQLabel = new QLabel;
					{
						pQLabel->setText ( QObject::tr ( "Show help on dock widget side:" ) );
					}
					
					this->sSup.pQComboBox_showHelpSide = new QComboBox ( this );
					{
						this->sSup.pQComboBox_showHelpSide->addItem ( QObject::tr ( "Left" ),  (int) FALSE );
						this->sSup.pQComboBox_showHelpSide->addItem ( QObject::tr ( "Right" ), (int) TRUE  );
						
						this->sSup.pQComboBox_showHelpSide->setCurrentIndex( (int) this->pSetApp_dlg->sSup.b_showHlpCtrlOnRightSide );
					}

					pQGridLayout->addWidget ( pQLabel,                            2, 0, 1, 1 );
					pQGridLayout->addWidget ( this->sSup.pQComboBox_showHelpSide, 2, 1, 1, 2 );

	/*				pQHBoxLayout_showHelpSide->addWidget ( pQLabel_title );
					pQHBoxLayout_showHelpSide->addWidget ( this->pQComboBox_showHelpSide );*/
				}

				// Check interval
				QHBoxLayout * pQHBoxLayout_chkIval = new QHBoxLayout;
				{
					QLabel * pQLabel = new QLabel;
					{
						pQLabel->setText ( QObject::tr ( "Check for updates on startup:" ) );
					}

					this->sSup.pQComboBox_chkIval = new QComboBox ( this );
					{
						this->sSup.pQComboBox_chkIval->addItem ( QObject::tr ( "Never" ),               (int) SetApp::eChkIvalNever   );
						this->sSup.pQComboBox_chkIval->addItem ( QObject::tr ( "Daily (recommended)" ), (int) SetApp::eChkIvalDaily   );
						this->sSup.pQComboBox_chkIval->addItem ( QObject::tr ( "Weekly" ),              (int) SetApp::eChkIvalWeekly  );
						this->sSup.pQComboBox_chkIval->addItem ( QObject::tr ( "Monthly" ),             (int) SetApp::eChkIvalMonthly );
						
						this->sSup.pQComboBox_chkIval->setCurrentIndex( (int) this->pSetApp_dlg->sSup.eChkIval );
					}
					pQGridLayout->addWidget ( pQLabel,                       3, 0, 1, 1 );
					pQGridLayout->addWidget ( this->sSup.pQComboBox_chkIval, 3, 1, 1, 2 );

	/*				pQHBoxLayout_chkIval->addWidget ( pQLabel_title );
					pQHBoxLayout_chkIval->addWidget ( this->pQComboBox_chkIval );*/
				}
				
				// Check interval
				QHBoxLayout * pQHBoxLayout_checkNow = new QHBoxLayout;
				{
					QPushButton * pQPushButton = new QPushButton;
					{
						pQPushButton->setText ( QObject::tr ( "Check &now" ) );
						
						connect ( pQPushButton, SIGNAL ( clicked() ), this, SLOT ( supViewSupportDlg() ) );
					}
					pQHBoxLayout_checkNow->addStretch();
					pQHBoxLayout_checkNow->addWidget ( pQPushButton );
				}

				pQGridLayout->addLayout ( pQHBoxLayout_checkNow, 4, 0, 1, 3 );
			}
			pQVBoxLayout_groupBox->addLayout ( pQGridLayout );
			pQVBoxLayout_groupBox->addStretch ();
		}
		pQWidget->setLayout ( pQVBoxLayout_groupBox );
	}
	return pQWidget;
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgApp::supGetSet ( void )
{
	if ( this->sSup.pQCheckBox_showStartInfo->checkState() == Qt::Checked )
		this->pSetApp_dlg->sSup.b_showStartInfo = TRUE;
	else
		this->pSetApp_dlg->sSup.b_showStartInfo = FALSE;
	
	// Get check interval
	{
		int i_currentIndex = this->sSup.pQComboBox_chkIval->currentIndex();
		this->pSetApp_dlg->sSup.eChkIval = (SetApp::eChkIval_t) i_currentIndex;
	}
	
	// Get show help side
	{
		int i_currentIndex = this->sSup.pQComboBox_showHelpSide->currentIndex();
		this->pSetApp_dlg->sSup.b_showHlpCtrlOnRightSide = static_cast<bool>( i_currentIndex );
	}
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgApp::supViewSupportDlg ( void )
{
	SupDlg SupDlg_inst ( this->pSetApp_dlg, this );

	SupDlg_inst.exec ();
}

/**
 *****************************************************************************************************************************
 */






