/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PRJ_H
#define PRJ_H

#include <QtCore>
#include <QtGui>

#include "MainGuiElements.h"
#include "Mod.h"
#include "PrjOpenDlg.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Project manager class for handling project settings.
 *
 *	The class adds a project menu to the menu bar of the committed QMainWindow object and facilitate generation,
 *	opening, editing and closing of project settings.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *	Change log
 *
 *	2009-08-30
 *		Freeze for first release
 *
 *	2009-09-11
 *		Recent menu added
 *		Unset parent element of error dialogbox fixed
 *
 *	2009-10-04
 *		Emitting project close signal after closing due to opening a new project
 *		Changing open dialog to a project collection manager version
 *		Fixed method for setting up recent list. Needed as result of changes in AppSet.
 *
 *****************************************************************************************************************************
 */

class Prj : public QObject
{
		Q_OBJECT

	public:

		/// Constructor. Inititializes creation of actions and menu bar entries.
		/// \param pMod				Pointer collection to root elements
		/// \param pQMainWindow_mainWindow	Main window widget.
		Prj ( Mod * pMod, QObject * pQObject_parent = 0 );

		///  Prjs up menu list.
		/// \param QMenuBar 			Menubar of main window to add project menubar.
		void setupMenuBar ( QMenuBar * pQMenuBar_mainWindow );

	signals:

		/// Prjtings has been changed.
		void settingsChanged ();

		/// Project has been closed.
		void projectClosed ( void );

	public slots:

		/// Opens an existing project. The location may be given by argument or, if argument is emtpy, get
		/// from dialog.
		/// \param QString_prjFilePath		Project file path
		void openProject ( QString QString_prjFilePath = QString ( ) );

		/// Closes the loaded project
		void closePrj ( void );


	private slots:

		void openProjectFromAction ( void );

		/// Generates a new project. A dialog asks for location.
		void newProject ( void );

		/// Edit the loaded project.
		void editProject ( void );

		/// Sets the settings to given settings
		/// \param pSet_dlg		Set to set.
		void changeSettings ( Set * pSet_dlg );

		/// Clears recent list
		void clearRecent ( void );

	private:

		/// Prjs recent opened project files
		void setRecent ( void );

		/// Pointer collection to root elements
		Mod * pMod;

		/// The project manager menu bar
		QMenu  * pQMenu_project;

		/// The recent sub menu bar
		QMenu * pQMenu_recent;

		/// New project generation action
		QAction * pQAction_newProject;

		/// Open project action
		QAction * pQAction_openProject;

		/// Edit project action
		QAction * pQAction_editProject;

		/// Recent projects action
// 		QAction * pQAction_recentProjects;

		/// Close project action
		QAction * pQAction_closePrj;

		/// Clears recent action
		QAction * pQAction_clearRecent;

		/// Recent files action
		QAction * apQAction_recentFile[ 4 ];

		/// Prjs up the project settings dialog.
		/// Checks the project settings and opens a project dialog, if settings valid.
		/// \retval bool 			Prjtings state
		bool setupPrjDlg ( void );

		/// Creates actions
		void createActions ( void );

		/// Opens a dialog box and returns the project file to store or open.
		/// \param pQFileInfo_prjFilePath	A pointer to return the file.
		/// \retval bool			True, if success, otherwise false
		bool getProjectPathDlgNew ( QFileInfo * pQFileInfo_prjFilePath );

		/// Opens a dialog box and returns the project file to store or open.
		/// \param pQFileInfo_prjFilePath	A pointer to return the file.
		/// \retval bool			True, if success, otherwise false
		bool getProjectPathDlgOpen ( QFileInfo * pQFileInfo_prjFilePath );
		
		
		
		
		
		/// Creates menus from actions
		void createMenus ( void );

		/// Checks, if a project is loaded. I so, it opens a dialog box and asks the user to
		/// close the loaded project.
		/// \retval bool 			True, if the project is still loaded, otherwise false.
		bool chkPrjForClose ( void );

		/// Prjs project status to valid or invalid. Regarding validity menu entries are
		/// enabled/disabled.
		/// \param b_projectValid		Project status.
		void setPrjValid ( bool b_projectValid );

		void addRecent ( QString QString_prjFilePath );

};

#endif
