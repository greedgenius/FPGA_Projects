/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "EdtNavi.h"

/**
 *****************************************************************************************************************************
 */

EdtNavi::EdtNavi ( QWidget * pQWidget_parent )  : QWidget ( pQWidget_parent )
{
	this->pEdtNaviTagList = NULL;
	
	QVBoxLayout * pQVBoxLayout_main = new QVBoxLayout;
	{
		QHBoxLayout * pQHBoxLayout_sort = new QHBoxLayout;
		{
			this->pQPushButton_jumpBack = new QPushButton;
			{
				this->pQPushButton_jumpBack->setIcon ( QIcon ( ":/edt/img/edt/jump.png" ) );
				this->pQPushButton_jumpBack->setEnabled ( FALSE );
				this->pQPushButton_jumpBack->setToolTip ( QObject::tr ( "Jump to highlighted tag" ) );

				connect (
					this->pQPushButton_jumpBack,
					SIGNAL ( clicked () ),
					this,
					SLOT ( jumpToHighlighted () )
				);
			}

			QLabel * pQLabel_sort = new QLabel;
			{
				pQLabel_sort->setText ( QString ( tr ( "Sort order:" ) ) );
			}

			this->pQComboBox_sortMode = new QComboBox;
			{
				this->pQComboBox_sortMode->addItem ( QString ( tr ( "Document" ) ) );
				this->pQComboBox_sortMode->addItem ( QString ( tr ( "Ascent"   ) ) );
				this->pQComboBox_sortMode->addItem ( QString ( tr ( "Descent"  ) ) );

				connect (
					this->pQComboBox_sortMode,
					SIGNAL ( currentIndexChanged ( int ) ),
					this,
					SLOT ( displayTagList ( int ) )
				);
			}

			pQHBoxLayout_sort->addWidget ( this->pQPushButton_jumpBack );
			pQHBoxLayout_sort->addWidget ( pQLabel_sort );
			pQHBoxLayout_sort->addWidget ( pQComboBox_sortMode );
		}

		this->pEdtNaviTreeWidget_tagList = new EdtNaviTreeWidget;
		{
			this->pEdtNaviTreeWidget_tagList->setColumnCount ( 1 );
			this->pEdtNaviTreeWidget_tagList->headerItem()->setHidden ( TRUE );
			this->pEdtNaviTreeWidget_tagList->setAlternatingRowColors ( FALSE );

			connect (
				pEdtNaviTreeWidget_tagList,
				SIGNAL ( clickedLeft ( QTreeWidgetItem *, int ) ),
				this,
				SLOT ( tagHighlighted ( QTreeWidgetItem *, int ) )
			);
			connect (
				pEdtNaviTreeWidget_tagList,
				SIGNAL ( itemDoubleClicked ( QTreeWidgetItem *, int ) ),
				this,
				SLOT ( tagSelected ( QTreeWidgetItem *, int ) )
			);
		}

		pQVBoxLayout_main->addLayout ( pQHBoxLayout_sort );
		pQVBoxLayout_main->addWidget ( pEdtNaviTreeWidget_tagList );
	}

	QWidget::setLayout ( pQVBoxLayout_main );
}

/**
 *****************************************************************************************************************************
 */

void EdtNavi::displayTagList ( int i_SortMode )
{
	if ( ! this->pEdtNaviTagList )
		return;
	
	EdtNaviTagList::QListTags_t * pQListTags;
	
	bool b_structureEn = TRUE;
	
	// Sort list
	switch ( i_SortMode )
	{
		default:
		case 0:	pQListTags = & this->pEdtNaviTagList->QListTags_doc;	b_structureEn = TRUE;	break;
		case 1:	pQListTags = & this->pEdtNaviTagList->QListTags_asc;	b_structureEn = FALSE;	break;
		case 2:	pQListTags = & this->pEdtNaviTagList->QListTags_desc;	b_structureEn = FALSE;	break;
	}

	// Set font tabName
	QFont QFont_tabName;
	QFont_tabName.setBold ( TRUE );

	// Clear old list
	this->pEdtNaviTreeWidget_tagList->clear();
	this->pEdtNaviTreeWidget_tagList->setColumnCount ( 1 );

	QTreeWidgetItem * pQTreeWidgetItem_tagSelected = NULL;

	// Set list
	QTreeWidgetItem * pQTreeWidgetItem_root = new QTreeWidgetItem ( QStringList() << this->QString_tagListName );
	pQTreeWidgetItem_root->setFont ( 0, QFont_tabName );
	
	// Insert new list
	this->pEdtNaviTreeWidget_tagList->insertTopLevelItem ( 0, pQTreeWidgetItem_root );
	this->pEdtNaviTreeWidget_tagList->expandItem ( pQTreeWidgetItem_root );

	// Set tag list to gui
	QTreeWidgetItem * pQTreeWidgetItem_parent = pQTreeWidgetItem_root;
	{
		int i_tagListCount = pQListTags->size();
		
		for ( int i_iterator = 0; i_iterator < i_tagListCount; ++i_iterator )
		{
// 			qDebug() << this->pEdtNaviTagList->QList_tags.at ( i_iterator ).first;
// 			qDebug() << this->pEdtNaviTagList->QList_tags.at ( i_iterator ).second;
			
			QString QString_tag = pQListTags->at ( i_iterator ).first;
			
			QFont QFont_tag;
			{
				QFont_tag.setBold ( TRUE );
			}
			QBrush QBrush_tag;
			{
				QBrush_tag.setStyle ( Qt::SolidPattern );
			}
			
			QTreeWidgetItem * pQTreeWidgetItem_tag = new QTreeWidgetItem;

			if ( pQListTags->at ( i_iterator ).first == this->QString_tagHighlighted )
			{
				QBrush_tag.setColor ( Qt::red );
			}
			else
			{
				switch ( pQListTags->at ( i_iterator ).second.eTagType )
				{
					case EdtNaviTagList::eTagTypeRef:						break;
					case EdtNaviTagList::eTagTypeConst:	QBrush_tag.setColor ( Qt::darkGreen );	break;
					case EdtNaviTagList::eTagTypeSep:	QBrush_tag.setColor ( Qt::darkYellow );	break;
					case EdtNaviTagList::eTagTypeHw:	QBrush_tag.setColor ( Qt::darkBlue );	break;
					case EdtNaviTagList::eTagTypeGrpBegin:	QBrush_tag.setColor ( Qt::darkYellow );	break;
					case EdtNaviTagList::eTagTypeGrpEnd:	QBrush_tag.setColor ( Qt::darkYellow );	break;
					default:				QBrush_tag.setColor ( Qt::darkGray );	break;
				}
			}
			
			pQTreeWidgetItem_tag->setForeground ( 0, QBrush_tag );
			pQTreeWidgetItem_tag->setFont       ( 0, QFont_tag );
			pQTreeWidgetItem_tag->setText       ( 0, QString_tag );
				
			if ( pQListTags->at ( i_iterator ).second.eTagType == EdtNaviTagList::eTagTypeGrpBegin )
			{
				pQTreeWidgetItem_parent->addChild ( pQTreeWidgetItem_tag );
				this->pEdtNaviTreeWidget_tagList->expandItem ( pQTreeWidgetItem_tag );

				if ( b_structureEn )
					pQTreeWidgetItem_parent = pQTreeWidgetItem_tag;
			}
			else if ( pQListTags->at ( i_iterator ).second.eTagType == EdtNaviTagList::eTagTypeGrpEnd )
			{
				if ( b_structureEn )
				{
					if ( pQTreeWidgetItem_parent != pQTreeWidgetItem_root )
					{
						delete pQTreeWidgetItem_tag;
						
						pQTreeWidgetItem_tag = NULL;
						
						pQTreeWidgetItem_parent = pQTreeWidgetItem_parent->parent();
					}
					else
					{
						pQTreeWidgetItem_tag->setForeground ( 0, QBrush ( Qt::red ) );
						pQTreeWidgetItem_tag->setText       ( 0, tr ( "Unexpected end tag" ) );
	// 				qDebug() << "Error";	
						pQTreeWidgetItem_parent->addChild ( pQTreeWidgetItem_tag );
					}
				}
				else
				{
						delete pQTreeWidgetItem_tag;
						
						pQTreeWidgetItem_tag = NULL;
				}
			}
			else
			{
				pQTreeWidgetItem_parent->addChild ( pQTreeWidgetItem_tag );
			}
			
			if ( pQTreeWidgetItem_tag && ( this->QString_tagSelected == pQListTags->at ( i_iterator ).first ) )
				pQTreeWidgetItem_tagSelected = pQTreeWidgetItem_tag;
		}
	}

	if ( pQTreeWidgetItem_tagSelected )
		this->pEdtNaviTreeWidget_tagList->setCurrentItem ( pQTreeWidgetItem_tagSelected );
}

/**
 *****************************************************************************************************************************
 */

void EdtNavi::setTagList ( QString QString_tagListName, EdtNaviTagList * pEdtNaviTagList )
{
	// Tidy up
	if ( this->pEdtNaviTagList )
		delete this->pEdtNaviTagList;
	
	// Generate sored lists
	pEdtNaviTagList->sort();
	
	this->pEdtNaviTagList     = pEdtNaviTagList;
	this->QString_tagListName = QString_tagListName;

	this->displayTagList ( this->pQComboBox_sortMode->currentIndex() );

	emit contentChanged ( this );
}

/**
 *****************************************************************************************************************************
 */

void EdtNavi::clearTagList ( void )
{
	this->pEdtNaviTreeWidget_tagList->clear();

	if ( this->pEdtNaviTagList )
		delete this->pEdtNaviTagList;
}

/**
 *****************************************************************************************************************************
 */

void EdtNavi::tagSelected ( QTreeWidgetItem * pQTreeWidgetItem_selected, int i_column )
{
	if ( ! this->pEdtNaviTagList )
		return;
	
	this->QString_tagSelected = pQTreeWidgetItem_selected->text ( i_column );
	
	// Find tag in list
	int i_tagListCount = this->pEdtNaviTagList->QListTags_doc.count();
	
	for ( int i_iterator = 0; i_iterator < i_tagListCount; ++i_iterator )
	{
		EdtNaviTagList::QPairTag_t QPair_tag = this->pEdtNaviTagList->QListTags_doc.at ( i_iterator );
		
		if ( this->QString_tagSelected != QPair_tag.first )
			continue;
			
// 		this->QString_tagSelected = QPair_tag.second.QString_ref;
	
		emit selectTag ( this->QString_tagListName, QPair_tag.second.QString_ref );
	}
}

/**
 *****************************************************************************************************************************
 */

void EdtNavi::tagHighlighted ( QTreeWidgetItem * pQTreeWidgetItem_selected, int i_column )
{
	this->pQPushButton_jumpBack->setEnabled ( TRUE );
	this->QString_tagHighlighted =  pQTreeWidgetItem_selected->text ( i_column );

	this->displayTagList ( this->pQComboBox_sortMode->currentIndex() );
}

/**
 *****************************************************************************************************************************
 */

void EdtNavi::jumpToHighlighted ( void )
{
	QList <QTreeWidgetItem *> QListpQTreeWidgetItem_highlighted;

	QListpQTreeWidgetItem_highlighted = this->pEdtNaviTreeWidget_tagList->findItems ( this->QString_tagHighlighted, Qt::MatchExactly | Qt::MatchRecursive, 0 );

	if ( QListpQTreeWidgetItem_highlighted.count () <= 0 )
		return;

	QTreeWidgetItem * pQTreeWidgetItem = QListpQTreeWidgetItem_highlighted.at ( 0 );

	this->pEdtNaviTreeWidget_tagList->setCurrentItem ( pQTreeWidgetItem, 0 );

	emit selectTag ( this->QString_tagListName, pQTreeWidgetItem->text ( 0 ) );
}

/**
 *****************************************************************************************************************************
 */

