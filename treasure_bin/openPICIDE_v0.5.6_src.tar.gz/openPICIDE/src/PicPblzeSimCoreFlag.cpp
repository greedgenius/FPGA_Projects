/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeSimCoreFlag.h"

/**
 *****************************************************************************************************************************
 */

PicPblzeSimCoreFlag::PicPblzeSimCoreFlag ( QWidget * pQWidget_parent ) : QWidget ( pQWidget_parent )
{
	QHBoxLayout * pQHBoxLayout_main = new QHBoxLayout;
	{
		QFont QFont_bold;
		QFont_bold.setBold ( TRUE );

		QHBoxLayout * pQHBoxLayout_carry = new QHBoxLayout;
		{
			QLabel * pQLabel_carry = new QLabel;
			{
				pQLabel_carry->setFont ( QFont_bold );
				pQLabel_carry->setText ( QString ( "Carry" ) );
			}

			this->pPicEdtBit_carry = new PicEdtBit;
			{
				this->pPicEdtBit_carry->setContentsMargins ( 5, 0, 5, 0 );
			}

			pQHBoxLayout_carry->addWidget ( pQLabel_carry );
			pQHBoxLayout_carry->addWidget ( this->pPicEdtBit_carry );
// 			pQHBoxLayout_carry->setSizeConstraint ( QLayout::SetMinimumSize );
		}

		QHBoxLayout * pQHBoxLayout_zero = new QHBoxLayout;
		{
			QLabel * pQLabel_zero = new QLabel;
			{
				pQLabel_zero->setFont ( QFont_bold );
				pQLabel_zero->setText ( QString ( "Zero" ) );
			}

			this->pPicEdtBit_zero = new PicEdtBit;
			{
				this->pPicEdtBit_zero->setContentsMargins ( 5, 0, 5, 0 );
			}

			pQHBoxLayout_zero->addWidget ( pQLabel_zero );
			pQHBoxLayout_zero->addWidget ( this->pPicEdtBit_zero );
// 			pQHBoxLayout_zero->setSizeConstraint ( QLayout::SetMinimumSize );
		}

		QHBoxLayout * pQHBoxLayout_int = new QHBoxLayout;
		{
			QLabel * pQLabel_int = new QLabel;
			{
				pQLabel_int->setFont ( QFont_bold );
				pQLabel_int->setText ( QString ( "Int" ) );
			}

			this->pPicEdtInterrupt = new PicEdtInterrupt;
			{
			}

			pQHBoxLayout_int->addWidget ( pQLabel_int );
			pQHBoxLayout_int->addWidget ( this->pPicEdtInterrupt );
// 			pQHBoxLayout_int->setSizeConstraint ( QLayout::SetMinimumSize );
		}

		pQHBoxLayout_main->addLayout ( pQHBoxLayout_carry );
		pQHBoxLayout_main->addLayout ( pQHBoxLayout_zero );
		pQHBoxLayout_main->addLayout ( pQHBoxLayout_int );
		pQHBoxLayout_main->addStretch ();

		pQHBoxLayout_main->setContentsMargins ( 0, 0, 0, 0 );
// 		pQHBoxLayout_main->setSizeConstraint ( QLayout::SetMinimumSize );
	}

	QWidget::setLayout ( pQHBoxLayout_main );
	QWidget::setContentsMargins ( 0, 0, 0, 0 );
// 	QWidget::setSizePolicy ( QSizePolicy::Minimum, QSizePolicy::Minimum );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCoreFlag::setCarry ( int i_value )
{
	this->pPicEdtBit_carry->setValue ( i_value );
	this->pPicEdtBit_carry->setHighlighted ( TRUE );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCoreFlag::getCarry ( void )
{
	return this->pPicEdtBit_carry->getValue();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCoreFlag::setZero ( int i_value )
{
	this->pPicEdtBit_zero->setValue ( i_value );
	this->pPicEdtBit_zero->setHighlighted ( TRUE );
}

/**
 *****************************************************************************************************************************
 */


bool PicPblzeSimCoreFlag::getZero ( void )
{
	return this->pPicEdtBit_zero->getValue();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCoreFlag::setInt ( PicEdtInterrupt::eInt_t eInt )
{
	return this->pPicEdtInterrupt->setValue ( eInt );
}

/**
 *****************************************************************************************************************************
 */


PicEdtInterrupt::eInt_t PicPblzeSimCoreFlag::getInt ( void )
{
	return this->pPicEdtInterrupt->getValue();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCoreFlag::clearHighlighted ( void )
{
	this->pPicEdtBit_carry->setHighlighted ( FALSE );
	this->pPicEdtBit_zero->setHighlighted ( FALSE );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCoreFlag::clear ( void )
{
	this->setZero ( 0 );
	this->setCarry ( 0 );
	this->clearHighlighted ();
}

/**
 *****************************************************************************************************************************
 */
