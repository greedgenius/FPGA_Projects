/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef EdtHlpIndex_H
#define EdtHlpIndex_H

#include <QtCore>
#include <QtGui>
#include <QtHelp>
// #include <QHelpEngine>




/**
 *****************************************************************************************************************************
 *
 *      \brief Tag browser widget.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *	Changelog
 *
 *	2009-08-30	Generated
 *	2009-10-02	Added tool tip to jump button
 *			Fixed losing of selecting during setTagList
 *
 *****************************************************************************************************************************
 */
class EdtHlpIndex : public QWidget
{
		Q_OBJECT

	public:

		/// Constructor
		/// \param pQWidget_parent		Pointer to parent widget
		EdtHlpIndex ( QHelpEngine * pQHelpEngine, QWidget * pQWidget_parent = 0 );

		/// Sets tag list
		/// \param pQString_tagListName		Pointer to tag list name
		/// \param pQStringList_tagList		Pointer to tag list
		void setTagList ( QString * pQString_tagListName, QStringList * pQStringList_tagList );

		/// Clears tag list
		void clearTagList ( void );

	private:

		QTabWidget * pQTabWidget;
		
		QLineEdit * pQLineEdit_filter;
		
		QWidget * setupTabPageContent ( QHelpEngine * pQHelpEngine );

		QWidget * setupTabPageIndex ( QHelpEngine * pQHelpEngine );

		
	// Select topic
	private:
		
		QWidget * pQWidget_selTopic;
		
		QLabel * pQLabel_topic;
		
		QTreeView * pQTreeView_topic;
		
		QStandardItemModel * pQStandardItemModel;
		
		QMap<QString, QUrl> QMapQStringQUrl_src;

	public slots:
		
		/// Initializes html viewer widget with given document and adds to tab widget.
		/// \param QUrl_src			Url to source
		void setLinkActivated ( const QUrl & QUrl_src );

		/// Initializes html viewer widget with given document and adds to tab widget.
		/// \param QUrl_src			Url to source
		void setLinkActivated ( const QUrl & QUrl_src, const QString & QString_keyword );

		/// Initializes html viewer widget with given document and adds to tab widget.
		/// \param QUrl_src			Url to source
		/// \param QString_keyWord		Keyword 
		void topicSetupList ( const QMap<QString, QUrl> & QMapQStringQUrl_src, const QString & QString_keyword );
		
		void topicSelected ( QModelIndex QModelIndex_clicked );
		
	signals:
		
		void linkActivated ( const QUrl & QUrl_src );
};

#endif
