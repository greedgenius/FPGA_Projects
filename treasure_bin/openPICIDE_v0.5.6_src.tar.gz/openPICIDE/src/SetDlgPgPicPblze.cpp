/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "SetDlgPgPicPblze.h"
#include "PicPblze.h"

/**
 *****************************************************************************************************************************
 */

SetDlgPgPicPblze::SetDlgPgPicPblze ( SetPrj * pSetPrj_dlg, QWidget * pQWidget_parent ) : SetDlgPgPicNone ( pQWidget_parent )
{
	this->pSetPrj_dlg = pSetPrj_dlg;

	QVBoxLayout * pQVBoxLayout = new QVBoxLayout ( this );
	{
		QTabWidget * pQTabWidget = new QTabWidget ( this );
		{
			pQTabWidget->addTab ( this->setupTabPageAbout(),    QObject::tr ( "About" ) );
			pQTabWidget->addTab ( this->setupTabPagePic(),      QObject::tr ( "Processor" ) );
			pQTabWidget->addTab ( this->setupTabPageCompiler(), QObject::tr ( "Compiler" ) );
		}

		pQVBoxLayout->addWidget ( pQTabWidget );
	}

	QWidget::setLayout ( pQVBoxLayout );

	this->pQComboBox_derivate->setCurrentIndex ( 3 );

	// Set settings
	this->setSet ();
}

/**
 *****************************************************************************************************************************
 */

SetDlgPgPicPblze::~SetDlgPgPicPblze ( void )
{
}

/**
 *****************************************************************************************************************************
 */

QWidget * SetDlgPgPicPblze::setupTabPageAbout ( void )
{
	QWidget * pQWidget_tabPage = new QWidget ( this );
	{
		// Tab page layout
		QVBoxLayout * pQVBoxLayout_tabPage = new QVBoxLayout ( pQWidget_tabPage );
		{
			QLabel * pQLabel = new QLabel;
			{
				pQLabel->setText ( QString ( 
						"<p>"
						"The Xilinx PicoBlaze%1 is a free soft processor core family "
						"from Xilinx for use in Xilinx FPGA and CPLD products. "
						"</p>"

						"<p>"
						"It is based on a 8 bit RISC architecture optimized for several "
						"FPGA and CPLD devices."
						"</p>"
						"<p>"
						"PicoBlaze%1 is a trademark of Xilinx, Inc."
						"<p/>"
						"<p>"
						"For more information see <a href=\"http://www.xilinx.com\">www.xilinx.com</a>."
						"<p/>"
						
				) .arg ( QChar ( 0x2122 ) ) );

				pQLabel->setTextInteractionFlags ( Qt::LinksAccessibleByMouse | Qt::LinksAccessibleByKeyboard );
				pQLabel->setWordWrap ( TRUE );

				connect ( pQLabel, SIGNAL ( linkActivated ( QString ) ), this, SLOT ( openUrl ( QString ) ) );

			}
			// Set tab page layout
			pQVBoxLayout_tabPage->addWidget ( pQLabel );
			pQVBoxLayout_tabPage->addStretch ( 1 );
		}
	}

	return pQWidget_tabPage;
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgPicPblze::openUrl ( QString QString_url )
{
	QDesktopServices::openUrl ( QUrl ( QString_url ) );
}

/**
 *****************************************************************************************************************************
 */

QWidget * SetDlgPgPicPblze::setupTabPagePic ( void )
{
	QWidget * pQWidget_tabPage = new QWidget ( this );
	{
		// Tab page layout
		QGridLayout * pQGridLayout_tabPage = new QGridLayout ( pQWidget_tabPage );
		{
			int i_row = 0;

			// Processor selection
			{
				// Set Processor label
				QLabel * pQLabel_title = new QLabel ( tr ( "Derivate:" ), this );

				// Set Processor combo box
				this->pQComboBox_derivate = new QComboBox ( this );
				{
					this->pQComboBox_derivate->addItem ( PicPblzeSet::getDerivateName ( PicPblzeSet::ePblzeCpld ), PicPblzeSet::ePblzeCpld );
					this->pQComboBox_derivate->addItem ( PicPblzeSet::getDerivateName ( PicPblzeSet::ePblze     ), PicPblzeSet::ePblze     );
					this->pQComboBox_derivate->addItem ( PicPblzeSet::getDerivateName ( PicPblzeSet::ePblzeII   ), PicPblzeSet::ePblzeII   );
					this->pQComboBox_derivate->addItem ( PicPblzeSet::getDerivateName ( PicPblzeSet::ePblze3    ), PicPblzeSet::ePblze3    );
					this->pQComboBox_derivate->addItem ( PicPblzeSet::getDerivateName ( PicPblzeSet::ePblze6    ), PicPblzeSet::ePblze6    );

					this->pQComboBox_derivate->setCurrentIndex ( 0 );

					connect (
						this->pQComboBox_derivate,
						SIGNAL ( currentIndexChanged ( const QString ) ),
						this,
						SLOT ( setDerivate ( const QString ) )
					);
				}
				pQGridLayout_tabPage->addWidget ( pQLabel_title,             i_row,   0, 1, 1 );
				pQGridLayout_tabPage->addWidget ( this->pQComboBox_derivate, i_row++, 1, 1, 1 );
			}

			// Scratchpad size
			{
				// Set label
				QLabel * pQLabel_title = new QLabel ( tr ( "Scratchpad size:" ), pQWidget_tabPage );

				QHBoxLayout * pQHBoxLayout = new QHBoxLayout;
				{
					// Memory depth
					this->pQComboBox_scrpdSize = new QComboBox ( pQWidget_tabPage );

					pQHBoxLayout->addWidget ( this->pQComboBox_scrpdSize );
					pQHBoxLayout->addStretch ();
				}
				// Add to layout
				pQGridLayout_tabPage->addWidget ( pQLabel_title, i_row,   0, 1, 1 );
				pQGridLayout_tabPage->addLayout ( pQHBoxLayout,  i_row++, 1, 1, 1 );
			}

			// Memory bank count
			{
				// Set label
				QLabel * pQLabel_title = new QLabel ( tr ( "Memory bank count:" ), pQWidget_tabPage );

				QHBoxLayout * pQHBoxLayout = new QHBoxLayout;
				{
					// Memory depth
					this->pQSpinBox_memBankCount = new QSpinBox ( pQWidget_tabPage );
					{
						this->pQSpinBox_memBankCount->setRange ( 1, 4 );
						this->pQSpinBox_memBankCount->setValue ( 1 );
					}

					pQHBoxLayout->addWidget ( this->pQSpinBox_memBankCount );
					pQHBoxLayout->addStretch ();
				}
				// Add to layout
				pQGridLayout_tabPage->addWidget ( pQLabel_title, i_row,   0, 1, 1 );
				pQGridLayout_tabPage->addLayout ( pQHBoxLayout,  i_row++, 1, 1, 1 );
			}

			// Memory size
			{
				// Set label
				QLabel * pQLabel_title = new QLabel ( tr ( "Memory bank size:" ), pQWidget_tabPage );

				QHBoxLayout * pQHBoxLayout = new QHBoxLayout;
				{
					// Memory depth
					this->pQComboBox_memBankSize = new QComboBox ( pQWidget_tabPage );

					QLabel * pQLabel_unit = new QLabel ( tr ( "Instructions" ), this );

					pQHBoxLayout->addWidget ( this->pQComboBox_memBankSize );
					pQHBoxLayout->addWidget ( pQLabel_unit );
					pQHBoxLayout->addStretch ();
				}
				// Add to layout
				pQGridLayout_tabPage->addWidget ( pQLabel_title, i_row,   0, 1, 1 );
				pQGridLayout_tabPage->addLayout ( pQHBoxLayout,  i_row++, 1, 1, 1 );
			}

			// Memory shared location
			{
				// Set label
				QLabel * pQLabel_title = new QLabel ( tr ( "Shared memory location:" ), pQWidget_tabPage );

				QHBoxLayout * pQHBoxLayout = new QHBoxLayout;
				{
					// Memory depth
					this->pQComboBox_sharedLoc = new QComboBox ( pQWidget_tabPage );
					{
						this->pQComboBox_sharedLoc->addItem ( "Low address range",  PicPblzeSet::eMemSharedLocLowAddr );
						this->pQComboBox_sharedLoc->addItem ( "High address range", PicPblzeSet::eMemSharedLocHighAddr );
					}
					pQHBoxLayout->addWidget ( this->pQComboBox_sharedLoc );
					pQHBoxLayout->addStretch ();
				}
				// Add to layout
				pQGridLayout_tabPage->addWidget ( pQLabel_title, i_row,   0, 1, 1 );
				pQGridLayout_tabPage->addLayout ( pQHBoxLayout,  i_row++, 1, 1, 1 );
			}

			// Interrupt vector
			{
				// Set label
				QLabel * pQLabel_title = new QLabel ( tr ( "Interrupt vector:" ), pQWidget_tabPage );

				QHBoxLayout * pQHBoxLayout = new QHBoxLayout;
				{
					// Memory depth
					this->pQSpinBox_intVector = new QSpinBox ( pQWidget_tabPage );

					pQHBoxLayout->addWidget ( this->pQSpinBox_intVector );
					pQHBoxLayout->addStretch ();
				}
				// Add to layout
				pQGridLayout_tabPage->addWidget ( pQLabel_title, i_row,   0, 1, 1 );
				pQGridLayout_tabPage->addLayout ( pQHBoxLayout,  i_row++, 1, 1, 1 );
			}
			
			// Clock frequency
			{
				// Set Processor label
				QLabel * pQLabel_title = new QLabel ( tr ( "Clock frequency:" ), this );

				QHBoxLayout * pQHBoxLayout = new QHBoxLayout;
				{
					this->pQSpinBox_clkFreq = new QSpinBox;
					{
						this->pQSpinBox_clkFreq->setRange ( 0, 1000 );
						this->pQSpinBox_clkFreq->setEnabled ( FALSE );
					}

					QLabel * pQLabel_unit = new QLabel ( tr ( "MHz" ), this );

					pQHBoxLayout->addWidget ( this->pQSpinBox_clkFreq );
					pQHBoxLayout->addWidget ( pQLabel_unit );
					pQHBoxLayout->addStretch ();
				}
				pQGridLayout_tabPage->addWidget ( pQLabel_title, i_row,   0, 1, 1 );
				pQGridLayout_tabPage->addLayout ( pQHBoxLayout,  i_row++, 1, 1, 1 );
			}

			pQGridLayout_tabPage->setColumnStretch ( 0,  0 );
			pQGridLayout_tabPage->setColumnStretch ( 1, 10 );
			pQGridLayout_tabPage->setRowStretch ( i_row++, 10 );
		}
		pQWidget_tabPage->setLayout ( pQGridLayout_tabPage );
	}

	return pQWidget_tabPage;
}

/**
 *****************************************************************************************************************************
 */

QWidget * SetDlgPgPicPblze::setupTabPageCompiler ( void )
{
	QWidget * pQWidget_tabPage = new QWidget ( this );
	{
		// Tab page layout
		QVBoxLayout * pQVBoxLayout_tabPage = new QVBoxLayout ( pQWidget_tabPage );
		{
			// Template file
			QGridLayout * pQGridLayout_tabPage = new QGridLayout();
			{
				{
					// Set label
					QLabel * pQLabel_title = new QLabel ( tr ( "Entity name:" ), pQWidget_tabPage );

					// Set file line edit
					this->pQLineEdit_entityName = new QLineEdit ( pQWidget_tabPage );

					// Add to layout
					pQGridLayout_tabPage->addWidget ( pQLabel_title,         1, 0, 1, 1 );
					pQGridLayout_tabPage->addWidget ( pQLineEdit_entityName, 1, 1, 1, 2 );
				}
				{
					// Set label
					QLabel * pQLabel_title = new QLabel ( tr ( "VHDL template file:" ), pQWidget_tabPage );

					// Set file line edit
					this->pQLineEdit_vhdlTemplateFile = new QLineEdit ( pQWidget_tabPage );

					// Set button for getting output file
					QPushButton * pQPushButton_getFile = new QPushButton ( );
					{
						pQPushButton_getFile->setFixedWidth ( 50 );
						pQPushButton_getFile->setIcon ( QIcon ( ":/prj/img/prj/folderOpen.png" ) );

						connect ( pQPushButton_getFile,
							SIGNAL ( clicked ( ) ),
							this,
							SLOT ( selectVhdlTemplateFile ( ) )
							);
					}

					// Add to layout
					pQGridLayout_tabPage->addWidget ( pQLabel_title,               2, 0, 1, 1 );
					pQGridLayout_tabPage->addWidget ( pQLineEdit_vhdlTemplateFile, 2, 1, 1, 2 );
					pQGridLayout_tabPage->addWidget ( pQPushButton_getFile,        2, 3, 1, 1 );
				}
				{
					// Set label
					QLabel * pQLabel_title = new QLabel ( tr ( "Verilog template file:" ), pQWidget_tabPage );

					// Set file line edit
					this->pQLineEdit_verilogTemplateFile = new QLineEdit ( pQWidget_tabPage );

					// Set button for getting output file
					QPushButton * pQPushButton_getFile = new QPushButton ( );
					{
						pQPushButton_getFile->setFixedWidth ( 50 );
						pQPushButton_getFile->setIcon ( QIcon ( ":/prj/img/prj/folderOpen.png" ) );

						connect ( pQPushButton_getFile,
							SIGNAL ( clicked ( ) ),
							this,
							SLOT ( selectVerilogTemplateFile ( ) )
							);
					}

					// Add to layout
					pQGridLayout_tabPage->addWidget ( pQLabel_title,                  3, 0, 1, 1 );
					pQGridLayout_tabPage->addWidget ( pQLineEdit_verilogTemplateFile, 3, 1, 1, 2 );
					pQGridLayout_tabPage->addWidget ( pQPushButton_getFile,           3, 3, 1, 1 );
				}
			
			}

			// Set tab page layout
			pQVBoxLayout_tabPage->addLayout ( pQGridLayout_tabPage );
			pQVBoxLayout_tabPage->addStretch ( 1 );
		}
	}

	return pQWidget_tabPage;
}

/**
 *****************************************************************************************************************************
 */

QWidget * SetDlgPgPicPblze::setupTabPageJTAG ( void )
{
	QWidget * pQWidget_tabPage = new QWidget ( this );
	{
		// Tab page layout
		QVBoxLayout * pQVBoxLayout_tabPage = new QVBoxLayout ( pQWidget_tabPage );
		{

			// Set tab page layout
			pQVBoxLayout_tabPage->addStretch ( 1 );
		}
	}

	return pQWidget_tabPage;
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgPicPblze::selectVhdlTemplateFile ( void )
{
	// Init dialog
	QFileDialog QFileDialog_file;
	QFileDialog_file.setViewMode ( QFileDialog::Detail );
	QFileDialog_file.setDefaultSuffix ( QString ( "vhd" ) );
	QFileDialog_file.setAcceptMode ( QFileDialog::AcceptOpen );
	QFileDialog_file.setWindowTitle ( tr ( "Select vhdl template file" ) );
	QFileDialog_file.setNameFilter ( tr ( "VHDL files (*.vhd)" ) );
	QFileDialog_file.setFileMode ( QFileDialog::ExistingFiles );

	if ( ! QFileDialog_file.exec () )
		return;

	QStringList QStringList_files = QFileDialog_file.selectedFiles ();

	if ( QStringList_files.count () != 1 )
		return;

	// Convert absolute to relative file path
	QString QString_file = this->pSetPrj_dlg->getRelativeFilePath ( QStringList_files.at ( 0 ) );

	this->pQLineEdit_vhdlTemplateFile->setText ( QString_file );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgPicPblze::selectVerilogTemplateFile ( void )
{
	// Init dialog
	QFileDialog QFileDialog_file;
	QFileDialog_file.setViewMode ( QFileDialog::Detail );
	QFileDialog_file.setDefaultSuffix ( QString ( "v" ) );
	QFileDialog_file.setAcceptMode ( QFileDialog::AcceptOpen );
	QFileDialog_file.setWindowTitle ( tr ( "Select verilog template file" ) );
	QFileDialog_file.setNameFilter ( tr ( "VHDL files (*.v)" ) );
	QFileDialog_file.setFileMode ( QFileDialog::ExistingFiles );

	if ( ! QFileDialog_file.exec () )
		return;

	QStringList QStringList_files = QFileDialog_file.selectedFiles ();

	if ( QStringList_files.count () != 1 )
		return;

	// Convert absolute to relative file path
	QString QString_file = this->pSetPrj_dlg->getRelativeFilePath ( QStringList_files.at ( 0 ) );

	this->pQLineEdit_verilogTemplateFile->setText ( QString_file );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgPicPblze::setDerivate ( QString QString_derivate )
{
	if ( QString_derivate == PicPblzeSet::getDerivateName ( PicPblzeSet::ePblzeCpld ) )
		this->setDerivateDependendSet ( PicPblzeSet::ePblzeCpld );

	else if ( QString_derivate == PicPblzeSet::getDerivateName ( PicPblzeSet::ePblze ) )
		this->setDerivateDependendSet ( PicPblzeSet::ePblze );

	else if ( QString_derivate == PicPblzeSet::getDerivateName ( PicPblzeSet::ePblzeII ) )
		this->setDerivateDependendSet ( PicPblzeSet::ePblzeII );

	else if ( QString_derivate == PicPblzeSet::getDerivateName ( PicPblzeSet::ePblze3 ) )
		this->setDerivateDependendSet ( PicPblzeSet::ePblze3 );

	else if ( QString_derivate == PicPblzeSet::getDerivateName ( PicPblzeSet::ePblze6 ) )
		this->setDerivateDependendSet ( PicPblzeSet::ePblze6 );
	
// 	this->setSet ();
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgPicPblze::setDerivateDependendSet ( PicPblzeSet::ePicDerivate_t ePicDerivate )
{
	this->pQComboBox_scrpdSize->clear();
	this->pQComboBox_memBankSize->clear ();
	
	switch ( ePicDerivate )
	{
		case PicPblzeSet::ePblzeCpld:
			
			// Set interrupt vector
			this->pQSpinBox_intVector->setMinimum ( 0x0FF );
			this->pQSpinBox_intVector->setMaximum ( 0x0FF );
			
			// Set scratchpad size
			this->pQComboBox_scrpdSize->addItem ( "0",  0 );
			
			// Set memory bank size
			this->pQComboBox_memBankSize->addItem ( "  16",   16 );
			this->pQComboBox_memBankSize->addItem ( "  32",   32 );
			this->pQComboBox_memBankSize->addItem ( "  64",   64 );
			this->pQComboBox_memBankSize->addItem ( " 128",  128 );
			this->pQComboBox_memBankSize->addItem ( " 256",  256 );

			break;
			
		case PicPblzeSet::ePblze:
			
			// Set interrupt vector
			this->pQSpinBox_intVector->setMinimum ( 0x0FF );
			this->pQSpinBox_intVector->setMaximum ( 0x0FF );
			
			// Set scratchpad size
			this->pQComboBox_scrpdSize->addItem ( "0",  0 );
			
			// Set memory bank size
			this->pQComboBox_memBankSize->addItem ( "  16",   16 );
			this->pQComboBox_memBankSize->addItem ( "  32",   32 );
			this->pQComboBox_memBankSize->addItem ( "  64",   64 );
			this->pQComboBox_memBankSize->addItem ( " 128",  128 );
			this->pQComboBox_memBankSize->addItem ( " 256",  256 );
			
			break;
			
		case PicPblzeSet::ePblzeII:
			
			// Set interrupt vector
			this->pQSpinBox_intVector->setMinimum ( 0x3FF );
			this->pQSpinBox_intVector->setMaximum ( 0x3FF );
			
			// Set scratchpad size
			this->pQComboBox_scrpdSize->addItem ( "0",  0 );
			
			// Set memory bank size
			this->pQComboBox_memBankSize->addItem ( "  16",   16 );
			this->pQComboBox_memBankSize->addItem ( "  32",   32 );
			this->pQComboBox_memBankSize->addItem ( "  64",   64 );
			this->pQComboBox_memBankSize->addItem ( " 128",  128 );
			this->pQComboBox_memBankSize->addItem ( " 256",  256 );
			this->pQComboBox_memBankSize->addItem ( " 512",  512 );
			this->pQComboBox_memBankSize->addItem ( "1024", 1024 );
			
			break;
			
		case PicPblzeSet::ePblze3:
			
			// Set interrupt vector
			this->pQSpinBox_intVector->setMinimum ( 0x3FF );
			this->pQSpinBox_intVector->setMaximum ( 0x3FF );
			
			// Set scratchpad size
			this->pQComboBox_scrpdSize->addItem ( " 64",  64 );
			
			// Set memory bank size
			this->pQComboBox_memBankSize->addItem ( "  16",   16 );
			this->pQComboBox_memBankSize->addItem ( "  32",   32 );
			this->pQComboBox_memBankSize->addItem ( "  64",   64 );
			this->pQComboBox_memBankSize->addItem ( " 128",  128 );
			this->pQComboBox_memBankSize->addItem ( " 256",  256 );
			this->pQComboBox_memBankSize->addItem ( " 512",  512 );
			this->pQComboBox_memBankSize->addItem ( "1024", 1024 );

			break;
			
		case PicPblzeSet::ePblze6:
		
			// Set interrupt vector
			this->pQSpinBox_intVector->setMinimum ( 0x000 );
			this->pQSpinBox_intVector->setMaximum ( 0xFFF );
			
			// Set scratchpad size
			this->pQComboBox_scrpdSize->addItem ( " 64",  64 );
			this->pQComboBox_scrpdSize->addItem ( "128", 128 );
			this->pQComboBox_scrpdSize->addItem ( "256", 256 );
			
			// Set memory bank size
			this->pQComboBox_memBankSize->addItem ( "  16",   16 );
			this->pQComboBox_memBankSize->addItem ( "  32",   32 );
			this->pQComboBox_memBankSize->addItem ( "  64",   64 );
			this->pQComboBox_memBankSize->addItem ( " 128",  128 );
			this->pQComboBox_memBankSize->addItem ( " 256",  256 );
			this->pQComboBox_memBankSize->addItem ( " 512",  512 );
			this->pQComboBox_memBankSize->addItem ( "1024", 1024 );
			this->pQComboBox_memBankSize->addItem ( "2048", 2048 );
			this->pQComboBox_memBankSize->addItem ( "4096", 4096 );
			
			break;
	}
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgPicPblze::setCurrentIndexFromValue ( QComboBox * pQComboBox, int i_value )
{
	int i_index = pQComboBox->findData ( i_value );
	
	if ( i_index < 0 )
	{
		pQComboBox->setCurrentIndex ( pQComboBox->count() - 1 );
		return;
	}
	
	pQComboBox->setCurrentIndex ( i_index );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgPicPblze::setSet ( void )
{
	// Get and check settings structure
	PicPblzeSet * pPicPblzeSet;
	{
		if ( this->pSetPrj_dlg->sPic.QString_picType != PicPblze::getName () )
			return;

		if ( ! this->pSetPrj_dlg->sPic.pv_picSet )
			return;

		pPicPblzeSet = static_cast <PicPblzeSet *> ( this->pSetPrj_dlg->sPic.pv_picSet );
	}
	
	// Check derivate
	if ( pPicPblzeSet->ePicDerivate > 4 )
		pPicPblzeSet->ePicDerivate = PicPblzeSet::ePblze6;
	
	// Set processor settings
	{
		this->setCurrentIndexFromValue ( this->pQComboBox_derivate,    pPicPblzeSet->ePicDerivate  );
		this->setCurrentIndexFromValue ( this->pQComboBox_sharedLoc,   pPicPblzeSet->eMemSharedLoc );
		this->setCurrentIndexFromValue ( this->pQComboBox_scrpdSize,   pPicPblzeSet->i_scrpdSize   );
		this->setCurrentIndexFromValue ( this->pQComboBox_memBankSize, pPicPblzeSet->i_memBankSize );
		
		this->pQSpinBox_clkFreq->setValue      ( pPicPblzeSet->i_clkFreq );
		this->pQSpinBox_memBankCount->setValue ( pPicPblzeSet->i_memBankCount );
		this->pQSpinBox_intVector->setValue    ( pPicPblzeSet->i_intVector );
	}
	
	// Set compiler settings
	{
		this->pQLineEdit_entityName->setText          ( pPicPblzeSet->QString_entityName );
		this->pQLineEdit_vhdlTemplateFile->setText    ( this->pSetPrj_dlg->getRelativeFilePath ( pPicPblzeSet->QString_vhdlTemplateFile ) );
		this->pQLineEdit_verilogTemplateFile->setText ( this->pSetPrj_dlg->getRelativeFilePath ( pPicPblzeSet->QString_verilogTemplateFile ) );
	}
}

/**
 *****************************************************************************************************************************
 */

int SetDlgPgPicPblze::getCurrentValueFromIndex ( QComboBox * pQComboBox )
{
	return pQComboBox->itemData ( pQComboBox->currentIndex () ).toInt();
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgPicPblze::getSet ( void )
{
	PicPblzeSet * pPicPblzeSet;

	if ( this->pSetPrj_dlg->sPic.QString_picType != PicPblze::getName () )
	{
		if ( this->pSetPrj_dlg->sPic.pv_picSet )
			delete this->pSetPrj_dlg->sPic.pv_picSet;

		pPicPblzeSet = new PicPblzeSet;
	}
	else
	{
		if ( this->pSetPrj_dlg->sPic.pv_picSet )
			pPicPblzeSet = static_cast<PicPblzeSet *> ( this->pSetPrj_dlg->sPic.pv_picSet );
		else
			pPicPblzeSet = new PicPblzeSet;
	}
	this->pSetPrj_dlg->sPic.pv_picSet       = pPicPblzeSet;
	this->pSetPrj_dlg->sPic.QString_picType = PicPblze::getName ();

	// Get processor settings
	{
		pPicPblzeSet->ePicDerivate	= static_cast <PicPblzeSet::ePicDerivate_t>  ( this->getCurrentValueFromIndex ( this->pQComboBox_derivate ) );
		pPicPblzeSet->eMemSharedLoc	= static_cast <PicPblzeSet::eMemSharedLoc_t> ( this->getCurrentValueFromIndex ( this->pQComboBox_sharedLoc ) );
		
		pPicPblzeSet->i_scrpdSize	= this->getCurrentValueFromIndex ( this->pQComboBox_scrpdSize );
		pPicPblzeSet->i_memBankSize	= this->getCurrentValueFromIndex ( this->pQComboBox_memBankSize );
		
		pPicPblzeSet->i_memBankCount	= this->pQSpinBox_memBankCount->value ();
		pPicPblzeSet->i_clkFreq		= this->pQSpinBox_clkFreq->value ();
		pPicPblzeSet->i_intVector	= this->pQSpinBox_intVector->value ();
	}
	
	// Get compiler settings
	{
		pPicPblzeSet->QString_entityName		= this->pQLineEdit_entityName->text ();
		pPicPblzeSet->QString_vhdlTemplateFile		= this->pSetPrj_dlg->getAbsoluteFilePath ( this->pQLineEdit_vhdlTemplateFile->text () );
		pPicPblzeSet->QString_verilogTemplateFile	= this->pSetPrj_dlg->getAbsoluteFilePath ( this->pQLineEdit_verilogTemplateFile->text () );
	}
}

/**
 *****************************************************************************************************************************
 */

