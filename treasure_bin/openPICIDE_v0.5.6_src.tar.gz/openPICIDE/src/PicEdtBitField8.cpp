/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicEdtBitField8.h"


/**
 *****************************************************************************************************************************
 */

PicEdtBitField8::PicEdtBitField8 ( QWidget * pQWidget_parent ) : QWidget ( pQWidget_parent )
{
	this->psBitFieldValue_start = NULL;
	this->psBitFieldValue_stop  = NULL;

	QHBoxLayout * pQHBoxLayout_main = new QHBoxLayout;
	{
		QHBoxLayout * pQHBoxLayout_msNibble = new QHBoxLayout;
		{
			for ( int i_bitIterator = 0; i_bitIterator < 4; i_bitIterator++ )
			{
				sBitFieldValue_t * psBitFieldValue_tmp = new sBitFieldValue_t;

				if ( ! psBitFieldValue_tmp )
				{
					return;
				}

				if ( ! this->psBitFieldValue_start )
				{
					this->psBitFieldValue_start = psBitFieldValue_tmp;
					this->psBitFieldValue_stop  = psBitFieldValue_tmp;
				}
				else
				{
					this->psBitFieldValue_stop->psBitFieldValue_next = psBitFieldValue_tmp;
					this->psBitFieldValue_stop = psBitFieldValue_tmp;
				}

				psBitFieldValue_tmp->psBitFieldValue_next = NULL;

				connect ( & ( psBitFieldValue_tmp->PicEdtBit_value ), SIGNAL ( valueChanged ( bool ) ), this, SLOT ( setValueChanged ( bool ) ) );

				pQHBoxLayout_msNibble->addWidget ( & ( psBitFieldValue_tmp->PicEdtBit_value ) );
			}

			pQHBoxLayout_msNibble->setSpacing ( 7 );
			pQHBoxLayout_msNibble->setContentsMargins ( 0, 0, 0, 0 );
		}

		QHBoxLayout * pQHBoxLayout_lsNibble = new QHBoxLayout;
		{
			for ( int i_bitIterator = 0; i_bitIterator < 4; i_bitIterator++ )
			{
				sBitFieldValue_t * psBitFieldValue_tmp = new sBitFieldValue_t;

				if ( ! psBitFieldValue_tmp )
				{
					return;
				}

				if ( ! this->psBitFieldValue_start )
				{
					this->psBitFieldValue_start = psBitFieldValue_tmp;
					this->psBitFieldValue_stop  = psBitFieldValue_tmp;
				}
				else
				{
					this->psBitFieldValue_stop->psBitFieldValue_next = psBitFieldValue_tmp;
					this->psBitFieldValue_stop = psBitFieldValue_tmp;
				}

				psBitFieldValue_tmp->psBitFieldValue_next = NULL;

				connect ( & ( psBitFieldValue_tmp->PicEdtBit_value ), SIGNAL ( valueChanged ( bool ) ), this, SLOT ( setValueChanged ( bool ) ) );

				pQHBoxLayout_lsNibble->addWidget ( & ( psBitFieldValue_tmp->PicEdtBit_value ) );
			}

			pQHBoxLayout_lsNibble->setSpacing ( 7 );
			pQHBoxLayout_lsNibble->setContentsMargins ( 0, 0, 0, 0 );
		}

		pQHBoxLayout_main->addLayout ( pQHBoxLayout_msNibble );
		pQHBoxLayout_main->addLayout ( pQHBoxLayout_lsNibble );

		pQHBoxLayout_main->setSpacing ( 15 );
		pQHBoxLayout_main->setContentsMargins ( 0, 0, 0, 0 );
	}

	QWidget::setLayout ( pQHBoxLayout_main );
}

/**
 *****************************************************************************************************************************
 */

void PicEdtBitField8::setValue ( int i_value )
{
	sBitFieldValue_t * psBitFieldValue_tmp = this->psBitFieldValue_start;

	unsigned char uc_value   = static_cast <unsigned char> ( i_value );
	unsigned char uc_shifter = 7;

	while ( psBitFieldValue_tmp )
	{
		bool b_bit = static_cast <bool> ( ( uc_value >> uc_shifter-- ) & 0x01 );

		psBitFieldValue_tmp->PicEdtBit_value.setValue ( b_bit );

		psBitFieldValue_tmp = psBitFieldValue_tmp->psBitFieldValue_next;
	}
}

/**
 *****************************************************************************************************************************
 */

int PicEdtBitField8::getValue ( void )
{
	sBitFieldValue_t * psBitFieldValue_tmp = this->psBitFieldValue_start;

	unsigned char uc_shifter = 7;
	unsigned char uc_value   = 0;

	while ( psBitFieldValue_tmp )
	{
		uc_value |= static_cast <unsigned char> ( psBitFieldValue_tmp->PicEdtBit_value.getValue() ) << uc_shifter--;


		psBitFieldValue_tmp = psBitFieldValue_tmp->psBitFieldValue_next;
	}

	return  static_cast <int> ( uc_value );
}

/**
 *****************************************************************************************************************************
 */

void PicEdtBitField8::mousePressEvent ( QMouseEvent * pQMouseEvent )
{
	if ( pQMouseEvent->button() == Qt::RightButton )
	{
		this->toggleValue();
	}
}

/**
 *****************************************************************************************************************************
 */

void PicEdtBitField8::toggleValue ( void )
{
// 	sBitFieldValue_t * psBitFieldValue_tmp = this->psBitFieldValue_start;

	if ( this->getValue() > 4 )
	{
		this->setValue ( 0x00 );
		emit valueChanged ( 0x00 );
	}
	else
	{
		this->setValue ( 0xFF );
		emit valueChanged ( 0xFF );
	}
}

/**
 *****************************************************************************************************************************
 */

void PicEdtBitField8::setValueChanged ( bool b_value )
{
	emit valueChanged ( static_cast <int> ( this->getValue () ) );
}

/**
 *****************************************************************************************************************************
 */

void PicEdtBitField8::setHighlighted ( bool b_highlighted )
{
	sBitFieldValue_t * psBitFieldValue_tmp = this->psBitFieldValue_start;

	while ( psBitFieldValue_tmp )
	{
		psBitFieldValue_tmp->PicEdtBit_value.setHighlighted ( b_highlighted );

		psBitFieldValue_tmp = psBitFieldValue_tmp->psBitFieldValue_next;
	}
}

/**
 *****************************************************************************************************************************
 */
