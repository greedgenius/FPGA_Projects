/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicImport.h"

/**
 *****************************************************************************************************************************
 */

PicImport::PicImport ()
{
}

/**
 *****************************************************************************************************************************
 */
PicImport::eRetVal_t PicImport::convertLine ( QString * pQString_line )
{
	return eRetValUnchanged;
}

/**
 *****************************************************************************************************************************
 */

PicImport::sLineFragments_t PicImport::lineSplit ( QString QString_line )
{
	sLineFragments_t sLineFragments;
	
	// Extract comment from line
	if ( QString_line.contains ( QChar ( ';' ) ) )
	{
		QString QString_comment = QString_line.section ( QChar ( ';' ), 1 );

		if ( ! QString_comment.isEmpty() )
		{
			sLineFragments.QString_8_comment = ";" +  QString_comment;
			
			QString_line = QString_line.section ( QChar ( ';' ), 0, 0 );
		}
	}
	
	// Extract reference from line
	if ( QString_line.contains ( QChar ( ':' ) ) )
	{
		QString QString_reference = QString_line.section ( QChar ( ':' ), 0, 0 );
	
		if ( ! QString_reference.isEmpty() )
		{
			sLineFragments.QString_0_reference = QString_reference + ":";
			
			QString_line = QString_line.section ( QChar ( ':' ), 1 );
		}
	}

	// Extract instruction from line
	{
		QStringList QStringList_fragments = QString_line.split ( QRegExp ( "\\s+" ), QString::SkipEmptyParts );
	
		if ( QStringList_fragments.count() >= 1 )
		{
			// Extract spacer before cmd
			sLineFragments.QString_1_spacer = QString_line.section ( QStringList_fragments.at( 0 ), 0, 0 );

			// Extract cmd
			sLineFragments.QString_2_text = QStringList_fragments.at( 0 );
			
			QString_line = QString_line.section ( QStringList_fragments.at( 0 ), 1 );
		}

		if ( QStringList_fragments.count() >= 2 )
		{
			// Extract spacer before arg0
			sLineFragments.QString_3_spacer = QString_line.section ( QStringList_fragments.at( 1 ), 0, 0 );

			// Extract arg0
			sLineFragments.QString_4_text = QStringList_fragments.at( 1 );
			
			QString_line = QString_line.section ( QStringList_fragments.at( 1 ), 1 );
		}

		if ( QStringList_fragments.count() >= 3 )
		{
			// Extract spacer before arg1
			sLineFragments.QString_5_spacer = QString_line.section ( QStringList_fragments.at( 2 ), 0, 0 );

			// Extract arg1
			sLineFragments.QString_6_text = QStringList_fragments.at( 2 );
			
			QString_line = QString_line.section ( QStringList_fragments.at( 2 ), 1 );
		}
		
		// Extract spacer before comment
		sLineFragments.QString_7_spacer = QString_line;

/*		qDebug() << sLineFragments.QString_0_reference;
		qDebug() << sLineFragments.QString_1_spacer;
		qDebug() << sLineFragments.QString_2_text;
		qDebug() << sLineFragments.QString_3_spacer;
		qDebug() << sLineFragments.QString_4_text;
		qDebug() << sLineFragments.QString_5_spacer;
		qDebug() << sLineFragments.QString_6_text;
		qDebug() << sLineFragments.QString_7_spacer;
		qDebug() << sLineFragments.QString_8_comment;*/
	}
	
	return sLineFragments;
}

/**
 *****************************************************************************************************************************
 */

QString PicImport::lineCombine ( sLineFragments_t * psLineFragments )
{
	QString QString_line;
	
	QString_line  = psLineFragments->QString_0_reference;
	QString_line += psLineFragments->QString_1_spacer;
	QString_line += psLineFragments->QString_2_text;
	QString_line += psLineFragments->QString_3_spacer;
	QString_line += psLineFragments->QString_4_text;
	QString_line += psLineFragments->QString_5_spacer;
	QString_line += psLineFragments->QString_6_text;
	QString_line += psLineFragments->QString_7_spacer;
	QString_line += psLineFragments->QString_8_comment;
	
	return QString_line;
}

/**
 *****************************************************************************************************************************
 */

QString PicImport::getErrMsg ( void )
{
	return this->QString_errMsg;
}

/**
 *****************************************************************************************************************************
 */

