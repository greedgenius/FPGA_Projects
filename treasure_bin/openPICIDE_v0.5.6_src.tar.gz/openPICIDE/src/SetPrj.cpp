/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "SetPrj.h"
#include "SetPrjRdWr.h"
#include "PicNone.h"
#include "PicPblze.h"

/**
 *****************************************************************************************************************************
 */

SetPrj::SetPrj ()
{
	// Preset project settings
	this->sPrj.b_prjVld = FALSE;
	
	// Preset processor page settings
	this->sPic.QString_picType = PicNone::getName ();
	this->sPic.pv_picSet  = NULL;

	// Preset source page settings
// 	sSrc.QStringList_srcFiles = QStringList();
}

/**
 *****************************************************************************************************************************
 */

bool SetPrj::read ( void )
{
	if ( ! this->chkPrjPathVld () )
		return FALSE;

	QString QString_errMsg;
	SetPrjRdWr SetPrjRdWr_rd;
	
	if ( ! SetPrjRdWr_rd.read ( this, & QString_errMsg ) )
	{
		this->showErrMsg ( QString_errMsg );
		return FALSE;
	}
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool SetPrj::save ( void )
{
	if ( ! this->sPrj.b_prjVld )
		return TRUE;
	
	if ( ! this->chkPrjPathVld () )
		return FALSE;
	
	QString QString_errMsg;
	SetPrjRdWr SetPrjRdWr_wr;
	
	if ( ! SetPrjRdWr_wr.save ( this, & QString_errMsg ) )
	{
		this->showErrMsg ( QString_errMsg );
		return FALSE;
	}
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool SetPrj::openPrj ( QString QString_prjFilePath )
{
	if ( this->sPrj.b_prjVld )
		this->closePrj ();
	
	QFileInfo QFileInfo_prjFilePath ( QString_prjFilePath );
	
	this->sPrj.QString_prjFile = QFileInfo_prjFilePath.fileName();
	this->sPrj.QString_prjPath = QFileInfo_prjFilePath.path() + QString ( "/" );

	bool b_retVal = FALSE;
	
	if ( QFileInfo_prjFilePath.exists () )
		this->sPrj.b_prjVld = this->read ();
	else
		this->sPrj.b_prjVld = this->save ();
	
	return this->sPrj.b_prjVld;
}

/**
 *****************************************************************************************************************************
 */

bool SetPrj::closePrj ( void )
{
	if ( this->save () )
	{
		this->sPrj.QString_prjFile.clear ();
		this->sPrj.QString_prjPath.clear ();
		this->sPrj.b_prjVld = FALSE;
		
		this->sVer.QString_comment.clear ();
		this->sVer.QString_title.clear ();
		this->sVer.QString_version.clear ();
		
		
		if ( this->sPic.QString_picType == PicPblze::getName () )
		{
			PicPblzeSet * pPicPblzeSet = static_cast <PicPblzeSet *> ( this->sPic.pv_picSet );

			delete pPicPblzeSet;
		}
		this->sPic.pv_picSet = NULL;
		this->sPic.QString_picType = PicNone::getName ();

		this->sSrc.QStringList_srcFiles.clear ();
		
		this->sEdt.QStringList_loadedFiles.clear ();
		
		return TRUE;
	}
	
	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

void SetPrj::setDirty ( void )
{
	this->save ();
}

/**
 *****************************************************************************************************************************
 */

bool SetPrj::chkPrjPathVld ( void )
{
	if ( this->sPrj.QString_prjFile.isEmpty () || this->sPrj.QString_prjPath.isEmpty () )
	{
		this->showErrMsg ( QObject::tr( "No valid project path set!" ) );
		
		return FALSE;
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

QString SetPrj::getRelativeFilePath ( QString QString_absoluteFilePath )
{
	QDir QDir_prj ( this->sPrj.QString_prjPath );

	return QDir_prj.relativeFilePath ( QString_absoluteFilePath );
}

/**
 *****************************************************************************************************************************
 */

QString SetPrj::getAbsoluteFilePath ( QString QString_relativeFilePath )
{
	QDir QDir_prj ( this->sPrj.QString_prjPath );

	return QDir_prj.absoluteFilePath ( QString_relativeFilePath );
}

/**
 *****************************************************************************************************************************
 */

void SetPrj::showErrMsg ( QString QString_errMsg )
{
	QMessageBox::critical ( 0,
				QObject::tr ( "Project settings" ),
				QString_errMsg,
				QMessageBox::Ok,
				QMessageBox::Ok
				);
}

/**
 *****************************************************************************************************************************
 */
