/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PicPblzeMMViewer_H
#define PicPblzeMMViewer_H

#include <QtCore>
// #include <QtGui>

#include "PicPblzeAsmParser.h"
// #include "Msg.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Xilinx PicoBlaze (tm) assembler compiler.
 *
 *
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.1
 *
 *	Change log
 *
 *	2009-08-30	Freeze for first release
 *	2009-09-09	Change memset to for-loop.
 *	2009-10-02	Change handling of NZ|Z|NC|C to case insensitive
 *	2009-10-04	Renamed some things
 * 	2011-08-30	Fixed bug: replacing "\n" with "\r\n" results in an damaged file on windows systems
 *
 *****************************************************************************************************************************
 */

class PicPblzeMMViewer : public PicPblzeAsmParser
{
	Q_OBJECT

	// Constructor
	public:
		
		/// Constructor.
		/// \param pQObject_parent		Pointer to parent widget
                PicPblzeMMViewer ( QObject * pQObject_parent = 0 );

		/// Destructor. Tidies up.
		~PicPblzeMMViewer ( void );

	// Parameter handling
	public:

		struct sCfg_t {

			PicPblzeAsmParser::sCfg_t sCfg_asmParser;

// 			QString QString_outputFilePath;
		} sCfg;
		
		bool setCfg ( sCfg_t sCfg );
	
	// Generate memory map file
	public:
		
// 		bool generateMemMapFile ( void );
		
		bool generateMemMap ( QString * pQString_memMap );
		
	// Message handling
	protected:
		
		enum eMsgType_t
		{
			eMsgType_ok,

// 			eMsgType_warn,
// 			eMsgType_tmemStuffing,

			eMsgType_err,
			eMsgType_outputFileIO
		};
		
		void msgEmit ( eMsgType_t eMsgType );

// 		void msgEmit ( eMsgType_t eMsgType, sCodeLine_t * psCodeLine );

		/// Emits message.
		/// \param pMsg				Message
		void msgEmit ( Msg * pMsg, eMsgType_t eMsgType );
};

#endif
