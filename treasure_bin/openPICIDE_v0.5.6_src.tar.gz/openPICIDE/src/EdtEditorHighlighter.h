/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef EdtEditorHighlighter_H
#define EdtEditorHighlighter_H

#include <QtGui>
#include <QtCore>

/**
 *****************************************************************************************************************************
 *
 *      \brief Highlighter class for document text editor.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *	Change log
 *
 *	2009-10-06
 *		Moving highlighting key word to processor classes
 *
 *****************************************************************************************************************************
 */
class EdtEditorHighlighter : public QSyntaxHighlighter
{
		Q_OBJECT

	public:

		/// Highlighting colors
		struct sHighlightingFormats_t {

			QTextCharFormat QTextCharFormat_cmd;		/// Highlighting format for assembler commands
			QTextCharFormat QTextCharFormat_directive;	/// Highlighting format for compiler directives
			QTextCharFormat QTextCharFormat_hw;		/// Highlighting format for register
			QTextCharFormat QTextCharFormat_hexNumber;	/// Highlighting format for hexadecimal numbers
			QTextCharFormat QTextCharFormat_decNumber;	/// Highlighting format for decimal numbers
			QTextCharFormat QTextCharFormat_octNumber;	/// Highlighting format for octal numbers
			QTextCharFormat QTextCharFormat_comment;	/// Highlighting format for single line comments
			QTextCharFormat QTextCharFormat_separator;	/// Highlighting format for multiline comments
			QTextCharFormat QTextCharFormat_fct;		/// Highlighting format for functions
			QTextCharFormat QTextCharFormat_doc;		/// Highlighting format for documentation
			QTextCharFormat QTextCharFormat_navi;		/// Highlighting format for navi
		};

		/// Highlighting key words and regular expressions
		struct sHighlightingKeyWords_t {

			QStringList QStringList_cmd;				/// Command list
			QStringList QStringList_directive;			/// Pre compiler command list
			QStringList QStringList_hwComponent;			/// Hardware components list
			QStringList QStringList_navi;				/// Navi command list

			QMap<QString,QStringList> QMap_numberRegExp;		/// Regular expression map for highlighting numbers
		};

		/// Highlighting parameter
		struct sHighlightingParameter_t {

			sHighlightingFormats_t  formats;
			sHighlightingKeyWords_t keyWords;
		};

		/// Constructor
		/// \param pQTextDocument_parent	Pointer to text document used with
		EdtEditorHighlighter ( QTextDocument * pQTextDocument_parent = 0 );

		/// Sets highlighting parameter
		/// \param sHighlighting		Highlighting parameter
		void setHighlightingParameter ( sHighlightingParameter_t sHighlightingParameter );
		
	protected:

		/// Highlights within given text block
		/// \param QString_text		Reference to text block
		void highlightBlock ( const QString & QString_text );

	private:

		/// Rules for highlighting
		struct sHighlightingRule_t
		{
			QRegExp		QRegExp_pattern;
			QTextCharFormat	QTextCharFormat_format;
		};

		/// Rules for highlighting
		QVector<sHighlightingRule_t> QVectorOfHighlightingRule_rules;
};

#endif
