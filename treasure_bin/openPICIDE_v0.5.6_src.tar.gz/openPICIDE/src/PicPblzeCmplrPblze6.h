/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/
#ifndef PicPblzeCmplrPblze6_H
#define PicPblzeCmplrPblze6_H

#include <QtCore>
#include <QtGui>

#include "PicPblzeCmplr.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Xilinx PicoBlaze (tm) assembler compiler.
 *
 *
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.1
 *
 *	Change log
 *
 *	2009-08-30	Freeze for first release
 *	2009-09-09	Change memset to for-loop.
 *	2009-10-02	Change handling of NZ|Z|NC|C to case insensitive
 *	2009-10-04	Renamed some things
 *
 *****************************************************************************************************************************
 */

class PicPblzeCmplrPblze6 : public PicPblzeCmplr
{
                Q_OBJECT

	// Constructor
        public:

		/// Constructor.
		/// \param pQObject_parent		Pointer to parent widget
                PicPblzeCmplrPblze6 ( QObject * pQObject_parent = 0 );

		/// Destructor. Tidies up.
		~PicPblzeCmplrPblze6 ( void );

	// Compile
	public:
		
		/// Compiles parsed code base
		bool compile ( void );

	// Compile commands
	private:

		/// Translates register from Mnemonic to integer
                QMap<QString, int>  QMap_reg;

		/// Compiles code
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		bool compileCmd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles ADD command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdAdd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles ADDCY command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdAddCy ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles AND command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdAnd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles CALL command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdCall ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles COMPARE command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdCompare ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles COMPAREC command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdCompareCy ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles interrupt disable command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdIntDis ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles interrupt enable command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdIntEn ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles FETCH command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdFetch ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles INPUT command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdInput ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles JUMP command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdJump  ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles LOAD command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdLoad ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles LOADRET command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdLoadRet ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles OR command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdOr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles OUTPUT command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdOutput ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles RETURN command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdReturn ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles RETURNI command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdReturnI ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles RL command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdRl  ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles RR command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdRr  ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SL0 command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSl0 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SL1 command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSl1 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SLA command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSla ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SLX command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSlx ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SR0 command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSr0 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SR1 command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSr1 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SRA command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSra ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SRX command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSrx ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles STORE command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdStore ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SUB command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSub ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SUBCY command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSubCy ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles STAR command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdStar ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles TEST command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdTest ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles TESTC command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdTestC ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );
		
		/// Compiles XOR command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdXor ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles HWBUILD command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdHwbld ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles REGBANK command
		/// \param psCodeLine	Code line element
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileCmdRBank ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

	// Compile arguments
	private:

		/// Get processor memory line  bits for register - register/constant
		/// \param psCodeLine	Code line element
		/// \param i_memReg		Register command bits
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileArgReg ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memReg, unsigned int * pui_memCell );
		
		/// Get processor memory line  bits for register - register/constant
		/// \param psCodeLine	Code line element
		/// \param i_memReg		Register command bits
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileArgRegVsReg ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memReg, unsigned int * pui_memCell );

		/// Get processor memory line  bits for register - register/constant
		/// \param psCodeLine	Code line element
		/// \param i_memConst		Constant command bits
		/// \param i_memReg		Register command bits
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileArgMemRegVsRegConst ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memConst, int i_memReg, unsigned int * pui_memCell );

		/// Get processor memory line  bits for register - register/constant
		/// \param psCodeLine	Code line element
		/// \param i_memConst		Constant command bits
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileArgMemRegVsConst ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memConst, unsigned int * pui_memCell );

		/// Get processor memory line  bits for register - register/port address
		/// \param psCodeLine	Code line element
		/// \param i_memConst		Constant command bits
		/// \param i_memReg		Register command bits
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileArgMemRegVsRegPAddr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memAddr,  int i_memReg, unsigned int * pui_memCell );

		/// Get processor memory line  bits for register - register/scratch pad address
		/// \param psCodeLine	Code line element
		/// \param i_memConst		Constant command bits
		/// \param i_memReg		Register command bits
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileArgMemRegVsRegSAddr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memPAddr, int i_memReg, unsigned int * pui_memCell );

		/// Get processor memory line  bits for register
		/// \param psCodeLine	Code line element
		/// \param i_mem		Command bits
		/// \param pui_memCell		Processor memory cell
		/// \retval bool		True, if success, otherwise false
		bool compileArgMemReg ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_mem, unsigned int * pui_memCell );

		/// Get processor memory line bits for destination register
		/// \param QString_regDst	Destination register
		/// \retval int			Processor memory cell bits
		int compileArgRegDst ( QString QString_regDst );

		/// Get processor memory line bits for source register
		/// \param QString_regDst	Source register
		/// \retval int			Processor memory cell bits
		int compileArgRegSrc ( QString QString_regSrc );

		/// Get processor memory line bits for constant
		/// \param QString_regDst	Constant
		/// \retval int			Processor memory cell bits
		int compileArgConst ( int i_const );

		/// Get processor memory line bits for memory address
		/// \param QString_regDst	Address
		/// \retval int			Processor memory cell bits
		int compileArgMAddr ( int i_addr );

		/// Get processor memory line bits for scratch pad address
		/// \param QString_regDst	Address
		/// \retval int			Processor memory cell bits
		int compileArgSAddr ( int i_addr );

		/// Get processor memory line bits for port address address
		/// \param QString_regDst	Address
		/// \retval int			Processor memory cell bits
		int compileArgPAddr ( int i_addr );
};

#endif
