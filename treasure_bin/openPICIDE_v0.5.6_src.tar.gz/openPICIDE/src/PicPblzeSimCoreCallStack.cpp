/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeSimCoreCallStack.h"

/**
 *****************************************************************************************************************************
 */

PicPblzeSimCoreCallStack::PicPblzeSimCoreCallStack ( QWidget * pQWidget_parent ) : QWidget ( pQWidget_parent )
{
        QHBoxLayout * pQHBoxLayout_main = new QHBoxLayout;
        {
                this->pQTreeView_messages = new QTreeView;
                {
                        this->pQTreeView_messages->setModel ( & this->QStandardItemModel_callStack );
                        this->pQTreeView_messages->setRootIsDecorated ( FALSE );
                        this->pQTreeView_messages->setAlternatingRowColors ( TRUE );
                }

                pQHBoxLayout_main->addWidget ( this->pQTreeView_messages );
        }

        QWidget::setLayout ( pQHBoxLayout_main );

        this->clear();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCoreCallStack::clear ( void )
{
        this->QStandardItemModel_callStack.clear();

        this->QStandardItemModel_callStack.setColumnCount ( 2 );
        this->QStandardItemModel_callStack.setRowCount ( 0 );

        this->QStandardItemModel_callStack.setHeaderData ( 0, Qt::Horizontal, QString ( tr ( "Level" ) ) );
        this->QStandardItemModel_callStack.setHeaderData ( 1, Qt::Horizontal, QString ( tr ( "Reference name" ) ) );

}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCoreCallStack::hide ( void )
{
        this->setHidden ( TRUE );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCoreCallStack::add ( QString QString_ref )
{
        int i_rowCount = this->QStandardItemModel_callStack.rowCount();

        QStandardItem * pQStandardItem_level = new QStandardItem;
        {
                pQStandardItem_level->setEditable ( FALSE );
                pQStandardItem_level->setText ( QString ( "%1" ).arg ( i_rowCount ) );
        }

        QStandardItem * pQStandardItem_ref = new QStandardItem;
        {
                pQStandardItem_ref->setEditable ( FALSE );
                pQStandardItem_ref->setText ( QString_ref );
        }

//         this->QStandardItemModel_callStack.appendRow ( pQStandardItem_ref );

        this->QStandardItemModel_callStack.insertRow ( i_rowCount );
        this->QStandardItemModel_callStack.setItem ( i_rowCount, 0, pQStandardItem_level );
        this->QStandardItemModel_callStack.setItem ( i_rowCount, 1, pQStandardItem_ref );

        this->pQTreeView_messages->resizeColumnToContents ( 0 );
        this->pQTreeView_messages->resizeColumnToContents ( 1 );

        emit contentChanged ( this );

        return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCoreCallStack::delLast ( void )
{
        int i_rowCount = this->QStandardItemModel_callStack.rowCount();

        if ( i_rowCount <= 0 )
                return FALSE;

        return this->QStandardItemModel_callStack.removeRow ( --i_rowCount );
}

/**
 *****************************************************************************************************************************
 */

