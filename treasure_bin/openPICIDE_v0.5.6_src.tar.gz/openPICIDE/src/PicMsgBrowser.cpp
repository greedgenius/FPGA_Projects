/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicMsgBrowser.h"

/**
 *****************************************************************************************************************************
 */

PicMsgBrowser::PicMsgBrowser ( QWidget * pQWidget_parent )  : QWidget ( pQWidget_parent )
{
	this->psMsgList_start = NULL;
	this->psMsgList_stop  = NULL;
	
	QHBoxLayout * pQHBoxLayout_main = new QHBoxLayout;
	{
		this->pQTreeView_msg = new QTreeView;
		{
			this->pQTreeView_msg->setModel ( & this->QStandardItemModel_msg );
			this->pQTreeView_msg->setRootIsDecorated ( FALSE );
			this->pQTreeView_msg->setAlternatingRowColors ( TRUE );

			connect ( this->pQTreeView_msg, SIGNAL ( clicked ( QModelIndex ) ), this, SLOT ( handleClick ( QModelIndex ) ) );
		}

		pQHBoxLayout_main->addWidget ( this->pQTreeView_msg );
	}

	QWidget::setLayout ( pQHBoxLayout_main );

	this->clearMsgList();
}

/**
 *****************************************************************************************************************************
 */

void PicMsgBrowser::clearMsgList ( void )
{
	sMsgList_t * psMsgList_del;
	sMsgList_t * psMsgList_run = this->psMsgList_start;
		
	while ( psMsgList_run )
	{
		psMsgList_del = psMsgList_run;
		psMsgList_run = psMsgList_run->psMsgList_nxt;
		
		delete psMsgList_del;
	}
	
	this->psMsgList_start = NULL;
	this->psMsgList_stop  = NULL;
	
	this->QStandardItemModel_msg.clear();

	this->QStandardItemModel_msg.setColumnCount ( 4 );
	this->QStandardItemModel_msg.setRowCount ( 0 );

	this->QStandardItemModel_msg.setHeaderData ( 0, Qt::Horizontal, QString () );
	this->QStandardItemModel_msg.setHeaderData ( 1, Qt::Horizontal, QString ( tr ( "Help" ) ) );
	this->QStandardItemModel_msg.setHeaderData ( 2, Qt::Horizontal, QString ( tr ( "Source" ) ) );
	this->QStandardItemModel_msg.setHeaderData ( 3, Qt::Horizontal, QString ( tr ( "Message" ) ) );

	this->i_tableRowCount = 0;
}

/**
 *****************************************************************************************************************************
 */

void PicMsgBrowser::setMessage ( Msg * pMsg )
{
	// Set status icon
	QStandardItem * pQStandardItem_status = new QStandardItem;
	{
		QIcon QIcon_status;
		{
			switch ( pMsg->eStatus )
			{
				case Msg::e_ok:		QIcon_status = QIcon ( ":/pic/img/pic/msgOk.png" );		break;
				case Msg::e_warning:	QIcon_status = QIcon ( ":/pic/img/pic/msgWarning.png" );	break;
				case Msg::e_error:	QIcon_status = QIcon ( ":/pic/img/pic/msgError.png" );		break;
			}
		}
		pQStandardItem_status->setEditable ( FALSE );
		pQStandardItem_status->setIcon ( QIcon_status );
	}
	
	// Set help
	QStandardItem * pQStandardItem_hlp = new QStandardItem;
	{
		if ( ! pMsg->QUrl_hlpUrl.isEmpty() )
			pQStandardItem_hlp->setIcon ( QIcon ( ":/pic/img/pic/msgInfo.png" ) );

		pQStandardItem_hlp->setEditable ( FALSE );
	}
	
	// Set source
	QStandardItem * pQStandardItem_src = new QStandardItem;
	{
		QString QString_src;
		{
			if ( ! pMsg->QUrl_srcUrl.isEmpty() )
				QString_src += pMsg->QUrl_srcUrl.path();
			
			if ( pMsg->QUrl_srcUrl.hasFragment() )
				QString_src += QString ( "#%1" ).arg( pMsg->QUrl_srcUrl.fragment() );
		}
		pQStandardItem_src->setEditable ( FALSE );
		pQStandardItem_src->setText ( QString_src );
	}
	
	// Set message
	QStandardItem * pQStandardItem_message = new QStandardItem;
	{
		pQStandardItem_message->setEditable ( FALSE );
		pQStandardItem_message->setText ( pMsg->QString_msg );
	}

	this->QStandardItemModel_msg.insertRow ( this->i_tableRowCount );
	this->QStandardItemModel_msg.setItem   ( this->i_tableRowCount, 0, pQStandardItem_status );
	this->QStandardItemModel_msg.setItem   ( this->i_tableRowCount, 1, pQStandardItem_hlp );
	this->QStandardItemModel_msg.setItem   ( this->i_tableRowCount, 2, pQStandardItem_src );
	this->QStandardItemModel_msg.setItem   ( this->i_tableRowCount, 3, pQStandardItem_message );

	this->pQTreeView_msg->resizeColumnToContents ( 0 );
	this->pQTreeView_msg->resizeColumnToContents ( 1 );
	this->pQTreeView_msg->resizeColumnToContents ( 2 );
	this->pQTreeView_msg->resizeColumnToContents ( 3 );
	
	// Add message to chained list
	{
		sMsgList_t * psMsgList = new sMsgList_t;
	
		psMsgList->pMsg          = pMsg;
		psMsgList->i_row         = this->i_tableRowCount;
		psMsgList->psMsgList_nxt = NULL;
		
		if ( this->psMsgList_stop )
		{
			this->psMsgList_stop->psMsgList_nxt = psMsgList;
			this->psMsgList_stop = psMsgList;
		}
		else
		{
			this->psMsgList_start = psMsgList;
			this->psMsgList_stop  = psMsgList;
		}
	}
	
	this->i_tableRowCount++;

	this->pQTreeView_msg->scrollToBottom();
	
	emit contentChanged ( this );

	QApplication::processEvents ( QEventLoop::AllEvents );	
}

/**
 *****************************************************************************************************************************
 */

void PicMsgBrowser::setMessage ( QString QString_message, QString QString_filePath, int i_lineNumber, Msg::eStatus_t eStatus )
{

}

/**
 *****************************************************************************************************************************
 */

void PicMsgBrowser::hide ( void )
{
	this->setHidden ( TRUE );
}

/**
 *****************************************************************************************************************************
 */

void PicMsgBrowser::handleClick ( QModelIndex QModelIndex_selected )
{
	int i_row = QModelIndex_selected.row();

	sMsgList_t * psMsgList = this->psMsgList_start;
		
	while ( psMsgList )
	{
		if ( i_row == psMsgList->i_row )
		{
			switch ( QModelIndex_selected.column () )
			{
				case 1:		emit lineClicked ( psMsgList->pMsg->QUrl_hlpUrl );	return;
				default:	emit lineClicked ( psMsgList->pMsg->QUrl_srcUrl );	return;
			}
		}
		psMsgList = psMsgList->psMsgList_nxt;
	}
}

/**
 *****************************************************************************************************************************
 */














