/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeCmplrPblze6.h"

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Constructor/destructor
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

PicPblzeCmplrPblze6::PicPblzeCmplrPblze6 ( QObject * pQObject_parent ) : PicPblzeCmplr ( pQObject_parent )
{
	this->QMap_reg [ "s0" ] = 0x0;
	this->QMap_reg [ "s1" ] = 0x1;
	this->QMap_reg [ "s2" ] = 0x2;
	this->QMap_reg [ "s3" ] = 0x3;
	this->QMap_reg [ "s4" ] = 0x4;
	this->QMap_reg [ "s5" ] = 0x5;
	this->QMap_reg [ "s6" ] = 0x6;
	this->QMap_reg [ "s7" ] = 0x7;
	this->QMap_reg [ "s8" ] = 0x8;
	this->QMap_reg [ "s9" ] = 0x9;
	this->QMap_reg [ "sA" ] = 0xA;
	this->QMap_reg [ "sB" ] = 0xB;
	this->QMap_reg [ "sC" ] = 0xC;
	this->QMap_reg [ "sD" ] = 0xD;
	this->QMap_reg [ "sE" ] = 0xE;
	this->QMap_reg [ "sF" ] = 0xF;
}

/**
 *****************************************************************************************************************************
 */
PicPblzeCmplrPblze6::~PicPblzeCmplrPblze6 ( void )
{
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Compile
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compile ( void )
{
	// Parse code
	if ( ! PicPblzeAsmParser::parse () )
		return FALSE;

	// Allocate new pic memory
	PicPblzeCmplr::asMemCell = new sMemCell_t[ PicPblzeAsmParser::sMem.i_memSize ];

	// Preset pic memory with zero
	memset ( PicPblzeCmplr::asMemCell, NULL, ( PicPblzeAsmParser::sMem.i_memSize * sizeof ( PicPblzeCmplr::sMemCell_t ) ) );
	
	// Compile
	for ( int i_iterator = 0; i_iterator < PicPblzeAsmParser::sMem.i_memSize; ++i_iterator )
	{
		unsigned int ui_memCell;
		
		sCodeLine_t * psCodeLine = PicPblzeAsmParser::sMem.apsCodeLine_memMap[ i_iterator ];
		
		if ( ! psCodeLine )
			continue;
		
		if ( psCodeLine->eLineType > PicPblzeAsmParser::eLineType_cmd )
		{
			// Get memory line
			if ( ! this->compileCmd ( psCodeLine, & ui_memCell ) )
			{
				PicPblzeCmplr::msgEmit ( PicPblzeCmplr::eMsgType_compError );
				return FALSE;
			}

			// Store memory line
			PicPblzeCmplr::asMemCell [ i_iterator ].b_valid  = TRUE;
			PicPblzeCmplr::asMemCell [ i_iterator ].ui_value = ui_memCell;
		}
		else
		{
			PicPblzeCmplr::msgEmit ( PicPblzeCmplr::eMsgType_compError );
			return FALSE;
		}
	}

	// Write output file
	return PicPblzeCmplr::writeOutputFile ();
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Compile commands
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	switch ( psCodeLine->eLineType )
	{
		case eLineType_cmdRet:		return this->compileCmdReturn    ( psCodeLine, pui_memCell );
		case eLineType_cmdReti:		return this->compileCmdReturnI   ( psCodeLine, pui_memCell );
		case eLineType_cmdAddc:		return this->compileCmdAddCy     ( psCodeLine, pui_memCell );
		case eLineType_cmdSubc:		return this->compileCmdSubCy     ( psCodeLine, pui_memCell );
		case eLineType_cmdIn:		return this->compileCmdInput     ( psCodeLine, pui_memCell );
		case eLineType_cmdOut:		return this->compileCmdOutput    ( psCodeLine, pui_memCell );
		case eLineType_cmdEint:		return this->compileCmdIntEn     ( psCodeLine, pui_memCell );
		case eLineType_cmdDint:		return this->compileCmdIntDis    ( psCodeLine, pui_memCell );
		case eLineType_cmdComp:		return this->compileCmdCompare   ( psCodeLine, pui_memCell );
		case eLineType_cmdCompC:	return this->compileCmdCompareCy ( psCodeLine, pui_memCell );
		case eLineType_cmdHwbld:	return this->compileCmdHwbld     ( psCodeLine, pui_memCell );
		case eLineType_cmdAdd:		return this->compileCmdAdd       ( psCodeLine, pui_memCell );
		case eLineType_cmdAnd:		return this->compileCmdAnd       ( psCodeLine, pui_memCell );
		case eLineType_cmdCall:		return this->compileCmdCall      ( psCodeLine, pui_memCell );
		case eLineType_cmdJump:		return this->compileCmdJump      ( psCodeLine, pui_memCell );
		case eLineType_cmdLoad:		return this->compileCmdLoad      ( psCodeLine, pui_memCell );
		case eLineType_cmdOr:		return this->compileCmdOr        ( psCodeLine, pui_memCell );
		case eLineType_cmdRl:		return this->compileCmdRl        ( psCodeLine, pui_memCell );
		case eLineType_cmdRr:		return this->compileCmdRr        ( psCodeLine, pui_memCell );
		case eLineType_cmdSl0:		return this->compileCmdSl0       ( psCodeLine, pui_memCell );
		case eLineType_cmdSl1:		return this->compileCmdSl1       ( psCodeLine, pui_memCell );
		case eLineType_cmdSlA:		return this->compileCmdSla       ( psCodeLine, pui_memCell );
		case eLineType_cmdSlX:		return this->compileCmdSlx       ( psCodeLine, pui_memCell );
		case eLineType_cmdSr0:		return this->compileCmdSr0       ( psCodeLine, pui_memCell );
		case eLineType_cmdSr1:		return this->compileCmdSr1       ( psCodeLine, pui_memCell );
		case eLineType_cmdSrA:		return this->compileCmdSra       ( psCodeLine, pui_memCell );
		case eLineType_cmdSrX:		return this->compileCmdSrx       ( psCodeLine, pui_memCell );
		case eLineType_cmdSub:		return this->compileCmdSub       ( psCodeLine, pui_memCell );
		case eLineType_cmdTest:		return this->compileCmdTest      ( psCodeLine, pui_memCell );
		case eLineType_cmdTestC:	return this->compileCmdTestC     ( psCodeLine, pui_memCell );
		case eLineType_cmdXor:		return this->compileCmdXor       ( psCodeLine, pui_memCell );
		case eLineType_cmdStore:	return this->compileCmdStore     ( psCodeLine, pui_memCell );
		case eLineType_cmdFetch:	return this->compileCmdFetch     ( psCodeLine, pui_memCell );
		case eLineType_cmdStar:		return this->compileCmdStar      ( psCodeLine, pui_memCell );
		case eLineType_cmdRBank:	return this->compileCmdRBank     ( psCodeLine, pui_memCell );
		case eLineType_cmdLoadRet:	return this->compileCmdLoadRet   ( psCodeLine, pui_memCell );
	}

	PicPblzeAsmParser::msgEmit ( PicPblzeAsmParser::eMsgType_ivldCmd, psCodeLine );

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdAdd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemRegVsRegConst ( psCodeLine, 0x11000, 0x10000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdAddCy ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemRegVsRegConst ( psCodeLine, 0x13000, 0x12000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdAnd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemRegVsRegConst ( psCodeLine, 0x03000, 0x02000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdCall ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	//********************************************************************************************************************
	//* Address only
	//********************************************************************************************************************
	if ( psCodeLine->QStringList_args.count () == 1 )
	{
		QString QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );

		sCodeLine_t * psCodeLine_addr;
		
		if ( ! PicPblzeAsmParser::checkArgRef ( QString_addr, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell = 0x20000 | this->compileArgMAddr ( psCodeLine_addr->i_addr );
		return TRUE;
	}
	
	//********************************************************************************************************************
	//* 
	//********************************************************************************************************************
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QString_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	QString QString_cond = QString_arg0.toUpper ();

	if ( QString ( "C" ) == QString_cond )
	{
		sCodeLine_t * psCodeLine_addr;

		if ( ! PicPblzeAsmParser::checkArgRef ( QString_arg1, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell = 0x38000 | this->compileArgMAddr ( psCodeLine_addr->i_addr );
	}
	else if ( QString ( "NC" ) == QString_cond )
	{
		sCodeLine_t * psCodeLine_addr;

		if ( ! PicPblzeAsmParser::checkArgRef ( QString_arg1, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell = 0x3C000 | this->compileArgMAddr ( psCodeLine_addr->i_addr );
	}
	else if ( QString ( "NZ" ) == QString_cond )
	{
		sCodeLine_t * psCodeLine_addr;

		if ( ! PicPblzeAsmParser::checkArgRef ( QString_arg1, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell = 0x34000 | this->compileArgMAddr ( psCodeLine_addr->i_addr );
	}
	else if ( QString ( "Z" ) == QString_cond )
	{
		sCodeLine_t * psCodeLine_addr;

		if ( ! PicPblzeAsmParser::checkArgRef ( QString_arg1, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell = 0x30000 | this->compileArgMAddr ( psCodeLine_addr->i_addr );
	}
	else
	{
		QString QString_regH;
		QString QString_regL;
		
		// Remove brackets
		QString_arg0 = QString_arg0.remove ( 0, 1 );
		QString_arg1 = QString_arg1.remove ( QString_arg1.length() - 1, 1 );
		
		if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regH ) )
			return FALSE;

		if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg1, & QString_regL ) )
			return FALSE;
			
		*pui_memCell = 0x24000 | this->compileArgRegDst ( QString_regH ) | this->compileArgRegSrc ( QString_regL );
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdCompare ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemRegVsRegConst ( psCodeLine, 0x1D000, 0x1C000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdCompareCy ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemRegVsRegConst ( psCodeLine, 0x1F000, 0x1E000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdIntDis ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	*pui_memCell = 0x28000;
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdIntEn ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	*pui_memCell = 0x28001;
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdFetch ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemRegVsRegSAddr ( psCodeLine, 0x0B000, 0x0A000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdInput ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemRegVsRegPAddr ( psCodeLine, 0x09000, 0x08000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdJump ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	//********************************************************************************************************************
	//* Address only
	//********************************************************************************************************************
	if ( psCodeLine->QStringList_args.count () == 1 )
	{
		QString QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );

		sCodeLine_t * psCodeLine_addr;
		
		if ( ! PicPblzeAsmParser::checkArgRef ( QString_addr, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell = 0x22000 | this->compileArgMAddr ( psCodeLine_addr->i_addr );
		return TRUE;
	}
	
	//********************************************************************************************************************
	//* 
	//********************************************************************************************************************
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QString_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	QString QString_cond = QString_arg0.toUpper ();

	if ( QString ( "C" ) == QString_cond )
	{
		sCodeLine_t * psCodeLine_addr;

		if ( ! PicPblzeAsmParser::checkArgRef ( QString_arg1, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell = 0x3A000 | this->compileArgMAddr ( psCodeLine_addr->i_addr );
	}
	else if ( QString ( "NC" ) == QString_cond )
	{
		sCodeLine_t * psCodeLine_addr;

		if ( ! PicPblzeAsmParser::checkArgRef ( QString_arg1, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell = 0x3E000 | this->compileArgMAddr ( psCodeLine_addr->i_addr );
	}
	else if ( QString ( "NZ" ) == QString_cond )
	{
		sCodeLine_t * psCodeLine_addr;

		if ( ! PicPblzeAsmParser::checkArgRef ( QString_arg1, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell = 0x36000 | this->compileArgMAddr ( psCodeLine_addr->i_addr );
	}
	else if ( QString ( "Z" ) == QString_cond )
	{
		sCodeLine_t * psCodeLine_addr;

		if ( ! PicPblzeAsmParser::checkArgRef ( QString_arg1, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell = 0x32000 | this->compileArgMAddr ( psCodeLine_addr->i_addr );
	}
	else
	{
		QString QString_regH;
		QString QString_regL;
		
		// Remove brackets
		QString_arg0 = QString_arg0.remove ( 0, 1 );
		QString_arg1 = QString_arg1.remove ( QString_arg1.length() - 1, 1 );
		
		if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regH ) )
			return FALSE;

		if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg1, & QString_regL ) )
			return FALSE;
			
		*pui_memCell = 0x26000 | this->compileArgRegDst ( QString_regH ) | this->compileArgRegSrc ( QString_regL );
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdLoad ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemRegVsRegConst ( psCodeLine, 0x01000, 0x00000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdLoadRet ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemRegVsConst ( psCodeLine, 0x21000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdOr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemRegVsRegConst ( psCodeLine, 0x05000, 0x04000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdOutput ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QStirng_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	// Check first argument for register 
	if ( this->checkArgRegSubst ( QString_arg0 ) )
		return this->compileArgMemRegVsRegPAddr ( psCodeLine, 0x2D000, 0x2C000, pui_memCell );

	// Compile: Constant -> Port
	int i_const;
	int i_pAddr;

	// Get constant
	if ( ! PicPblzeAsmParser::checkArgNumberConst ( QString_arg0, & i_const ) )
		return FALSE;
	
	// Get port address
	if ( ! PicPblzeAsmParser::checkArgNumberConst ( QStirng_arg1, & i_pAddr ) )
		return FALSE;
	
	// Setup memory cell
	*pui_memCell = 0x2B000 | ( ( i_const & 0xFF ) << 4 ) | ( i_pAddr & 0xF );
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdReturn ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0;

	if ( psCodeLine->QStringList_args.count () > 0 )
		QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();

	//********************************************************************************************************************
	//* Check for jump type
	//********************************************************************************************************************
	if ( QString_arg0 == QString ( "C" ) )		// RETURN C
	{
		*pui_memCell  = 0x39000;
	}
	else if ( QString_arg0 == QString ( "NC" ) )	// RETURN NC
	{
		*pui_memCell  = 0x3D000;
	}
	else if ( QString_arg0 == QString ( "NZ" ) )	// RETURN NZ
	{
		*pui_memCell  = 0x35000;
	}
	else if ( QString_arg0 == QString ( "Z" ) )	// RETURN Z
	{
		*pui_memCell  = 0x31000;
	}
	else
	{
		*pui_memCell  = 0x25000;
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdReturnI ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();

	if ( QString_arg0 == QString ( "DISABLE" ) )
		*pui_memCell = 0x29000;

	else if ( QString_arg0 == QString ( "ENABLE" ) )
		*pui_memCell = 0x29001;

	else
		return FALSE;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdRl ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemReg ( psCodeLine, 0x14002, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdRr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemReg ( psCodeLine, 0x1400C, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdSl0 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemReg ( psCodeLine, 0x14006, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdSl1 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemReg ( psCodeLine, 0x14007, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdSla ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemReg ( psCodeLine, 0x14000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdSlx ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemReg ( psCodeLine, 0x14004, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdSr0 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemReg ( psCodeLine, 0x1400E, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdSr1 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemReg ( psCodeLine, 0x1400F, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdSra ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemReg ( psCodeLine, 0x14008, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdSrx ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemReg ( psCodeLine, 0x1400A, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdStar ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgRegVsReg ( psCodeLine, 0x16000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdStore ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemRegVsRegSAddr ( psCodeLine, 0x2F000, 0x2E000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdSub ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemRegVsRegConst ( psCodeLine, 0x19000, 0x18000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdSubCy ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemRegVsRegConst ( psCodeLine, 0x1B000, 0x1A000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdTest ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemRegVsRegConst ( psCodeLine, 0x0D000, 0x0C000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdTestC ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemRegVsRegConst ( psCodeLine, 0x0F000, 0x0E000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdXor ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgMemRegVsRegConst ( psCodeLine, 0x07000, 0x06000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdHwbld ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return this->compileArgReg ( psCodeLine, 0x14080, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileCmdRBank ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();

	if ( QString_arg0 == QString ( "A" ) )
		*pui_memCell = 0x37000;

	else if ( QString_arg0 == QString ( "B" ) )
		*pui_memCell = 0x37001;

	else
		return FALSE;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Compile arguments
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileArgReg ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memReg, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );

	QString QString_regDst;
	int i_constant;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	*pui_memCell = i_memReg | compileArgRegDst ( QString_regDst );
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileArgRegVsReg ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memReg, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QStirng_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	QString QString_regDst;
	QString QString_regSrc;
	int i_constant;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QStirng_arg1, & QString_regSrc ) )
		return FALSE;

	*pui_memCell = i_memReg | compileArgRegDst ( QString_regDst ) | compileArgRegSrc ( QString_regSrc );
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileArgMemRegVsRegConst ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memConst, int i_memReg, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QStirng_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	QString QString_regDst;
	QString QString_regSrc;
	int i_constant;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	//********************************************************************************************************************
	//* Check for constant
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgNumberConst ( QStirng_arg1, & i_constant ) )
	{
		*pui_memCell = i_memConst | compileArgRegDst ( QString_regDst ) | compileArgConst ( i_constant );
		return TRUE;
	}

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgRegSubst ( QStirng_arg1, & QString_regSrc ) )
	{
		*pui_memCell = i_memReg | compileArgRegDst ( QString_regDst ) | compileArgRegSrc ( QString_regSrc );
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileArgMemRegVsConst ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memConst, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QStirng_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	QString QString_regDst;
	QString QString_regSrc;
	int i_constant;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	//********************************************************************************************************************
	//* Check for constant
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgNumberConst ( QStirng_arg1, & i_constant ) )
	{
		*pui_memCell = i_memConst | compileArgRegDst ( QString_regDst ) | compileArgConst ( i_constant );
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileArgMemRegVsRegPAddr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memPAddr, int i_memReg, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QStirng_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	QString QString_regDst;
	QString QString_regSrc;
	int i_pAddr;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	//********************************************************************************************************************
	//* Check for port address
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgNumberConst ( QStirng_arg1, & i_pAddr ) )
	{
		*pui_memCell = i_memPAddr | compileArgRegDst ( QString_regDst ) | compileArgPAddr ( i_pAddr );
		return TRUE;
	}

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgAddrByReg ( QStirng_arg1, & QString_regSrc ) )
	{
		*pui_memCell = i_memReg | compileArgRegDst ( QString_regDst ) | compileArgRegSrc ( QString_regSrc );
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileArgMemRegVsRegSAddr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memPAddr, int i_memReg, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QStirng_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	QString QString_regDst;
	QString QString_regSrc;
	int i_pAddr;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	//********************************************************************************************************************
	//* Check for port address
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgNumberConst ( QStirng_arg1, & i_pAddr ) )
	{
		*pui_memCell = i_memPAddr | compileArgRegDst ( QString_regDst ) | compileArgSAddr ( i_pAddr );
		return TRUE;
	}

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgAddrByReg ( QStirng_arg1, & QString_regSrc ) )
	{
		*pui_memCell = i_memReg | compileArgRegDst ( QString_regDst ) | compileArgRegSrc ( QString_regSrc );
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze6::compileArgMemReg ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_mem, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );

	QString QString_regDst;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	*pui_memCell = i_mem | compileArgRegDst ( QString_regDst );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze6::compileArgRegDst ( QString QString_regDst )
{
	return ( this->QMap_reg [ QString_regDst ] & 0xF ) << 8;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze6::compileArgRegSrc ( QString QString_regSrc )
{
	return ( this->QMap_reg [ QString_regSrc ] & 0xF ) << 4;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze6::compileArgConst ( int i_const )
{
	return i_const & 0xFF;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze6::compileArgMAddr ( int i_addr )
{
	return i_addr & 0xFFF;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze6::compileArgSAddr ( int i_addr )
{
	return i_addr & 0xFF;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze6::compileArgPAddr ( int i_addr )
{
	return i_addr & 0xFF;
}

/**
 *****************************************************************************************************************************
 */


