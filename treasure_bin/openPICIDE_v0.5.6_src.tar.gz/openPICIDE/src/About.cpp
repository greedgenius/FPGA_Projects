/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "About.h"

/**
 *****************************************************************************************************************************
 */

About::About ( SetApp * pSetApp, QWidget * pQWidgetParent ) : QDialog ( pQWidgetParent )
{
	QHBoxLayout * pQHBoxLayout_main = new QHBoxLayout;
	{
		QLabel * pQLabel_pic = new QLabel;
		{
			pQLabel_pic->setPixmap ( QPixmap ( ":/main/img/main/designedForGnuLinux.png" ) );
		}

		QVBoxLayout * pQVBoxLayout_main = new QVBoxLayout;
		{
			QLabel * pQLabel_pic = new QLabel;
			{
				pQLabel_pic->setPixmap ( QPixmap ( ":/main/img/designedForGnuLinux.png" ) );
			}

			QHBoxLayout * pQHBoxLayout_title = new QHBoxLayout;
			{
				QLabel * pQLabel_icon = new QLabel;
				{
					pQLabel_icon->setPixmap ( QPixmap ( ":/main/img/main/appIcon.png" ) );
				}

				pQHBoxLayout_title->addWidget ( pQLabel_icon );

				QLabel * pQLabel = new QLabel;
				{
					pQLabel->setFont ( QFont ( "Helvetica", 12, QFont::Bold ) );
					pQLabel->setText ( QString ( "openPICIDE " ) + pSetApp->sSup.QString_appVer );
				}

				pQHBoxLayout_title->addWidget ( pQLabel );
				pQHBoxLayout_title->addStretch ();
			}

			QTabWidget * pQTabWidget_editor = new QTabWidget;
			{
				pQTabWidget_editor->addTab ( this->tabPageAbout(),   QObject::tr ( "About" ) );
				pQTabWidget_editor->addTab ( this->tabPageAuthors(), QObject::tr ( "Authors" ) );
				pQTabWidget_editor->addTab ( this->tabPageThanks(),  QObject::tr ( "Thanks to" ) );
				pQTabWidget_editor->addTab ( this->tabPageLicense(), QObject::tr ( "License" ) );
			}

			QHBoxLayout * pQHBoxLayout_buttons = new QHBoxLayout;
			{
				QPushButton * pQPushButton = new QPushButton;
				{
					pQPushButton->setText ( QString ( tr ( "Close" ) ) );
					connect ( pQPushButton, SIGNAL ( clicked () ), this, SLOT ( close() ) );
				}

				pQHBoxLayout_buttons->addStretch ( );
				pQHBoxLayout_buttons->addWidget ( pQPushButton );
			}

			pQVBoxLayout_main->addLayout ( pQHBoxLayout_title );
			pQVBoxLayout_main->addWidget ( pQTabWidget_editor );
			pQVBoxLayout_main->addLayout ( pQHBoxLayout_buttons );
		}

		pQHBoxLayout_main->addWidget ( pQLabel_pic );
		pQHBoxLayout_main->addLayout ( pQVBoxLayout_main );
	}
	// Set dialog layout
	this->setLayout ( pQHBoxLayout_main );

	this->setWindowTitle ( QString ( tr ( "About" ) ) );
	this->resize ( 640, 300 );
}

/**
 *****************************************************************************************************************************
 */

QWidget * About::tabPageAbout ( void )
{
	QWidget * pQWidget_page = new QWidget;
	{
		QVBoxLayout * pQVBoxLayout = new QVBoxLayout;
		{
			QLabel * pQLabel = new QLabel;
			{
				QString QString_text;
				QString_text  = QString ( QObject::tr (
				                              "<p>The integrated development environment openPICIDE<br/>"
				                              "was been developed to combine the most stability and highly<br/>"
				                              "usability of a linux system with a powerful processor IDE.</p>"
				                              "<p>(c) 2008-2011 by <a href=\"mailto:christoph.fauck@fauck.com\">Christoph Fauck</a></p>"
				                              "<a href=\"http://www.openpicide.org\">www.openpicide.org</a>"
				                          ) );

				pQLabel->setText ( QString_text );
				pQLabel->setTextInteractionFlags ( Qt::LinksAccessibleByMouse | Qt::LinksAccessibleByKeyboard );


				connect ( pQLabel, SIGNAL ( linkActivated ( QString ) ), this, SLOT ( openUrl ( QString ) ) );
			}

			pQVBoxLayout->addWidget ( pQLabel );
			pQVBoxLayout->addStretch ( );
		}

		pQWidget_page->setLayout ( pQVBoxLayout );
	}

	return pQWidget_page;
}

/**
 *****************************************************************************************************************************
 */

QWidget * About::tabPageLicense ( void )
{
	QWidget * pQWidget_page = new QWidget;
	{
		QVBoxLayout * pQVBoxLayout = new QVBoxLayout;
		{
			QLabel * pQLabel = new QLabel;
			{
				QString QString_text;
				QString_text  = QString ( 
				                        "<p>openPICIDE is free software: you can redistribute it and/or "
							"modify it under the terms of the GNU General Public License as  "
							"published by the Free Software Foundation, either version 3 of  "
							"the License, or (at your option) any later version.</p>"
				                        "<p>openPICIDE is distributed in the hope that it will be useful,  "
							"but WITHOUT ANY WARRANTY; without even the implied warranty of  "
							"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the  "
							"<a href=\"http://www.gnu.org/licenses\">GNU General Public "
							"License</a> for more details.</p>"
				                         );

				pQLabel->setText ( QString_text );
				pQLabel->setTextInteractionFlags ( Qt::LinksAccessibleByMouse | Qt::LinksAccessibleByKeyboard );
				pQLabel->setWordWrap ( TRUE );

				connect ( pQLabel, SIGNAL ( linkActivated ( QString ) ), this, SLOT ( openUrl ( QString ) ) );
			}

			pQVBoxLayout->addWidget ( pQLabel );
			pQVBoxLayout->addStretch ( );
		}

		pQWidget_page->setLayout ( pQVBoxLayout );
	}

	return pQWidget_page;
}

/**
 *****************************************************************************************************************************
 */

QWidget * About::tabPageThanks ( void )
{
	QScrollArea * pQScrollArea = new QScrollArea;
	{
		QWidget * pQWidget_page = new QWidget;
		{
			QVBoxLayout * pQVBoxLayout = new QVBoxLayout;
			{
				pQVBoxLayout->addLayout ( this->addThanksEntry (
					QString ( "Xilinx Inc." ),
					QString ( "The PicoBlaze%1 processor is developed and provided by Xilinx." ).arg ( QChar ( 0x2122 ) ),
					QString ( "" ),
					QString ( "http://www.xilinx.com" )
				) );

				pQVBoxLayout->addLayout ( this->addThanksEntry (
					QString ( "Marcus Hasenstab from Harerod" ),
					QString ( "Marcus is an openPICIDE user and tester, who provides feedback and suggestions for improvement." ),
					QString ( "" ),
					QString ( "http://www.harerod.de" )
				) );

				pQVBoxLayout->addLayout ( this->addThanksEntry (
					QString ( "Mark Six" ),
					QString ( "Mark has developed a graphical IDE named kpicosim for Linux. The IDE is based on KDE 3.x and uses kwrite as plugin." ),
					QString ( "" ),
					QString ( "http://www.xs4all.nl/~marksix" )
				) );

				pQVBoxLayout->addLayout ( this->addThanksEntry (
					QString ( "Mediatronix" ),
					QString ( "Mediatronix has developed a graphical IDE named pBlazIDE for MS Windows." ),
					QString ( "" ),
					QString ( "http://www.mediatronix.com/pBlazeIDE.htm" )
				) );

				pQVBoxLayout->addLayout ( this->addThanksEntry (
					QString ( "KDevelop development team" ),
					QString ( "KDevelop is a C++ IDE for Linux, openPICIDE is written with kdevelop. Some icons are borrowed from the kdevelop project." ),
					QString ( "" ),
					QString ( "http://www.kdevelop.org" )
				) );

				pQVBoxLayout->addLayout ( this->addThanksEntry (
					QString ( "KDE development team" ),
					QString ( "KDE is a powerful GUI for Linux. OpenPICIDE is developed using KDE. Some icons are borrowed from the kdevelop project." ),
					QString ( "" ),
					QString ( "http://www.kde.org" )
				) );

				pQVBoxLayout->addStretch ( );
			}
			pQWidget_page->setLayout ( pQVBoxLayout );
		}
		pQScrollArea->setHorizontalScrollBarPolicy ( Qt::ScrollBarAlwaysOff );
		pQScrollArea->setVerticalScrollBarPolicy ( Qt::ScrollBarAlwaysOn );
		pQScrollArea->setContentsMargins ( 0, 0, 0, 0 );
		pQScrollArea->setWidgetResizable ( TRUE );
		pQScrollArea->setWidget ( pQWidget_page );
	}

	return pQScrollArea;
}

/**
 *****************************************************************************************************************************
 */

QVBoxLayout * About::addThanksEntry ( QString QString_name, QString QString_text, QString QString_email, QString QString_url )
{
	QVBoxLayout * pQVBoxLayout = new QVBoxLayout;
	{
		QLabel * pQLabel_name = new QLabel;
		{
			pQLabel_name->setText ( QString ( "<b>%1</b>" ).arg ( QString_name ) );
		}
		pQVBoxLayout->addWidget ( pQLabel_name );

		QLabel * pQLabel_text = new QLabel;
		{
			pQLabel_text->setText ( QString_text );
			pQLabel_text->setIndent ( 10);
			pQLabel_text->setWordWrap ( TRUE );
		}
		pQVBoxLayout->addWidget ( pQLabel_text );

		if ( ! QString_email.isEmpty () )
		{
			QLabel * pQLabel_email = new QLabel;
			{
				pQLabel_email->setText ( QString ( "<a href=\"mailto:%1\">%1</a>" ).arg ( QString_email ) );
				pQLabel_email->setTextInteractionFlags ( Qt::LinksAccessibleByMouse | Qt::LinksAccessibleByKeyboard );
				pQLabel_email->setIndent ( 10);
	
				connect ( pQLabel_email, SIGNAL ( linkActivated ( QString ) ), this, SLOT ( openUrl ( QString ) ) );
			}
			pQVBoxLayout->addWidget ( pQLabel_email );
		}

		if ( ! QString_url.isEmpty () )
		{
			QLabel * pQLabel_url = new QLabel;
			{
				pQLabel_url->setText ( QString ( "<a href=\"%1\">%1</a>" ).arg ( QString_url ) );
				pQLabel_url->setTextInteractionFlags ( Qt::LinksAccessibleByMouse | Qt::LinksAccessibleByKeyboard );
				pQLabel_url->setIndent ( 10);
	
				connect ( pQLabel_url, SIGNAL ( linkActivated ( QString ) ), this, SLOT ( openUrl ( QString ) ) );
			}
			pQVBoxLayout->addWidget ( pQLabel_url );
		}
	}
	return pQVBoxLayout;
}

/**
 *****************************************************************************************************************************
 */

QWidget * About::tabPageAuthors ( void )
{
	QWidget * pQWidget_page = new QWidget;
	{
		QVBoxLayout * pQVBoxLayout = new QVBoxLayout;
		{
			pQVBoxLayout->addLayout ( this->addAuthor ( QString ( "Christoph Fauck" ), QString ( "christoph.fauck@fauck.com" ), QString ( "Initiator and developer" ) ) );


			pQVBoxLayout->addStretch ( );
		}

		pQWidget_page->setLayout ( pQVBoxLayout );
	}

	return pQWidget_page;
}

/**
 *****************************************************************************************************************************
 */

QVBoxLayout * About::addAuthor ( QString QString_name, QString QString_email, QString QString_job )
{
	QVBoxLayout * pQVBoxLayout = new QVBoxLayout;
	{
		QLabel * pQLabel_name = new QLabel;
		{
			pQLabel_name->setText ( QString ( "<b>%1</b>" ).arg ( QString_name ) );
		}

		QLabel * pQLabel_email = new QLabel;
		{
			pQLabel_email->setText ( QString ( "<a href=\"mailto:%1\">%1</a>" ).arg ( QString_email ) );
			pQLabel_email->setTextInteractionFlags ( Qt::LinksAccessibleByMouse | Qt::LinksAccessibleByKeyboard );
			pQLabel_email->setIndent ( 10);

			connect ( pQLabel_email, SIGNAL ( linkActivated ( QString ) ), this, SLOT ( openUrl ( QString ) ) );
		}

		QLabel * pQLabel_job = new QLabel;
		{
			pQLabel_job->setText ( QString_job );
			pQLabel_job->setIndent ( 10);
			pQLabel_job->setWordWrap ( TRUE );
		}

		pQVBoxLayout->addWidget ( pQLabel_name );
		pQVBoxLayout->addWidget ( pQLabel_email );
		pQVBoxLayout->addWidget ( pQLabel_job );
	}
	return pQVBoxLayout;
}

/**
 *****************************************************************************************************************************
 */

void About::openUrl ( QString QString_link )
{
	QUrl QUrl_link ( QString_link );

	QDesktopServices::openUrl ( QUrl_link );
}

/**
 *****************************************************************************************************************************
 */



