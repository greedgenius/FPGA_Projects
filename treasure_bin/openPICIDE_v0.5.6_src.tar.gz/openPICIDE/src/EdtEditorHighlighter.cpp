/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "EdtEditorHighlighter.h"

/**
 *****************************************************************************************************************************
 */

EdtEditorHighlighter::EdtEditorHighlighter ( QTextDocument * pQTextDocument_parent ) : QSyntaxHighlighter ( pQTextDocument_parent )
{
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorHighlighter::setHighlightingParameter ( sHighlightingParameter_t sHighlightingParameter )
{
	QVectorOfHighlightingRule_rules.clear ();

	sHighlightingRule_t sHighlightingRule;

	QString QString_regExp;

	// Assembler keywords
	foreach ( QString QString_pattern, sHighlightingParameter.keyWords.QStringList_cmd )
	{
		QString_regExp = QString ( "\\b" ) + QString_pattern + QString ( "\\b" );

		sHighlightingRule.QRegExp_pattern	 = QRegExp ( QString_regExp, Qt::CaseInsensitive );
		sHighlightingRule.QTextCharFormat_format = sHighlightingParameter.formats.QTextCharFormat_cmd;

		QVectorOfHighlightingRule_rules.append ( sHighlightingRule );
	}

	// Compiler directives
	foreach ( QString QString_pattern, sHighlightingParameter.keyWords.QStringList_directive )
	{
		QString_regExp = QString ( "\\b" ) + QString_pattern + QString ( "\\b" );

		sHighlightingRule.QRegExp_pattern	 = QRegExp ( QString_regExp, Qt::CaseInsensitive );
		sHighlightingRule.QTextCharFormat_format = sHighlightingParameter.formats.QTextCharFormat_directive;

		QVectorOfHighlightingRule_rules.append ( sHighlightingRule );
	}

	// Hardware keywords
	foreach ( QString QString_pattern, sHighlightingParameter.keyWords.QStringList_hwComponent )
	{
		QString_regExp = QString ( "\\b" ) + QString_pattern + QString ( "\\b" );

		sHighlightingRule.QRegExp_pattern	 = QRegExp ( QString_regExp, Qt::CaseInsensitive );
		sHighlightingRule.QTextCharFormat_format = sHighlightingParameter.formats.QTextCharFormat_hw;

		QVectorOfHighlightingRule_rules.append ( sHighlightingRule );
	}

	// Numbers
	if ( sHighlightingParameter.keyWords.QMap_numberRegExp.contains ( "HEX" ) )
	{
		QStringList QStringList_regExp = sHighlightingParameter.keyWords.QMap_numberRegExp[ "HEX" ];

		for ( int i_iterator = 0; i_iterator < QStringList_regExp.size (); ++i_iterator )
		{
			sHighlightingRule.QTextCharFormat_format = sHighlightingParameter.formats.QTextCharFormat_hexNumber;
			sHighlightingRule.QRegExp_pattern        = QRegExp ( QStringList_regExp.at ( i_iterator ) );

			QVectorOfHighlightingRule_rules.append ( sHighlightingRule );
		}
	}

	if ( sHighlightingParameter.keyWords.QMap_numberRegExp.contains ( "DEC" ) )
	{
		QStringList QStringList_regExp = sHighlightingParameter.keyWords.QMap_numberRegExp[ "DEC" ];

		for ( int i_iterator = 0; i_iterator < QStringList_regExp.size (); ++i_iterator )
		{
			sHighlightingRule.QTextCharFormat_format = sHighlightingParameter.formats.QTextCharFormat_decNumber;
			sHighlightingRule.QRegExp_pattern        = QRegExp ( QStringList_regExp.at ( i_iterator ) );

			QVectorOfHighlightingRule_rules.append ( sHighlightingRule );
		}
	}

	if ( sHighlightingParameter.keyWords.QMap_numberRegExp.contains ( "OCT" ) )
	{
		QStringList QStringList_regExp = sHighlightingParameter.keyWords.QMap_numberRegExp[ "OCT" ];

		for ( int i_iterator = 0; i_iterator < QStringList_regExp.size (); ++i_iterator )
		{
			sHighlightingRule.QTextCharFormat_format = sHighlightingParameter.formats.QTextCharFormat_octNumber;
			sHighlightingRule.QRegExp_pattern        = QRegExp ( QStringList_regExp.at ( i_iterator ) );

			QVectorOfHighlightingRule_rules.append ( sHighlightingRule );
		}
	}

        // Function
        sHighlightingRule.QRegExp_pattern = QRegExp ( "^\\S+:" );
        sHighlightingRule.QTextCharFormat_format = sHighlightingParameter.formats.QTextCharFormat_fct;
        QVectorOfHighlightingRule_rules.append ( sHighlightingRule );

	// Comments
	sHighlightingRule.QRegExp_pattern = QRegExp ( ";[^\n]*" );
	sHighlightingRule.QTextCharFormat_format = sHighlightingParameter.formats.QTextCharFormat_comment;
	QVectorOfHighlightingRule_rules.append ( sHighlightingRule );

	// Header comments
	sHighlightingRule.QRegExp_pattern = QRegExp ( "^;\\*[^\n]*" );
	sHighlightingRule.QTextCharFormat_format = sHighlightingParameter.formats.QTextCharFormat_doc;
	QVectorOfHighlightingRule_rules.append ( sHighlightingRule );

	sHighlightingRule.QRegExp_pattern = QRegExp ( "^;\\s\\*[^\n]*" );
	sHighlightingRule.QTextCharFormat_format = sHighlightingParameter.formats.QTextCharFormat_doc;
	QVectorOfHighlightingRule_rules.append ( sHighlightingRule );

	
	// Line separators -> at leas two ##
//         sHighlightingRule.QRegExp_pattern = QRegExp ( "; #[^\n]*" );
        sHighlightingRule.QRegExp_pattern = QRegExp ( "; #[^\n]{1,}" );
        sHighlightingRule.QTextCharFormat_format = sHighlightingParameter.formats.QTextCharFormat_separator;
        QVectorOfHighlightingRule_rules.append ( sHighlightingRule );

	// Navi commands
	foreach ( QString QString_pattern, sHighlightingParameter.keyWords.QStringList_navi )
	{
// 		QString_regExp = QString ( "\\b" ) + QString_pattern + QString ( "\\b" );

		sHighlightingRule.QRegExp_pattern	 = QRegExp ( QString_pattern, Qt::CaseInsensitive );
		sHighlightingRule.QTextCharFormat_format = sHighlightingParameter.formats.QTextCharFormat_navi;

		QVectorOfHighlightingRule_rules.append ( sHighlightingRule );
	}


	QSyntaxHighlighter::rehighlight ();
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorHighlighter::highlightBlock ( const QString &QString_text )
{
	foreach ( sHighlightingRule_t sHighlightingRule, QVectorOfHighlightingRule_rules )
	{
		QRegExp QRegExp_Expression ( sHighlightingRule.QRegExp_pattern );

		int i_index = QString_text.indexOf ( QRegExp_Expression );

		while ( i_index >= 0 )
		{
			int i_Length = QRegExp_Expression.matchedLength();
			setFormat ( i_index, i_Length, sHighlightingRule.QTextCharFormat_format );
			i_index = QString_text.indexOf ( QRegExp_Expression, i_index + i_Length );
		}
	}

	QSyntaxHighlighter::setCurrentBlockState ( 0 );
}

/**
 *****************************************************************************************************************************
 */


