/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PicPblzeCmplrPblze_H
#define PicPblzeCmplrPblze_H

#include "PicPblzeCmplr.h"

/**
	@author Christoph Fauck <christoph.fauck@fauck-technologies.com>
*/
class PicPblzeCmplrPblze : public PicPblzeCmplr
{
		Q_OBJECT

	// Constructor
	public:

		/// Constructor.
		/// \param pQObject_parent		Pointer to parent widget
		PicPblzeCmplrPblze ( QObject * pQObject_parent = 0 );

		/// Destructor. Tidies up.
		~PicPblzeCmplrPblze();

	// Compile
	public:
		
		/// Compiles parsed code base
		bool compile ( void );

	// Compile commands
	private:

		/// Translates register from Mnemonic to integer
                QMap<QString, int>  QMap_reg;

		/// Compiles code
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		bool compileCmd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles ADD command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdAdd   ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles ADDCY command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdAddCy ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles AND command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdAnd   ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles CALL command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdCall  ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles interrupt disable command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdIntDis ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles interrupt enable command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdIntEn ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles INPUT command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdInput ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles JUMP command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdJump  ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles LOAD command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdLoad ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles OR command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdOr ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles OUTPUT command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdOutput ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles RETURN command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdReturn ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles RETURNI command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdReturnI ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles RL command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdRl  ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles RR command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdRr  ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SL0 command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSl0 ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SL1 command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSl1 ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SLA command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSla ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SLX command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSlx ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SR0 command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSr0 ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SR1 command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSr1 ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SRA command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSra ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SRX command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSrx ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SUB command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSub ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles SUBCY command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdSubCy ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

		/// Compiles XOR command
		/// \param psCodeLine	Code line element
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileCmdXor ( sCodeLine_t * psCodeLine, unsigned int * pui_memCell );

	// Helpers

		/// Get processor memory line  bits for register - register/constant
		/// \param psCodeLine	Code line element
		/// \param i_memConst		Constant command bits
		/// \param i_memReg		Register command bits
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileArgMemRegVsRegConst ( sCodeLine_t * psCodeLine, int i_memConst, int i_memReg, unsigned int * pui_memCell );

		/// Get processor memory line  bits for register - register/port address
		/// \param psCodeLine	Code line element
		/// \param i_memConst		Constant command bits
		/// \param i_memReg		Register command bits
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileArgMemRegVsRegPAddr ( sCodeLine_t * psCodeLine, int i_memAddr,  int i_memReg, unsigned int * pui_memCell );

		/// Get processor memory line  bits for register
		/// \param psCodeLine	Code line element
		/// \param i_mem		Command bits
		/// \param pi_memLine		Processor memory line
		/// \retval bool		True, if success, otherwise false
		bool compileArgMemReg ( sCodeLine_t * psCodeLine, int i_mem, unsigned int * pui_memCell );

		/// Get processor memory line bits for destination register
		/// \param QString_regDst	Destination register
		/// \retval int			Processor memory line bits
		int compileArgRegDst ( QString QString_regDst );

		/// Get processor memory line bits for source register
		/// \param QString_regDst	Source register
		/// \retval int			Processor memory line bits
		int compileArgRegSrc ( QString QString_regSrc );

		/// Get processor memory line bits for constant
		/// \param QString_regDst	Constant
		/// \retval int			Processor memory line bits
		int compileArgConst ( int i_const );

		/// Get processor memory line bits for memory address
		/// \param QString_regDst	Address
		/// \retval int			Processor memory line bits
		int compileArgMAddr ( int i_addr );

		/// Get processor memory line bits for port address address
		/// \param QString_regDst	Address
		/// \retval int			Processor memory line bits
		int compileArgPAddr ( int i_addr );
};

#endif
