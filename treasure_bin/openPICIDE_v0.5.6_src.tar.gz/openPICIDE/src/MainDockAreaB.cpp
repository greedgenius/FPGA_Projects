/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "MainDockAreaB.h"

/**
 *****************************************************************************************************************************
 */

MainDockAreaB::MainDockAreaB ( QString QString_title, QWidget * pQWidget_parent )  : QDockWidget ( QString_title, pQWidget_parent, Qt::SplashScreen )
{
	QWidget * pQWidget = new QWidget;
	{
		QVBoxLayout * pQVBoxLayout_main = new QVBoxLayout;
		{
			this->pQTabWidget = new QTabWidget;
			{
				QPushButton * pQPushButton_cornerWidget = new QPushButton;
				{
					pQPushButton_cornerWidget->setFlat ( TRUE );
					pQPushButton_cornerWidget->setIcon ( QIcon ( ":/main/img/main/closeWidget.png" ) );

					connect ( pQPushButton_cornerWidget, SIGNAL ( clicked ( ) ), this, SLOT ( hide ( ) ) );
				}

				this->pQTabWidget->setCornerWidget ( pQPushButton_cornerWidget, Qt::TopRightCorner );
			}

			pQVBoxLayout_main->addWidget ( this->pQTabWidget );
		}

		pQWidget->setLayout ( pQVBoxLayout_main );
	}

	QDockWidget::setFeatures ( QDockWidget::DockWidgetVerticalTitleBar );
	QDockWidget::setWidget ( pQWidget );
	QDockWidget::hide();
}

/**
 *****************************************************************************************************************************
 */

void MainDockAreaB::addWidget ( QString QString_name, QWidget * pQWidget )
{
	this->pQTabWidget->addTab ( pQWidget, QString_name );
	this->pQTabWidget->setCurrentWidget ( pQWidget );

// 	connect ( pQWidget, SIGNAL ( reqFocus ( QWidget * ) ), this, SLOT ( setCurrentWidget ( QWidget * ) ) );
	connect ( pQWidget, SIGNAL ( contentChanged (  QWidget * ) ), this, SLOT ( setCurrentWidget (  QWidget * ) ) );
}

/**
 *****************************************************************************************************************************
 */

void MainDockAreaB::removeWidget ( QWidget * pQWidget )
{
	disconnect ( pQWidget, SIGNAL ( contentChanged ( QWidget * ) ), this, SLOT ( setCurrentWidget ( QWidget * ) ) );

	this->pQTabWidget->removeTab ( this->pQTabWidget->indexOf ( pQWidget ) );

	if ( this->pQTabWidget->count() == 0 )
	{
		QDockWidget::hide();
	}
}

/**
 *****************************************************************************************************************************
 */

void MainDockAreaB::setCurrentWidget ( QWidget * pQWidget )
{
	this->pQTabWidget->setCurrentWidget ( pQWidget );
	QDockWidget::show();
}

/**
 *****************************************************************************************************************************
 */

bool MainDockAreaB::hasWidget ( QWidget * pQWidget )
{
	if ( this->pQTabWidget->indexOf ( pQWidget ) < 0 )
		return FALSE;
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */
