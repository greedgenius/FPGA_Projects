/*****************************************************************************************************************************
 *   Copyright (C) 2010 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "AppStyle.h"

/**
 *****************************************************************************************************************************
 */

AppStyle::AppStyle ( void )
{
	
}

/**
 *****************************************************************************************************************************
 */

QStringList AppStyle::getStyleList ( void )
{
	QStringList QStringList_styles;
	
	QStringList_styles << "Default";
	QStringList_styles << "CDE";
	QStringList_styles << "Cleanlooks";
	QStringList_styles << "GTK";
	QStringList_styles << "Macintosh";
	QStringList_styles << "Motif";
	QStringList_styles << "Plastique";
	QStringList_styles << "Windows";
	QStringList_styles << "Windows XP";
	QStringList_styles << "Windows Vista";
	
	return QStringList_styles;
}

/**
 *****************************************************************************************************************************
 */

QStringList AppStyle::setStyle ( QString QString_style )
{
	
}

/**
 *****************************************************************************************************************************
 */

QStringList AppStyle::setStyle ( int i_style )
{
	switch ( i_style )
	{
		case 0:
		case 1:		QApplication::setStyle ( new QWindowsStyle );
		case 2:		QApplication::setStyle ( new QWindowsStyle );
		case 3:		QApplication::setStyle ( new QWindowsStyle );
			
		
	}
}

/**
 *****************************************************************************************************************************
 */
