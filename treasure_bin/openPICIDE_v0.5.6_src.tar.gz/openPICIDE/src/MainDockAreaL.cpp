/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "MainDockAreaL.h"

/**
 *****************************************************************************************************************************
 */

MainDockAreaL::MainDockAreaL ( QString QString_title, QWidget * pQWidget_parent )  : QDockWidget ( QString_title, pQWidget_parent, Qt::SplashScreen )
{
	this->pQWidget_dockWidget = new QWidget;
	{
		QVBoxLayout * pQVBoxLayout_main = new QVBoxLayout;
		{
			this->pQTabWidget = new QTabWidget;
			{
				QPushButton * pQPushButton_cornerWidget = new QPushButton;
				{
					pQPushButton_cornerWidget->setFlat ( TRUE );
					pQPushButton_cornerWidget->setIcon ( QIcon ( ":main/img/main/closeWidget.png" ) );

					connect ( pQPushButton_cornerWidget, SIGNAL ( clicked ( ) ), this, SLOT ( hide ( ) ) );
				}

				this->pQTabWidget->setCornerWidget ( pQPushButton_cornerWidget, Qt::TopRightCorner );

				connect ( pQTabWidget, SIGNAL ( currentChanged ( int ) ), this, SLOT ( currentWidgetChanged ( int ) ) );
			}

			pQVBoxLayout_main->addWidget ( this->pQTabWidget );
		}

		this->pQWidget_dockWidget->setLayout ( pQVBoxLayout_main );
	}

	QDockWidget::setFeatures ( QDockWidget::DockWidgetVerticalTitleBar );
	QDockWidget::setWidget ( this->pQWidget_dockWidget );
	QDockWidget::hide();
}

/**
 *****************************************************************************************************************************
 */

void MainDockAreaL::addWidget ( QString QString_name, QWidget * pQWidget )
{
	this->pQTabWidget->addTab ( pQWidget, QString_name );
//         this->pQTabWidget->setCurrentWidget ( pQWidget );
	this->setCurrentWidget ( pQWidget );

	connect ( pQWidget, SIGNAL ( contentChanged (  QWidget * ) ), this, SLOT ( setCurrentWidget (  QWidget * ) ) );
}

/**
 *****************************************************************************************************************************
 */

void MainDockAreaL::removeWidget ( QWidget * pQWidget )
{
	disconnect ( pQWidget, SIGNAL ( contentChanged (  QWidget * ) ), this, SLOT ( setCurrentWidget (  QWidget * ) ) );

	this->pQTabWidget->removeTab ( this->pQTabWidget->indexOf ( pQWidget ) );

	if ( this->pQTabWidget->count() == 0 )
		QDockWidget::hide();
}

/**
 *****************************************************************************************************************************
 */

void MainDockAreaL::setCurrentWidget ( QWidget * pQWidget )
{
	this->pQTabWidget->setCurrentWidget ( pQWidget );
	QDockWidget::show();

	// Run event loop for repainting changed widgets
	QApplication::processEvents ( QEventLoop::ExcludeUserInputEvents | QEventLoop::ExcludeSocketNotifiers );

// 	this->pQWidget_dockWidget->setMaximumWidth ( this->pQTabWidget->currentWidget ()->sizeHint().width () + 20 );
}

/**
 *****************************************************************************************************************************
 */

void MainDockAreaL::currentWidgetChanged ( int i_index )
{
	if ( ! this->pQTabWidget->widget ( i_index ) )
		return;

	// Run event loop for repainting changed widgets
	QApplication::processEvents ( QEventLoop::ExcludeUserInputEvents | QEventLoop::ExcludeSocketNotifiers );

// 	this->pQWidget_dockWidget->setMaximumWidth ( this->pQTabWidget->currentWidget ()->sizeHint().width () + 20 );
}

/**
 *****************************************************************************************************************************
 */

bool MainDockAreaL::hasWidget ( QWidget * pQWidget )
{
	if ( this->pQTabWidget->indexOf ( pQWidget ) < 0 )
		return FALSE;
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */
