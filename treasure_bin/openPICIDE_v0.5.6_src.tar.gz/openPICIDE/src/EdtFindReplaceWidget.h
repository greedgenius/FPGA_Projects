/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef EdtReplaceWidget_H
#define EdtReplaceWidget_H

#include <QtGui>
#include <QtCore>


/**
 *****************************************************************************************************************************
 *
 *	\brief Editor module class
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *	Change log
 *		2009-08-30	Freeze for first release		Christoph Fauck <christoph.fauck@fauck.com>
 *		2009-09-13	Breakpoints added			Christoph Fauck <christoph.fauck@fauck.com>
 *****************************************************************************************************************************
 */

class EdtFindReplaceWidget : public QWidget
{
		Q_OBJECT

	public:

		/// Constructor. Sets up editor main widget. The widget contains a tab widget which manages the
		/// document editor widgets.
		/// \param pQWidget_parent		Pointer to the parent widget
		EdtFindReplaceWidget ( QWidget * pQWidget_parent = 0 );

		enum eMode_t
		{
			eModeFind,
			eModeReplace
		};

		void setMode ( eMode_t eMode );

		void setInitFocus ( QString QString_find );
		
		struct sFRParam_t
		{
			QString QString_find;
			QString QString_replace;
			
			bool b_fndCaseSensitive;
			bool b_fndWholeWords;
			bool b_findFromCursor;
		};
		
	signals:
		
		void findNext   ( EdtFindReplaceWidget::sFRParam_t * );
		void findPrev   ( EdtFindReplaceWidget::sFRParam_t * );
		void replace    ( EdtFindReplaceWidget::sFRParam_t * );
		void replaceAll ( EdtFindReplaceWidget::sFRParam_t * );
		
	private:
		
		QLabel * pQLabel_replace;
		
		QLineEdit * pQLineEdit_find;
		QLineEdit * pQLineEdit_replace;

		QPushButton * pQPushButton_close;
		QPushButton * pQPushButton_clearFind;
		QPushButton * pQPushButton_mode;
		QPushButton * pQPushButton_findNext;
		QPushButton * pQPushButton_findPrev;
		QPushButton * pQPushButton_replaceClr;
		QPushButton * pQPushButton_replace;
		QPushButton * pQPushButton_replaceAll;

		QCheckBox * pQCheckBox_caseSensitive;
		QCheckBox * pQCheckBox_wholeWords;
		QCheckBox * pQCheckBox_fromCursor;
		
		QStringList QStringList_findLst;
		QStringList QStringList_replaceLst;

		sFRParam_t sFRParam;
		
		eMode_t eMode;
		
		void fetchParameter ( void );
		
	public slots:
		
		void findNext ( void );
		void findPrev ( void );
		
	private slots:
		
		void replace ( void );
		void replaceAll ( void );
		void chkFindStringVld ( QString QString_gui );
		void chkReplaceStringVld ( QString QString_gui );
		void toggleMode ( void );


};

#endif
