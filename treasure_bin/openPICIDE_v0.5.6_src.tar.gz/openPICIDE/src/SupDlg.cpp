/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include <iostream>
#include "SupDlg.h"

/**
 *****************************************************************************************************************************
 */

SupDlg::SupDlg ( SetApp * pSetApp, QWidget * pQWidget_parent ) : QDialog ( pQWidget_parent )
{
	this->pSetApp = pSetApp;

	// Set navigator and content layout
	QVBoxLayout * pQVBoxLayout_content = new QVBoxLayout;
	{
		// Info text
		QLabel * pQLabel = new QLabel ( "<p>" + QObject::tr ( "openPICIDE automatically checks for new releases." ) + "</p>" );
		{
			pQVBoxLayout_content->addWidget ( pQLabel );
		}
		
		// Line
		QFrame * pQFrame = new QFrame;
		{
			pQFrame->setFrameStyle ( QFrame::Plain | QFrame::HLine );
			pQFrame->setLineWidth ( 1 );
			
			pQVBoxLayout_content->addWidget ( pQFrame );
		}

		// Check interval
		QHBoxLayout * pQHBoxLayout_chkIval = new QHBoxLayout;
		{
			QLabel * pQLabel_title = new QLabel;
			{
				pQLabel_title->setText ( QObject::tr ( "Check on startup:" ) );
			}
			
			this->pQComboBox_chkIval = new QComboBox ( this );
			{
				this->pQComboBox_chkIval->addItem ( QObject::tr ( "Never" ),               (int) SetApp::eChkIvalNever   );
				this->pQComboBox_chkIval->addItem ( QObject::tr ( "Daily (recommendet)" ), (int) SetApp::eChkIvalDaily   );
				this->pQComboBox_chkIval->addItem ( QObject::tr ( "Weekly" ),              (int) SetApp::eChkIvalWeekly  );
				this->pQComboBox_chkIval->addItem ( QObject::tr ( "Monthly" ),             (int) SetApp::eChkIvalMonthly );
				
				this->pQComboBox_chkIval->setCurrentIndex( (int) this->pSetApp->sSup.eChkIval );
			}

			pQHBoxLayout_chkIval->addWidget ( pQLabel_title );
			pQHBoxLayout_chkIval->addWidget ( this->pQComboBox_chkIval );

			pQVBoxLayout_content->addLayout ( pQHBoxLayout_chkIval );
		}
		
		// Release info
		this->pQTextBrowser_releaseInfo = new QTextBrowser;
		{
			this->pQTextBrowser_releaseInfo->setText ( "" );

			this->pQTextBrowser_releaseInfo->setTextInteractionFlags ( Qt::LinksAccessibleByMouse | Qt::LinksAccessibleByKeyboard );
			this->pQTextBrowser_releaseInfo->setOpenExternalLinks ( TRUE );
			connect ( pQTextBrowser_releaseInfo, SIGNAL ( anchorClicked ( QUrl ) ), this, SLOT ( openUrl ( QUrl ) ) );

			pQVBoxLayout_content->addWidget ( this->pQTextBrowser_releaseInfo );
		}
	}

	// Update class
	{
		this->pSupChkUpdate = new SupChkUpdate;

		connect ( pSupChkUpdate,
			SIGNAL ( updateInfo ( SupChkUpdate::sUpdateInfo_t * ) ),
			this,
			SLOT ( showUpdateInfo (SupChkUpdate::sUpdateInfo_t * ) )
		);
	}

	// Set Button Layout
	QHBoxLayout * pQHBoxLayout_buttons = new QHBoxLayout;
	{
		// Set Buttons
		QPushButton * pQPushButton_chkUpdate = new QPushButton ( QObject::tr ( "Check &again" ) );
		QPushButton * pQPushButton_close     = new QPushButton ( QObject::tr ( "&Close" ) );

		connect ( pQPushButton_chkUpdate, SIGNAL ( clicked () ), this, SLOT ( chkUpdate () ) );
		connect ( pQPushButton_close,        SIGNAL ( clicked() ),  this, SLOT ( handleEventClose() ) );

		pQHBoxLayout_buttons->addStretch ( 1 );
		pQHBoxLayout_buttons->addWidget ( pQPushButton_chkUpdate );
		pQHBoxLayout_buttons->addWidget ( pQPushButton_close );
	}

	// Set dialog layout
	QVBoxLayout * pQVBoxLayout_main = new QVBoxLayout;
	pQVBoxLayout_main->addLayout ( pQVBoxLayout_content );
	pQVBoxLayout_main->addSpacing ( 12 );
	pQVBoxLayout_main->addLayout ( pQHBoxLayout_buttons );

	QDialog::setLayout ( pQVBoxLayout_main );
	QDialog::setWindowTitle ( QObject::tr ( "Checking for updates" ) );
	QDialog::resize(550, 550);
	
	// Check for updates
	this->chkUpdate ();
}

/**
 *****************************************************************************************************************************
 */

void SupDlg::handleEventClose ( void )
{
	int i_currentIndex = this->pQComboBox_chkIval->currentIndex();
	
	// Fetch data from gui
	this->pSetApp->sSup.eChkIval = (SetApp::eChkIval_t) i_currentIndex;
	this->pSetApp->setDirty();

	QDialog::close();
}

/**
 *****************************************************************************************************************************
 */

void SupDlg::chkUpdate ( void )
{
	this->pQTextBrowser_releaseInfo->setText ( QObject::tr( "Download update information..." ) );

	this->pSupChkUpdate->chkUpdate ( this->pSetApp->sSup.QString_appVer, this->pSetApp->sSup.QString_serNo, this->pSetApp->sSup.QString_platform, FALSE );
}

/**
 *****************************************************************************************************************************
 */

void SupDlg::showUpdateInfo ( SupChkUpdate::sUpdateInfo_t * sUpdateInfo )
{
	this->pQTextBrowser_releaseInfo->setText ( sUpdateInfo->QString_releaseInfo );
}

/**
 *****************************************************************************************************************************
 */

void SupDlg::openUrl ( QUrl QUrl_link )
{
	QDesktopServices::openUrl ( QUrl_link );
}

/**
 *****************************************************************************************************************************
 */



