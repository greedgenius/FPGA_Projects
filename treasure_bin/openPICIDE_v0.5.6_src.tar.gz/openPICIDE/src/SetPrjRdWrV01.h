/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef SetPrjRdWrV01_H
#define SetPrjRdWrV01_H

#include <QtCore>
#include <QtGui>

#include "SetPrj.h"

/**
 *****************************************************************************************************************************
 *
 *	\brief SetPrjRdWrV01 class
 *
 *      Reads and writes project settings
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2010-03-26
 *	\version	0.1.0
 *
 *	Change log
 *
 *	2010-03-26
 *		Initialized
 *
 *****************************************************************************************************************************
 */

class SetPrjRdWrV01
{

	public:

		SetPrjRdWrV01 ();

		/// Parses given xml document and stores extracted information to \c pPrjSet.
		/// \param pSetPrj		Reference to store project settings
		/// \param pQXmlStreamReader	XML stream reader instance
		void rdXml ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader );
		
	private:
		
		/// Parses versioning section 
		/// of given xml document and stores extracted information to \c pPrjSet.
		/// \param pPrjSet		Reference to store project settings
		/// \param pQXmlStreamReader	XML stream reader instance
		void rdXmlVersioning ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader );

		/// Parses processor section
		/// of given xml document and stores extracted information to \c pPrjSet.
		/// \param pPrjSet		Reference to store project settings
		/// \param pQXmlStreamReader	XML stream reader instance
		void rdXmlProcessor ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader );

		/// Parses Xilinx Picoblaze (tm) processor section 
		/// of given xml document and stores extracted information to \c pPrjSet.
		/// \param pPrjSet		Reference to store project settings
		/// \param pQXmlStreamReader	XML stream reader instance
		void rdXmlProcessorPBlze ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader );

		/// Parses sources section 
		/// of given xml document and stores extracted information to \c pPrjSet.
		/// \param pPrjSet		Reference to store project settings
		/// \param pQXmlStreamReader	XML stream reader instance
		void rdXmlSources ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader );

		/// Parses source files section 
		/// of given xml document and stores extracted information to \c pPrjSet.
		/// \param pPrjSet		Reference to store project settings
		/// \param pQXmlStreamReader	XML stream reader instance
		void rdXmlSourcesFiles ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader );

		/// Parses loaded files section 
		/// of given xml document and stores extracted information to \c pPrjSet.
		/// \param pPrjSet		Reference to store project settings
		/// \param pQXmlStreamReader	XML stream reader instance
		void rdXmlLoadedFiles ( SetPrj * pSetPrj, QXmlStreamReader * pQXmlStreamReader );


};

#endif
 
 
 
 
