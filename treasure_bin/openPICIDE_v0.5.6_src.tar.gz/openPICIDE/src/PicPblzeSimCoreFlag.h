/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PicPblzeSimCoreFlag_H
#define PicPblzeSimCoreFlag_H

#include <QtCore>
#include <QtGui>

#include "PicEdtBit.h"
#include "PicEdtInterrupt.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Xilinx PicoBlaze (tm) core flag widget.
 *
 *	
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class PicPblzeSimCoreFlag : public QWidget
{

		Q_OBJECT

	public:

		/// Constructor.
		/// \param pQWidget_parent	Pointer to parent widget
		PicPblzeSimCoreFlag ( QWidget * pQWidget_parent = 0 );

		/// Sets carry bit
		/// \param i_value	Carry bit
		void setCarry ( int i_value );

		/// Gets carry bit
		/// \retval bool	Carry bit
		bool getCarry ( void );

		/// Sets zero bit
		/// \param i_value	Zero bit
		void setZero ( int i_value );

		/// Gets zero bit
		/// \retval bool	Zero bit
		bool getZero ( void );

		/// Sets interrupt status
		/// \param eInt		Interrupt status
		void setInt ( PicEdtInterrupt::eInt_t eInt );

		/// Gets interrupt status
		/// \retval PicEdtInterrupt::eInt_t	Interrupt status
		PicEdtInterrupt::eInt_t getInt ( void );

		/// Clears highlighting
		void clearHighlighted ( void );

		/// Clears all
		void clear ( void );

	private:

		/// Widget containing carry flag
		PicEdtBit  * pPicEdtBit_carry;

		/// Widget containing zero flag
		PicEdtBit  * pPicEdtBit_zero;

		/// Widget containing interrupt sign
		PicEdtInterrupt * pPicEdtInterrupt;
};

#endif
