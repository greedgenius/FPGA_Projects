/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicIOFifo8Bit.h"

/**
 *****************************************************************************************************************************
 */

PicIOFifo8Bit::PicIOFifo8Bit ( QWidget * pQWidget_parent ) : QWidget ( pQWidget_parent )
{
	this->QColor_bgNormal      = Qt::black;
	this->QColor_bgHighlighted = Qt::red;

	QFont QFont_bold;
	QFont_bold.setBold ( TRUE );

	QVBoxLayout * pQVBoxLayout_main = new QVBoxLayout;
	{
		QFrame * pQFrame = new QFrame;
		{
			QHBoxLayout * pQHBoxLayout_frame = new QHBoxLayout;
			{
				QVBoxLayout * pQVBoxLayout_content = new QVBoxLayout;
				{
					this->pQWidget_addr = new QWidget;
					{
						QHBoxLayout * pQHBoxLayout_addr = new QHBoxLayout;
						{
							QLabel * pQLabel_addrTitle = new QLabel;
							{
								QPalette QPalette_actual = pQLabel_addrTitle->palette();
								QPalette_actual.setColor ( QPalette::Active, QPalette::Foreground, Qt::white );
								QPalette_actual.setColor ( QPalette::Inactive, QPalette::Foreground, Qt::white );
								pQLabel_addrTitle->setPalette ( QPalette_actual );

								pQLabel_addrTitle->setFont ( QFont_bold );
								pQLabel_addrTitle->setText ( "Addr:" );
							}

							this->pPicEdtInteger_addr = new PicEdtInteger;
							{
								this->pPicEdtInteger_addr->setToolTip ( QObject::tr ( "Address" ) );
							}

							this->pQLabel_addrSymbol = new QLabel;
							{
								QPalette QPalette_actual = pQLabel_addrSymbol->palette();
								QPalette_actual.setColor ( QPalette::Active, QPalette::Foreground, Qt::white );
								QPalette_actual.setColor ( QPalette::Inactive, QPalette::Foreground, Qt::white );
								this->pQLabel_addrSymbol->setPalette ( QPalette_actual );

								this->pQLabel_addrSymbol->setToolTip ( QObject::tr ( "Address substitute" ) );
							}

							pQHBoxLayout_addr->addWidget ( pQLabel_addrTitle );
							pQHBoxLayout_addr->addWidget ( this->pPicEdtInteger_addr );
							pQHBoxLayout_addr->addWidget ( pQLabel_addrSymbol );
							pQHBoxLayout_addr->addStretch ();
							pQHBoxLayout_addr->setContentsMargins ( 2, 2, 2, 2 );
						}

						this->pQWidget_addr->setLayout ( pQHBoxLayout_addr );

						// Set background color
						QPalette QPalette_actual = this->pQWidget_addr->palette();
						QPalette_actual.setColor ( QPalette::Active, QPalette::Window, QColor_bgNormal );
						QPalette_actual.setColor ( QPalette::Inactive, QPalette::Window, QColor_bgNormal );
						this->pQWidget_addr->setPalette ( QPalette_actual );
						this->pQWidget_addr->setAutoFillBackground ( TRUE );
						this->pQWidget_addr->setContentsMargins ( 0, 0, 0, 0 );
					}

					QHBoxLayout * pQHBoxLayout_data = new QHBoxLayout;
					{
						this->pQLabel_dirLeft = new QLabel;

						this->pPicEdtInteger_valueCur = new PicEdtInteger;
						{
							this->pPicEdtInteger_valueCur->setToolTip ( QObject::tr ( "Current value" ) );
							this->pPicEdtInteger_valueCur->setEnabled ( FALSE );
							this->pPicEdtInteger_valueCur->setText ( "" );
						}

						this->pQLabel_dirRight = new QLabel;

						this->pPicEdtInteger_valueLstNxt = new PicEdtInteger;
						{
							this->pPicEdtInteger_valueLstNxt->setEnabled ( FALSE );
							this->pPicEdtInteger_valueLstNxt->setText ( "" );
						}

						this->pQPushButton_list = new QPushButton;
						{
							this->pQPushButton_list->setToolTip ( QObject::tr ( "Expand list" ) );
							this->pQPushButton_list->setIcon ( QIcon ( ":/pic/img/pic/fifoExpand.png" ) );

							connect ( this->pQPushButton_list, SIGNAL ( clicked() ), this, SLOT ( setupEditor () ) );
						}

						this->pQComboBox_direction = new QComboBox;
						{
							this->pQComboBox_direction->setToolTip ( QObject::tr ( "Direction" ) );

							this->pQComboBox_direction->addItem ( QString ( "I" ) );
							this->pQComboBox_direction->addItem ( QString ( "O" ) );


							connect ( this->pQComboBox_direction, SIGNAL ( currentIndexChanged ( int ) ), this, SLOT ( changeDirection ( int ) ) );
						}

// 						QPushButton * pQPushButton_close = new QPushButton;
// 						{
// 							pQPushButton_close->setToolTip ( QObject::tr ( "Close device" ) );
// 							pQPushButton_close->setFlat ( TRUE );
// 							pQPushButton_close->setIcon ( QIcon ( ":/main/img/main/closeWidget.png" ) );
// 
// 							connect ( pQPushButton_close, SIGNAL ( clicked() ), this, SLOT ( closePort() ) );
// 						}

						pQHBoxLayout_data->addWidget ( this->pQLabel_dirLeft );
						pQHBoxLayout_data->addWidget ( this->pPicEdtInteger_valueCur );
						pQHBoxLayout_data->addWidget ( this->pQLabel_dirRight );
						pQHBoxLayout_data->addWidget ( this->pPicEdtInteger_valueLstNxt );
						pQHBoxLayout_data->addStretch ();
						pQHBoxLayout_data->addWidget ( this->pQPushButton_list );
						pQHBoxLayout_data->addWidget ( this->pQComboBox_direction );
// 						pQHBoxLayout_data->addWidget ( pQPushButton_close );

						pQHBoxLayout_data->setContentsMargins ( 0, 0, 2, 0 );
					}

					QVBoxLayout * pQVBoxLayout_editor = new QVBoxLayout;
					{
						this->pPicIOFifoEditor = new PicIOFifoEditor;
						{
							this->pPicIOFifoEditor->hide ();

							connect (
								this->pPicIOFifoEditor,
								SIGNAL ( textChanged() ),
								this,
								SLOT ( checkEditorLines () )
							);

							connect (
								this->pPicIOFifoEditor,
								SIGNAL ( valuesChanged () ),
								this,
								SLOT ( setValuesFromEditor () )
							);
						}
						pQVBoxLayout_editor->addWidget ( this->pPicIOFifoEditor );
					}
					pQVBoxLayout_content->addWidget ( this->pQWidget_addr );
					pQVBoxLayout_content->addLayout ( pQHBoxLayout_data );
					pQVBoxLayout_content->addLayout ( pQVBoxLayout_editor );

					pQVBoxLayout_content->setSpacing ( 2 );
					pQVBoxLayout_content->setContentsMargins ( 0, 0, 0, 2 );
				}
				
				QWidget * pQWidget_ioType = new QWidget;
				{
					QVBoxLayout * pQVBoxLayout_ioType = new QVBoxLayout;
					{
						QPushButton * pQPushButton_close = new QPushButton;
						{
							pQPushButton_close->setToolTip ( QObject::tr ( "Close device" ) );
							pQPushButton_close->setFlat ( TRUE );
							pQPushButton_close->setIcon ( QIcon ( ":/main/img/main/closeWidget.png" ) );

							connect ( pQPushButton_close, SIGNAL ( clicked() ), this, SLOT ( closePort() ) );
						}

	// 					pQVBoxLayout_ioType->addStretch ();
						pQVBoxLayout_ioType->addWidget ( pQPushButton_close );
						pQVBoxLayout_ioType->setAlignment ( Qt::AlignTop );
						
						pQVBoxLayout_ioType->setSpacing ( 0 );
						pQVBoxLayout_ioType->setContentsMargins ( 0, 0, 0, 0 );
					}
					pQWidget_ioType->setLayout ( pQVBoxLayout_ioType );
					
					QPalette QPalette_actual = pQWidget_ioType->palette();
					QPalette_actual.setColor ( QPalette::Window, Qt::darkYellow );
					pQWidget_ioType->setPalette ( QPalette_actual );
					pQWidget_ioType->setAutoFillBackground ( TRUE );
				}

				pQHBoxLayout_frame->addLayout ( pQVBoxLayout_content );
				pQHBoxLayout_frame->addWidget ( pQWidget_ioType );

				pQHBoxLayout_frame->setSpacing ( 0 );
				pQHBoxLayout_frame->setContentsMargins ( 0, 0, 0, 0 );
			}

			QPalette QPalette_actual = pQFrame->palette();
			QPalette_actual.setColor ( QPalette::Normal, QPalette::Foreground, Qt::black );
			pQFrame->setPalette ( QPalette_actual );

			pQFrame->setFrameShape ( QFrame::Box );
			pQFrame->setFrameShadow ( QFrame::Plain );

			pQFrame->setLayout ( pQHBoxLayout_frame );
		}
		pQVBoxLayout_main->addWidget ( pQFrame );
		pQVBoxLayout_main->setContentsMargins ( 0, 0, 0, 0 );
	}
	QWidget::setLayout ( pQVBoxLayout_main );

	this->setDirection ( eDirOut );
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifo8Bit::setValue ( int i_value )
{
	QString QString_valueCur = QString ( "%1" ).arg ( i_value, 2, this->i_Base, QChar ( '0' ) ).toUpper ();

	this->pPicEdtInteger_valueLstNxt->setText ( this->pPicEdtInteger_valueCur->text () );
	this->pPicEdtInteger_valueCur->setText ( QString_valueCur );

	this->pPicIOFifoEditor->setValue ( QString_valueCur );

	this->pPicEdtInteger_valueCur->setHighlighted ( TRUE );
	this->pPicEdtInteger_valueLstNxt->setHighlighted ( TRUE );

}

/**
 *****************************************************************************************************************************
 */

void PicIOFifo8Bit::setValuesFromEditor ( void )
{
	QString QString_valueCur;
	QString QString_valueLstNxt;

	if ( eDirIn == static_cast <PicIOCommon::eDirection_t> ( this->pQComboBox_direction->currentIndex() ) )
	{
		this->pPicIOFifoEditor->getRdValue ( & QString_valueCur, & QString_valueLstNxt );
	}
	else
	{
		this->pPicIOFifoEditor->getWrValue ( & QString_valueCur, & QString_valueLstNxt );
	}

	this->pPicEdtInteger_valueCur->setText    ( QString_valueCur );
	this->pPicEdtInteger_valueLstNxt->setText ( QString_valueLstNxt );
}

/**
 *****************************************************************************************************************************
 */

bool PicIOFifo8Bit::getValue ( int * pi_value )
{
	QString QString_valueCur;
	QString QString_valueNxt;

	if ( ! this->pPicIOFifoEditor->getRdValue ( & QString_valueCur, & QString_valueNxt ) )
		return FALSE;

	bool b_success;

	*pi_value = QString_valueCur.toInt ( & b_success, this->i_Base );

	if ( ( ! b_success ) || ( *pi_value > 255 ) )
		return FALSE;

	this->pPicIOFifoEditor->getRdValue ( & QString_valueCur, & QString_valueNxt, TRUE );

	this->pPicEdtInteger_valueCur->setText    ( QString_valueCur );
	this->pPicEdtInteger_valueLstNxt->setText ( QString_valueNxt );

	this->pPicEdtInteger_valueCur->setHighlighted ( TRUE );
	this->pPicEdtInteger_valueLstNxt->setHighlighted ( TRUE );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifo8Bit::setBase ( int i_base )
{
	this->i_Base = i_base;

	this->pPicEdtInteger_addr->setBase ( i_base );
	
	this->pPicEdtInteger_valueCur->setBase ( i_base );
	this->pPicEdtInteger_valueLstNxt->setBase ( i_base );
	this->pPicIOFifoEditor->setBase ( i_Base );
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifo8Bit::closePort ( void )
{
	emit closeRequest ( this );
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifo8Bit::setAddr ( int i_addr )
{
	this->pPicEdtInteger_addr->setValue ( i_addr );
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifo8Bit::setAddrSymbol ( QString QString_addrSymbol )
{
	this->pQLabel_addrSymbol->setText ( QString_addrSymbol );
}

/**
 *****************************************************************************************************************************
 */

bool PicIOFifo8Bit::chkAddr ( int i_value )
{
	int i_addr;

	if ( ! this->pPicEdtInteger_addr->getValue ( & i_addr ) )
		return FALSE;

	if ( i_value != i_addr )
		return FALSE;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicIOFifo8Bit::setDirection ( PicIOCommon::eDirection_t eDirection )
{
	// changeDirection will be called indirectly

	if ( ( eDirection != eDirIn ) and ( eDirection != eDirOut ) )
		return FALSE;

	this->pQComboBox_direction->setCurrentIndex ( static_cast < int > ( eDirection ) );
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicIOFifo8Bit::chkDirection ( PicIOCommon::eDirection_t eDirection )
{
	if ( eDirection == static_cast < PicIOCommon::eDirection_t > ( this->pQComboBox_direction->currentIndex() ) )
		return TRUE;

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifo8Bit::changeDirection ( int i_index )
{
	PicIOCommon::eDirection_t eDirection = static_cast < PicIOCommon::eDirection_t > ( i_index );

	if ( eDirection == eDirIn )
	{
		this->checkEditorLines ();

		this->pPicEdtInteger_valueLstNxt->setToolTip ( QObject::tr ( "Next value" ) );

		this->pQLabel_dirLeft->setPixmap  ( QPixmap ( ":/pic/img/pic/fifoDirIn.png" ) );
		this->pQLabel_dirRight->setPixmap ( QPixmap ( ":/pic/img/pic/fifoDirIn.png" ) );

		connect ( this->pPicIOFifoEditor, SIGNAL ( textChanged() ), this, SLOT ( checkEditorLines () ) );
	}
	else
	{
		this->pPicEdtInteger_valueLstNxt->setToolTip ( QObject::tr ( "Last value" ) );

		this->pQLabel_dirLeft->setPixmap  ( QPixmap ( ":/pic/img/pic/fifoDirOut.png" ) );
		this->pQLabel_dirRight->setPixmap ( QPixmap ( ":/pic/img/pic/fifoDirOut.png" ) );

		disconnect ( this->pPicIOFifoEditor, SIGNAL ( textChanged() ), this, SLOT ( checkEditorLines () ) );
	}

	this->setValuesFromEditor ();
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifo8Bit::setHighlighted ( bool b_highlighted )
{
	QPalette QPalette_actual = this->pQWidget_addr->palette();

	if ( b_highlighted )
	{
		QPalette_actual.setColor ( QPalette::Active,   QPalette::Window, this->QColor_bgHighlighted );
		QPalette_actual.setColor ( QPalette::Inactive, QPalette::Window, this->QColor_bgHighlighted );
	}
	else
	{
		QPalette_actual.setColor ( QPalette::Active,   QPalette::Window, this->QColor_bgNormal );
		QPalette_actual.setColor ( QPalette::Inactive, QPalette::Window, this->QColor_bgNormal );
	}

	this->pQWidget_addr->setPalette ( QPalette_actual );
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifo8Bit::clearHighlighted ( void )
{
	this->setHighlighted ( FALSE );
	this->pPicEdtInteger_valueCur->setHighlighted ( FALSE );
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifo8Bit::setupEditor ( void )
{
	if ( this->pPicIOFifoEditor->isVisible () )
	{
		this->pQPushButton_list->setToolTip ( QObject::tr ( "Expand list" ) );
		this->pQPushButton_list->setIcon ( QIcon ( ":/pic/img/pic/fifoExpand.png" ) );

		this->pPicIOFifoEditor->hide ();
	}
	else
	{
		this->pQPushButton_list->setToolTip ( QObject::tr ( "Collapse list" ) );
		this->pQPushButton_list->setIcon ( QIcon ( ":/pic/img/pic/fifoCollapse.png" ) );

		this->pPicIOFifoEditor->show ();
	}
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifo8Bit::checkEditorLines ( void )
{
	this->pPicIOFifoEditor->clearLineHighlight ();

	QTextBlock QTextBlock_run = this->pPicIOFifoEditor->document ()->begin ();

	while ( QTextBlock_run.isValid () )
	{
		bool b_success;
		int i_value;

		i_value = QTextBlock_run.text ().toInt ( & b_success, this->i_Base );

		if ( ( ! b_success ) || ( i_value > 255 ) )
			this->pPicIOFifoEditor->setLineHighlight ( QTextCursor ( QTextBlock_run ) );

		QTextBlock_run = QTextBlock_run.next();
	}

	this->setValuesFromEditor ();
}

/**
 *****************************************************************************************************************************
 */

void PicIOFifo8Bit::clear ( void )
{
// 	this->pPicIOFifoEditor->setValuePointer ( 0 );

	this->setValuesFromEditor ();

	if ( this->chkDirection ( eDirOut ) )
	{
		this->pPicIOFifoEditor->clear ();
		this->pPicEdtInteger_valueLstNxt->setText ( "" );
		this->pPicEdtInteger_valueCur->setText ( "" );
	}
}

/**
 *****************************************************************************************************************************
 */
















