/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PROJECTDIALOG_H
#define PROJECTDIALOG_H

#include <QtGui>
#include <QtCore>

#include "SetApp.h"
#include "SupChkUpdate.h"


/**
 *****************************************************************************************************************************
 *
 *      \brief Project dialog class for editing project settings.
 *
 *	The class provides a dialog for editing the project settings.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class SupDlg : public QDialog
{
		Q_OBJECT

	public:

		/// Constructor. Generates the dialog layout.
		/// \param Set_dlg			Copy of settings changeable by dialog
		/// \param pQWidget_parent		Reference to the Parent widget.
		SupDlg ( SetApp * pSetApp, QWidget * pQWidget_parent = 0 );

	private slots:

		/// Handles clicks to the close button.
		void handleEventClose ( void );
		
		/// Check for updates
		void chkUpdate ( void );

		/// Opens the given url. The slot method has is connected to text widgets containing clickable urls.
		/// \param	QUrl_link	Url to open
		void openUrl ( QUrl QUrl_link );

	public slots:
		
		/// Shows update info
		void showUpdateInfo ( SupChkUpdate::sUpdateInfo_t * sUpdateInfo );

	private:

		/// Dialog settings
		SetApp * pSetApp;

		/// Check interval
		QComboBox * pQComboBox_chkIval;
		
		/// Checking for updates
		SupChkUpdate * pSupChkUpdate;
		
		/// Serial number
		QTextBrowser * pQTextBrowser_releaseInfo;
		
		
		
		
};

#endif
