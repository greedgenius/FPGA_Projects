/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicEdtInterrupt.h"

/**
 *****************************************************************************************************************************
 */

PicEdtInterrupt::PicEdtInterrupt ( QWidget * pQWidget_parent ) : QWidget ( pQWidget_parent )
{
	QVBoxLayout * pQVBoxLayout_main = new QVBoxLayout;
	{
		this->pQLabel_int = new QLabel;
		{
			this->setValue ( eIntDisabled );
		}

		pQVBoxLayout_main->addWidget ( this->pQLabel_int );
	}

	QWidget::setLayout ( pQVBoxLayout_main );
}

/**
 *****************************************************************************************************************************
 */

void PicEdtInterrupt::setValue ( eInt_t eInt )
{
	switch ( eInt )
	{
		case eIntDisabled:
			this->pQLabel_int->setPixmap ( QPixmap ( ":/pic/img/pic/intDisabled.png" ) );
			this->eInt = eInt;
			break;

		case eIntEnabled:
			this->pQLabel_int->setPixmap ( QPixmap ( ":/pic/img/pic/intEnabled.png" ) );
			this->eInt = eInt;
			break;

		case eIntRequested:
		case eIntActive:
			this->pQLabel_int->setPixmap ( QPixmap ( ":/pic/img/pic/intActive.png" ) );
			this->eInt = eInt;
			break;
	}
}

/**
 *****************************************************************************************************************************
 */

PicEdtInterrupt::eInt_t PicEdtInterrupt::getValue ( void )
{
	return this->eInt;
}

/**
 *****************************************************************************************************************************
 */

bool PicEdtInterrupt::event ( QEvent * pQEvent )
{
	if ( pQEvent->type() == QEvent::MouseButtonPress )
	{
		QMouseEvent * pQMouseEvent = static_cast <QMouseEvent *> ( pQEvent );

		if ( pQMouseEvent->button() == Qt::LeftButton )
		{
			this->toggleValue();
			return TRUE;
		}
		else if ( pQMouseEvent->button() == Qt::RightButton )
		{
			this->toggleValue();
			return TRUE;
		}
	}

	return QWidget::event ( pQEvent );
}

/**
 *****************************************************************************************************************************
 */

void PicEdtInterrupt::toggleValue ( void )
{
	switch ( this->eInt )
	{
		case eIntEnabled:
			this->setValue ( eIntRequested );
			break;

		case eIntRequested:
			this->setValue ( eIntEnabled );
			break;
	}
}

/**
 *****************************************************************************************************************************
 */




