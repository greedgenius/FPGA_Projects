/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PicPblze_H
#define PicPblze_H

#include <QtCore>
#include <QtGui>

#include "PicPblzeSet.h"
#include "Mod.h"

#include "Edt.h"
#include "PicNone.h"
#include "Msg.h"

#include "PicMsgBrowser.h"

#include "PicPblzeSim.h"
#include "PicPblzeCmplr.h"
#include "PicPblzeCmplrPblze.h"
#include "PicPblzeCmplrPblzeII.h"
#include "PicPblzeCmplrPblze3.h"
#include "PicPblzeCmplrPblze6.h"
#include "PicPblzeCmplrPblzeCpld.h"
#include "PicPblzeAsmParser.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Xilinx PicoBlaze (tm) processor instance.
 *
 *
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class PicPblze : public PicNone
{

		Q_OBJECT

	public:

		/// Returns name of processor
		/// \retval QString		Processor name
		static QString getName ( void );

		/// Constructor.
		/// \param pMod				Pointer collection to root elements
		/// \param pQObject_parent		Pointer to parent widget
		PicPblze ( Mod * pMod, QObject * pQObject_parent = 0 );

		/// Destructor. Tidies up.
		~PicPblze();

		/// Sets the project settings to the pic. The method will be called if the project settings changed.
		void changeSettings ( void );

		/// Adds menu entries to the given menubar.
		/// \param	pQMenuBar		Pointer to the menubar
		void setupMenuBar ( QMenuBar * pQMenuBar );

	public slots:

		/// Sets breakpoints to simulator
		void setbreakpoints ( void );

	private slots:

		/// Initializes code syntax checking
		void chkSyntax ( void );

		/// Initializes compilation and vhdl file generation. Calls \c compile().
		void compileToVhdl ( void );

		/// Initializes compilation and verilog file generation. Calls \c compile().
		void compileToVerilog ( void );

		/// Initializes compilation and mem file generation. Calls \c compile().
		void compileToMem ( void );

		/// Initializes compilation and hex file generation. Calls \c compile().
		void compileToHex ( void );
		
		/// Generate memory mapping file;
		void generateMMFile ( void );

		/// Enables/disables and initializes simulator
		void simEn ( void );

		/// Sets integer formats to decimal
		void setBaseDec ( void );

		/// Sets integer formats to hexadecimal
		void setBaseHex ( void );

		/// Sets integer formats to octal
		void setBaseOct ( void );

		/// Initialize reload of code within simulator
		void simReload ( void );

		/// Set simulator to run mode
		void simRun ( void );

		/// Sets simulator to reset mode
		void simRst ( void );

		/// Sets simulator to next instruction mode
		void simNextInstruction ( void );

		/// Sets simulator to next line mode
		void simNextLine ( void );

		/// Sets simulator to interrupt mode
		void simInt ( void );

		/// Sets simulator to end of call mode
		void simToEndOfCall ( void );

		/// Sets simulator program counter from cursor
		void setPcFromCursor ( void );

	private:

		/// Simulator status
		enum eSimStatus_t {
			eDisabled,
			eBlocked,
			eIdle,
			eRun,
			eRunNextInstruction,
			eRunNextLine,
			eRunToEndOfCall
		};

		/// Pointer collection to root elements
		Mod * pMod;

		/// Processor specific settings
		PicPblzeSet * pPicPblzeSet;

		/// Message browser widget placed in bottom dock widget
		PicMsgBrowser * pPicMsgBrowser;

		/// Simulator
		PicPblzeSim * pPicPblzeSim;

		/// Status bar widget
		QWidget * pQWidget_statusBar;

		/// Instruction count for bank 0 placed in status bar
		QLabel * pQLabel_picDerivate;
		
		/// Instruction count for bank 0 placed in status bar
		QLabel * pQLabel_instCountBank0;
		
		/// Instruction count for bank 1 placed in status bar
		QLabel * pQLabel_instCountBank1;
		
		/// Instruction count for bank 2 placed in status bar
		QLabel * pQLabel_instCountBank2;
		
		/// Instruction count for bank 3 placed in status bar
		QLabel * pQLabel_instCountBank3;
		
		/// Instruction count for shared memory space placed in status bar
		QLabel * pQLabel_instCountShared;
		
		/// Code length widget, placed in status bar
		QLabel * pQLabel_pcFromCursor;

		/// Simulator status widget, placed in status bar
		QLabel * pQLabel_simStatus;

		/// Base set by \c setBaseHex, \c setBaseDec or \c setBaseOct
// 		int i_base;

		/// Menu
		QMenu * pQMenu;

		/// Toolbar
		QToolBar * pQToolBar;

		/// Check syntax action
		QAction * pQAction_chkSyntax;

		/// Compile to vhdl action
		QAction * pQAction_compileToVhdl;

		/// Compile to vhdl action
		QAction * pQAction_compileToVerilog;

		/// Compile to mem action
		QAction * pQAction_compileToMem;

		/// Compile to hex action
		QAction * pQAction_compileToHex;
		
		/// Generate memory mapping file
		QAction * pQAction_generateMMFile;

		/// Simulator enable/disable action
		QAction * pQAction_simEn;

		/// Simulator reload action
		QAction  * pQAction_simReload;

		/// Simulator in run mode action
		QAction  * pQAction_simRun;

		/// Simulator in run instruction mode action
		QAction  * pQAction_simNextInstruction;

		/// Simulator in run line mode action
		QAction  * pQAction_simNextLine;

		/// Simulator set interrupt action
		QAction  * pQAction_simInt;

		/// Simulator set reset action
		QAction  * pQAction_simRst;

		/// Simulator set run to end of call mode action
		QAction  * pQAction_simToEndOfCall;

		/// Simulator set program counter from cursor
		QAction  * pQAction_setPcFromCursor;

		/// Set format to hexadecimal action
		QAction  * pQAction_setBaseHex;

		/// Set format to decimal action
		QAction  * pQAction_setBaseDec;

		/// Set format to octal action
		QAction  * pQAction_setBaseOct;
		
		/// Create action
		void createActions ( void );

		/// Create menus from actions
		void createMenus ( void );

		/// Remove menus
		void removeMenus ( void );

		/// Create tool bars from actions
		void createToolBars ( void );

		/// remove toolbars
		void removeToolBars ( void );

		/// Create dock widgets
		void createDockWidgets ( void );

		/// Compile code
		/// \param PicPblzeCmplr::eOutputType	Output type
		/// \param QString_outputFilePath	Output file path
		/// \param QString_templateFilePath	Template file path
		void compile ( PicPblzeCmplr::eOutputType_t eOutputType, 
			       QString QString_outputFilePath, 
			       QString QString_templateFilePath = QString() );

		/// Set instruction count to status bar
		/// \param i_instCnt			Memory usage
		void setGuiInstCount ( PicPblzeAsmParser::sInstCount_t * psInstCount = NULL );

		/// Set program counter from cursor to status bar
		/// \param i_memUsage			Memory usage
		void setGuiPcFromCursor ( int i_pc );

		/// Set memory usage to status bar
		/// \param eSimStatus			Simulator status
		void setSimStatus ( eSimStatus_t eSimStatus );

		QString getPathViaDialog ( QString QString_title, QString QString_nameFilter, QString QString_defaultSuffix, QString QString_defaultPath );

	// Message handling
	public slots:
		
		void msgSet ( Msg * pMsg );
		
		void msgHndlClick ( QUrl QUrl_doc );
};

#endif
