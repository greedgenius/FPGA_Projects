/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeSimCoreScrpd.h"

/**
 *****************************************************************************************************************************
 */

PicPblzeSimCoreScrpd::PicPblzeSimCoreScrpd ( int i_scrpdSize, QWidget * pQWidget_parent ) : QScrollArea ( pQWidget_parent )
{
	this->sScrpd.i_size = i_scrpdSize;
	
	QWidget * pQWidget = new QWidget;
	{
		QVBoxLayout * pQVBoxLayout_main = new QVBoxLayout;
		{
			this->sScrpd.asScrpdValue = new sScrpdValue_t [ this->sScrpd.i_size ];

			QHBoxLayout * pQHBoxLayout = NULL;
			
			for ( int i_addr = 0; i_addr < this->sScrpd.i_size; ++i_addr )
			{
				sScrpdValue_t * psScrpdValue = & this->sScrpd.asScrpdValue [ i_addr ];
				
				if ( ! ( i_addr % 8 ) )
				{
					if ( pQHBoxLayout )
					{
						pQHBoxLayout->addStretch ();
						
						pQHBoxLayout->setSpacing ( 0 );
						pQHBoxLayout->setContentsMargins ( 0, 0, 0, 0 );
						
						pQVBoxLayout_main->addLayout ( pQHBoxLayout );
					}
					
					pQHBoxLayout = new QHBoxLayout;
				
					QLabel * pQLabel_addr = new QLabel;
					{
						QFont QFont_addr;
						QFont_addr.setBold ( TRUE );
		
						pQLabel_addr->setFont ( QFont_addr );
						pQLabel_addr->setText ( QString ( "0x" ) + QString ( "%1" ).arg ( i_addr, 2, 16, QChar ( '0' ) ) );
						pQLabel_addr->setMinimumWidth ( QFontMetrics ( pQLabel_addr->font() ).width ( QChar ( '0' ) ) * 5 );
						
						pQHBoxLayout->addWidget ( pQLabel_addr );
					}
					
				}
				
				QString QString_toolTip;
				{
					QString_toolTip  = QString ( QObject::tr ( "Address" ) );
					QString_toolTip += QString ( ": %1" ).arg ( i_addr, 2, 10, QChar ( '0' ).toUpper() );

					psScrpdValue->PicEdtInteger_value.setToolTip ( QString_toolTip );
				}
				
				psScrpdValue->PicEdtInteger_value.setBase ( 16 );
				
				pQHBoxLayout->addWidget ( & psScrpdValue->PicEdtInteger_value );
			}
			
			if ( pQHBoxLayout )
			{
				pQHBoxLayout->addStretch ();
				
				pQHBoxLayout->setSpacing ( 0 );
				pQHBoxLayout->setContentsMargins ( 0, 0, 0, 0 );
				
				pQVBoxLayout_main->addLayout ( pQHBoxLayout );
			}
			pQVBoxLayout_main->setSpacing ( 0 );
			pQVBoxLayout_main->setContentsMargins ( 0, 0, 0, 0 );
		}
		pQWidget->setLayout ( pQVBoxLayout_main );
	}
	
	
	QScrollArea::setFrameShadow ( QFrame::Plain );
	QScrollArea::setFrameShape ( QFrame::NoFrame );
	
	QScrollArea::setHorizontalScrollBarPolicy ( Qt::ScrollBarAlwaysOff );
	QScrollArea::setVerticalScrollBarPolicy ( Qt::ScrollBarAsNeeded );
	
	QScrollArea::setWidget ( pQWidget );
	QScrollArea::setContentsMargins ( 0, 0, 0, 0 );
	QScrollArea::setMinimumWidth ( pQWidget->width() + QScrollArea::verticalScrollBar()->sizeHint().width() );
}

/**
 *****************************************************************************************************************************
 */

PicPblzeSimCoreScrpd::~PicPblzeSimCoreScrpd ()
{
	if ( this->sScrpd.asScrpdValue )
		delete[] this->sScrpd.asScrpdValue;
	
	this->sScrpd.asScrpdValue = NULL;
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCoreScrpd::setBase ( int i_base )
{
	QString QString_prefix;
	QString QString_toolTip;

	switch ( i_base )
	{
		case  8:	QString_prefix = QObject::tr ( "Address" ) + QString ( ": \\" ); break;
		case 10:	QString_prefix = QObject::tr ( "Address" ) + QString ( ": "   ); break;
		case 16:	QString_prefix = QObject::tr ( "Address" ) + QString ( ": 0x" ); break;
		default:	return;
	}
	
	// Set base
	for ( int i_addr = 0; i_addr < this->sScrpd.i_size; ++i_addr )
	{
		QString_toolTip = QString_prefix + QString ( "%1" ).arg ( i_addr, 2, i_base, QChar ( '0' ) ).toUpper ();

		this->sScrpd.asScrpdValue [ i_addr ].PicEdtInteger_value.setToolTip ( QString_toolTip );
		this->sScrpd.asScrpdValue [ i_addr ].PicEdtInteger_value.setBase ( i_base );
	}
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCoreScrpd::setValue ( int i_addr, int i_value )
{
	if ( i_addr >= this->sScrpd.i_size )
		return FALSE;
	
	this->clearHighlighted ();
	
	this->sScrpd.asScrpdValue [ i_addr ].PicEdtInteger_value.setHighlighted ( TRUE );
	
	
	QScrollArea::ensureWidgetVisible ( & this->sScrpd.asScrpdValue [ i_addr ].PicEdtInteger_value );
	
	return this->sScrpd.asScrpdValue [ i_addr ].PicEdtInteger_value.setValue ( i_value );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCoreScrpd::getValue ( int i_addr, int * pi_value )
{
	if ( i_addr >= this->sScrpd.i_size )
		return FALSE;
	
	return this->sScrpd.asScrpdValue [ i_addr ].PicEdtInteger_value.getValue ( pi_value );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCoreScrpd::clearHighlighted ( void )
{
	for ( int i_addr = 0; i_addr < this->sScrpd.i_size; ++i_addr )
	{
		this->sScrpd.asScrpdValue [ i_addr ].PicEdtInteger_value.setHighlighted ( FALSE );
	}
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCoreScrpd::clear ( void )
{
	for ( int i_addr = 0; i_addr < this->sScrpd.i_size; ++i_addr )
	{
		this->sScrpd.asScrpdValue [ i_addr ].PicEdtInteger_value.setHighlighted ( FALSE );
		this->sScrpd.asScrpdValue [ i_addr ].PicEdtInteger_value.setValue ( 0 );
	}
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCoreScrpd::setContentsMargins ( int i_left, int i_top, int i_right, int i_bottom )
{
	QWidget::setContentsMargins ( 0, 0, 0, 0 );
}
		
/**
 *****************************************************************************************************************************
 */

// void PicPblzeSimCoreScrpd::setContentsMargins ( const QMargins & QMargins_margins )
// {
// 	QWidget::setContentsMargins ( 0, 0, 0, 0 );
// }

/**
 *****************************************************************************************************************************
 */

