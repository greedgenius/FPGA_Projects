/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   The original code of this file was copied from nokia qt 4.6.0 examples and then modified for openPICIDE.                *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PICIOMEMEDITOR_H
#define PICIOMEMEDITOR_H

#include <QtCore>
#include <QtGui>

/**
	@author Christoph Fauck <christoph.fauck@fauck-technologies.com>
*/

class PicIOMemEditor : public QPlainTextEdit
{
		Q_OBJECT

	public:


		/// Constructor. This class is the left margin of the PicIOFifoEditor widget.
		/// \param pQWidget_parent	Reference to parent widget
		PicIOMemEditor ( QWidget * pQWidget_parent = 0 );

		/// Gets value from port
		/// \param i_addr		Memory address
		/// \param pQString_value	Returned value
		/// \return bool		True, if value is valid, otherwise false
		bool getValue ( int i_addr, QString * pQString_value );

		/// Sets given value to port
		/// \param i_addr		Memory address
		/// \param QString_value	Value to set
		void setValue ( int i_addr, QString QString_value );

		/// Paint method for painting the left margin.
		/// Will be called by \c PicIOFifoEditorLeftMargin class.
		/// \param pQPaintEvent		Paint event
		void leftMarginPaintEvent ( QPaintEvent * pQPaintEvent );

		/// Calculates the with of the left margin from line number digits.
		/// \retval int			Line margin width
		int  leftMarginWidth ( void );

		/// Gets the line number from y coordinate.
		/// \param i_posY		Y coordinate
		void  leftMarginLineFromPos ( int i_posY );

		/// Highlights line
		/// \param QTextCursor_highlight	Text cursor to highlight
		void setLineHighlight ( QTextCursor QTextCursor_highlight );

		/// Clears line highlighting
		void clearLineHighlight ( void );

		/// Sets background color for cursor,
		/// \param QColor_bgCursor		Color
		void setBgColorCursor ( QColor QColor_bgCursor );

		/// Sets background color for cursor,
		/// \param QColor_bgCursor		Color
		void setBgColorHighlight ( QColor QColor_bgHighlight );

		/// Sets memory size
		void setSize ( int i_memSize );

		/// Clears editor
		void clear ( void );
		
		/// Change base
		/// \param i_base		Base
		void setBase ( int i_base );

	protected:

		/// Handles all resize events.
		/// \param pQResizeEvent_event	Resize event
		void resizeEvent ( QResizeEvent * pQResizeEvent_event );


	private slots:

		/// Updates the left margin width if the block count was changed.
		/// \param i_newBlockCount	New block count
		void updateLeftMarginWidth ( int i_newBlockCount );

		/// Updates the left margin. Will be called, if the content of the left margin was changed.
		/// \param QRect			Rectangle
		/// \param i_pixelScrolledVertical	The pixel, the document was scralled vertical
		void updateLeftMargin ( const QRect &, int i_pixelScrolledVertical );

		/// Highlights the current line, the cursor is located.
		void highlightCurrentLine();

	private:

		/// Base
		int i_base;
		
		/// Memory size
		int i_memSize;

		/// The cursor selection
		QTextEdit::ExtraSelection ExtraSelection_cursor;

		/// A list of all selections to highlight
		QList<QTextEdit::ExtraSelection> QListExtraSelection_highlight;

		/// The left margin widget
		QWidget * pPicIOMemEditorLeftMargin;

		/// The line number reference the icon points to
		int i_valuePtr;

		/// Sets all extraselections to the document widget.
		void setLineHighlights ( void );
};

/**
 *****************************************************************************************************************************
 *
 *      \brief Memory editor left margin widget.
 *
 *	This code
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-09-15
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class PicIOMemEditorLeftMargin : public QWidget
{
		Q_OBJECT

	public:

		/// Constructor. This class is the left margin of the PicIOFifoEditor widget.
		/// \param pPicIOFifoEditor	Reference to parent widget
		PicIOMemEditorLeftMargin ( PicIOMemEditor * pPicIOMemEditor ) : QWidget ( pPicIOMemEditor )
		{
			this->pPicIOMemEditor = pPicIOMemEditor;
		}

		/// Returns the size hint.
		/// \retval QSize	Size hint
		QSize sizeHint() const
		{
			return QSize ( this->pPicIOMemEditor->leftMarginWidth(), 0 );
		}

	protected:

		/// Handles double click event.
		/// \param pQMouseEvent		Mouse event
		void mouseDoubleClickEvent ( QMouseEvent * pQMouseEvent )
		{
			this->pPicIOMemEditor->leftMarginLineFromPos ( pQMouseEvent->y() );
			QWidget::update ();
		}

		/// Paints the widget.
		/// \param pQPaintEvent		Paint event
		void paintEvent ( QPaintEvent * pQPaintEvent )
		{
			this->pPicIOMemEditor->leftMarginPaintEvent ( pQPaintEvent );
		}

	private:

		/// Reference to parent widget.
		PicIOMemEditor * pPicIOMemEditor;
};

#endif
