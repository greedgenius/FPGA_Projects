/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/
#ifndef PRJOPENDLGLSTELEMENT_H
#define PRJOPENDLGLSTELEMENT_H

#include <QtGui>
#include <QtCore>

/**
 *****************************************************************************************************************************
 *
 *      \brief Project collection list element
 *
 *	Shows some project parameter.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-10-04
 *	\version	0.1.1
 *
 *	Change log
 *
 *	2009-10-04	Generated
 *
 *****************************************************************************************************************************
 */

class PrjOpenDlgLstElement : public QWidget
{
		Q_OBJECT

	public:

		/// Constructor. Generates the dialog layout.
		/// \param pQWidgetParent		Reference to the Parent widget.
		PrjOpenDlgLstElement ( QWidget * pQWidget_parent = 0 );

		/// Sets project file path. The project will be opened and 
		/// some parameter displayed.
		/// \param QString_prjFilePath		Project file path
		bool setPrjFilePath ( QString QString_prjFilePath );

		/// Returns the project file path
		QString getPrjFilePath ( void );

	signals:

		/// Emits an open request
		/// \param pPrjOpenDlgLstElement	Reference to itself
		void reqOpen   ( PrjOpenDlgLstElement * pPrjOpenDlgLstElement );

		/// Emits a remove request to remove this element from 
		/// project collection list.
		/// \param pPrjOpenDlgLstElement	Reference to itself
		void reqRemove ( PrjOpenDlgLstElement * pPrjOpenDlgLstElement );

	private slots:

		/// Handles the click event from open button and emits a \c reqOpen request.
		void hndlOpenButton ( void );

		/// Handles the click event from remove button and emits a \c reqRemove request.
		void hndlRemoveButton ( void );

	private:
		
		QString QString_prjFilePath;

		/// Project path
		QLabel * pQLabel_prjPath;

		/// Project file
		QLabel * pQLabel_prjFile;

		/// Project title
		QLabel * pQLabel_prjTitle;
		
		/// Project version
		QLabel * pQLabel_prjVersion;

		/// Selected processor
		QLabel * pQLabel_processor;

		/// Project comment
		QTextBrowser * pQTextBrowser_comment;
		
	protected:
		
		/// Handles double click event
		/// \param[in] pQMouseEvent	Reference to Mouse event
		void mouseDoubleClickEvent ( QMouseEvent * pQMouseEvent );
};

#endif
