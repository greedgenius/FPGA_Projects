/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeCmplrPblze3.h"

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Constructor/destructor
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

PicPblzeCmplrPblze3::PicPblzeCmplrPblze3 ( QObject * pQObject_parent ) : PicPblzeCmplr ( pQObject_parent )
{
	this->QMap_reg [ "s0" ] = 0x0;
	this->QMap_reg [ "s1" ] = 0x1;
	this->QMap_reg [ "s2" ] = 0x2;
	this->QMap_reg [ "s3" ] = 0x3;
	this->QMap_reg [ "s4" ] = 0x4;
	this->QMap_reg [ "s5" ] = 0x5;
	this->QMap_reg [ "s6" ] = 0x6;
	this->QMap_reg [ "s7" ] = 0x7;
	this->QMap_reg [ "s8" ] = 0x8;
	this->QMap_reg [ "s9" ] = 0x9;
	this->QMap_reg [ "sA" ] = 0xA;
	this->QMap_reg [ "sB" ] = 0xB;
	this->QMap_reg [ "sC" ] = 0xC;
	this->QMap_reg [ "sD" ] = 0xD;
	this->QMap_reg [ "sE" ] = 0xE;
	this->QMap_reg [ "sF" ] = 0xF;
}

/**
 *****************************************************************************************************************************
 */
PicPblzeCmplrPblze3::~PicPblzeCmplrPblze3 ( void )
{
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Compile
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compile ( void )
{
	// Parse code
	if ( ! PicPblzeAsmParser::parse () )
		return FALSE;

	// Allocate new pic memory
	PicPblzeCmplr::asMemCell = new sMemCell_t[ PicPblzeAsmParser::sMem.i_memSize ];

	// Preset pic memory with zero
	memset ( PicPblzeCmplr::asMemCell, NULL, ( PicPblzeAsmParser::sMem.i_memSize * sizeof ( PicPblzeCmplr::sMemCell_t ) ) );
	
	// Compile
	for ( int i_iterator = 0; i_iterator < this->sMem.i_memSize; ++i_iterator )
	{
		unsigned int ui_memCell;
		
		sCodeLine_t * psCodeLine = PicPblzeAsmParser::sMem.apsCodeLine_memMap[ i_iterator ];
		
		if ( ! psCodeLine )
			continue;
		
		if ( psCodeLine->eLineType > PicPblzeAsmParser::eLineType_cmd )
		{
			// Get memory line
			if ( ! this->compileCmd ( psCodeLine, & ui_memCell ) )
			{
				PicPblzeCmplr::msgEmit ( PicPblzeCmplr::eMsgType_compError );
				return FALSE;
			}

			// Store memory line
			PicPblzeCmplr::asMemCell [ i_iterator ].b_valid  = TRUE;
			PicPblzeCmplr::asMemCell [ i_iterator ].ui_value = ui_memCell;
		}
		else
		{
			PicPblzeCmplr::msgEmit ( PicPblzeCmplr::eMsgType_compError );
			return FALSE;
		}
	}

	// Write output file
	return PicPblzeCmplr::writeOutputFile ();
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Compile commands
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	switch ( psCodeLine->eLineType )
	{
		case eLineType_cmdRet:		return this->compileCmdReturn  ( psCodeLine, pui_memCell );
		case eLineType_cmdReti:		return this->compileCmdReturnI ( psCodeLine, pui_memCell );
		case eLineType_cmdAddc:		return this->compileCmdAddCy   ( psCodeLine, pui_memCell );
		case eLineType_cmdSubc:		return this->compileCmdSubCy   ( psCodeLine, pui_memCell );
		case eLineType_cmdIn:		return this->compileCmdInput   ( psCodeLine, pui_memCell );
		case eLineType_cmdOut:		return this->compileCmdOutput  ( psCodeLine, pui_memCell );
		case eLineType_cmdEint:		return this->compileCmdIntEn   ( psCodeLine, pui_memCell );
		case eLineType_cmdDint:		return this->compileCmdIntDis  ( psCodeLine, pui_memCell );
		case eLineType_cmdComp:		return this->compileCmdCompare ( psCodeLine, pui_memCell );
		case eLineType_cmdAdd:		return this->compileCmdAdd     ( psCodeLine, pui_memCell );
		case eLineType_cmdAnd:		return this->compileCmdAnd     ( psCodeLine, pui_memCell );
		case eLineType_cmdCall:		return this->compileCmdCall    ( psCodeLine, pui_memCell );
		case eLineType_cmdJump:		return this->compileCmdJump    ( psCodeLine, pui_memCell );
		case eLineType_cmdLoad:		return this->compileCmdLoad    ( psCodeLine, pui_memCell );
		case eLineType_cmdOr:		return this->compileCmdOr      ( psCodeLine, pui_memCell );
		case eLineType_cmdRl:		return this->compileCmdRl      ( psCodeLine, pui_memCell );
		case eLineType_cmdRr:		return this->compileCmdRr      ( psCodeLine, pui_memCell );
		case eLineType_cmdSl0:		return this->compileCmdSl0     ( psCodeLine, pui_memCell );
		case eLineType_cmdSl1:		return this->compileCmdSl1     ( psCodeLine, pui_memCell );
		case eLineType_cmdSlA:		return this->compileCmdSla     ( psCodeLine, pui_memCell );
		case eLineType_cmdSlX:		return this->compileCmdSlx     ( psCodeLine, pui_memCell );
		case eLineType_cmdSr0:		return this->compileCmdSr0     ( psCodeLine, pui_memCell );
		case eLineType_cmdSr1:		return this->compileCmdSr1     ( psCodeLine, pui_memCell );
		case eLineType_cmdSrA:		return this->compileCmdSra     ( psCodeLine, pui_memCell );
		case eLineType_cmdSrX:		return this->compileCmdSrx     ( psCodeLine, pui_memCell );
		case eLineType_cmdSub:		return this->compileCmdSub     ( psCodeLine, pui_memCell );
		case eLineType_cmdTest:		return this->compileCmdTest    ( psCodeLine, pui_memCell );
		case eLineType_cmdXor:		return this->compileCmdXor     ( psCodeLine, pui_memCell );
		case eLineType_cmdStore:	return this->compileCmdStore   ( psCodeLine, pui_memCell );
		case eLineType_cmdFetch:	return this->compileCmdFetch   ( psCodeLine, pui_memCell );
	}

	PicPblzeAsmParser::msgEmit ( PicPblzeAsmParser::eMsgType_ivldCmd, psCodeLine );

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdAdd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x18000, 0x19000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdAddCy ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x1A000, 0x1B000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdAnd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x0A000, 0x0B000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdCall ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();
	QString QString_addr;

	//********************************************************************************************************************
	//* Check for jump type
	//********************************************************************************************************************
	if ( QString_arg0 == QString ( "C" ) )		// CALL C
	{
		*pui_memCell = 0x31800;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "NC" ) )	// CALL NC
	{
		*pui_memCell = 0x31C00;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "NZ" ) )	// CALL NZ
	{
		*pui_memCell = 0x31400;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "Z" ) )	// CALL Z
	{
		*pui_memCell = 0x31000;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else
	{
		*pui_memCell = 0x30000;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	}

	//********************************************************************************************************************
	//* Check for address
	//********************************************************************************************************************
	{
		sCodeLine_t * psCodeLine_addr;

		if ( ! PicPblzeAsmParser::checkArgRef ( QString_addr, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell |= compileArgMAddr ( psCodeLine_addr->i_addr );
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdCompare ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x14000, 0x15000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdIntDis ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	*pui_memCell = 0x3C000;
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdIntEn ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	*pui_memCell = 0x3C001;
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdFetch ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegSAddr ( psCodeLine, 0x06000, 0x07000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdInput ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegPAddr ( psCodeLine, 0x04000, 0x05000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdJump ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();
	QString QString_addr;

	//********************************************************************************************************************
	//* Check for jump type
	//********************************************************************************************************************
	if ( QString_arg0 == QString ( "C" ) )		// JUMP C
	{
		*pui_memCell = 0x35800;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "NC" ) )	// JUMP NC
	{
		*pui_memCell = 0x35C00;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "NZ" ) )	// JUMP NZ
	{
		*pui_memCell = 0x35400;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "Z" ) )	// JUMP Z
	{
		*pui_memCell = 0x35000;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else
	{
		*pui_memCell = 0x34000;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	}

	//********************************************************************************************************************
	//* Check for address
	//********************************************************************************************************************
	{
		sCodeLine_t * psCodeLine_addr;

		if ( ! PicPblzeAsmParser::checkArgRef ( QString_addr, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell |= compileArgMAddr ( psCodeLine_addr->i_addr );
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdLoad ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x00000, 0x01000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdOr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x0C000, 0x0D000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdOutput ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegPAddr ( psCodeLine, 0x2C000, 0x2D000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdReturn ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0;

	if ( psCodeLine->QStringList_args.count () > 0 )
		QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();

	//********************************************************************************************************************
	//* Check for jump type
	//********************************************************************************************************************
	if ( QString_arg0 == QString ( "C" ) )		// RETURN C
	{
		*pui_memCell  = 0x2B800;
	}
	else if ( QString_arg0 == QString ( "NC" ) )	// RETURN NC
	{
		*pui_memCell  = 0x2BC00;
	}
	else if ( QString_arg0 == QString ( "NZ" ) )	// RETURN NZ
	{
		*pui_memCell  = 0x2B400;
	}
	else if ( QString_arg0 == QString ( "Z" ) )	// RETURN Z
	{
		*pui_memCell  = 0x2B000;
	}
	else
	{
		*pui_memCell  = 0x2A000;
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdReturnI ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();

	if ( QString_arg0 == QString ( "DISABLE" ) )
		*pui_memCell = 0x38000;

	else if ( QString_arg0 == QString ( "ENABLE" ) )
		*pui_memCell = 0x38001;

	else
		return FALSE;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdRl ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x20002, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdRr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x2000C, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdSl0 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x20006, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdSl1 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x20007, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdSla ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x20000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdSlx ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x20004, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdSr0 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x2000E, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdSr1 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x2000F, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdSra ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x20008, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdSrx ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x2000A, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdStore ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegSAddr ( psCodeLine, 0x2E000, 0x2F000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdSub ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x1C000, 0x1D000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdSubCy ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x1E000, 0x1F000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdTest ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x12000, 0x13000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileCmdXor ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x0E000, 0x0F000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Compile arguments
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileArgMemRegVsRegConst ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memConst, int i_memReg, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QStirng_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	QString QString_regDst;
	QString QString_regSrc;
	int i_constant;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	//********************************************************************************************************************
	//* Check for constant
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgNumberConst ( QStirng_arg1, & i_constant ) )
	{
		*pui_memCell = i_memConst | compileArgRegDst ( QString_regDst ) | compileArgConst ( i_constant );
		return TRUE;
	}

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgRegSubst ( QStirng_arg1, & QString_regSrc ) )
	{
		*pui_memCell = i_memReg | compileArgRegDst ( QString_regDst ) | compileArgRegSrc ( QString_regSrc );
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileArgMemRegVsRegPAddr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memPAddr, int i_memReg, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QStirng_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	QString QString_regDst;
	QString QString_regSrc;
	int i_pAddr;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	//********************************************************************************************************************
	//* Check for port address
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgNumberConst ( QStirng_arg1, & i_pAddr ) )
	{
		*pui_memCell = i_memPAddr | compileArgRegDst ( QString_regDst ) | compileArgPAddr ( i_pAddr );
		return TRUE;
	}

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgAddrByReg ( QStirng_arg1, & QString_regSrc ) )
	{
		*pui_memCell = i_memReg | compileArgRegDst ( QString_regDst ) | compileArgRegSrc ( QString_regSrc );
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileArgMemRegVsRegSAddr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memPAddr, int i_memReg, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QStirng_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	QString QString_regDst;
	QString QString_regSrc;
	int i_pAddr;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	//********************************************************************************************************************
	//* Check for port address
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgNumberConst ( QStirng_arg1, & i_pAddr ) )
	{
		*pui_memCell = i_memPAddr | compileArgRegDst ( QString_regDst ) | compileArgSAddr ( i_pAddr );
		return TRUE;
	}

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgAddrByReg ( QStirng_arg1, & QString_regSrc ) )
	{
		*pui_memCell = i_memReg | compileArgRegDst ( QString_regDst ) | compileArgRegSrc ( QString_regSrc );
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblze3::compileArgMemReg ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_mem, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );

	QString QString_regDst;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	*pui_memCell = i_mem | compileArgRegDst ( QString_regDst );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze3::compileArgRegDst ( QString QString_regDst )
{
	return ( this->QMap_reg [ QString_regDst ] & 0xF ) << 8;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze3::compileArgRegSrc ( QString QString_regSrc )
{
	return ( this->QMap_reg [ QString_regSrc ] & 0xF ) << 4;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze3::compileArgConst ( int i_const )
{
	return i_const & 0xFF;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze3::compileArgMAddr ( int i_addr )
{
	return i_addr & 0x3FF;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze3::compileArgSAddr ( int i_addr )
{
	return i_addr & 0x3F;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblze3::compileArgPAddr ( int i_addr )
{
	return i_addr & 0xFF;
}

/**
 *****************************************************************************************************************************
 */


