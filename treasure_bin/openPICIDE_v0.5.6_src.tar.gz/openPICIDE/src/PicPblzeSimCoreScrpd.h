/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PicPblzeSimCoreScrpd_H
#define PicPblzeSimCoreScrpd_H

#include <QtCore>
#include <QtGui>
#include "PicEdtInteger.h"
#include "PicPblzeSet.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Xilinx PicoBlaze (tm) core register widget.
 *
 *	
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */

/*
 *****************************************************************************************************************************
 * Change log
 *
 * 2009-08-30
 *	Freeze for first release
 *
 * 2009-09-10
 *	Added base to tooltip
 *	Changed tr to QObject::tr
 *	Added workaround to increase scratch pad address fiels width
 *
 *****************************************************************************************************************************
 */

class PicPblzeSimCoreScrpd : public QScrollArea
{

		Q_OBJECT

	public:

		/// Constructor.
		/// \param i_scrpdSize		Scratch pad size
		/// \param pQObject_parent	Pointer to parent widget
		PicPblzeSimCoreScrpd ( int i_scrpdSize, QWidget * pQWidget_parent = 0 );

		/// Destructor
		~PicPblzeSimCoreScrpd ();

		/// Sets base.
		/// \param i_base		Integer base
		void setBase ( int i_base );

		/// Sets scratch pad
		/// \param i_addr		Scratch pad address
		/// \param i_value		Scratch pad value
		/// \retval bool		True, if success, otherwise false
		bool setValue ( int i_addr, int i_value );

		/// Gets scratch pad
		/// \param i_addr		Scratch pad address
		/// \param pi_value		Scratch pad value
		/// \retval bool		True, if success, otherwise false
		bool getValue ( int i_addr, int * pi_value );

		/// Clears highlighting
		void clearHighlighted ( void );

		/// Clears all
		void clear ( void );

	private:

		/// Doubly connected scratch pad list element
		struct sScrpdValue_t
		{

			PicEdtInteger PicEdtInteger_value;

			sScrpdValue_t * psScrpdValue_nxt;
		};

		struct sScrpd_t
		{
			int i_size;
			sScrpdValue_t * asScrpdValue;
		} sScrpd;
		
		/// Start of scratch pad element list
// 		sScrpdValue_t * psScrpdValue_start;

		/// Stop of scratch pad element list
// 		sScrpdValue_t * psScrpdValue_stop;

		/// Value format
		QString QString_format;

	protected:
	
		/// Sets contents margins
		/// \param[in]	int i_left		Left margin
		/// \param[in]	int i_top		Top margin
		/// \param[in]	int i_right		Right margin
		/// \param[in]	int i_bottom		Bottom margin
		void setContentsMargins ( int i_left, int i_top, int i_right, int i_bottom );
		
		/// Sets contents margins
		/// \param[in]	QMargins_margins	Margins
// 		void setContentsMargins ( const QMargins & QMargins_margins );
		
};

#endif
