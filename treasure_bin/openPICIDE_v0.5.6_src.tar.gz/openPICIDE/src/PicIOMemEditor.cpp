/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/
#include "PicIOMemEditor.h"

/**
 *****************************************************************************************************************************
 */

PicIOMemEditor::PicIOMemEditor ( QWidget * pQWidget_parent ) : QPlainTextEdit ( pQWidget_parent )
{
	this->pPicIOMemEditorLeftMargin = new PicIOMemEditorLeftMargin ( this );

	connect ( this, SIGNAL ( blockCountChanged ( int ) ),            this, SLOT ( updateLeftMarginWidth ( int ) ) );
	connect ( this, SIGNAL ( updateRequest ( const QRect &, int ) ), this, SLOT ( updateLeftMargin ( const QRect &, int ) ) );
	connect ( this, SIGNAL ( cursorPositionChanged() ),              this, SLOT ( highlightCurrentLine() ) );

	QColor QColor_cursor ( 0xEEF6FF );
	QColor_cursor.setAlpha ( 0x7F );

	this->ExtraSelection_cursor.format.setBackground (  QColor_cursor );
	this->ExtraSelection_cursor.format.setProperty ( QTextFormat::FullWidthSelection, TRUE );
	this->ExtraSelection_cursor.cursor.clearSelection();

	this->updateLeftMarginWidth ( 0 );
	this->highlightCurrentLine();

	this->i_valuePtr = -1;
	this->i_base     = 16;

	QPlainTextEdit::setFrameShape ( QFrame::NoFrame );
}

/**
 *****************************************************************************************************************************
 */

int PicIOMemEditor::leftMarginWidth ( void )
{
	int i_digits = 1;
	int i_max = qMax ( 1, QPlainTextEdit::blockCount() );

	while ( i_max >= 10 )
	{
		i_max /= 10;
		i_digits++;
	}

	int i_space = 16 + QPlainTextEdit::fontMetrics().width ( QLatin1Char ( '9' ) ) * i_digits;

	return i_space;
}

/**
 *****************************************************************************************************************************
 */

void PicIOMemEditor::updateLeftMarginWidth ( int i_newBlockCount )
{
	QPlainTextEdit::setViewportMargins ( leftMarginWidth(), 0, 0, 0 );
}

/**
 *****************************************************************************************************************************
 */

void PicIOMemEditor::updateLeftMargin ( const QRect & QRect_area, int i_pixelScrolledVertical )
{
// 	if ( this->i_valuePtr >= QPlainTextEdit::blockCount() )
// 		this->i_valuePtr = QPlainTextEdit::blockCount() - 1;

	if ( i_pixelScrolledVertical )
		this->pPicIOMemEditorLeftMargin->scroll ( 0, i_pixelScrolledVertical );
	else
		this->pPicIOMemEditorLeftMargin->update ( 0, QRect_area.y(), this->pPicIOMemEditorLeftMargin->width(), QRect_area.height() );

	if ( QRect_area.contains ( viewport ()->rect () ) )
		this->updateLeftMarginWidth ( 0 );
}

/**
 *****************************************************************************************************************************
 */

void PicIOMemEditor::resizeEvent ( QResizeEvent * pQResizeEvent )
{
	QPlainTextEdit::resizeEvent ( pQResizeEvent );

	QRect cr = contentsRect();
	this->pPicIOMemEditorLeftMargin->setGeometry ( QRect ( cr.left(), cr.top(), leftMarginWidth(), cr.height() ) );
}

/**
 *****************************************************************************************************************************
 */

void PicIOMemEditor::setBgColorCursor ( QColor QColor_bgCursor )
{
	this->ExtraSelection_cursor.format.setBackground (  QColor_bgCursor );

	this->setLineHighlights ();
}

/**
 *****************************************************************************************************************************
 */

void PicIOMemEditor::setBgColorHighlight ( QColor QColor_bgHighlight )
{
// 	this->ExtraSelection_highlight.format.setBackground (  QColor_bgHighlight );

	this->setLineHighlights ();
}

/**
 *****************************************************************************************************************************
 */

void PicIOMemEditor::highlightCurrentLine ()
{
	this->ExtraSelection_cursor.cursor = QPlainTextEdit::textCursor();

	this->setLineHighlights ();
}

/**
 *****************************************************************************************************************************
 */

void PicIOMemEditor::setLineHighlight ( QTextCursor QTextCursor_highlight )
{
	QTextEdit::ExtraSelection ExtraSelection_error;

	ExtraSelection_error.format.setBackground (  QColor ( 0xF5CACA ) );
	ExtraSelection_error.format.setProperty ( QTextFormat::FullWidthSelection, TRUE );
	ExtraSelection_error.cursor = QTextCursor_highlight;
	ExtraSelection_error.cursor.clearSelection();

	this->QListExtraSelection_highlight.append ( ExtraSelection_error );

	this->setLineHighlights ();
}

/**
 *****************************************************************************************************************************
 */

void PicIOMemEditor::clearLineHighlight ( void )
{
	this->QListExtraSelection_highlight.clear ();

	this->setLineHighlights ();
}

/**
 *****************************************************************************************************************************
 */

void PicIOMemEditor::setLineHighlights ( void )
{
	QList<QTextEdit::ExtraSelection> QListExtraSelection_highlight;

	QListExtraSelection_highlight = this->QListExtraSelection_highlight;

	QListExtraSelection_highlight.append ( ExtraSelection_cursor );

	QPlainTextEdit::setExtraSelections ( QListExtraSelection_highlight );

	QPlainTextEdit::update ();
}

/**
 *****************************************************************************************************************************
 */

void PicIOMemEditor::leftMarginPaintEvent ( QPaintEvent * pQPaintEvent )
{
	QPainter QPainter_lineNumberArea ( /*this->*/pPicIOMemEditorLeftMargin );

	QPainter_lineNumberArea.fillRect ( pQPaintEvent->rect(), QColor ( 0xEAE9E8 ) );//Qt::lightGray );
	QPainter_lineNumberArea.setPen ( Qt::black );

	QTextBlock QTextBlock_run = QPlainTextEdit::firstVisibleBlock();

	int i_blockNumber = QTextBlock_run.blockNumber();

	int i_top    = static_cast <int> ( QPlainTextEdit::blockBoundingGeometry ( QTextBlock_run ).translated ( QPlainTextEdit::contentOffset() ).top() );
	int i_bottom = static_cast <int> ( QPlainTextEdit::blockBoundingRect     ( QTextBlock_run ).height() ) + i_top;

	while ( QTextBlock_run.isValid () && i_top <= pQPaintEvent->rect().bottom() )
	{
		if ( i_blockNumber == this->i_valuePtr )
			QPainter_lineNumberArea.drawImage ( QPointF ( 0, i_top ), QImage ( ":/pic/img/pic/fifoPointer.png" ) );

		if ( QTextBlock_run.isVisible() && i_bottom >= pQPaintEvent->rect().top() )
		{
			QString QString_number = QString::number ( i_blockNumber );
			QPainter_lineNumberArea.drawText ( 0, i_top, this->pPicIOMemEditorLeftMargin->width(), QPlainTextEdit::fontMetrics().height(), Qt::AlignRight, QString_number );
		}

		QTextBlock_run = QTextBlock_run.next();
		i_top    = i_bottom;
		i_bottom =  static_cast <int> (  QPlainTextEdit::blockBoundingRect ( QTextBlock_run ).height() ) + i_top;
		i_blockNumber++;
	}
}

/**
 *****************************************************************************************************************************
 */

void PicIOMemEditor::leftMarginLineFromPos ( int i_posY )
{
	QTextBlock QTextBlock_run = firstVisibleBlock();

	while ( QTextBlock_run.isValid () && QTextBlock_run.isVisible () )
	{
		QRectF QRectF_textBlock = QPlainTextEdit::blockBoundingGeometry ( QTextBlock_run ).translated ( QPlainTextEdit::contentOffset() );

		if ( QRectF_textBlock.contains ( 0, i_posY ) )
		{
// 			this->i_valuePtr = QTextBlock_run.blockNumber();
// 			emit valuesChanged ();
		}
		QTextBlock_run = QTextBlock_run.next();
	}
}

/**
 *****************************************************************************************************************************
 */

void PicIOMemEditor::setSize ( int i_memSize )
{
	int i_rowCount = QPlainTextEdit::blockCount ();

	this->i_memSize = i_memSize;

	if ( i_rowCount < i_memSize )
	{
		QTextBlock QTextBlock_run = QPlainTextEdit::document ()->lastBlock ();

		QTextCursor QTextCursor_value ( QTextBlock_run );
		QTextCursor_value.movePosition ( QTextCursor::End );

		QPlainTextEdit::setMaximumBlockCount ( i_memSize );

		for ( int i_iterator = 0; i_iterator < ( i_memSize - i_rowCount ); i_iterator++ )
			QTextCursor_value.insertBlock ();
	}
	else
	{
		QTextBlock QTextBlock_run = QPlainTextEdit::document ()->findBlockByNumber ( i_memSize - 1 );

		QTextCursor QTextCursor_value ( QTextBlock_run );

		QTextCursor_value.movePosition ( QTextCursor::EndOfLine, QTextCursor::MoveAnchor );
		QTextCursor_value.movePosition ( QTextCursor::End, QTextCursor::KeepAnchor );

		QTextCursor_value.removeSelectedText ();

		QPlainTextEdit::setMaximumBlockCount ( i_memSize );
	}
}

/**
 *****************************************************************************************************************************
 */

void PicIOMemEditor::clear ( void )
{
	QPlainTextEdit::clear ();

	QTextBlock QTextBlock_run = QPlainTextEdit::document ()->lastBlock ();

	QTextCursor QTextCursor_value ( QTextBlock_run );
	QTextCursor_value.movePosition ( QTextCursor::End );

	for ( int i_iterator = 0; i_iterator < this->i_memSize; i_iterator++ )
		QTextCursor_value.insertBlock ();
}

/**
 *****************************************************************************************************************************
 */

bool PicIOMemEditor::getValue ( int i_addr, QString * pQString_value )
{
	if ( i_addr >= this->i_memSize )
		return FALSE;

	QTextBlock QTextBlock_value = QPlainTextEdit::document ()->findBlockByNumber ( i_addr );

	if ( ! QTextBlock_value.isValid () )
		return FALSE;

	*pQString_value = QTextBlock_value.text ();

	this->i_valuePtr = i_addr;

	QPlainTextEdit::update ();

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

void PicIOMemEditor::setValue (  int i_addr, QString QString_value )
{
	if ( i_addr >= this->i_memSize )
		return;

	QTextBlock QTextBlock_value = QPlainTextEdit::document ()->findBlockByNumber ( i_addr );

	if ( ! QTextBlock_value.isValid () )
		return;

	this->i_valuePtr = i_addr;

	QTextCursor QTextCursor_value ( QTextBlock_value );
	QTextCursor_value.select ( QTextCursor::LineUnderCursor );
	QTextCursor_value.removeSelectedText ();
	QTextCursor_value.insertText ( QString_value );

	QPlainTextEdit::update ();
}

/**
 *****************************************************************************************************************************
 */

void PicIOMemEditor::setBase ( int i_base )
{
	QTextBlock QTextBlock_run = QPlainTextEdit::document ()->firstBlock ();

	int i_value;
	bool b_success;
	
	while ( QTextBlock_run.isValid () )
	{
		i_value = QTextBlock_run.text ().toInt ( & b_success, this->i_base );
		
		if ( b_success )
		{
			QTextCursor QTextCursor_value ( QTextBlock_run );
			QTextCursor_value.select ( QTextCursor::LineUnderCursor );
			QTextCursor_value.removeSelectedText ();
			QTextCursor_value.insertText ( QString ( "%1" ).arg ( i_value, 0, i_base ) );
		}
	
		QTextBlock_run = QTextBlock_run.next();
	}

	this->i_base = i_base;
}

/**
 *****************************************************************************************************************************
 */

