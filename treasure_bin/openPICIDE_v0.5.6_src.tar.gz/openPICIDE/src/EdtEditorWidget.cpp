/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   The original code of this file was copied from nokia qt 4.6.0 examples and then modified for openPICIDE.                *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "EdtEditorWidget.h"

/**
 *****************************************************************************************************************************
 * Init
 *****************************************************************************************************************************
 */

EdtEditorWidget::EdtEditorWidget ( QWidget * pQWidget_parent ) : QPlainTextEdit ( pQWidget_parent )
{
	this->b_keyPressedShift = FALSE;

	// Setup document handling
	{
		this->pQTextDocument = new QTextDocument;
		{
			this->pQTextDocument->setDocumentLayout ( new QPlainTextDocumentLayout ( this->pQTextDocument ) );
		}
	
		this->pEdtEditorHighlighter = new EdtEditorHighlighter;
		{
			this->pEdtEditorHighlighter->setDocument ( this->pQTextDocument );
		}

		QPlainTextEdit::setDocument ( this->pQTextDocument );
		QPlainTextEdit::setTabStopWidth ( 4 );
	}

	// Setup document state
	{
		this->b_copyAvailable   = FALSE;
		this->b_undoAvailable   = FALSE;
		this->b_redoAvailable   = FALSE;
		this->b_documentChanged = FALSE;
	
		connect ( this, SIGNAL ( copyAvailable ( bool ) ), this, SLOT ( setCopyAvailable ( bool ) ) );
		connect ( this, SIGNAL ( undoAvailable ( bool ) ), this, SLOT ( setUndoAvailable ( bool ) ) );
		connect ( this, SIGNAL ( redoAvailable ( bool ) ), this, SLOT ( setRedoAvailable ( bool ) ) );
		connect ( this->pQTextDocument, SIGNAL ( contentsChanged() ),    this, SLOT ( setDocumentChanged () ) );
	}
	
	pEdtEditorWidgetLeftMargin = new EdtEditorWidgetLeftMargin ( this );

	connect ( this, SIGNAL ( blockCountChanged ( int ) ),            this, SLOT ( updateLeftMarginWidth ( int ) ) );
	connect ( this, SIGNAL ( updateRequest ( const QRect &, int ) ), this, SLOT ( updateLeftMargin ( const QRect &, int ) ) );
	connect ( this, SIGNAL ( cursorPositionChanged() ),              this, SLOT ( highlightCurrentLine() ) );

	this->b_lineNumberEn = TRUE;
	this->b_breakpointEn = FALSE;
	this->b_highlightEn  = FALSE;

	this->ExtraSelection_cursor.format.setBackground (  QColor ( 0xEEF6FF ) );
	this->ExtraSelection_cursor.format.setProperty ( QTextFormat::FullWidthSelection, TRUE );
	this->ExtraSelection_cursor.cursor.clearSelection();

	this->ExtraSelection_highlight.format.setBackground (  QColor ( 0xF5CACA ) );
	this->ExtraSelection_highlight.format.setProperty ( QTextFormat::FullWidthSelection, TRUE );
	this->ExtraSelection_highlight.cursor.clearSelection();

	this->ExtraSelection_grayout.format.setBackground (  QColor ( 0xD7D7D7 ) );
	this->ExtraSelection_grayout.format.setProperty ( QTextFormat::FullWidthSelection, TRUE );
	this->ExtraSelection_grayout.cursor.clearSelection();

	this->updateLeftMarginWidth ( 0 );
	this->highlightCurrentLine();
}

/**
 *****************************************************************************************************************************
 * Left margin
 *****************************************************************************************************************************
 */

void EdtEditorWidget::leftMarginPaintEvent ( QPaintEvent * pQPaintEvent )
{
	QPainter QPainter_lineNumberArea ( pEdtEditorWidgetLeftMargin );

	QPainter_lineNumberArea.fillRect ( pQPaintEvent->rect(), QColor ( 0xEAE9E8 ) );//Qt::lightGray );
	QPainter_lineNumberArea.setPen ( Qt::black );

	QTextBlock QTextBlock_run = QPlainTextEdit::firstVisibleBlock();

	int i_blockNumber = QTextBlock_run.blockNumber();

	int i_top    = static_cast <int> ( QPlainTextEdit::blockBoundingGeometry ( QTextBlock_run ).translated ( QPlainTextEdit::contentOffset() ).top() );
	int i_bottom = static_cast <int> ( QPlainTextEdit::blockBoundingRect     ( QTextBlock_run ).height() ) + i_top;

	while ( QTextBlock_run.isValid () && i_top <= pQPaintEvent->rect().bottom() )
	{
		if ( QTextBlock_run.isVisible() && i_bottom >= pQPaintEvent->rect().top() )
		{
			if ( this->b_breakpointEn &&  this->QListI_breakpoints.contains ( i_blockNumber ) )
			{
				QPainter_lineNumberArea.drawImage ( QPointF ( 0, i_top ), QImage ( ":/edt/img/edt/breakpoint.png" ) );
			}

			if ( this->b_lineNumberEn )
			{
				QString QString_number = QString::number ( i_blockNumber + 1 );
				QPainter_lineNumberArea.drawText ( 0, i_top, pEdtEditorWidgetLeftMargin->width(), QPlainTextEdit::fontMetrics().height(), Qt::AlignRight, QString_number );
			}
		}

		QTextBlock_run = QTextBlock_run.next();
		i_top    = i_bottom;
		i_bottom =  static_cast <int> (  QPlainTextEdit::blockBoundingRect ( QTextBlock_run ).height() ) + i_top;
		i_blockNumber++;
	}
}

/**
 *****************************************************************************************************************************
 */

int EdtEditorWidget::leftMarginWidth ( void )
{
	int i_digits = 1;
	int i_max = qMax ( 1, QPlainTextEdit::blockCount() );

	while ( i_max >= 10 )
	{
		i_max /= 10;
		i_digits++;
	}

	int i_space = 16 + QPlainTextEdit::fontMetrics().width ( QLatin1Char ( '9' ) ) * i_digits;

	return i_space;
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::leftMarginLineFromPos ( int i_posY )
{
	QTextBlock QTextBlock_run = firstVisibleBlock();

	while ( QTextBlock_run.isValid () && QTextBlock_run.isVisible () )
	{
		QRectF QRectF_textBlock = QPlainTextEdit::blockBoundingGeometry ( QTextBlock_run ).translated ( QPlainTextEdit::contentOffset() );

		if ( QRectF_textBlock.contains ( 0, i_posY ) )
		{
			int i_blockNumber = QTextBlock_run.blockNumber();

			if ( this->QListI_breakpoints.contains ( i_blockNumber ) )
				this->QListI_breakpoints.removeOne ( i_blockNumber );
			else
				this->QListI_breakpoints << i_blockNumber;

			emit breakpointChanged ();
			return;
		}
		QTextBlock_run = QTextBlock_run.next();
	}
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::updateLeftMarginWidth ( int i_newBlockCount )
{
	QPlainTextEdit::setViewportMargins ( leftMarginWidth(), 0, 0, 0 );
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::updateLeftMargin ( const QRect & QRect_area, int i_pixelScrolledVertical )
{
	if ( i_pixelScrolledVertical )
		this->pEdtEditorWidgetLeftMargin->scroll ( 0, i_pixelScrolledVertical );
	else
		this->pEdtEditorWidgetLeftMargin->update ( 0, QRect_area.y(), this->pEdtEditorWidgetLeftMargin->width(), QRect_area.height() );

	if ( QRect_area.contains ( viewport ()->rect () ) )
		this->updateLeftMarginWidth ( 0 );
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::resizeEvent ( QResizeEvent * pQResizeEvent )
{
	QPlainTextEdit::resizeEvent ( pQResizeEvent );

	QRect cr = contentsRect();
	pEdtEditorWidgetLeftMargin->setGeometry ( QRect ( cr.left(), cr.top(), leftMarginWidth(), cr.height() ) );
}

/**
 *****************************************************************************************************************************
 * Break points
 *****************************************************************************************************************************
 */

void EdtEditorWidget::setBreakpointEn ( bool b_breakpointEn )
{
	this->b_breakpointEn = b_breakpointEn;
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::getbreakpoints ( QList<int> * pQListI_lineNumber )
{
	*pQListI_lineNumber = this->QListI_breakpoints;
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::clearBreakpoints ( void )
{
	this->QListI_breakpoints.clear ();

	QPlainTextEdit::update ();
}

/**
 *****************************************************************************************************************************
 * Highlighting and formating
 *****************************************************************************************************************************
 */

void EdtEditorWidget::setHighlightingParameter ( EdtEditorHighlighter::sHighlightingParameter_t sHighlightingParameter )
{
	// Setting highlighter causes emitting of contentsChanged signal
	
	if ( ! this->b_documentChanged )
		disconnect ( this->pQTextDocument, SIGNAL ( contentsChanged() ), this, SLOT ( setDocumentChanged () ) );
	
	this->pEdtEditorHighlighter->setHighlightingParameter ( sHighlightingParameter );
	
	if ( ! this->b_documentChanged )
		connect ( this->pQTextDocument, SIGNAL ( contentsChanged() ), this, SLOT ( setDocumentChanged () ) );
}

/**
 *****************************************************************************************************************************
 */

bool EdtEditorWidget::getLine ( int i_lineNumber, QString * pQString_line )
{
	QTextCursor QTextCursor_line = QPlainTextEdit::textCursor();

	QTextCursor_line.movePosition ( QTextCursor::Start );

	for ( int i_iterator = 0; i_iterator < i_lineNumber; i_iterator++ )
	{
		if ( ! QTextCursor_line.movePosition ( QTextCursor::Down ) )
			return FALSE;
	}
	
	QTextCursor_line.movePosition ( QTextCursor::StartOfLine, QTextCursor::MoveAnchor );
	QTextCursor_line.movePosition ( QTextCursor::EndOfLine,   QTextCursor::KeepAnchor );
	
	*pQString_line = QTextCursor_line.selectedText ();
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool EdtEditorWidget::setLine ( int i_lineNumber, QString QString_line )
{
	QTextCursor QTextCursor_line = QPlainTextEdit::textCursor();

	QTextCursor_line.movePosition ( QTextCursor::Start );
	
	for ( int i_iterator = 0; i_iterator < i_lineNumber; i_iterator++ )
	{
		if ( QTextCursor_line.movePosition ( QTextCursor::Down ) )
			continue;
		
		QTextCursor_line.movePosition ( QTextCursor::EndOfLine );
		QTextCursor_line.insertText ( QChar ( '\n' ) );
		QTextCursor_line.movePosition ( QTextCursor::Down );
	}

	QTextCursor_line.movePosition ( QTextCursor::StartOfLine, QTextCursor::MoveAnchor );
	QTextCursor_line.movePosition ( QTextCursor::EndOfLine,   QTextCursor::KeepAnchor );

	QTextCursor_line.removeSelectedText ();
	QTextCursor_line.insertText ( QString_line );
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool EdtEditorWidget::selectLine ( int i_lineNumber )
{
	QTextCursor QTextCursor_line = QPlainTextEdit::textCursor();

	QTextCursor_line.movePosition ( QTextCursor::Start );

	for ( int i_iterator = 0; i_iterator < i_lineNumber; i_iterator++ )
	{
		if ( ! QTextCursor_line.movePosition ( QTextCursor::Down ) )
		{
			return FALSE;
		}
	}

	QPlainTextEdit::setTextCursor ( QTextCursor_line );

	this->highlightLine ( QTextCursor_line );

// 	QPlainTextEdit::moveCursor ( QTextCursor::Start );
// 	QPlainTextEdit::ensureCursorVisible();
	QPlainTextEdit::ensureCursorVisible();

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::selectTag ( QString QString_tag )
{
	// Start from beginning
	QPlainTextEdit::moveCursor ( QTextCursor::Start );

	// Find position of tag
	while ( QPlainTextEdit::find ( QString_tag, QFlags <QTextDocument::FindFlag> ( 0 ) ) )
	{
		QTextCursor QTextCursor_line = QPlainTextEdit::textCursor();

		QString QString_line;
		{
			QTextCursor_line.movePosition ( QTextCursor::StartOfLine, QTextCursor::MoveAnchor );
			QTextCursor_line.movePosition ( QTextCursor::EndOfLine,   QTextCursor::KeepAnchor );
		
			QString_line = QTextCursor_line.selectedText ();
		
			QTextCursor_line.clearSelection ();
		}

		// To display the tag in the first line, jump to end of document first
		QPlainTextEdit::moveCursor ( QTextCursor::End );
		
		// Select tag
		QPlainTextEdit::setTextCursor ( QTextCursor_line );
		
		// Scroll up and down two lines
		QPlainTextEdit::moveCursor ( QTextCursor::Up );
		QPlainTextEdit::moveCursor ( QTextCursor::Up );
		QPlainTextEdit::moveCursor ( QTextCursor::Down );
		QPlainTextEdit::moveCursor ( QTextCursor::Down );

		if ( QString_line.contains ( QRegExp ( "^" + QString_tag ) ) )
			return;

		else if ( QString_line.contains ( QRegExp ( "^;." + QString_tag ) ) )
			return;
	}
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::getTagList ( EdtNaviTagList * pEdtNaviTagList )
{
	QRegExp QRegExp_tags = pEdtNaviTagList->getRegExp();
	
	QTextCursor QTextCursor_tmp;
	QTextCursor_tmp = this->pQTextDocument->find ( QRegExp_tags, 0, QFlags <QTextDocument::FindFlag> ( 0 ) );
	
	while ( QTextCursor_tmp.hasSelection() )
	{
		pEdtNaviTagList->addTag ( QTextCursor_tmp.selectedText() );
		
		QTextCursor_tmp = this->pQTextDocument->find ( QRegExp_tags, QTextCursor_tmp, QFlags <QTextDocument::FindFlag> ( 0 ) );
	};
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::highlightLine ( QTextCursor & QTextCursor_highlight )
{
	this->b_highlightEn = TRUE;

	this->ExtraSelection_highlight.cursor = QTextCursor_highlight;

	this->highlightLines ();
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::highlightCurrentLine ()
{
	this->ExtraSelection_cursor.cursor = QPlainTextEdit::textCursor();

	this->highlightLines ();
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::clearLineHighlighting ( void )
{
	this->b_highlightEn = FALSE;

	this->ExtraSelection_highlight.cursor.clearSelection();

	this->highlightLines ();
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::setBgColorCursor ( QColor QColor_bgCursor )
{
	this->ExtraSelection_cursor.format.setBackground (  QColor_bgCursor );

	this->highlightLines ();
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::setBgColorHighlight ( QColor QColor_bgHighlight )
{
	this->ExtraSelection_highlight.format.setBackground (  QColor_bgHighlight );

	this->highlightLines ();
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::setTabStopWidth ( int i_tabIndent )
{
	QPlainTextEdit::setTabStopWidth ( QFontMetrics ( QPlainTextEdit::font() ).width ( " " ) * i_tabIndent );
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::setDynamicWordWrapEn ( bool b_dynamicWordWrapEn )
{
	if ( b_dynamicWordWrapEn )
		QPlainTextEdit::setLineWrapMode ( QPlainTextEdit::WidgetWidth );
	else
		QPlainTextEdit::setLineWrapMode ( QPlainTextEdit::NoWrap );
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::highlightLines ( void )
{
	QList<QTextEdit::ExtraSelection> QListExtraSelection;

	QListExtraSelection.append ( ExtraSelection_cursor );
// 	QListExtraSelection.append ( QListExtraSelection_undergray );

	if ( this->b_highlightEn )
		QListExtraSelection.append ( ExtraSelection_highlight );

	QPlainTextEdit::setExtraSelections ( QListExtraSelection );

	QPlainTextEdit::update ();
}

/**
 *****************************************************************************************************************************
 * Internal key handling
 *****************************************************************************************************************************
 */

void EdtEditorWidget::keyPressEvent ( QKeyEvent * pQKeyEvent_event )
{
	if  ( pQKeyEvent_event->key() == Qt::Key_Return )
	{
		this->insertEnterTab ( pQKeyEvent_event );
		return;
	}
	else if  ( pQKeyEvent_event->key() == Qt::Key_Shift )
	{
		this->b_keyPressedShift = TRUE;
	}
	else if  ( ( pQKeyEvent_event->key() == Qt::Key_Tab ) && QPlainTextEdit::textCursor().hasSelection() )
	{
		if ( ! this->b_keyPressedShift )
			this->indent ();
		else
			this->deindent ();
			
		return;
	}
		
	QPlainTextEdit::keyPressEvent ( pQKeyEvent_event );
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::keyReleaseEvent ( QKeyEvent * pQKeyEvent_event )
{
	if  ( pQKeyEvent_event->key() == Qt::Key_Shift )
	{
		this->b_keyPressedShift = FALSE;
	}
	
	QPlainTextEdit::keyReleaseEvent ( pQKeyEvent_event );
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::insertEnterTab ( QKeyEvent * pQKeyEvent_event )
{
	QTextCursor QTextCursor_line;

	// Get line indent
	QString QString_indent;
	{
		QTextCursor_line = QPlainTextEdit::textCursor();
		
		QTextCursor_line.movePosition ( QTextCursor::StartOfLine, QTextCursor::KeepAnchor );

		QString QString_line = QTextCursor_line.selectedText();

		for ( int i_pos = 0; i_pos < QString_line.length (); ++i_pos )
		{
			if ( ! QString_line.at ( i_pos ).isSpace()  )
				break;
			
			QString_indent += QString_line.at ( i_pos );
		}
	}
	
	QPlainTextEdit::keyPressEvent ( pQKeyEvent_event );
	
	// Insert indent
	{
		QTextCursor_line = QPlainTextEdit::textCursor();
		
		QTextCursor_line.insertText ( QString_indent );
	}
}

/**
 *****************************************************************************************************************************
 * Document handling
 *****************************************************************************************************************************
 */

void EdtEditorWidget::setFilePath ( QString QString_filePath )
{
	this->QString_filePath = QString_filePath;
}

/**
 *****************************************************************************************************************************
 */

QString EdtEditorWidget::getFilePath ( void )
{
	return this->QString_filePath;
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::setText ( QString QString_document )
{
	QPlainTextEdit::setUpdatesEnabled ( FALSE );
	
	this->pQTextDocument->setPlainText ( QString_document );
	
	QPlainTextEdit::setUpdatesEnabled ( TRUE );
	
	QPlainTextEdit::moveCursor ( QTextCursor::Start );
	
	this->clearDocumentChanged();
}

/**
 *****************************************************************************************************************************
 * Document state
 *****************************************************************************************************************************
 */

bool EdtEditorWidget::getDocumentChanged ( void )
{
	return this->b_documentChanged;
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::setDocumentChanged ( void )
{
	if ( this->b_documentChanged )
		return;
	
	this->b_documentChanged = TRUE;

	emit documentChanged ( this, this->b_documentChanged );

	disconnect ( this->pQTextDocument, SIGNAL ( contentsChanged() ), this, SLOT ( setDocumentChanged () ) );
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::clearDocumentChanged ( void )
{
	if ( ! this->b_documentChanged )
		return;

	this->b_documentChanged = FALSE;

	connect ( this->pQTextDocument, SIGNAL ( contentsChanged() ), this, SLOT ( setDocumentChanged () ) );

	emit documentChanged ( this, this->b_documentChanged );
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool EdtEditorWidget::getUndoAvailable ( void )
{
	return this->b_undoAvailable;
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::setUndoAvailable ( bool b_undoAvailable )
{
	this->b_undoAvailable = b_undoAvailable;

	emit undoAvailable ( this, b_undoAvailable );
}
/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

void EdtEditorWidget::setRedoAvailable ( bool b_redoAvailable )
{
	this->b_redoAvailable = b_redoAvailable;

	emit redoAvailable ( this, b_redoAvailable );
}

/**
 *****************************************************************************************************************************
 */

bool EdtEditorWidget::getRedoAvailable ( void )
{
	return this->b_redoAvailable;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool EdtEditorWidget::getCopyAvailable ( void )
{
	return this->b_copyAvailable;
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::setCopyAvailable ( bool b_copyAvailable )
{
	this->b_copyAvailable = b_copyAvailable;

	emit copyAvailable ( this, b_copyAvailable );
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

int EdtEditorWidget::getLineFromCursor ( void )
{
	return QPlainTextEdit::textCursor().blockNumber ();	// -1
}

/**
 *****************************************************************************************************************************
 */

QString EdtEditorWidget::getSelection ( void )
{
	return QPlainTextEdit::textCursor().selectedText ();
}

/**
 *****************************************************************************************************************************
 * Editing document
 *****************************************************************************************************************************
 */

void EdtEditorWidget::indent ( void )
{
	QTextCursor QTextCursor_sel = QPlainTextEdit::textCursor();

	if ( QTextCursor_sel.hasSelection() )
	{
		int i_posStart = QTextCursor_sel.selectionStart();
		int i_posEnd   = QTextCursor_sel.selectionEnd();

		QTextCursor_sel.beginEditBlock();

		// Move cursor to start
		QTextCursor_sel.setPosition ( i_posStart, QTextCursor::MoveAnchor );
		
		while ( QTextCursor_sel.position() < i_posEnd )
		{
			// Indent
			QTextCursor_sel.movePosition ( QTextCursor::StartOfLine, QTextCursor::MoveAnchor );
			QTextCursor_sel.insertText ( QChar ( 0x09 ) );
			i_posEnd++;

			// Move cursor to next line
			if ( ! QTextCursor_sel.movePosition ( QTextCursor::Down, QTextCursor::MoveAnchor ) )
				break;
		}
		
		// Regenerate selection
		QTextCursor_sel.setPosition ( i_posStart, QTextCursor::MoveAnchor );
		QTextCursor_sel.setPosition ( i_posEnd,   QTextCursor::KeepAnchor );

		QTextCursor_sel.endEditBlock();

		QPlainTextEdit::setTextCursor ( QTextCursor_sel );
	}
/*	else
	{
		int i_posCursor = QTextCursor_sel.position ();
		
		QTextCursor_sel.movePosition ( QTextCursor::StartOfLine, QTextCursor::MoveAnchor );
		QTextCursor_sel.insertText ( QChar ( 0x09 ) );

		
		// Regenerate selection
		QTextCursor_sel.setPosition ( i_posCursor, QTextCursor::MoveAnchor );
		
		QPlainTextEdit::setTextCursor ( QTextCursor_sel );
	}*/
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::deindent ( void )
{
	QTextCursor QTextCursor_sel = QPlainTextEdit::textCursor();

	if ( QTextCursor_sel.hasSelection() )
	{
		int i_posStart = QTextCursor_sel.selectionStart ();
		int i_posEnd   = QTextCursor_sel.selectionEnd ();

		QTextCursor_sel.beginEditBlock();

		// Move cursor to start
		QTextCursor_sel.setPosition ( i_posStart, QTextCursor::MoveAnchor );

		while ( QTextCursor_sel.position() < i_posEnd )
		{
			QTextCursor_sel.movePosition ( QTextCursor::StartOfLine, QTextCursor::MoveAnchor );
			QTextCursor_sel.movePosition ( QTextCursor::EndOfLine, QTextCursor::KeepAnchor );

			QString QString_line = QTextCursor_sel.selectedText ();

			if ( ( ! QString_line.isEmpty() ) && QString_line.at ( 0 ).isSpace () )
			{
				QString_line.remove ( 0, 1 );

				QTextCursor_sel.removeSelectedText ();
				QTextCursor_sel.insertText ( QString_line );
				
				// Subtract removed ";" from position
				i_posEnd--;
			}

			// Move cursor to next line
			if ( ! QTextCursor_sel.movePosition ( QTextCursor::Down, QTextCursor::MoveAnchor ) )
				break;
		}
		
		// Regenerate selection
		QTextCursor_sel.setPosition ( i_posStart, QTextCursor::MoveAnchor );
		QTextCursor_sel.setPosition ( i_posEnd,   QTextCursor::KeepAnchor );

		QTextCursor_sel.endEditBlock();

		QPlainTextEdit::setTextCursor ( QTextCursor_sel );
	}
	else
	{
		int i_posCursor = QTextCursor_sel.position ();
		
		QTextCursor_sel.movePosition ( QTextCursor::StartOfLine, QTextCursor::MoveAnchor );
		
		int i_posLineStart = QTextCursor_sel.position ();
		
		QTextCursor_sel.movePosition ( QTextCursor::EndOfLine, QTextCursor::KeepAnchor );

		QString QString_line = QTextCursor_sel.selectedText ();

		if ( ( ! QString_line.isEmpty() ) && QString_line.at ( 0 ).isSpace () )
		{
			QString_line.remove ( 0, 1 );

			QTextCursor_sel.removeSelectedText ();
			QTextCursor_sel.insertText ( QString_line );
			
			// Subtract removed ";" from position
			if ( i_posLineStart < i_posCursor )
				i_posCursor--;
		}
		
		// Regenerate selection
		QTextCursor_sel.setPosition ( i_posCursor, QTextCursor::MoveAnchor );
		
		QPlainTextEdit::setTextCursor ( QTextCursor_sel );
	}
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::commentOut ( void )
{
	QTextCursor QTextCursor_sel = QPlainTextEdit::textCursor();

	int i_posStart = QTextCursor_sel.selectionStart();
	int i_posEnd   = QTextCursor_sel.selectionEnd();

	QTextCursor_sel.beginEditBlock();

	// Move cursor to start
	QTextCursor_sel.setPosition ( i_posStart, QTextCursor::MoveAnchor );
	
	while ( QTextCursor_sel.position() <= i_posEnd )
	{
		// Comment out
		QTextCursor_sel.movePosition ( QTextCursor::StartOfLine, QTextCursor::MoveAnchor );
		QTextCursor_sel.insertText ( QString ( ";" ) );

		// Move cursor to next line
		QTextCursor_sel.movePosition ( QTextCursor::Down, QTextCursor::MoveAnchor );
	}

	QTextCursor_sel.endEditBlock();

	QPlainTextEdit::setTextCursor ( QTextCursor_sel );
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::commentIn ( void )
{
	QTextCursor QTextCursor_sel = QPlainTextEdit::textCursor();

	int i_posStart = QTextCursor_sel.selectionStart();
	int i_posEnd   = QTextCursor_sel.selectionEnd();

	QTextCursor_sel.beginEditBlock();

	// Move cursor to start
	QTextCursor_sel.setPosition ( i_posStart, QTextCursor::MoveAnchor );

	while ( QTextCursor_sel.position() <= i_posEnd )
	{
		// Comment in
		QTextCursor_sel.movePosition ( QTextCursor::StartOfLine, QTextCursor::MoveAnchor );
		QTextCursor_sel.movePosition ( QTextCursor::EndOfLine, QTextCursor::KeepAnchor );

		QString QString_line = QTextCursor_sel.selectedText ();

		if ( QString_line.contains ( QRegExp ( "^\\s*;" ) ) )
		{
			QString_line.remove ( QString_line.indexOf ( QChar ( ';' ) ), 1 );

			QTextCursor_sel.removeSelectedText ();
			QTextCursor_sel.insertText ( QString_line );
			
			// Subtract removed ";" from position
			--i_posEnd;
		}

		// Move cursor to next line
		QTextCursor_sel.movePosition ( QTextCursor::Down, QTextCursor::MoveAnchor );
	}

	QTextCursor_sel.endEditBlock();

	QPlainTextEdit::setTextCursor ( QTextCursor_sel );
}

/**
 *****************************************************************************************************************************
 */

bool EdtEditorWidget::find ( sSetFndRepl_t * psSetFndRepl )
{
	int i_flags;

	i_flags  = 0;
	i_flags |= QTextDocument::FindCaseSensitively * psSetFndRepl->b_fndCaseSensitive;
	i_flags |= QTextDocument::FindBackward        * psSetFndRepl->b_fndBackwards;
	i_flags |= QTextDocument::FindWholeWords      * psSetFndRepl->b_fndWholeWords;

	if ( ! psSetFndRepl->b_fndFromCursor )
		QPlainTextEdit::moveCursor ( QTextCursor::Start );

	// Find string
	return QPlainTextEdit::find ( psSetFndRepl->QString_find, QFlags <QTextDocument::FindFlag> ( i_flags ) );
}

/**
 *****************************************************************************************************************************
 */

bool EdtEditorWidget::replace ( sSetFndRepl_t * psSetFndRepl )
{
	if ( QPlainTextEdit::textCursor().hasSelection () )
		QPlainTextEdit::textCursor().insertText ( psSetFndRepl->QString_replace );
	
	return this->find ( psSetFndRepl );
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::replaceAll ( sSetFndRepl_t * psSetFndRepl )
{
	psSetFndRepl->b_fndFromCursor = FALSE;
	
	while ( this->find ( psSetFndRepl ) )
	{
		psSetFndRepl->b_fndFromCursor = TRUE;

		if ( QPlainTextEdit::textCursor().hasSelection () )
			QPlainTextEdit::textCursor().insertText ( psSetFndRepl->QString_replace );
	}
}

/**
 *****************************************************************************************************************************
 */

void EdtEditorWidget::duplicateLine ( void )
{
	QTextCursor QTextCursor_line = QPlainTextEdit::textCursor();

	QTextCursor_line.beginEditBlock();
	
	QTextCursor_line.movePosition ( QTextCursor::StartOfLine, QTextCursor::MoveAnchor );
	QTextCursor_line.movePosition ( QTextCursor::EndOfLine,   QTextCursor::KeepAnchor );

	QString QString_line;
	QString_line = QTextCursor_line.selectedText ();

	QTextCursor_line.clearSelection ();

	QTextCursor_line.insertBlock ();
	QTextCursor_line.insertText ( QString_line );
	
	QTextCursor_line.endEditBlock();

	QPlainTextEdit::setTextCursor ( QTextCursor_line );
}

/**
 *****************************************************************************************************************************
 */

