/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef Mod_H
#define Mod_H

// #include "Set.h"
// #include "Prj.h"
// #include "Edt.h"
// #include "Pic.h"

// #include "MainDockAreaL.h"
// #include "MainDockAreaR.h"
// #include "MainDockAreaB.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Root elements
 *
 *	Class for handling a collection of root elements.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2010-04-24
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */

class Set;
class Edt;
class Prj;
class Pic;

class MainDockAreaL;
class MainDockAreaR;
class MainDockAreaB;

class StatusBar;

class Mod
{

	public:
		
		Mod () {
			
			this->pSet = NULL;
			this->pPrj = NULL;
			this->pEdt = NULL;
			this->pPic = NULL;
			
			this->pQMainWindow   = NULL;
			this->pMainDockAreaL = NULL;
			this->pMainDockAreaB = NULL;
			this->pMainDockAreaR = NULL;
			
			this->pStatusBar = NULL;
		};

		/// Holds settings
		Set * pSet;
	
		/// Holds project manager instance
		Prj * pPrj;

		/// Holds editor instance
		Edt * pEdt;

		/// Holds pic management instance
		Pic * pPic;

		/// Pointer to the main window widget
		QMainWindow * pQMainWindow;

		/// Pointer to the left dock area widget
		MainDockAreaL * pMainDockAreaL;

		/// Pointer to the bottom dock area widget
		MainDockAreaB * pMainDockAreaB;

		/// Pointer to the right dock area widget
		MainDockAreaR * pMainDockAreaR;

		/// Pointer to the right dock area widget
		StatusBar * pStatusBar;
		
};

#endif
