/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PicPblzeSimCoreCallStack_H
#define PicPblzeSimCoreCallStack_H

#include <QtCore>
#include <QtGui>

/**
 *****************************************************************************************************************************
 *
 *      \brief Xilinx PicoBlaze (tm) core callstack widget.
 *
 *	
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class PicPblzeSimCoreCallStack : public QWidget
{

		Q_OBJECT

	public:

		/// Constructor.
		/// \param pQObject_parent	Pointer to parent widget
		PicPblzeSimCoreCallStack ( QWidget * pQWidget_parent = 0 );

		/// Adds a reference.
		bool add ( QString QString_ref );

		/// Deletes last reference.
		bool delLast ( void );

	signals:

		/// Signs that content changed
		/// \param pQWidget		Reference to itself
		void contentChanged ( QWidget * pQWidget );

	public slots:

		/// Clears the callstack list.
		void clear ( void );

		/// Hides the widget.
		void hide ( void );

	private:

		/// Callstack list
		QStandardItemModel QStandardItemModel_callStack;

		/// Widget for viewing call stack list
		QTreeView * pQTreeView_messages;
};

#endif
