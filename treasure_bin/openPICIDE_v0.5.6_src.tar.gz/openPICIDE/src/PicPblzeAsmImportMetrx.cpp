/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeAsmImportMetrx.h"

/**
 *****************************************************************************************************************************
 */

PicPblzeAsmImportMetrx::PicPblzeAsmImportMetrx () : PicImport ()
{
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportMetrx::convertLine ( QString * pQString_line )
{
	PicImport::sLineFragments_t sLineFragments;

	// Split lines into fragments
	sLineFragments = PicImport::lineSplit ( * pQString_line );

	PicImport::eRetVal_t eRetVal;

	// Substitute line
	eRetVal = this->lineSubst ( & sLineFragments );

	// Combine fragments to line
	if ( eRetVal == eRetValChanged )
		*pQString_line = PicImport::lineCombine ( & sLineFragments );

	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportMetrx::lineSubst ( PicImport::sLineFragments_t * psLineFragments )
{
	QString QString_cmd  = psLineFragments->QString_2_text.toUpper();
	QString QString_arg0 = psLineFragments->QString_4_text;
	QString QString_arg1 = psLineFragments->QString_6_text;
	
	qDebug() << QString_cmd;

	// Mediatronix assembler specific subset
	     if ( QString ( "RET" )     == QString_cmd ) { return this->chkInstRet     ( psLineFragments ); }
	else if ( QString ( "RETI" )    == QString_cmd ) { return this->chkInstRet     ( psLineFragments ); }
	else if ( QString ( "EINT" )    == QString_cmd ) { return this->chkInstInt     ( psLineFragments ); }
	else if ( QString ( "DINT" )    == QString_cmd ) { return this->chkInstInt     ( psLineFragments ); }
	else if ( QString ( "ADDC" )    == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "SUBC" )    == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "IN" )      == QString_cmd ) { return this->chkInstRegIO   ( psLineFragments ); }
	else if ( QString ( "OUT" )     == QString_cmd ) { return this->chkInstRegIO   ( psLineFragments ); }
	else if ( QString ( "COMP" )    == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }

	// Common used assembler subset
	else if ( QString ( "ADD" )     == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "AND" )     == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "CALL" )    == QString_cmd ) { return this->chkInstBranch  ( psLineFragments ); }
	else if ( QString ( "JUMP" )    == QString_cmd ) { return this->chkInstBranch  ( psLineFragments ); }
	else if ( QString ( "LOAD" )    == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "OR" )      == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "RL" )      == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "RR" )      == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SL0" )     == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SL1" )     == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SLA" )     == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SLX" )     == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SR0" )     == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SR1" )     == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SRA" )     == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SRX" )     == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SUB" )     == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "TEST" )    == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "XOR" )     == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "STORE" )   == QString_cmd ) { return this->chkInstRegIO   ( psLineFragments ); }
	else if ( QString ( "FETCH" )   == QString_cmd ) { return this->chkInstRegIO   ( psLineFragments ); }
	
	// Mediatronix compiler directives
	else if ( QString ( "ORG" )     == QString_cmd )  { return this->chkInstOrg    ( psLineFragments ); }
	else if ( QString ( "EQU" )     == QString_arg0 ) { return this->chkInstEqu    ( psLineFragments ); }
	else if ( QString ( "DS" )      == QString_arg0 ) { return this->chkInstDs     ( psLineFragments ); }
	else if ( QString ( "DSIN" )    == QString_arg0 ) { return this->chkInstDs     ( psLineFragments ); }
	else if ( QString ( "DSOUT" )   == QString_arg0 ) { return this->chkInstDs     ( psLineFragments ); }
	else if ( QString ( "DSIO" )    == QString_arg0 ) { return this->chkInstDs     ( psLineFragments ); }
	else if ( QString ( "DSRAM" )   == QString_arg0 ) { return this->chkInstDs     ( psLineFragments ); }
	else if ( QString ( "DSROM" )   == QString_arg0 ) { return this->chkInstDs     ( psLineFragments ); }
	else if ( QString ( "BROM" )    == QString_arg0 ) { return this->chkInstDs     ( psLineFragments ); }

	// Obsolete directives
	else if ( QString ( "INCL" )    == QString_cmd ) { return this->chkOsolete     ( psLineFragments ); }
	else if ( QString ( "VHDL" )    == QString_cmd ) { return this->chkOsolete     ( psLineFragments ); }
	else if ( QString ( "COE" )     == QString_cmd ) { return this->chkOsolete     ( psLineFragments ); }
	else if ( QString ( "MEM" )     == QString_cmd ) { return this->chkOsolete     ( psLineFragments ); }
	else if ( QString ( "EXEC" )    == QString_cmd ) { return this->chkOsolete     ( psLineFragments ); }















	return eRetValUnchanged;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportMetrx::chkInstRet ( PicImport::sLineFragments_t * psLineFragments )
{
	return eRetValUnchanged;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportMetrx::chkInstInt ( PicImport::sLineFragments_t * psLineFragments )
{
	return eRetValUnchanged;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportMetrx::chkInstRegVari ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_arg1 = psLineFragments->QString_6_text;

	this->chkArgNumber ( & QString_arg1, & eRetVal );
	
	psLineFragments->QString_6_text = QString_arg1;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportMetrx::chkInstBranch ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_arg0 = psLineFragments->QString_4_text;
	QString QString_arg1 = psLineFragments->QString_6_text;

	this->chkArgNumber ( & QString_arg0, & eRetVal );
	this->chkArgNumber ( & QString_arg1, & eRetVal );
	
	psLineFragments->QString_4_text = QString_arg0;
	psLineFragments->QString_6_text = QString_arg1;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportMetrx::chInstReg ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_arg1 = psLineFragments->QString_6_text;

	this->chkArgNumber ( & QString_arg1, & eRetVal );
	
	psLineFragments->QString_6_text = QString_arg1;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportMetrx::chkInstRegIO ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_arg1 = psLineFragments->QString_6_text;

	this->chkArgNumber ( & QString_arg1, & eRetVal );
	
	psLineFragments->QString_6_text = QString_arg1;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportMetrx::chkInstOrg ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_arg0 = psLineFragments->QString_4_text;

	this->chkArgNumber ( & QString_arg0, & eRetVal );
	
	psLineFragments->QString_4_text = QString_arg0;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportMetrx::chkInstEqu ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_arg1 = psLineFragments->QString_6_text;

	if ( ( ! this->chkArgNumber ( & QString_arg1, & eRetVal ) ) && ( ! this->chkArgReg ( & QString_arg1, & eRetVal ) ) )
	{
		return eRetValErr;
	}
	
	psLineFragments->QString_6_text = QString_arg1;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportMetrx::chkInstDs ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_cmd  = QString ( "EQU" );
	QString QString_arg1 = psLineFragments->QString_6_text;

	if ( ! this->chkArgNumber ( & QString_arg1, & eRetVal ) )
		return eRetValErr;

	psLineFragments->QString_4_text = QString_cmd;
	psLineFragments->QString_6_text = QString_arg1;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportMetrx::chkOsolete ( PicImport::sLineFragments_t * psLineFragments )
{
	psLineFragments->QString_0_reference.insert ( 0, QChar (';' ) );
	
	return eRetValChanged;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmImportMetrx::chkArgNumber ( QString * pQString_arg, PicImport::eRetVal_t * peRetVal )
{
	//********************************************************************************************************************
	//* Check for hex $00
	//********************************************************************************************************************
	if ( pQString_arg->contains ( QRegExp ( "^\\$[0-9a-fA-F]*$" ) ) )
	{
		pQString_arg->remove ( 0, 1 );
		pQString_arg->insert ( 0, "0x" );
		
		if ( eRetValUnchanged == *peRetVal )
			*peRetVal = eRetValChanged;
		
		return TRUE;
	}
	//********************************************************************************************************************
	//* Check for decimal
	//********************************************************************************************************************
	else if ( pQString_arg->contains ( QRegExp ( "^[0-9]*$" ) ) )
	{
		return TRUE;
	}
	//********************************************************************************************************************
	//* Check for binary
	//********************************************************************************************************************
	else if ( pQString_arg->contains ( QRegExp ( "^B[0-1]*$" ) ) )
	{
		pQString_arg->remove( 0, 1 );
		
		bool b_success = TRUE;
		
		int i_number = pQString_arg->toInt ( & b_success, 2 );
		
		if ( ! b_success )
		{
			*peRetVal = eRetValErr;
			return FALSE;
		}
		
		*pQString_arg = QString ( "0x%1" ).arg ( QString::number ( i_number, 16 ) );
		
		if ( eRetValUnchanged == *peRetVal )
			*peRetVal = eRetValChanged;
		
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmImportMetrx::chkArgReg ( QString * pQString_arg, PicImport::eRetVal_t * peRetVal )
{
	if ( pQString_arg->contains ( QRegExp ( "^[sS][0-7]$" ) ) )
		return TRUE;

	else if ( pQString_arg->contains ( QRegExp ( "^[sS][0-9a-fA-F]$" ) ) )
		return TRUE;
	
	else if ( pQString_arg->contains ( QRegExp ( "^[sS][0-9a-fA-F][0-9a-fA-F]$" ) ) )
		return TRUE;
	
	else if ( pQString_arg->contains ( QRegExp ( "^[sS][0-9a-fA-F]$" ) ) )
		return TRUE;
	
	return FALSE;
}

/**
 *****************************************************************************************************************************
 */



