/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PrjOpenDlgLstElement.h"
#include "SetPrj.h"

/**
 *****************************************************************************************************************************
 */

PrjOpenDlgLstElement::PrjOpenDlgLstElement ( QWidget * pQWidget_parent ) : QWidget ( pQWidget_parent )
{
	QVBoxLayout * QVBoxLayout_main = new QVBoxLayout;
	{
		QFrame * pQFrame = new QFrame;
		{
			QGridLayout * pQGridLayout_content = new QGridLayout;
			{
				int i_row = 0;
				
				// Setup line 0
				{
					QLabel * pQLabel_title = new QLabel ( "<b>" + QObject::tr ( "Path:" ) + "<b>" );

					this->pQLabel_prjPath = new QLabel;
					this->pQLabel_prjPath->setSizePolicy ( QSizePolicy::Fixed, QSizePolicy::Preferred );
		
					pQGridLayout_content->addWidget ( pQLabel_title,             i_row, 0, 1, 1 );
					pQGridLayout_content->addWidget ( this->pQLabel_prjPath,     i_row, 1, 1, 1 );
				}

				// Setup line 1
				{
					++i_row;
					
					QLabel * pQLabel_title = new QLabel ( "<b>" + QObject::tr ( "File:" ) + "<b>" );

					this->pQLabel_prjFile = new QLabel;
					this->pQLabel_prjFile->setSizePolicy ( QSizePolicy::Fixed, QSizePolicy::Preferred );
		
					pQGridLayout_content->addWidget ( pQLabel_title,            i_row, 0, 1, 1 );
					pQGridLayout_content->addWidget ( this->pQLabel_prjFile,    i_row, 1, 1, 1 );
				}

				// Setup line 2
				{
					++i_row;

					QLabel * pQLabel_title = new QLabel ( "<b>" + QObject::tr ( "Version:" ) + "<b>" );
			
					this->pQLabel_prjVersion = new QLabel;
					this->pQLabel_prjVersion->setSizePolicy ( QSizePolicy::Fixed, QSizePolicy::Preferred );
			
					pQGridLayout_content->addWidget ( pQLabel_title,            i_row, 0, 1, 1 );
					pQGridLayout_content->addWidget ( this->pQLabel_prjVersion, i_row, 1, 1, 1 );
				}
				{
					++i_row;

					QLabel * pQLabel_title = new QLabel ( "<b>" + QObject::tr ( "Processor:" ) + "<b>" );
			
					this->pQLabel_processor = new QLabel;
					this->pQLabel_processor->setSizePolicy ( QSizePolicy::Fixed, QSizePolicy::Preferred );
			
					pQGridLayout_content->addWidget ( pQLabel_title,             i_row, 0, 1, 1 );
					pQGridLayout_content->addWidget ( this->pQLabel_processor,   i_row, 1, 1, 1 );
				}

				// Setup line 3
				{
					++i_row;

					QLabel * pQLabel_title = new QLabel ( "<b>" + QObject::tr ( "Title:" ) + "<b>" );

					this->pQLabel_prjTitle = new QLabel;
					this->pQLabel_prjTitle->setSizePolicy ( QSizePolicy::Fixed, QSizePolicy::Preferred );
		
					pQGridLayout_content->addWidget ( pQLabel_title,             i_row, 0, 1, 1 );
					pQGridLayout_content->addWidget ( this->pQLabel_prjTitle,    i_row, 1, 1, 3 );
				}

				// Setup line 4
				{
					++i_row;

					QLabel * pQLabel_title = new QLabel ( "<b>" + QObject::tr ( "Comment:" ) + "<b>" );

					pQGridLayout_content->addWidget ( pQLabel_title,             i_row, 0, 1, 1 );
				}

				// Setup line 5
				{
					++i_row;

					this->pQTextBrowser_comment = new QTextBrowser;

					pQGridLayout_content->addWidget ( this->pQTextBrowser_comment, i_row, 0, 1, 4 );
				}

				// Setup line 6
				{
					++i_row;

					QHBoxLayout * pQHBoxLayout_buttons = new QHBoxLayout;
					{
						// Set Buttons
						QPushButton * pQPushButton_remove = new QPushButton ( QObject::tr ( "Remove from collection" ) );
						QPushButton * pQPushButton_open   = new QPushButton ( QObject::tr ( "Open" ) );
				
						connect ( pQPushButton_remove, SIGNAL ( clicked() ), this, SLOT ( hndlRemoveButton() ) );
						connect ( pQPushButton_open,   SIGNAL ( clicked() ), this, SLOT ( hndlOpenButton() ) );
				
						pQHBoxLayout_buttons->addWidget ( pQPushButton_remove );
						pQHBoxLayout_buttons->addStretch ( 1 );
						pQHBoxLayout_buttons->addWidget ( pQPushButton_open );
					}
					pQGridLayout_content->addLayout ( pQHBoxLayout_buttons, i_row, 0, 1, 4 );
				}
			}

			QPalette QPalette_actual = pQFrame->palette();
			QPalette_actual.setColor ( QPalette::Normal, QPalette::Foreground, Qt::black );
			pQFrame->setPalette ( QPalette_actual );

			pQFrame->setFrameShape ( QFrame::Box );
			pQFrame->setFrameShadow ( QFrame::Plain );

			pQFrame->setLayout ( pQGridLayout_content );
		}
		QVBoxLayout_main->addWidget ( pQFrame );
	}

	QWidget::setLayout ( QVBoxLayout_main );
}

/**
 *****************************************************************************************************************************
 */

bool PrjOpenDlgLstElement::setPrjFilePath ( QString QString_prjFilePath )
{
	SetPrj SetPrj_tmp;
	
	if ( ! SetPrj_tmp.openPrj ( QString_prjFilePath ) )
		return FALSE;

	this->QString_prjFilePath = SetPrj_tmp.sPrj.QString_prjPath + SetPrj_tmp.sPrj.QString_prjFile;
	
	// Truncate path
	if ( SetPrj_tmp.sPrj.QString_prjPath.size() > 50 )
	{
		this->pQLabel_prjPath->setText ( "..." + SetPrj_tmp.sPrj.QString_prjPath.right ( 50 ) );
	}
/*	else
	{
		this->pQLabel_prjPath->setText ( SetPrj_tmp.sPrj.QString_prjPath );
	}*/
	
	// Set settings to gui
	
	this->pQLabel_prjFile->setText       ( SetPrj_tmp.sPrj.QString_prjFile );
	this->pQLabel_prjVersion->setText    ( SetPrj_tmp.sVer.QString_version );
	this->pQLabel_prjTitle->setText      ( SetPrj_tmp.sVer.QString_title );
	this->pQTextBrowser_comment->setText ( SetPrj_tmp.sVer.QString_comment );
	this->pQLabel_processor->setText     ( SetPrj_tmp.sPic.QString_picType );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

QString PrjOpenDlgLstElement::getPrjFilePath ( void )
{
	return this->QString_prjFilePath;
}

/**
 *****************************************************************************************************************************
 */

void PrjOpenDlgLstElement::hndlOpenButton ( void )
{
	emit reqOpen ( this );
}

/**
 *****************************************************************************************************************************
 */

void PrjOpenDlgLstElement::hndlRemoveButton ( void )
{
	emit reqRemove ( this );
}

/**
 *****************************************************************************************************************************
 */

void PrjOpenDlgLstElement::mouseDoubleClickEvent ( QMouseEvent * pQMouseEvent )
{
	emit reqOpen ( this );
}

/**
 *****************************************************************************************************************************
 */
