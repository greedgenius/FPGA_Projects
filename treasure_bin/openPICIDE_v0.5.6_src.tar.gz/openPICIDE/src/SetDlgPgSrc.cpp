/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "SetDlgPgSrc.h"

/**
 *****************************************************************************************************************************
 */

SetDlgPgSrc::SetDlgPgSrc ( SetPrj * pSetPrj_dlg, QWidget * pQWidget_parent ) : QWidget ( pQWidget_parent )
{
	this->pSetPrj_dlg = pSetPrj_dlg;

	// Files group box
	QGroupBox * pQGroupBox_sourceFiles = new QGroupBox ( tr ( "Source file settings" ) );
	{
		// Files group box layout
		QHBoxLayout * pQHBoxLayout_groupBox = new QHBoxLayout;
		{
			// Set file table
			this->pQStandardItemModel_sourceFiles = new QStandardItemModel();
			this->pQStandardItemModel_sourceFiles->setColumnCount ( 1 );
			this->pQStandardItemModel_sourceFiles->setRowCount ( 0 );
			this->pQStandardItemModel_sourceFiles->sort ( Qt::AscendingOrder );

			this->pQListView_sourceFiles = new QListView();
			this->pQListView_sourceFiles->setModel ( this->pQStandardItemModel_sourceFiles );
			this->pQListView_sourceFiles->setAlternatingRowColors ( TRUE );

			// Set button layout
			QVBoxLayout * pQVBoxLayout_buttons = new QVBoxLayout;
			{
				// Set buttons
				QPushButton * pQPushButton_add    = new QPushButton ( tr ( "Add" ) );
				QPushButton * pQPushButton_remove = new QPushButton ( tr ( "Remove" ) );
				QPushButton * pQPushButton_up     = new QPushButton ( tr ( "Up" ) );
				QPushButton * pQPushButton_down   = new QPushButton ( tr ( "Down" ) );

				// Connect buttons
				connect ( pQPushButton_add,    SIGNAL ( clicked ( ) ), this, SLOT ( addFile ( ) ) );
				connect ( pQPushButton_remove, SIGNAL ( clicked ( ) ), this, SLOT ( removeFile ( ) ) );
				connect ( pQPushButton_up,     SIGNAL ( clicked ( ) ), this, SLOT ( moveUp ( ) ) );
				connect ( pQPushButton_down,   SIGNAL ( clicked ( ) ), this, SLOT ( moveDown ( ) ) );

				// Add elements to layout
				pQVBoxLayout_buttons->addWidget ( pQPushButton_add );
				pQVBoxLayout_buttons->addWidget ( pQPushButton_remove );
				pQVBoxLayout_buttons->addWidget ( pQPushButton_up );
				pQVBoxLayout_buttons->addWidget ( pQPushButton_down );
				pQVBoxLayout_buttons->addStretch ( 1 );
			}

			// Add elements to layout
			pQHBoxLayout_groupBox->addWidget ( pQListView_sourceFiles );
			pQHBoxLayout_groupBox->addLayout ( pQVBoxLayout_buttons );
		}

		pQGroupBox_sourceFiles->setLayout ( pQHBoxLayout_groupBox );
	}

	// Set Page Layout
	QVBoxLayout * pQVBoxLayout_page = new QVBoxLayout;
	pQVBoxLayout_page->addWidget ( pQGroupBox_sourceFiles );
	setLayout ( pQVBoxLayout_page );

	// Set settings
	this->setSrcFileList ( pSetPrj_dlg->sSrc.QStringList_srcFiles );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgSrc::addFile ( void )
{
	// Setup file dialog
	QFileDialog QFileDialog_file;
	QFileDialog_file.setViewMode ( QFileDialog::Detail );
	QFileDialog_file.setDefaultSuffix ( QString ( "psm" ) );
	QFileDialog_file.setAcceptMode ( QFileDialog::AcceptOpen );
	QFileDialog_file.setWindowTitle ( tr ( "Select psm template file" ) );
	QFileDialog_file.setNameFilter ( tr ( "VHDL files (*.psm)" ) );
	QFileDialog_file.setFileMode ( QFileDialog::ExistingFiles );

	// Select files
	if ( ! QFileDialog_file.exec () )
		return;

	QStringList QStringList_filesSel = QFileDialog_file.selectedFiles ();

	if ( QStringList_filesSel.count () < 1 )
		return;

	// Get files list from project
	QStringList QStringList_srcFileListTmp;
	QStringList_srcFileListTmp = this->getSrcFileList ();

	for ( int i_iterator = 0; i_iterator < QStringList_filesSel.size(); i_iterator++ )
	{
		QString QString_fileSel = this->pSetPrj_dlg->getRelativeFilePath ( QStringList_filesSel.at ( i_iterator ) );

		// Check, if path located within project folder
		if ( QString_fileSel.startsWith ( QString ( "../" ), Qt::CaseSensitive ) )
		{
			QString QString_message;
			QString_message  = QString_fileSel;
			QString_message += QString ( ": \n\n" );
			QString_message += QString ( tr ( "Only files located beneath the project folder could be added to project." ) );

			QMessageBox::warning ( this, tr ( "Adding file" ), QString_message, QMessageBox::Ok, QMessageBox::Ok );
			continue;
		}

		// Check, if file still available in project
		if ( QStringList_srcFileListTmp.contains ( QString_fileSel ) )
		{
			QString QString_message;
			QString_message  = QString_fileSel;
			QString_message += QString ( ": \n\n" );
			QString_message += QString ( tr ( "File is already existent in the project." ) );

			QMessageBox::warning ( this, tr ( "Adding file" ), QString_message, QMessageBox::Ok, QMessageBox::Ok );
			continue;
		}

		QStringList_srcFileListTmp << QString_fileSel;
	}

	this->setSrcFileList ( QStringList_srcFileListTmp );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgSrc::removeFile ( void )
{
	QModelIndex QModelIndex_Current = this->pQListView_sourceFiles->currentIndex();

	if ( QModelIndex_Current.isValid() )
	{
		int i_row = QModelIndex_Current.row();
		this->pQStandardItemModel_sourceFiles->removeRow ( i_row );
	}
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgSrc::getSet ( void )
{
	// Clear old file list
	this->pSetPrj_dlg->sSrc.QStringList_srcFiles.clear();

	// Set actual file list
	this->pSetPrj_dlg->sSrc.QStringList_srcFiles = getSrcFileList();
}

/**
 *****************************************************************************************************************************
 */

QStringList SetDlgPgSrc::getSrcFileList ( void )
{
	QStringList QStringList_tmp;

	for ( int i_iterator = 0; i_iterator < pQStandardItemModel_sourceFiles->rowCount(); i_iterator++ )
	{
		QString QString_relFilePath = this->pQStandardItemModel_sourceFiles->item ( i_iterator, 0 )->text();
		QString QString_absFilePath = this->pSetPrj_dlg->getAbsoluteFilePath ( QString_relFilePath );

		QStringList_tmp <<  ( QString_absFilePath );
	}

	return QStringList_tmp;
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgSrc::setSrcFileList ( QStringList QStringList_srcFiles )
{
	this->pQStandardItemModel_sourceFiles->clear();

	for ( int i_iterator = 0; i_iterator < QStringList_srcFiles.size(); i_iterator++ )
	{
		QString QString_relFilePath = this->pSetPrj_dlg->getRelativeFilePath ( QStringList_srcFiles.at ( i_iterator ) );
		// Append filename to list
		QStandardItem * pQStandardItem_temp = new QStandardItem ( QString_relFilePath );
		this->pQStandardItemModel_sourceFiles->appendRow ( pQStandardItem_temp );
	}
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgSrc::moveUp ( void )
{
	QModelIndex QModelIndex_current = this->pQListView_sourceFiles->currentIndex ();

	if ( ! QModelIndex_current.isValid () )
		return;

	int i_row = QModelIndex_current.row ();

	if ( i_row <= 0 )
		return;

	// Get row content
	QString QString_filePath = this->pQStandardItemModel_sourceFiles->item ( i_row, 0 )->text();

	// Remove row
	this->pQStandardItemModel_sourceFiles->removeRow ( i_row );

	// Insert row
	QStandardItem * pQStandardItem = new QStandardItem ( QString_filePath );
	this->pQStandardItemModel_sourceFiles->insertRow ( --i_row, pQStandardItem );

	// Select inserted row
	this->pQListView_sourceFiles->setCurrentIndex (  this->pQStandardItemModel_sourceFiles->indexFromItem ( pQStandardItem )  );
}

/**
 *****************************************************************************************************************************
 */

void SetDlgPgSrc::moveDown ( void )
{
	QModelIndex QModelIndex_current = this->pQListView_sourceFiles->currentIndex ();

	if ( ! QModelIndex_current.isValid () )
		return;

	int i_row = QModelIndex_current.row ();

	if ( i_row >= this->pQStandardItemModel_sourceFiles->rowCount () - 1 )
		return;

	// Get row content
	QString QString_filePath = this->pQStandardItemModel_sourceFiles->item ( i_row, 0 )->text();

	// Remove row
	this->pQStandardItemModel_sourceFiles->removeRow ( i_row );

	// Insert row
	QStandardItem * pQStandardItem = new QStandardItem ( QString_filePath );
	this->pQStandardItemModel_sourceFiles->insertRow ( ++i_row, pQStandardItem );

	// Select inserted row
	this->pQListView_sourceFiles->setCurrentIndex (  this->pQStandardItemModel_sourceFiles->indexFromItem ( pQStandardItem )  );
}

/**
 *****************************************************************************************************************************
 */


















