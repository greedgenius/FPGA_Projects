/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeMMViewer.h"
// #include "string.h"

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Constructor
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

PicPblzeMMViewer::PicPblzeMMViewer ( QObject * pQObject_parent ) : PicPblzeAsmParser ( pQObject_parent )
{
	
}

/**
 *****************************************************************************************************************************
 */

PicPblzeMMViewer::~PicPblzeMMViewer ( void )
{
	
	
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeMMViewer::setCfg ( sCfg_t sCfg )
{
	this->sCfg = sCfg;
	
	// Set parser parameter
	if ( ! PicPblzeAsmParser::setCfg ( this->sCfg.sCfg_asmParser ) )
		return FALSE;

// 	// Check files
// 	{
// 		QFileInfo QFileInfo_check;
// 
// 		// Check output file
// 		{
// 			QFileInfo_check.setFile ( this->sCfg.QString_outputFilePath );
// 			
// 			// Check, if file exists and is writable
// 			if ( QFileInfo_check.exists () && ( ! QFileInfo_check.isWritable () ) )
// 			{
// 				this->msgEmit ( eMsgType_outputFileIO );
// 				return FALSE;
// 			}
// 		}
// 	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

// bool PicPblzeMMViewer::generateMemMapFile ( void )
// {
// 	QString QString_memMap;
// 	
// 	// Generate memory map
// 	if ( ! this->generateMemMap ( & QString_memMap ) )
// 		return FALSE;
// 	
// 	// Open destination file
// 	QFile QFile_output ( this->sCfg.QString_outputFilePath );
// 
// 	if ( ! QFile_output.open ( QIODevice::ReadWrite | QIODevice::Text ) )
// 	{
// 		this->msgEmit ( eMsgType_outputFileIO );
// 		return FALSE;
// 	}
// 
// 	// Set file size to zero
// 	QFile_output.resize ( 0 );
// 
// 	QTextStream QTextStream_output ( & QFile_output );
// 	{
// 		QTextStream_output << QString_memMap;
// 	}
// 	
// 	QFile_output.close();
// 
// 	return TRUE;
// }

bool PicPblzeMMViewer::generateMemMap ( QString * pQString_memMap )
{
	// Parse code
	if ( ! PicPblzeAsmParser::parse () )
		return FALSE;
	
	pQString_memMap->append ( "Range  | Address | Code line\n" );
	
	sCodeLine_t * psCodeLine = PicPblzeAsmParser::psCodeLine_start;

	while ( psCodeLine )
	{
		if ( ! psCodeLine )
			continue;
		
		if ( psCodeLine->eLineType > PicPblzeAsmParser::eLineType_cmd )
		{
			switch ( psCodeLine->eMFlag )
			{
				case eMFlag_unset:	pQString_memMap->append ( "Unset " );	break;
				case eMFlag_shared:	pQString_memMap->append ( "Shared" );	break;
				case eMFlag_bank0:	pQString_memMap->append ( "Bank0 " );	break;
				case eMFlag_bank1:	pQString_memMap->append ( "Bank1 " );	break;
				case eMFlag_bank2:	pQString_memMap->append ( "Bank2 " );	break;
				case eMFlag_bank3:	pQString_memMap->append ( "Bank3 " );	break;
				default:		pQString_memMap->append ( "Error " );	break;
			}
			
			pQString_memMap->append ( " | 0x" + QString ( "%1" ).arg ( psCodeLine->i_addr, 5, 16, QChar ( '0' ) ).toUpper () );
		}
		else
		{
			pQString_memMap->append ( QString ( "       |        " ) );
		}
		
		pQString_memMap->append ( " | " + psCodeLine->QString_line );
		
		psCodeLine = psCodeLine->psCodeLine_next;
	}
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Message handling
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

void PicPblzeMMViewer::msgEmit ( eMsgType_t eMsgType )
{
	Msg * pMsg = new Msg;
	
	this->msgEmit ( pMsg, eMsgType );
}

/**
 *****************************************************************************************************************************
 */

// void PicPblzeMMViewer::msgEmit ( eMsgType_t eMsgType, sCodeLine_t * psCodeLine )
// {
// 	Msg * pMsg = new Msg;
// 	
// 	pMsg->QUrl_srcUrl.setScheme( "file" );
// 	pMsg->QUrl_srcUrl.setPath ( PicPblzeAsmParser::msgGetFilePath ( psCodeLine->i_fileNumber ) );
// 	pMsg->QUrl_srcUrl.setFragment ( QString::number ( psCodeLine->i_lineNumber ) );
// 	
// 	this->msgEmit ( pMsg, eMsgType );
// }

/**
 *****************************************************************************************************************************
 */

void PicPblzeMMViewer::msgEmit ( Msg * pMsg, eMsgType_t eMsgType )
{
	QString QString_hlpFragment;
	
	// Set message text
	switch ( eMsgType )
	{
// 		// Warnings
// 		case eMsgType_tmemStuffing:
// 			
// 			QString_hlpFragment 	= "tmemStuffing";
// 			pMsg->eStatus 		= Msg::e_warning;
// 			pMsg->QString_msg 	= tr ( "Template memory size bigger than expected: Stuffing with zeros" );
// 			break;

/*		// Error messages
		case eMsgType_templateFileIO:
			
			QString_hlpFragment 	= "templateFileIO";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Template file I/O error" );
			break;*/
			
		case eMsgType_outputFileIO:
			
			QString_hlpFragment 	= "outputFileIO";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Output file I/O error" );
			break;
			
/*		case eMsgType_entityName:
			
			QString_hlpFragment 	= "entityName";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Entity name not set" );
			break;
			*/
/*		case eMsgType_compError:
			
			QString_hlpFragment 	= "compError";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Compile error" );
			break;*/
			
/*		case eMsgType_tmemSizeToSmall:
			
			QString_hlpFragment 	= "tmemSizeToSmall";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Template memory size too small" );
			break;*/
	}

	pMsg->QUrl_hlpUrl = QUrl ( "qthelp://openPICIDE/openPICIDE/openPICIDE/800_processors/XilinxPicoBlaze/800_messages/index.html" );

	pMsg->QUrl_hlpUrl.setFragment ( QString_hlpFragment );
	
	emit PicPblzeAsmParser::message ( pMsg );
}

/**
 *****************************************************************************************************************************
 */
