/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef SetApp_H
#define SetApp_H

#include <QtCore>
#include <QtGui>

/**
 *****************************************************************************************************************************
 *
 *	\brief SetApp class
 *
 *      Contains application settings.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2010-03-26
 *	\version	0.1.0
 *
 *	Change log
 *
 *	2010-03-26
 *		Initialized
 *
 *****************************************************************************************************************************
 */

class SetApp
{

	public:

		// Constructor
		SetApp ();

		/// Reads settings from environment
		void read ( void );
		
		/// Reads settings from environment
		void save ( void );
		
		/// Marks settings as dirty
		void setDirty ( void );
		
		/// Gets platform the application runs on
		QString getPlatform ( void );

		/// Get nominal font
		QString getNominalFont ( void );
		
		/// Generates a pseudo random serial number
		QString genRandomSerNo ( void );

		/// Check serial number. openPICIDE was delivered with an
		/// insufficient serial number generator in version 0.4.0
		/// who produces only one serial number ;-(
		void checkSerNo ( void );
		
		void setStyle ( void );

		enum eChkIval_t {
			eChkIvalNever   = 0,
			eChkIvalDaily   = 1,
			eChkIvalWeekly  = 2,
			eChkIvalMonthly = 3
		};
		
		/// Support settings
		struct sSup_t
		{
			eChkIval_t eChkIval;
			QDate   QDate_lstUpdateChk;
			QString QString_serNo;
			QString QString_appVer;
			QString QString_platform;
			QString QString_updateServer;
			
			bool b_showStartInfo;
			bool b_showHlpCtrlOnRightSide;
			QString QString_hlpCollectionFile;
		} sSup;
		
		/// Window settings
		struct sGui_t
		{
			int i_mainWindowHeight;
			int i_mainWindowWidth;
			int i_mainWindowX;
			int i_mainWindowY;
			
			int i_iconSize;
			
			int i_style;
		} sGui;
		
		/// Project settings
		struct sPrj_t
		{
			QStringList QStringList_recent;
			QStringList QStringList_collection;
		} sPrj;
		
		/// Structure, containing editor settings.
		struct sEdt_t
		{
			int  i_tabIndent;				/// The Tabulator indent of the text editor.
			bool b_dynamicWordWrapEn;			/// Enables/disables dynamic word wrap of the text editor.
			QColor QColor_bgCursor;				/// Background color for cursor
			QColor QColor_bgHighlight;			/// Background color for highlighted lines

			QFont QFont_std;
			QTextCharFormat QTextCharFormat_cmd;		/// Highlighting format for assembler commands
			QTextCharFormat QTextCharFormat_directive;	/// Highlighting format for preassemlber commands
			QTextCharFormat QTextCharFormat_hw;		/// Highlighting format for register
			QTextCharFormat QTextCharFormat_hexNumber;	/// Highlighting format for hexadecimal numbers
			QTextCharFormat QTextCharFormat_decNumber;	/// Highlighting format for decimal numbers
			QTextCharFormat QTextCharFormat_octNumber;	/// Highlighting format for octal numbers
			QTextCharFormat QTextCharFormat_comment;	/// Highlighting format for single line comments
			QTextCharFormat QTextCharFormat_separator;	/// Highlighting format for multiline comments
			QTextCharFormat QTextCharFormat_fct;		/// Highlighting format for functions
			QTextCharFormat QTextCharFormat_doc;		/// Highlighting format for documentation
			QTextCharFormat QTextCharFormat_navi;		/// Highlighting format for navi
		} sEdt;
};

#endif
 
 
