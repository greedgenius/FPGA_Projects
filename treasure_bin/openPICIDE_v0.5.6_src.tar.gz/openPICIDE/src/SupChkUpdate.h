/*****************************************************************************************************************************
 *   Copyright (C) 2010 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef SupChkUpdate_H
#define SupChkUpdate_H

#include <QtGui>
#include <QtCore>
#include <QNetworkAccessManager>
#include <QHttp>

/**
 *****************************************************************************************************************************
 *
 *      \brief Text editor widget wrapper.
 *
 *	The wrapper widget handles the status from editor widget.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2010-03-06
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class SupChkUpdate : public QObject
{
		Q_OBJECT

	public:

		/// Constructor.
		/// \param pQWidget_Parent		Reference to parent widget
		SupChkUpdate ( QObject * pQObject_parent = 0 );

		/// Enables proxy mode
		/// \param QString_host
		/// \param i_port
		/// \param QString_username
		/// \param QString_password
		void cfgProxy ( QString QString_host, int i_port, QString QString_username, QString QString_password );

		/// Shows a dialog box with update information
		void showUpdateInfo ( void );

		struct sUpdateInfo_t {
			
			/// Update info answer from server. True, if the current version is beeing expired.
			bool b_expired;
		
			/// Current release
			QString QString_curRelease;

			/// Release information
			QString QString_releaseInfo;
		};
		
	public slots:
		
		/// Checks for update
		/// \param QString_curRelease		Current release
		void chkUpdate ( QString QString_curRelease, QString QString_serNo, QString QString_platform, bool b_quiet );

	signals:
		
		void updateInfo ( SupChkUpdate::sUpdateInfo_t * );
		
		void expired ( bool );
		
	private:

		/// Handles http protocol
		QHttp * pQHttp;
		
		/// Update infos
		sUpdateInfo_t sUpdateInfo;
		
		
		/// Interprets update info form server
		bool getUpdateInfo ( void );
		
		/// Interprets update info version 1 from server
		bool getUpdateInfoV01 ( QXmlStreamReader * pQXmlStreamReader );
		
		
	private slots:
		
		/// Handles received http data
		void httpRequestFinished ( int, bool );

};

#endif
