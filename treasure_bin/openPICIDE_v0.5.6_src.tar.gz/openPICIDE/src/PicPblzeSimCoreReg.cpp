/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeSimCoreReg.h"


/**
 *****************************************************************************************************************************
 */

PicPblzeSimCoreReg::PicPblzeSimCoreReg ( int i_regCountA, int i_regCountB, QWidget * pQWidget_parent ) : QWidget ( pQWidget_parent )
{
	this->sReg.asRegValue_bankA = NULL;
	this->sReg.asRegValue_bankB = NULL;

	int i_regNameLen = 1;
	{
		if ( ( i_regCountA > 16 ) || ( i_regCountB > 16 ) )
			i_regNameLen = 2;
	}
	
	this->sReg.i_regCountA = i_regCountA;
	this->sReg.i_regCountB = i_regCountB;

	QVBoxLayout * pQVBoxLayout = new QVBoxLayout ( this );
	{
		QHBoxLayout * pQHBoxLayout = new QHBoxLayout ( this );
		{
			this->sReg.pQComboBox_bankSel = new QComboBox ( this );
			{
				this->sReg.pQComboBox_bankSel->addItem ( "A", eBankSel_A );
				
				if ( this->sReg.i_regCountB > 0 )
					this->sReg.pQComboBox_bankSel->addItem ( "B", eBankSel_B );
				
				this->sReg.pQComboBox_bankSel->setCurrentIndex ( 0 );
				
			}
			pQHBoxLayout->addWidget ( new QLabel ( "Bank:" ) );
			pQHBoxLayout->addWidget ( this->sReg.pQComboBox_bankSel );
			pQHBoxLayout->addStretch ();
		}
		
		this->sReg.pQStackedWidget = new QStackedWidget ( this );
		{
			this->sReg.pQStackedWidget->addWidget ( this->setupBank ( eBankSel_A, this->sReg.i_regCountA, i_regNameLen ) );
			this->sReg.pQStackedWidget->addWidget ( this->setupBank ( eBankSel_B, this->sReg.i_regCountB, i_regNameLen ) );
			
			connect ( 
				this->sReg.pQComboBox_bankSel, 
					SIGNAL ( currentIndexChanged ( int ) ), 
					this->sReg.pQStackedWidget, 
					SLOT ( setCurrentIndex ( int ) ) 
			);
		}
		
		pQVBoxLayout->addLayout ( pQHBoxLayout );
		pQVBoxLayout->addWidget ( this->sReg.pQStackedWidget );
	}

	QWidget::setLayout ( pQVBoxLayout );
	QWidget::setContentsMargins ( 0, 0, 0, 0 );
}

/**
 *****************************************************************************************************************************
 */

PicPblzeSimCoreReg::~PicPblzeSimCoreReg ()
{
	if ( this->sReg.asRegValue_bankA )
		delete[] this->sReg.asRegValue_bankA;

	if ( this->sReg.asRegValue_bankB )
		delete[] this->sReg.asRegValue_bankB;
}

/**
 *****************************************************************************************************************************
 */

QWidget * PicPblzeSimCoreReg::setupBank ( eBankSel_t eBankSel, int i_regCount, int i_regNameLen )
{
	sRegValue_t * asRegValue_bank = new sRegValue_t [ i_regCount ];

	switch ( eBankSel )
	{
		case eBankSel_A:	this->sReg.asRegValue_bankA = asRegValue_bank;	break;
		case eBankSel_B:	this->sReg.asRegValue_bankB = asRegValue_bank;	break;
	}
	
	QWidget * pQWidget = new QWidget;
	{
		QVBoxLayout * pQVBoxLayout = new QVBoxLayout ( pQWidget );
		{
			QFont QFont_bold;
			QFont_bold.setBold ( TRUE );
	
			for ( int i_iterator = 0; i_iterator < i_regCount; ++i_iterator )
			{
				QString QString_regName = "s" + QString ( "%1" ).arg ( i_iterator, i_regNameLen, 16, QChar ( '0' ) ).toUpper();
				
				sRegValue_t * psRegValue = & asRegValue_bank[ i_iterator ];
				
				psRegValue->QLabel_regName.setFont ( QFont_bold );
				psRegValue->QLabel_regName.setText ( QString_regName );
				
				int i_charWidth = QFontMetrics ( psRegValue->QLabel_regName.font() ).width ( QChar ( '0' ) );

				psRegValue->QLabel_regName.setMinimumWidth ( i_charWidth * ( QString_regName.length () + 1 ) );

// 				psRegValue->PicEdtInteger_value.setW
				
				QHBoxLayout * pQHBoxLayout = new QHBoxLayout;
				{
					pQHBoxLayout->addWidget ( & ( psRegValue->QLabel_regName ) );
					pQHBoxLayout->addWidget ( & ( psRegValue->PicEdtInteger_value ) );
					pQHBoxLayout->addWidget ( & ( psRegValue->QLabel_regSubst ) );
					pQHBoxLayout->addStretch ();

					pQHBoxLayout->setSpacing ( 0 );
					pQHBoxLayout->setContentsMargins ( 0, 0, 0, 0 );
// 					pQHBoxLayout->setSizeConstraint ( QLayout::SetMinimumSize );

					pQVBoxLayout->addLayout ( pQHBoxLayout );
				}
			}
			pQVBoxLayout->setSpacing ( 0 );
			pQVBoxLayout->setContentsMargins ( 0, 0, 0, 0 );
		}
		pQWidget->setLayout ( pQVBoxLayout );
		pQWidget->setContentsMargins ( 0, 0, 0, 0 );
	}
	return pQWidget;
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCoreReg::resetTabOrder ( void )
{
/*	sRegValue_t * psRegValue_prev = this->psRegValue_start;
	sRegValue_t * psRegValue_next = this->psRegValue_start->psRegValue_nxt;
	
	while ( psRegValue_prev && psRegValue_next )
	{
		QWidget::setTabOrder ( & psRegValue_prev->PicEdtInteger_value, & psRegValue_next->PicEdtInteger_value );
		
		psRegValue_prev = psRegValue_next;
		psRegValue_next = psRegValue_next->psRegValue_nxt;
	}*/
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCoreReg::setBase ( int i_base )
{
	// Set bank A
	for ( int i_iterator = 0; i_iterator < this->sReg.i_regCountA; ++i_iterator )
		this->sReg.asRegValue_bankA[ i_iterator ].PicEdtInteger_value.setBase ( i_base );

	// Set bank B
	for ( int i_iterator = 0; i_iterator < this->sReg.i_regCountB; ++i_iterator )
		this->sReg.asRegValue_bankB[ i_iterator ].PicEdtInteger_value.setBase ( i_base );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCoreReg::setRegister ( QString QString_regName, QString QString_regSubst, int i_value )
{
	switch ( this->getBank() )
	{
		case eBankSel_A:
			
			for ( int i_iterator = 0; i_iterator < this->sReg.i_regCountA; ++i_iterator )
			{
				sRegValue_t * psRegValue = & this->sReg.asRegValue_bankA[ i_iterator ];
				
				if ( psRegValue->QLabel_regName.text() != QString_regName )
					continue;
				
				psRegValue->PicEdtInteger_value.setHighlighted ( TRUE );
				psRegValue->QLabel_regSubst.setText ( QString_regSubst );
				
				return psRegValue->PicEdtInteger_value.setValue ( i_value );
			}
			break;
			
		case eBankSel_B:
			
			for ( int i_iterator = 0; i_iterator < this->sReg.i_regCountB; ++i_iterator )
			{
				sRegValue_t * psRegValue = & this->sReg.asRegValue_bankB[ i_iterator ];
				
				if ( psRegValue->QLabel_regName.text() != QString_regName )
					continue;
				
				psRegValue->PicEdtInteger_value.setHighlighted ( TRUE );
				psRegValue->QLabel_regSubst.setText ( QString_regSubst );
				
				return psRegValue->PicEdtInteger_value.setValue ( i_value );
			}
			break;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCoreReg::getRegister ( QString QString_regName, QString QString_regSubst, int * pi_value )
{
	switch ( this->getBank () )
	{
		case eBankSel_A:
			
			for ( int i_iterator = 0; i_iterator < this->sReg.i_regCountA; ++i_iterator )
			{
				sRegValue_t * psRegValue = & this->sReg.asRegValue_bankA[ i_iterator ];
				
				if ( psRegValue->QLabel_regName.text() != QString_regName )
					continue;
				
				psRegValue->QLabel_regSubst.setText ( QString_regSubst );
				
				return psRegValue->PicEdtInteger_value.getValue ( pi_value );
			}
			break;
			
		case eBankSel_B:
			
			
			for ( int i_iterator = 0; i_iterator < this->sReg.i_regCountB; ++i_iterator )
			{
				sRegValue_t * psRegValue = & this->sReg.asRegValue_bankB[ i_iterator ];
				
				if ( psRegValue->QLabel_regName.text() != QString_regName )
					continue;
				
				psRegValue->QLabel_regSubst.setText ( QString_regSubst );
				
				return psRegValue->PicEdtInteger_value.getValue ( pi_value );
			}
			break;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCoreReg::clearHighlighted ( void )
{
	for ( int i_iterator = 0; i_iterator < this->sReg.i_regCountA; ++i_iterator )
		this->sReg.asRegValue_bankA[ i_iterator ].PicEdtInteger_value.setHighlighted ( FALSE );
	
	for ( int i_iterator = 0; i_iterator < this->sReg.i_regCountB; ++i_iterator )
		this->sReg.asRegValue_bankB[ i_iterator ].PicEdtInteger_value.setHighlighted ( FALSE );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimCoreReg::clear ( void )
{
	for ( int i_iterator = 0; i_iterator < this->sReg.i_regCountA; ++i_iterator )
	{
		sRegValue_t * psRegValue = & this->sReg.asRegValue_bankA[ i_iterator ];
				
		psRegValue->PicEdtInteger_value.setHighlighted ( FALSE );
		psRegValue->PicEdtInteger_value.setValue ( 0 );
		psRegValue->QLabel_regSubst.setText ( QString ( "" ) );
	}

	for ( int i_iterator = 0; i_iterator < this->sReg.i_regCountB; ++i_iterator )
	{
		sRegValue_t * psRegValue = & this->sReg.asRegValue_bankB[ i_iterator ];
				
		psRegValue->PicEdtInteger_value.setHighlighted ( FALSE );
		psRegValue->PicEdtInteger_value.setValue ( 0 );
		psRegValue->QLabel_regSubst.setText ( QString ( "" ) );
	}
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCoreReg::setBank ( eBankSel_t eBankSel )
{
	switch ( eBankSel )
	{
		case eBankSel_A:	this->sReg.pQComboBox_bankSel->setCurrentIndex ( eBankSel_A );	return TRUE;
		case eBankSel_B:	this->sReg.pQComboBox_bankSel->setCurrentIndex ( eBankSel_B );	return TRUE;
	}
	
	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

PicPblzeSimCoreReg::eBankSel_t PicPblzeSimCoreReg::getBank ( void )
{
	int i_currentIndex = this->sReg.pQComboBox_bankSel->currentIndex();
	
	return static_cast <eBankSel_t> ( this->sReg.pQComboBox_bankSel->itemData ( i_currentIndex ).toInt() );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeSimCoreReg::toggleBank ( void )
{
	switch ( this->getBank () )
	{
		case eBankSel_A:	this->sReg.pQComboBox_bankSel->setCurrentIndex ( eBankSel_B );	return TRUE;
		case eBankSel_B:	this->sReg.pQComboBox_bankSel->setCurrentIndex ( eBankSel_A );	return TRUE;
	}
	
	return FALSE;
}

/**
 *****************************************************************************************************************************
 */






