/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PrjOpenDlg.h"

/**
 *****************************************************************************************************************************
 */
PrjOpenDlg::PrjOpenDlg ( QWidget * pQWidgetParent ) : QDialog ( pQWidgetParent )
{
	QVBoxLayout * QVBoxLayout_main = new QVBoxLayout;
	{
		QHBoxLayout * QHBoxLayout_prjFilePath = new QHBoxLayout;
		{
			QLabel * pQLabel_title = new QLabel ( QObject::tr ( "Project file:" ) );

			this->pQLineEdit_prjFilePath = new QLineEdit;

			// Set button for getting output file
			QPushButton * pQPushButton_getFile = new QPushButton ( );
			{
				pQPushButton_getFile->setFixedWidth ( 50 );
				pQPushButton_getFile->setIcon ( QIcon ( ":/prj/img/prj/folderOpen.png" ) );

				connect ( pQPushButton_getFile,
					SIGNAL ( clicked ( ) ),
					this,
					SLOT ( selectPrjFile ( ) )
					);
			}

			QHBoxLayout_prjFilePath->addWidget ( pQLabel_title );
			QHBoxLayout_prjFilePath->addWidget ( this->pQLineEdit_prjFilePath );
			QHBoxLayout_prjFilePath->addWidget ( pQPushButton_getFile );
		}
		QVBoxLayout_main->addLayout ( QHBoxLayout_prjFilePath );

		// Set Button Layout
		QHBoxLayout * pQHBoxLayout_buttons = new QHBoxLayout;
		{
			// Set Buttons
			QPushButton * pQPushButton_add    = new QPushButton ( QObject::tr ( "Add to collection" ) );
			QPushButton * pQPushButton_open   = new QPushButton ( QObject::tr ( "Open" ) );
			QPushButton * pQPushButton_cancel = new QPushButton ( QObject::tr ( "Cancel" ) );
	
			connect ( pQPushButton_add,    SIGNAL ( clicked() ), this, SLOT ( hndlOpenAdd() ) );
			connect ( pQPushButton_open,   SIGNAL ( clicked() ), this, SLOT ( hndlButtonOpen() ) );
			connect ( pQPushButton_cancel, SIGNAL ( clicked() ), this, SLOT ( hndlOpenCancel() ) );
	
			pQHBoxLayout_buttons->addStretch ( 1 );
			pQHBoxLayout_buttons->addWidget ( pQPushButton_add );
			pQHBoxLayout_buttons->addWidget ( pQPushButton_open );
			pQHBoxLayout_buttons->addWidget ( pQPushButton_cancel );
		}
		QVBoxLayout_main->addLayout ( pQHBoxLayout_buttons );

		QLabel * pQLabel_title = new QLabel;
		{
			 pQLabel_title->setText ( QObject::tr ( "Project collection:" ) );

		}
		QVBoxLayout_main->addWidget ( pQLabel_title );

		this->pQScrollArea_prjList = new QScrollArea;
		{
			QWidget * pQWidget = new QWidget;
			{
				this->pQVBoxLayout_prjList = new QVBoxLayout;
				{
					this->pQVBoxLayout_prjList->setContentsMargins ( 0, 0, 0, 0 );
					this->pQVBoxLayout_prjList->addStretch ();
				}

				pQWidget->setLayout ( this->pQVBoxLayout_prjList );
				pQWidget->setAutoFillBackground ( TRUE );
			}

			this->pQScrollArea_prjList->setHorizontalScrollBarPolicy ( Qt::ScrollBarAlwaysOff );
			this->pQScrollArea_prjList->setVerticalScrollBarPolicy ( Qt::ScrollBarAlwaysOn );

			this->pQScrollArea_prjList->setContentsMargins ( 0, 0, 0, 0 );
			this->pQScrollArea_prjList->setWidgetResizable ( TRUE );
			this->pQScrollArea_prjList->setWidget ( pQWidget );

// 			this->pQScrollArea_prjList->setFrameShape ( QFrame::NoFrame );
// 			this->pQScrollArea_prjList->setFrameShadow ( QFrame::Plain );
		}
		QVBoxLayout_main->addWidget ( this->pQScrollArea_prjList );
	}

	QDialog::setLayout ( QVBoxLayout_main );
	QDialog::setWindowTitle ( QObject::tr ( "Open project" ) );
	QDialog::resize(700, 500);
}

/**
 *****************************************************************************************************************************
 */

QString PrjOpenDlg::getPrjFilePath ( void )
{
	return this->QString_prjFilePath;
}

/**
 *****************************************************************************************************************************
 */

void PrjOpenDlg::selectPrjFile ( void )
{
	// Init dialog
	QFileDialog QFileDialog_file;
	QFileDialog_file.setViewMode ( QFileDialog::Detail );
	QFileDialog_file.setDefaultSuffix ( QString ( "openPICIDE" ) );
	QFileDialog_file.setAcceptMode ( QFileDialog::AcceptOpen );
	QFileDialog_file.setWindowTitle ( tr ( "Select project file" ) );
// 	QFileDialog_file.setNameFilter ( tr ( "openPicIde files (*.openPICIDE)" ) );
	QFileDialog_file.setFileMode ( QFileDialog::ExistingFiles );

	if ( ! QFileDialog_file.exec () )
		return;

	QStringList QStringList_files = QFileDialog_file.selectedFiles ();

	if ( QStringList_files.count () != 1 )
		return;

	this->pQLineEdit_prjFilePath->setText ( QStringList_files.at ( 0 ) );
}

/**
 *****************************************************************************************************************************
 */

void PrjOpenDlg::hndlButtonOpen ( void )
{
	this->QString_prjFilePath = this->pQLineEdit_prjFilePath->text ();

	if ( this->QString_prjFilePath.isEmpty () )
		return;

	QDialog::accept ();
}

/**
 *****************************************************************************************************************************
 */

void PrjOpenDlg::hndlOpenAdd ( void )
{
	QString QString_prjFilePath = this->pQLineEdit_prjFilePath->text ();

	if ( QString_prjFilePath.isEmpty () )
		return;

	if ( this->pSetApp->sPrj.QStringList_collection.contains ( QString_prjFilePath ) )
		return;

	this->addListElement ( QString_prjFilePath );

	this->pSetApp->sPrj.QStringList_collection << QString_prjFilePath;
	this->pSetApp->setDirty();
}

/**
 *****************************************************************************************************************************
 */

void PrjOpenDlg::hndlOpenCancel ( void )
{
	this->QString_prjFilePath.clear ();

	QDialog::reject();
}

/**
 *****************************************************************************************************************************
 */

void PrjOpenDlg::setSettingsApp ( SetApp * pSetApp )
{
	this->pSetApp = pSetApp;

	int i_collectionCnt = pSetApp->sPrj.QStringList_collection.size ();

	for ( int i_iterator = ( i_collectionCnt - 1 ); i_iterator >= 0 ; i_iterator-- )
	{
		QString QString_prjFilePath = pSetApp->sPrj.QStringList_collection.at ( i_iterator );

		if ( QString_prjFilePath.isEmpty () )
			return;

		this->addListElement ( QString_prjFilePath );
	}

	if ( pSetApp->sPrj.QStringList_collection.size () <= 0 )
		this->selectPrjFile ();
}

/**
 *****************************************************************************************************************************
 */

void PrjOpenDlg::addListElement ( QString QString_prjFilePath )
{
	PrjOpenDlgLstElement * pPrjOpenDlgLstElement = new PrjOpenDlgLstElement ( this );

	if ( ! pPrjOpenDlgLstElement->setPrjFilePath ( QString_prjFilePath ) )
	{
		delete pPrjOpenDlgLstElement;
		return;
	}

	connect (
		pPrjOpenDlgLstElement,
		SIGNAL ( reqOpen ( PrjOpenDlgLstElement * ) ),
		this,
		SLOT ( hndlListEventOpen ( PrjOpenDlgLstElement * ) )
	);
	connect (
		pPrjOpenDlgLstElement,
		SIGNAL ( reqRemove ( PrjOpenDlgLstElement * ) ),
		this,
		SLOT ( hndlListEventRemove ( PrjOpenDlgLstElement * ) )
	);

	this->pQVBoxLayout_prjList->insertWidget ( 0, pPrjOpenDlgLstElement );
}

/**
 *****************************************************************************************************************************
 */

void PrjOpenDlg::hndlListEventRemove ( PrjOpenDlgLstElement * pPrjOpenDlgLstElement )
{
	QString QString_prjFilePath = pPrjOpenDlgLstElement->getPrjFilePath ();

	this->pSetApp->sPrj.QStringList_collection.removeOne ( QString_prjFilePath );
	this->pSetApp->setDirty();

	this->pQVBoxLayout_prjList->removeWidget ( pPrjOpenDlgLstElement );

	delete pPrjOpenDlgLstElement;
}

/**
 *****************************************************************************************************************************
 */

void PrjOpenDlg::hndlListEventOpen ( PrjOpenDlgLstElement * pPrjOpenDlgLstElement )
{
	this->QString_prjFilePath = pPrjOpenDlgLstElement->getPrjFilePath ();

	if ( this->QString_prjFilePath.isEmpty () )
		return;

	QDialog::accept ();
}

/**
 *****************************************************************************************************************************
 */
