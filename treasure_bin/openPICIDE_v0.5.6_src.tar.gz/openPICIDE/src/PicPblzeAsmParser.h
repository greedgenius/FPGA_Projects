/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PicPblzeAsmParser_H
#define PicPblzeAsmParser_H

#include <QtCore>
#include "PicMsgBrowser.h"
#include "PicPblzeSet.h"
#include "Msg.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Xilinx PicoBlaze (tm) assembler parser.
 *
 *
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *
 * Changelog
 *
 *	2009-08-30	Generated
 *	2009-10-04	Expanded ADDRESS argument value range to 0x3FF
 *			Adding compatibility mode for openPICIDE, Xilinx and Mediatronix assembler code
 * 			Change handling of NZ|Z|NC|C to case insensitive
 *			Renamed some things
 * 	2011-08-23	Fixed bug in memChkCalls: CALL (sX, sY) results in an argument error
 *
 *****************************************************************************************************************************
 */
class PicPblzeAsmParser : public QObject
{
		Q_OBJECT

	// Assembler code elements needed for highlighting
	public:

		/// Returns command list
		/// \param ePicDerivate			Processor derivate
		/// \retval QStringList			Command list
		static QStringList getCmdList ( PicPblzeSet::ePicDerivate_t ePicDerivate );

		/// Returns directive list
		/// \param ePicDerivate			Processor derivate
		/// \retval QStringList			Directive list
		static QStringList getDirectiveList ( PicPblzeSet::ePicDerivate_t ePicDerivate );

		/// Returns hardware components list
		/// \param ePicDerivate			Processor derivate
		/// \retval QStringList			Hardware component list
		static QStringList getHwComponentList ( PicPblzeSet::ePicDerivate_t ePicDerivate );

		/// Returns regular expression map for highlighting numbers
		/// \param ePicDerivate			Processor derivate
		/// \retval QMap<QString,QStringList>	Regular expression map
		static QMap<QString, QStringList> getNumberRegExp ( PicPblzeSet::ePicDerivate_t ePicDerivate );

	// Constructor
	public:
		
		/// Constructor.
		/// \param pQObject_parent		Pointer to parent widget
		PicPblzeAsmParser ( QObject * pQObject_parent = 0 );

		/// Destructor. Tidies up.
		~PicPblzeAsmParser ();
		
	// Parameter handling
	public:
		
		/// Parsing parameter
		struct sCfg_t {

			int i_memBankSize;
			int i_memBankCount;
			int i_scrpdSize;
			int i_intVector;
			
			QStringList QStringList_filePath;
			
			PicPblzeSet::eMemSharedLoc_t eMemSharedLoc;
			PicPblzeSet::ePicDerivate_t ePicDerivate;
		} sCfg;

		/// Set assembler files to parse. Calls \c addFile() to open and read the files.
		/// \param sCfg		Parameter
		/// \retval 		TRUE if success, otherwise FALSE
		bool setCfg ( sCfg_t sCfg );

	private:
		
		/// Clears the parser
		void clear ( void );

	// Reading files to chained list
	private:

		/// Opens and reads given file. Calls \c addCodeLine() for each read line.
		/// \param i_fileNumber		File number
		/// \param QString_filePath	File path
		bool addFile ( int i_fileNumber, QString QString_filePath );

		/// Adds given code line to doubly connected code line element list.
		/// Empty and comment lines will be filtered out.
		/// \param i_fileNumber		File number
		/// \param i_lineNumber		Line number
		/// \param QString_line		Code line
		bool addCodeLine ( int i_fileNumber, int i_lineNumber, QString QString_line );

	// Parsing code lines
	public:

		/// Parse the code lines
		bool parse ( void );

	protected:
		
		/// Line type
		enum eLineType_t
		{
			eLineType_empty,
			eLineType_comment,
			eLineType_unset,
			
			// Directives
			eLineType_dirOrg,
			eLineType_dirEqu,
			eLineType_dirMflag,
			
			// Commands
			eLineType_cmd,
			eLineType_cmdRet,
			eLineType_cmdReti,
			eLineType_cmdAddc,
			eLineType_cmdSubc,
			eLineType_cmdIn,
			eLineType_cmdOut,
			eLineType_cmdEint,
			eLineType_cmdDint,
			eLineType_cmdComp,
			eLineType_cmdCompC,
			eLineType_cmdAdd,
			eLineType_cmdAnd,
			eLineType_cmdCall,
			eLineType_cmdHwbld,
			eLineType_cmdJump,
			eLineType_cmdLoad,
			eLineType_cmdOr,
			eLineType_cmdRl,
			eLineType_cmdRr,
			eLineType_cmdSl0,
			eLineType_cmdSl1,
			eLineType_cmdSlA,
			eLineType_cmdSlX,
			eLineType_cmdSr0,
			eLineType_cmdSr1,
			eLineType_cmdSrA,
			eLineType_cmdSrX,
			eLineType_cmdStar,
			eLineType_cmdSub,
			eLineType_cmdTest,
			eLineType_cmdTestC,
			eLineType_cmdXor,
			eLineType_cmdStore,
			eLineType_cmdFetch,
			eLineType_cmdRBank,
			eLineType_cmdLoadRet
		};
		
		/// Memory flags
		enum eMFlag_t
		{
			eMFlag_unset,
			eMFlag_shared,
			eMFlag_bank0,
			eMFlag_bank1,
			eMFlag_bank2,
			eMFlag_bank3
		};
		
		enum eArgType_t
		{
			eArgType_unset,
			eArgType_reg,
			eArgType_regSubst,
			eArgType_number,
			eArgType_const,
			eArgType_ref,
			eArgType_refReg
		};
		
		struct sArg_t
		{
			eArgType_t eArgType;
			
			int i_value;
			
			QString QString_value;
		};
		
		/// Code line. Element of doubly connected list.
		struct sCodeLine_t
		{
			// Source seciont
			int i_fileNumber;			// Set by addCodeLine(), File number for handling of multiple files
			int i_lineNumber;			// Set by addCodeLine(), Line number within file
			QString QString_line;			// Set by addCodeLine(), Complete code line

			// Splitted section
			eLineType_t eLineType;
			
			
			
// 			QString QString_dir;			// Set by splitCodeLines(), Container for directives to jump to or to call it
// 			QString QString_ref;			// Set by splitCodeLines(), Container for reference to jump to or to call it
			QString QString_cmd;			// Set by splitCodeLines(), Container for commands
			QStringList QStringList_args;		// Set by splitCodeLines(), Container for command arguments

// 			QString QString_subst;			// Set by getDirectives(), Container for substitutes like NAMEREG, CONSTANT or ADDRESS

			// Memory organize section
			eMFlag_t eMFlag;			// Set by addCodeLine
			
			// Arguments
			int i_argCount;
			sArg_t sArg_0;
			sArg_t sArg_1;
			
			int i_addr;				// Set by addrCodeLines (), Memory address

			// Simulator section
			bool b_breakpoint;			// Breakpoint


			// Management section
			sCodeLine_t * psCodeLine_prev;
			sCodeLine_t * psCodeLine_next;
		};
		
		/// Start of doubly connected list code list.
		sCodeLine_t * psCodeLine_start;

		/// Stop of doubly connected list code list.
		sCodeLine_t * psCodeLine_stop;

	private:
		
		/// Key word list. Needed for checking of substitutes.
		QStringList QStringList_keyWords;

		/// Contains supported command list
		QStringList QStringList_cmd;
		
		/// Reference list. Set by \c splitCodeLines() and cleared by \c clear ()
		QMap<QString, sCodeLine_t *> QMap_refs;

		/// Constant list. Set by \c splitCodeLines() and cleared by \c clear ()
		QMap<QString, int>           QMap_constants;

		/// Substitute list. Set by \c splitCodeLines() and cleared by \c clear ()
		QMap<QString, QString>       QMap_regSubst;

		/// Splits code lines into reference, command and argument list.
		/// \retval bool		TRUE if success, otherwise FALSE
		bool parseLine ( void );

		/// Checks symbol for validity
		/// \param psCodeLine		Command line element
		/// \param QString_symbol	Symbol
		/// \retval bool		TRUE, if given symbol is valid, otherwise FALSE
		bool parseCheckSymbol ( sCodeLine_t * psCodeLine, QString QString_symbol );

		/// Split directive "ORG" code line
		/// \param psCodeLine		Command line element
		/// \param QString_line		Preparsed line
		/// \retval bool		TRUE, if successfull, otherwise FALSE
		bool parseDirectiveOrg ( QString & QString_line, sCodeLine_t * psCodeLine );

		/// Split directive "EQU" code line
		/// \param psCodeLine		Command line element
		/// \param QString_line		Preparsed line
		/// \retval bool		TRUE, if successfull, otherwise FALSE
		bool parseDirectiveEqu ( QString & QString_line, sCodeLine_t * psCodeLine );

		/// Split directive "MFLAG" code line
		/// \param psCodeLine		Command line element
		/// \param QString_line		Preparsed line
		/// \retval bool		TRUE, if successfull, otherwise FALSE
		bool parseDirectiveMflag ( QString & QString_line, sCodeLine_t * psCodeLine );
		
		/// Split opcode code line
		/// \param psCodeLine		Command line element
		/// \param QString_line		Preparsed line
		bool parseOpcode ( QString & QString_line, sCodeLine_t * psCodeLine );
		
	// Check commands
	protected:
		
		/// Argument list positions
		enum eArg_t
		{
			eFrstArg = 0,
			eScndArg = 1
		};

	private:
		
		/// Checks arguments for validity
		bool chkCmd ( void );
		
		/// Checks return commands.
		/// \param psCodeLine		Command line element
		/// \retval bool		True, if command and arguments valid
		bool compileCmd_Return ( sCodeLine_t * psCodeLine );

		/// Checks return commands with interrupt enable/disable.
		/// \param psCodeLine		Command line element
		/// \retval bool		True, if command and arguments valid
		bool compileCmd_ReturnI ( sCodeLine_t * psCodeLine );

		/// Checks regbank command.
		/// \param psCodeLine		Command line element
		/// \retval bool		True, if command and arguments valid
		bool compileCmd_RBank ( sCodeLine_t * psCodeLine );

		/// Checks commands with register and register arguments.
		/// \param psCodeLine		Command line element
		/// \retval bool		True, if command and arguments valid
		bool compileCmd_R_R ( sCodeLine_t * psCodeLine );

		/// Checks commands with register and register/constant arguments.
		/// \param psCodeLine		Command line element
		/// \retval bool		True, if command and arguments valid
		bool compileCmd_R_RK ( sCodeLine_t * psCodeLine );

		/// Checks commands with register and constant arguments.
		/// \param psCodeLine		Command line element
		/// \retval bool		True, if command and arguments valid
		bool compileCmd_R_K ( sCodeLine_t * psCodeLine );

		/// Checks commands with register and io arguments.
		/// \param psCodeLine		Command line element
		/// \retval bool		True, if command and arguments valid
		bool compileCmd_R_IO ( sCodeLine_t * psCodeLine );

		/// Checks interrupt enable/disable commands.
		/// \param psCodeLine		Command line element
		/// \retval bool		True, if command and arguments valid
		bool compileCmd_Int ( sCodeLine_t * psCodeLine );
		
		/// Checks branch commands.
		/// \param psCodeLine		Command line element
		/// \retval bool		True, if command and arguments valid
		bool compileCmd_Branch ( sCodeLine_t * psCodeLine );

		/// Checks commands with register argument.
		/// \param psCodeLine		Command line element
		/// \retval bool		True, if command and arguments valid
		bool compileCmd_R ( sCodeLine_t * psCodeLine );

		/// Checks commands with register/constant and register/constant arguments.
		/// \param psCodeLine		Command line element
		/// \retval bool		True, if command and arguments valid
		bool compileCmd_Out ( sCodeLine_t * psCodeLine );

	// Checking arguments
	protected:

		/// Checks number argument.
		/// \param Qstring_arg		Argument
		/// \param pi_argDecimal	If not null, the number will be returned as decimal
		/// \param i_maximum		Maximum valid number value
		/// \retval bool		True, if argument valid
		bool checkArgNumber ( QString Qstring_arg, int * pi_argDecimal = NULL, int i_maximum = 0xFF );

		/// Checks number constant argument.
		/// \param Qstring_arg		Argument
		/// \param pi_argDecimal	If not null, the number will be returned as decimal
		/// \param i_maximum		Maximum valid number value
		/// \retval bool		True, if argument valid
		bool checkArgNumberConst ( QString QString_arg, int * pi_argDecimal = NULL, int i_maximum = 0xFF );

		/// Checks register argument.
		/// \param Qstring_arg		Argument
		/// \param pQString_reg		If not null, the Register will be returned
		/// \retval bool		True, if argument valid
		bool checkArgReg ( QString Qstring_arg, QString * pQString_reg = NULL );

		/// Checks register substitute argument.
		/// \param Qstring_arg		Argument
		/// \param pQString_reg		If not null, the Register will be returned
		/// \retval bool		True, if argument valid
		bool checkArgRegSubst ( QString Qstring_arg, QString * pQString_reg = NULL );

		/// Checks Reference argument.
		/// \param Qstring_arg		Argument
		/// \param ppsCodeLine		If not null, a pointer to the code line element will be returned
		/// \retval bool		True, if argument valid
		bool checkArgRef ( QString Qstring_arg, sCodeLine_t ** ppsCodeLine = NULL );

		/// Checks address by register argument.
		/// \param Qstring_arg		Argument
		/// \param pQString_reg		If not null, the register will be returned
		/// \param pQString_regSubst	If not null, the register substitute will be returned
		/// \retval bool		True, if argument valid
		bool checkArgAddrByReg ( QString QString_arg, QString * pQString_reg = NULL, QString * pQString_regSubst = NULL );

		/// Checks argument for branch conditions: C, NC, Z, NZ
		/// \retval bool		True, if condition valid
		bool checkBranchCondition ( QString QString_arg );

	// Memory organization
	public:
		
		/// Memory range parameter
		struct sMemRange_t
		{
			sCodeLine_t * psCodeLine_start;
			
			int i_addrStart;
			int i_addrStop;
		};
		
		/// Memory organization data
		struct sMem_t
		{
			sMemRange_t sMemRangeShared;
			sMemRange_t sMemRangeBank0;
			sMemRange_t sMemRangeBank1;
			sMemRange_t sMemRangeBank2;
			sMemRange_t sMemRangeBank3;

			int i_memSize;
			
			/// Array of memory mapped code lines
			sCodeLine_t ** apsCodeLine_memMap;
		} sMem;
		
		
		/// Handle inst count
		struct sInstCount_t
		{
			int i_shared;
			int i_bank0;
			int i_bank1;
			int i_bank2;
			int i_bank3;
		} sInstCount;
		
		/// Gets the pic memory usage.
		sInstCount_t * getInstCount ( void );

	private:
		/// Addresses dubly connected command line element list.
		/// \retval bool		True if success, otherwise FALSE
		bool memOrganize ( void );

		
		/// Parse code base for MFlags and get memory range sizes
		/// \retval bool		True if success, otherwise FALSE
		bool memDetectRanges ( void );
		
		/// Parse code base and check for calls from bank to bank without intermediate calls
		/// \retval bool		True if success, otherwise FALSE
		bool memChkCalls ( void );
		
		/// Parse code base and set memory addresses
		/// \retval bool		True if success, otherwise FALSE
		bool memSetAddresses ( void );

		/// Parse code base and set memory addresses
		/// \param eMFlag		Type of address range
		/// \param psCodeLine_start	Start of address range
		/// \param pi_addrStart		Start value of address counter
		/// \param pi_addrStop		Stop value of address counter
		/// \retval bool		True if success, otherwise FALSE
		bool memSetAddressRangeDown ( eMFlag_t eMFlag, sCodeLine_t * psCodeLine_start, int * pi_addrStart, int i_addrStop );

		/// Parse code base and set memory addresses
		/// \param eMFlag		Type of address range
		/// \param psCodeLine_start	Start of address range
		/// \param i_addrStart		Start value of address counter
		/// \param pi_addrStop		Stop value of address counter
		/// \retval bool		True if success, otherwise FALSE
		bool memSetAddressRangeUp ( eMFlag_t eMFlag, sCodeLine_t * psCodeLine_start, int i_addrStart, int * pi_addrStop );

		/// Prints code base to stdout
		void memDbgCodeBase ( void );
		
		/// Prints memory map to stdout
		void memDbgMap ( void );
		
		/// Sets up memory map
		/// \retval bool	TRUE if success, otherwise false
		bool memMap ( void );

		/// Maps memory range to memory
		/// \retval bool		True if success, otherwise FALSE
		bool memMapRange ( sCodeLine_t * psCodeLine_start, sCodeLine_t ** apsCodeLine, int * pi_memCntr );
		
		/// Checks memory map.
		/// \retval bool		True if success, otherwise FALSE
		bool memMapChk ( void );
		
	// Message handling
	protected:
		
		enum eMsgType_t
		{
			eMsgType_ok,
			eMsgType_readingFile,
			
			eMsgType_warn,
			eMsgType_unusedBank0,
			eMsgType_unusedBank1,
			eMsgType_unusedBank2,
			eMsgType_unusedBank3,
			eMsgType_unusedIntVectorBank0,
			eMsgType_unusedIntVectorBank1,
			eMsgType_unusedIntVectorBank2,
			eMsgType_unusedIntVectorBank3,
			
			eMsgType_err,
			eMsgType_fileIO,
			eMsgType_ivldCodeLineCnt,
			eMsgType_ivldColon,
			eMsgType_ivldSyntax,
			eMsgType_ivldCmd,
			eMsgType_ivldArg,
			
			eMsgType_argCnt,
			eMsgType_argNoKeyword,
			eMsgType_argNoNumber,
			eMsgType_argNoReg,
			eMsgType_argExpNumber,
			eMsgType_argExpReg,
			eMsgType_argExpBracket,
			eMsgType_argExpRegNumber,
			eMsgType_argExpPort,
			eMsgType_argExpBranchCond,
			eMsgType_argExpAddr,
			eMsgType_argExpMFLag,
			eMsgType_argExpedEnDisable,
			eMsgType_argExpedRegBank,
			eMsgType_argUsedAsConst,
			eMsgType_argUsedAsReg,
			eMsgType_argRefAlreadyUsed,
			eMsgType_memRangeDuplicate,
			eMsgType_memRangeCntExceeded,
			eMsgType_memOutOfBank,
			eMsgType_memAddrConflict,
			eMsgType_memOutOfRange,
			eMsgType_intVectorOor,
			eMsgType_memOverflow,
			eMsgType_picUnsupported,
			eMsgType_memExpIntermedCall
		};
		
		struct sMsg_t
		{
			int i_errCntr;
			
		} sMsg;
		
	protected:
		
		/// Gets file path from file number.
		/// \param i_fileNumber			File number
		QString msgGetFilePath ( int i_fileNumber );

		/// Emits message.
		/// \param eMsgType			Message type
		/// \param QString_filePath		File path
		void msgEmit ( eMsgType_t eMsgType, QString QString_filePath );

		/// Emits message.
		/// \param eMsgType			Message type
		/// \param psCodeLine			Code line element
		void msgEmit ( eMsgType_t eMsgType, sCodeLine_t * psCodeLine );
		
		void msgEmit ( eMsgType_t eMsgType );

		/// Emits message.
		/// \param pMsg				Message
		void msgEmit ( Msg * pMsg, eMsgType_t eMsgType );

	signals:

		/// Emitts a message
		/// \param QString_message		Message
		/// \param QString_filePath		File path
		/// \param i_lineNumber			Line number
		/// \param eStatus			Message status
		void message ( QString QString_message, QString QString_filePath, int i_lineNumber, Msg::eStatus_t eStatus );

		void message ( Msg * pMsg );

	// Miscellaneous
	public:
		
		/// Gets program counter from code line
		/// \param[in]  QString_filePath	File path
		/// \param[in]  i_lineNumber		Line number
		/// \param[in]  pi_pc			Reference to return pc
		/// \retval sCodeLine_t *		Codeline if success, otherwise NULL
		sCodeLine_t * getPcFromCodeLine ( QString QString_filePath, int i_lineNumber, int * pi_pc = NULL);
		
	// Used within simulator
	protected:
		
		/// Program start code line element for initializing program counter.
// 		sCodeLine_t * getPcStart ( void );

		/// Program interrupt start code line element.
		/// \param sCodeLine_pc			Codeline referencing current program counter
		sCodeLine_t * getIntPtr ( sCodeLine_t * sCodeLine_pc = NULL );

		/// Gets file number from file path
		/// \param QString_filePath		File path
		int getFileNumber ( QString QString_filePath );
		
		/// Gets code line element from address.
		/// \param i_addr		Address
		/// \param ppsCodeLine		If not null, a pointer to the code line element will be returned
		/// \retval bool		True, if address valid
		bool getCodeLineByAddr ( int i_addr, sCodeLine_t ** ppsCodeLine = NULL );
};

#endif
