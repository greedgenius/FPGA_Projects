/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeCmplrPblzeII.h"


/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Constructor/destructor
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

PicPblzeCmplrPblzeII::PicPblzeCmplrPblzeII ( QObject * pQObject_parent ) : PicPblzeCmplr ( pQObject_parent )
{
	this->QMap_reg [ "s00" ] = 0x00;
	this->QMap_reg [ "s01" ] = 0x01;
	this->QMap_reg [ "s02" ] = 0x02;
	this->QMap_reg [ "s03" ] = 0x03;
	this->QMap_reg [ "s04" ] = 0x04;
	this->QMap_reg [ "s05" ] = 0x05;
	this->QMap_reg [ "s06" ] = 0x06;
	this->QMap_reg [ "s07" ] = 0x07;
	this->QMap_reg [ "s08" ] = 0x08;
	this->QMap_reg [ "s09" ] = 0x09;
	this->QMap_reg [ "s0A" ] = 0x0A;
	this->QMap_reg [ "s0B" ] = 0x0B;
	this->QMap_reg [ "s0C" ] = 0x0C;
	this->QMap_reg [ "s0D" ] = 0x0D;
	this->QMap_reg [ "s0E" ] = 0x0E;
	this->QMap_reg [ "s0F" ] = 0x0F;

	this->QMap_reg [ "s10" ] = 0x10;
	this->QMap_reg [ "s11" ] = 0x11;
	this->QMap_reg [ "s12" ] = 0x12;
	this->QMap_reg [ "s13" ] = 0x13;
	this->QMap_reg [ "s14" ] = 0x14;
	this->QMap_reg [ "s15" ] = 0x15;
	this->QMap_reg [ "s16" ] = 0x16;
	this->QMap_reg [ "s17" ] = 0x17;
	this->QMap_reg [ "s18" ] = 0x18;
	this->QMap_reg [ "s19" ] = 0x19;
	this->QMap_reg [ "s1A" ] = 0x1A;
	this->QMap_reg [ "s1B" ] = 0x1B;
	this->QMap_reg [ "s1C" ] = 0x1C;
	this->QMap_reg [ "s1D" ] = 0x1D;
	this->QMap_reg [ "s1E" ] = 0x1E;
	this->QMap_reg [ "s1F" ] = 0x1F;
}

/**
 *****************************************************************************************************************************
 */

PicPblzeCmplrPblzeII::~PicPblzeCmplrPblzeII()
{
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Compile
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compile ( void )
{
	// Parse code
	if ( ! PicPblzeAsmParser::parse () )
		return FALSE;

	// Allocate new pic memory
	PicPblzeCmplr::asMemCell = new sMemCell_t[ PicPblzeAsmParser::sMem.i_memSize ];

	// Preset pic memory with zero
	memset ( PicPblzeCmplr::asMemCell, NULL, ( PicPblzeAsmParser::sMem.i_memSize * sizeof ( PicPblzeCmplr::sMemCell_t ) ) );
	
	// Compile
	for ( int i_iterator = 0; i_iterator < this->sMem.i_memSize; ++i_iterator )
	{
		unsigned int ui_memCell;
		
		sCodeLine_t * psCodeLine = PicPblzeAsmParser::sMem.apsCodeLine_memMap[ i_iterator ];
		
		if ( ! psCodeLine )
			continue;
		
		if ( psCodeLine->eLineType > PicPblzeAsmParser::eLineType_cmd )
		{
			// Get memory line
			if ( ! this->compileCmd ( psCodeLine, & ui_memCell ) )
			{
				PicPblzeCmplr::msgEmit ( PicPblzeCmplr::eMsgType_compError );
				return FALSE;
			}

			// Store memory line
			PicPblzeCmplr::asMemCell [ i_iterator ].b_valid  = TRUE;
			PicPblzeCmplr::asMemCell [ i_iterator ].ui_value = ui_memCell;
		}
		else
		{
			PicPblzeCmplr::msgEmit ( PicPblzeCmplr::eMsgType_compError );
			return FALSE;
		}
	}

	// Write output file
	return PicPblzeCmplr::writeOutputFile ();
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Compile commands
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	switch ( psCodeLine->eLineType )
	{
		case eLineType_cmdRet:		return this->compileCmdReturn  ( psCodeLine, pui_memCell );
		case eLineType_cmdReti:		return this->compileCmdReturnI ( psCodeLine, pui_memCell );
		case eLineType_cmdAddc:		return this->compileCmdAddCy   ( psCodeLine, pui_memCell );
		case eLineType_cmdSubc:		return this->compileCmdSubCy   ( psCodeLine, pui_memCell );
		case eLineType_cmdIn:		return this->compileCmdInput   ( psCodeLine, pui_memCell );
		case eLineType_cmdOut:		return this->compileCmdOutput  ( psCodeLine, pui_memCell );
		case eLineType_cmdEint:		return this->compileCmdIntEn   ( psCodeLine, pui_memCell );
		case eLineType_cmdDint:		return this->compileCmdIntDis  ( psCodeLine, pui_memCell );
// 		case eLineType_cmdComp:		return this->compileCmdCompare ( psCodeLine, pui_memCell );
		case eLineType_cmdAdd:		return this->compileCmdAdd     ( psCodeLine, pui_memCell );
		case eLineType_cmdAnd:		return this->compileCmdAnd     ( psCodeLine, pui_memCell );
		case eLineType_cmdCall:		return this->compileCmdCall    ( psCodeLine, pui_memCell );
		case eLineType_cmdJump:		return this->compileCmdJump    ( psCodeLine, pui_memCell );
		case eLineType_cmdLoad:		return this->compileCmdLoad    ( psCodeLine, pui_memCell );
		case eLineType_cmdOr:		return this->compileCmdOr      ( psCodeLine, pui_memCell );
		case eLineType_cmdRl:		return this->compileCmdRl      ( psCodeLine, pui_memCell );
		case eLineType_cmdRr:		return this->compileCmdRr      ( psCodeLine, pui_memCell );
		case eLineType_cmdSl0:		return this->compileCmdSl0     ( psCodeLine, pui_memCell );
		case eLineType_cmdSl1:		return this->compileCmdSl1     ( psCodeLine, pui_memCell );
		case eLineType_cmdSlA:		return this->compileCmdSla     ( psCodeLine, pui_memCell );
		case eLineType_cmdSlX:		return this->compileCmdSlx     ( psCodeLine, pui_memCell );
		case eLineType_cmdSr0:		return this->compileCmdSr0     ( psCodeLine, pui_memCell );
		case eLineType_cmdSr1:		return this->compileCmdSr1     ( psCodeLine, pui_memCell );
		case eLineType_cmdSrA:		return this->compileCmdSra     ( psCodeLine, pui_memCell );
		case eLineType_cmdSrX:		return this->compileCmdSrx     ( psCodeLine, pui_memCell );
		case eLineType_cmdSub:		return this->compileCmdSub     ( psCodeLine, pui_memCell );
// 		case eLineType_cmdTest:		return this->compileCmdTest    ( psCodeLine, pui_memCell );
		case eLineType_cmdXor:		return this->compileCmdXor     ( psCodeLine, pui_memCell );
// 		case eLineType_cmdStore:	return this->compileCmdStore   ( psCodeLine, pui_memCell );
// 		case eLineType_cmdFetch:	return this->compileCmdFetch   ( psCodeLine, pui_memCell );
	}

	PicPblzeAsmParser::msgEmit ( PicPblzeAsmParser::eMsgType_ivldCmd, psCodeLine );

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdAdd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x08000, 0x18000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdAddCy ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x0A000, 0x1A000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdAnd ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x02000, 0x12000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdCall ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();
	QString QString_addr;

	//********************************************************************************************************************
	//* Check for jump type
	//********************************************************************************************************************
	if ( QString_arg0 == QString ( "C" ) )		// CALL C
	{
		*pui_memCell = 0x37800;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "NC" ) )	// CALL NC
	{
		*pui_memCell = 0x37C00;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "NZ" ) )	// CALL NZ
	{
		*pui_memCell = 0x37400;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "Z" ) )	// CALL Z
	{
		*pui_memCell = 0x37000;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else
	{
		*pui_memCell = 0x36000;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	}

	//********************************************************************************************************************
	//* Check for address
	//********************************************************************************************************************
	{
		sCodeLine_t * psCodeLine_addr;

		if ( ! PicPblzeAsmParser::checkArgRef ( QString_addr, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell |= compileArgMAddr ( psCodeLine_addr->i_addr );
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdIntDis ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	*pui_memCell = 0x3C000;
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdIntEn ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	*pui_memCell = 0x3C001;
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdInput ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegPAddr ( psCodeLine, 0x20000, 0x30000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdJump ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();
	QString QString_addr;

	//********************************************************************************************************************
	//* Check for jump type
	//********************************************************************************************************************
	if ( QString_arg0 == QString ( "C" ) )		// JUMP C
	{
		*pui_memCell = 0x35800;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "NC" ) )	// JUMP NC
	{
		*pui_memCell = 0x35C00;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "NZ" ) )	// JUMP NZ
	{
		*pui_memCell = 0x35400;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else if ( QString_arg0 == QString ( "Z" ) )	// JUMP Z
	{
		*pui_memCell = 0x35000;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );
	}
	else
	{
		*pui_memCell = 0x34000;
		QString_addr = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	}

	//********************************************************************************************************************
	//* Check for address
	//********************************************************************************************************************
	{
		sCodeLine_t * psCodeLine_addr;

		if ( ! PicPblzeAsmParser::checkArgRef ( QString_addr, & psCodeLine_addr ) )
			return FALSE;

		*pui_memCell |= compileArgMAddr ( psCodeLine_addr->i_addr );
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdLoad ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x00000, 0x10000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdOr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x04000, 0x14000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdOutput ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegPAddr ( psCodeLine, 0x22000, 0x32000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdReturn ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0;

	if ( psCodeLine->QStringList_args.count () > 0 )
		QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();

	//********************************************************************************************************************
	//* Check for jump type
	//********************************************************************************************************************
	if ( QString_arg0 == QString ( "C" ) )		// RETURN C
	{
		*pui_memCell  = 0x25800;
	}
	else if ( QString_arg0 == QString ( "NC" ) )	// RETURN NC
	{
		*pui_memCell  = 0x25C00;
	}
	else if ( QString_arg0 == QString ( "NZ" ) )	// RETURN NZ
	{
		*pui_memCell  = 0x25400;
	}
	else if ( QString_arg0 == QString ( "Z" ) )	// RETURN Z
	{
		*pui_memCell  = 0x25000;
	}
	else
	{
		*pui_memCell  = 0x24000;
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdReturnI ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg ).toUpper ();

	if ( QString_arg0 == QString ( "DISABLE" ) )
		*pui_memCell = 0x2C000;

	else if ( QString_arg0 == QString ( "ENABLE" ) )
		*pui_memCell = 0x2C001;

	else
		return FALSE;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdRl ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x28002, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdRr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x2800C, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdSl0 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x28006, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdSl1 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x28007, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdSla ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x28000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdSlx ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x28004, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdSr0 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x2800E, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdSr1 ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x2800F, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdSra ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x28008, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdSrx ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemReg ( psCodeLine, 0x2800A, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdSub ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x0C000, 0x1C000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdSubCy ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x0E000, 0x1E000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileCmdXor ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, unsigned int * pui_memCell )
{
	return compileArgMemRegVsRegConst ( psCodeLine, 0x06000, 0x16000, pui_memCell );
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Compile arguments
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileArgMemRegVsRegConst ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memConst, int i_memReg, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QStirng_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	QString QString_regDst;
	QString QString_regSrc;
	int i_constant;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	//********************************************************************************************************************
	//* Check for constant
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgNumberConst ( QStirng_arg1, & i_constant ) )
	{
		*pui_memCell = i_memConst | compileArgRegDst ( QString_regDst ) | compileArgConst ( i_constant );
		return TRUE;
	}

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgRegSubst ( QStirng_arg1, & QString_regSrc ) )
	{
		*pui_memCell = i_memReg | compileArgRegDst ( QString_regDst ) | compileArgRegSrc ( QString_regSrc );
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileArgMemRegVsRegPAddr ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_memPAddr, int i_memReg, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );
	QString QStirng_arg1 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eScndArg );

	QString QString_regDst;
	QString QString_regSrc;
	int i_pAddr;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	//********************************************************************************************************************
	//* Check for port address
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgNumberConst ( QStirng_arg1, & i_pAddr ) )
	{
		*pui_memCell = i_memPAddr | compileArgRegDst ( QString_regDst ) | compileArgPAddr ( i_pAddr );
		return TRUE;
	}

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	if ( PicPblzeAsmParser::checkArgAddrByReg ( QStirng_arg1, & QString_regSrc ) )
	{
		*pui_memCell = i_memReg | compileArgRegDst ( QString_regDst ) | compileArgRegSrc ( QString_regSrc );
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeCmplrPblzeII::compileArgMemReg ( PicPblzeAsmParser::sCodeLine_t * psCodeLine, int i_mem, unsigned int * pui_memCell )
{
	QString QString_arg0 = psCodeLine->QStringList_args.at ( PicPblzeAsmParser::eFrstArg );

	QString QString_regDst;

	//********************************************************************************************************************
	//* Get register
	//********************************************************************************************************************
	if ( ! PicPblzeAsmParser::checkArgRegSubst ( QString_arg0, & QString_regDst ) )
		return FALSE;

	*pui_memCell = i_mem | compileArgRegDst ( QString_regDst );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblzeII::compileArgRegDst ( QString QString_regDst )
{
	return ( this->QMap_reg [ QString_regDst ] & 0x1F ) << 8;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblzeII::compileArgRegSrc ( QString QString_regSrc )
{
	return ( this->QMap_reg [ QString_regSrc ] & 0x1F ) << 3;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblzeII::compileArgConst ( int i_const )
{
	return i_const & 0xFF;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblzeII::compileArgMAddr ( int i_addr )
{
	return i_addr & 0x3FF;
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeCmplrPblzeII::compileArgPAddr ( int i_addr )
{
	return i_addr & 0xFF;
}

/**
 *****************************************************************************************************************************
 */

