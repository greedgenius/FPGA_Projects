/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PIC_H
#define PIC_H

#include <QtCore>
#include <QtGui>

#include "PrjSettings.h"
#include "MainGuiElements.h"

#include "Edt.h"
#include "PicNone.h"
#include "PicPblze.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Pic management class
 *
 *	Instantiates a class regarding selected pic.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */

/*
 *****************************************************************************************************************************
 * Change log
 *
 * 2009-08-30
 *	Freeze for first release
 *
 * 2009-09-11
 *	Fixed setupMenuBar. this->pPicNone was accessed, when NULL.
 *
 *****************************************************************************************************************************
 */

class Pic : public QObject
{

		Q_OBJECT

	public:

		/// Constructor
		/// \param pMod				Pointer collection to root elements
		/// \param pQObject_parent		Pointer to parent widget
		Pic ( Mod * pMod, QObject * pQObject_parent = 0 );

		/// Destructor. Tidies up.
		~Pic ( void );

		/// Adds menu entries to the given menubar.
		/// \param	pQMenuBar		Pointer to the menubar
		void setupMenuBar ( QMenuBar * pQMenuBar );

		/// Sets the project settings to the pic. The method will be called if the project settings changed.
		void changeSettings ( void );

	private:

		/// Pointer collection to root elements
		Mod * pMod;

		/// Current pic
		struct sPicCurrent_t
		{
			/// Name of the pic got from project settings
			QString QString_picType;

			/// Holds pic instance
			PicNone * pPicNone;
			
		} sPicCurrent;

		/// Creates a pic instance form given pic name and stores in \var pPicNone.
		/// \param QString_pic				Pic name
		bool createPic ( QString QString_pic );

		/// Destroys pic instance in \var pPicNone
		void removePic ( void );
};

#endif
