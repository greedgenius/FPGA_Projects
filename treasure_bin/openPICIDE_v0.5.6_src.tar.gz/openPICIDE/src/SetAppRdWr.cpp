/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "SetAppRdWr.h"

/**
 *****************************************************************************************************************************
 */

SetAppRdWr::SetAppRdWr ()
{
	
}

/**
 *****************************************************************************************************************************
 */

void SetAppRdWr::readSet ( SetApp * pSetApp )
{
	QSettings QSettings_rd ( "openpicide.org", "openPICIDE" );

	// Support settings
	{
		if ( QSettings_rd.contains ( "support/chkForUpdate" ) )
			pSetApp->sSup.eChkIval = (SetApp::eChkIval_t) QSettings_rd.value ( "support/chkForUpdate" ).toInt ();

		if ( QSettings_rd.contains ( "support/serNo" ) )
			pSetApp->sSup.QString_serNo = QSettings_rd.value ( "support/serNo" ).toString ();

		if ( QSettings_rd.contains ( "support/lstUpdateChk" ) )
			pSetApp->sSup.QDate_lstUpdateChk = QDate::fromString ( QSettings_rd.value ( "support/lstUpdateChk" ).toString(), Qt::ISODate );

		if ( QSettings_rd.contains ( "support/showStartInfo" ) )
			pSetApp->sSup.b_showStartInfo = QSettings_rd.value ( "support/showStartInfo" ).toBool();
		
		if ( QSettings_rd.contains ( "support/showHlpCtrlOnRightSide" ) )
			pSetApp->sSup.b_showHlpCtrlOnRightSide = QSettings_rd.value ( "support/showHlpCtrlOnRightSide" ).toBool();
		
// 		if ( QSettings_rd.contains ( "support/hlpCollectionFile" ) )
// 			pSetApp->sSup.QString_hlpCollectionFile = QSettings_rd.value ( "support/hlpCollectionFile" ).toString();
	}

	// Main window settings
	{
		if ( QSettings_rd.contains ( "mainWindow/width" ) )
		{
			pSetApp->sGui.i_mainWindowWidth  = QSettings_rd.value ( "mainWindow/width" ).toInt ();

			if ( pSetApp->sGui.i_mainWindowWidth < 600 )
				pSetApp->sGui.i_mainWindowWidth = 600;
		}
		
		if ( QSettings_rd.contains ( "mainWindow/height" ) )
		{
			pSetApp->sGui.i_mainWindowHeight = QSettings_rd.value ( "mainWindow/height" ).toInt ();

			if ( pSetApp->sGui.i_mainWindowHeight < 400 )
				pSetApp->sGui.i_mainWindowHeight = 400;
		}

		if ( QSettings_rd.contains ( "mainWindow/x" ) )
			pSetApp->sGui.i_mainWindowX = QSettings_rd.value ( "mainWindow/x" ).toInt ();

		if ( QSettings_rd.contains ( "mainWindow/x" ) )
			pSetApp->sGui.i_mainWindowY = QSettings_rd.value ( "mainWindow/y" ).toInt ();
		
		if ( QSettings_rd.contains ( "mainWindow/style" ) )
			pSetApp->sGui.i_style = QSettings_rd.value ( "mainWindow/style" ).toInt ();
	}
	
	// Restore recent projects
	{
		int i_iterator = 0;

		while ( true )
		{
			QString QString_section = QString ( "project/recent" ) + QString::number ( i_iterator++ );

			QString QString_prjRecent = QSettings_rd.value ( QString_section ).toString ();

			if ( QString_prjRecent.isEmpty () )
				break;
			else
				pSetApp->sPrj.QStringList_recent << QString_prjRecent;
		}
	}

	// Restore project collection
	{
		int i_iterator = 0;

		while ( true )
		{
			QString QString_section = QString ( "project/collection" ) + QString::number ( i_iterator++ );

			QString QString_prjCollection = QSettings_rd.value ( QString_section ).toString ();

			if ( QString_prjCollection.isEmpty () )
				break;
			else
				pSetApp->sPrj.QStringList_collection << QString_prjCollection;
		}
	}
	
	// Restore editor settings
	{
		if ( QSettings_rd.contains ( "editor/tabIndent" ) )
			pSetApp->sEdt.i_tabIndent = QSettings_rd.value ( "editor/tabIndent" ).toInt ();
		
		if ( QSettings_rd.contains ( "editor/dynamicWordWrapEn" ) )
			pSetApp->sEdt.b_dynamicWordWrapEn = QSettings_rd.value ( "editor/dynamicWordWrapEn" ).toBool ();
		
		if ( QSettings_rd.contains ( "editor/bgCursor" ) )
			pSetApp->sEdt.QColor_bgCursor     = QColor ( QSettings_rd.value ( "editor/bgCursor" ).toString () );
		
		if ( QSettings_rd.contains ( "editor/bgHighlight" ) )
			pSetApp->sEdt.QColor_bgHighlight  = QColor ( QSettings_rd.value ( "editor/bgHighlight" ).toString () );
		
		if ( QSettings_rd.contains ( "editor/fontFamily" ) )
			pSetApp->sEdt.QFont_std.setFamily    ( QSettings_rd.value ( "editor/fontFamily" ).toString () );
		
		if ( QSettings_rd.contains ( "editor/fontSize" ) )
			pSetApp->sEdt.QFont_std.setPointSize ( QSettings_rd.value ( "editor/fontSize" ).toInt () );

		QSettings_rd.beginReadArray( "font" );
		{
			this->readSetFont ( & QSettings_rd,  0, & pSetApp->sEdt.QTextCharFormat_cmd );
			this->readSetFont ( & QSettings_rd,  1, & pSetApp->sEdt.QTextCharFormat_directive );
			this->readSetFont ( & QSettings_rd,  2, & pSetApp->sEdt.QTextCharFormat_hw );
			this->readSetFont ( & QSettings_rd,  3, & pSetApp->sEdt.QTextCharFormat_hexNumber );
			this->readSetFont ( & QSettings_rd,  4, & pSetApp->sEdt.QTextCharFormat_decNumber );
			this->readSetFont ( & QSettings_rd,  5, & pSetApp->sEdt.QTextCharFormat_octNumber );
			this->readSetFont ( & QSettings_rd,  6, & pSetApp->sEdt.QTextCharFormat_comment );
			this->readSetFont ( & QSettings_rd,  7, & pSetApp->sEdt.QTextCharFormat_separator );
			this->readSetFont ( & QSettings_rd,  8, & pSetApp->sEdt.QTextCharFormat_fct );
			this->readSetFont ( & QSettings_rd,  9, & pSetApp->sEdt.QTextCharFormat_doc );
			this->readSetFont ( & QSettings_rd, 10, & pSetApp->sEdt.QTextCharFormat_navi );

			QSettings_rd.endArray();
		}
	}
}

/**
 *****************************************************************************************************************************
 */

void SetAppRdWr::readSetFont ( QSettings * pQSettings_rd, int i_index, QTextCharFormat * pQTextCharFormat )
{
	pQSettings_rd->setArrayIndex ( i_index );
	
	if ( pQSettings_rd->contains ( "italic" ) )
		pQTextCharFormat->setFontItalic ( pQSettings_rd->value ( "italic" ).toBool () );
	
	if ( pQSettings_rd->contains ( "weight" ) )
		pQTextCharFormat->setFontWeight ( pQSettings_rd->value ( "weight" ).toBool () );

	if ( pQSettings_rd->contains ( "color" ) )
		pQTextCharFormat->setForeground ( QColor ( pQSettings_rd->value ( "color" ).toString () ) );
}

/**
 *****************************************************************************************************************************
 */

void SetAppRdWr::saveSet ( SetApp * pSetApp )
{
	QSettings QSettings_wr ( "openpicide.org", "openPICIDE" );

	QSettings_wr.clear ();
	
	QSettings_wr.beginGroup ( "support" );
	{
		QSettings_wr.setValue ( "chkForUpdate",			pSetApp->sSup.eChkIval );
		QSettings_wr.setValue ( "serNo",			pSetApp->sSup.QString_serNo );
		QSettings_wr.setValue ( "lstUpdateChk",			pSetApp->sSup.QDate_lstUpdateChk.toString ( Qt::ISODate ) );
		QSettings_wr.setValue ( "showStartInfo",		pSetApp->sSup.b_showStartInfo );
		QSettings_wr.setValue ( "showHlpCtrlOnRightSide",	pSetApp->sSup.b_showHlpCtrlOnRightSide );
// 		QSettings_wr.setValue ( "hlpCollectionFile",		pSetApp->sSup.QString_hlpCollectionFile );
		
		QSettings_wr.endGroup ();
	}

	QSettings_wr.beginGroup ( "version" );
	{
		QSettings_wr.setValue ( "settingsVersion",  1 );
		
		QSettings_wr.endGroup ();
	}

	QSettings_wr.beginGroup ( "mainWindow" );
	{
		QSettings_wr.setValue ( "width",  pSetApp->sGui.i_mainWindowWidth );
		QSettings_wr.setValue ( "height", pSetApp->sGui.i_mainWindowHeight );
		QSettings_wr.setValue ( "x",      pSetApp->sGui.i_mainWindowX );
		QSettings_wr.setValue ( "y",      pSetApp->sGui.i_mainWindowY );
		QSettings_wr.setValue ( "style",  pSetApp->sGui.i_style );

		QSettings_wr.endGroup ();
	}

	QSettings_wr.beginGroup ( "editor" );
	{
		QSettings_wr.setValue ( "tabIndent",         pSetApp->sEdt.i_tabIndent );
		QSettings_wr.setValue ( "dynamicWordWrapEn", pSetApp->sEdt.b_dynamicWordWrapEn );
		QSettings_wr.setValue ( "bgCursor",          pSetApp->sEdt.QColor_bgCursor.name () );
		QSettings_wr.setValue ( "bgHighlight",       pSetApp->sEdt.QColor_bgHighlight.name () );
		
		QSettings_wr.setValue ( "fontFamily",        pSetApp->sEdt.QFont_std.family () );
		QSettings_wr.setValue ( "fontSize",          pSetApp->sEdt.QFont_std.pointSize () );

		QSettings_wr.beginWriteArray ( "font" );
		{
			this->saveSetFont ( & QSettings_wr,  0, & pSetApp->sEdt.QTextCharFormat_cmd );
			this->saveSetFont ( & QSettings_wr,  1, & pSetApp->sEdt.QTextCharFormat_directive );
			this->saveSetFont ( & QSettings_wr,  2, & pSetApp->sEdt.QTextCharFormat_hw );
			this->saveSetFont ( & QSettings_wr,  3, & pSetApp->sEdt.QTextCharFormat_hexNumber );
			this->saveSetFont ( & QSettings_wr,  4, & pSetApp->sEdt.QTextCharFormat_decNumber );
			this->saveSetFont ( & QSettings_wr,  5, & pSetApp->sEdt.QTextCharFormat_octNumber );
			this->saveSetFont ( & QSettings_wr,  6, & pSetApp->sEdt.QTextCharFormat_comment );
			this->saveSetFont ( & QSettings_wr,  7, & pSetApp->sEdt.QTextCharFormat_separator );
			this->saveSetFont ( & QSettings_wr,  8, & pSetApp->sEdt.QTextCharFormat_fct );
			this->saveSetFont ( & QSettings_wr,  9, & pSetApp->sEdt.QTextCharFormat_doc );
			this->saveSetFont ( & QSettings_wr, 10, & pSetApp->sEdt.QTextCharFormat_navi );
			
			QSettings_wr.endArray ();
		}
		
		QSettings_wr.endGroup ();
	}

	QSettings_wr.beginGroup ( "project" );
	{
		// Write project recent
		for ( int i_iterator = 0; i_iterator < pSetApp->sPrj.QStringList_recent.size (); i_iterator++ )
		{
			QString QString_key = QString ( "recent" ) + QString::number ( i_iterator );
			QString QString_val = pSetApp->sPrj.QStringList_recent.at ( i_iterator );

			QSettings_wr.setValue ( QString_key, QString_val );
		}

		// Write project collection
		for ( int i_iterator = 0; i_iterator < pSetApp->sPrj.QStringList_collection.size (); i_iterator++ )
		{
			QString QString_key = QString ( "collection" ) + QString::number ( i_iterator );
			QString QString_val = pSetApp->sPrj.QStringList_collection.at ( i_iterator );

			QSettings_wr.setValue ( QString_key, QString_val );
		}

		QSettings_wr.endGroup ();
	}

	QSettings_wr.sync ();
}

/**
 *****************************************************************************************************************************
 */

void SetAppRdWr::saveSetFont ( QSettings * pQSettings_wr, int i_index, QTextCharFormat * pQTextCharFormat )
{
	pQSettings_wr->setArrayIndex ( i_index );
	
	pQSettings_wr->setValue ( "italic", pQTextCharFormat->fontItalic () );
	pQSettings_wr->setValue ( "weight", pQTextCharFormat->fontWeight () );
	pQSettings_wr->setValue ( "color",  pQTextCharFormat->foreground () );
}

/**
 *****************************************************************************************************************************
 */