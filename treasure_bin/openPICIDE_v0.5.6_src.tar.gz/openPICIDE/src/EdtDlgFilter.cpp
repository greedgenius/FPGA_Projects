/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "EdtDlgFilter.h"
#include "PicPblzeAsmParser.h"

/**
 *****************************************************************************************************************************
 */

EdtDlgFilter::EdtDlgFilter ( QWidget * pQWidgetParent ) : QWidget ( pQWidgetParent )
{
	QVBoxLayout * pQVBoxLayout_dialog = new QVBoxLayout;
	{
		QGroupBox * pQGroupBox_source = new QGroupBox ( tr ( "Source file" ) );
                {
			QHBoxLayout * pQHBoxLayout = new QHBoxLayout;
			{
				QLabel * pQLabel = new QLabel;
				{
					pQLabel->setText ( QObject::tr ( "Source file:" ) );
				}
				this->pQLineEdit_srcFilePath = new QLineEdit;
				{
				}
				
				QPushButton * pQPushButton_sel = new QPushButton;
				{
					pQPushButton_sel->setFixedWidth ( 50 );
					pQPushButton_sel->setIcon ( QIcon ( ":/edt/img/edt/document-open.png" ) );

					connect ( pQPushButton_sel,
						SIGNAL ( clicked ( ) ),
						this,
						SLOT ( srcFileSelect ( ) )
					);
				}
	
				pQHBoxLayout->addWidget ( pQLabel );
				pQHBoxLayout->addWidget ( pQLineEdit_srcFilePath );
				pQHBoxLayout->addWidget ( pQPushButton_sel );
			}
			pQGroupBox_source->setLayout ( pQHBoxLayout );
		}
		
		QGroupBox * pQGroupBox_fileBrowserSrc = new QGroupBox ( tr ( "Source file browser" ) );
                {
			QVBoxLayout * pQVBoxLayout = new QVBoxLayout;
			{
				QHBoxLayout * pQHBoxLayout = new QHBoxLayout;
				{
					QHBoxLayout * pQHBoxLayout_syntax = new QHBoxLayout;
					{
						QLabel * pQLabel = new QLabel;
						{
							pQLabel->setText ( QObject::tr ( "Syntax:" ) );
						}
						
						this->pQComboBox_srcSyntax = new QComboBox;
						{
							this->pQComboBox_srcSyntax->addItem ( QString ( "Please select" ), -1 ); 
							this->pQComboBox_srcSyntax->addItem ( QString ( "openPICIDE 0.1 - 0.3" ), eSyntaxOpenPICIDE_v0_3_0 ); 
							this->pQComboBox_srcSyntax->addItem ( QString ( "Mediatronix" ), eSyntaxMediatronix ); 
							this->pQComboBox_srcSyntax->addItem ( QString ( "Xilinx" ), eSyntaxXilinx ); 
						}
						pQHBoxLayout_syntax->addWidget ( pQLabel );
						pQHBoxLayout_syntax->addWidget ( this->pQComboBox_srcSyntax );
					}
					
					QHBoxLayout * pQHBoxLayout_tabSpace = new QHBoxLayout;
					{
						QLabel * pQLabel = new QLabel;
						{
							pQLabel->setText ( QObject::tr ( "Tab space:" ) );
						}
						this->pQSpinBox_tabSpaceSrc = new QSpinBox;
						{
							this->pQSpinBox_tabSpaceSrc->setMaximum ( 100 );
							this->pQSpinBox_tabSpaceSrc->setMinimum ( 1 );
							this->pQSpinBox_tabSpaceSrc->setValue ( 4 );
						}
					
						pQHBoxLayout_tabSpace->addWidget ( pQLabel );
						pQHBoxLayout_tabSpace->addWidget ( this->pQSpinBox_tabSpaceSrc );
					}
					
					pQHBoxLayout->addLayout ( pQHBoxLayout_syntax );
					pQHBoxLayout->addLayout ( pQHBoxLayout_tabSpace );
					pQHBoxLayout->addStretch ();
				}
				
				this->pEdtEditorWidget_src = new EdtEditorWidget;
				{
					this->pEdtEditorWidget_src->setTabStopWidth ( 4 );
					this->pEdtEditorWidget_src->setLineWrapMode( QPlainTextEdit::NoWrap );
					
					connect ( this->pQSpinBox_tabSpaceSrc,
						SIGNAL ( valueChanged ( int ) ),
						this->pEdtEditorWidget_src,
						SLOT ( setTabStopWidth ( int ) )
					);
				}
				pQVBoxLayout->addLayout ( pQHBoxLayout );
				pQVBoxLayout->addWidget ( this->pEdtEditorWidget_src );
			}
			pQGroupBox_fileBrowserSrc->setLayout ( pQVBoxLayout );
		}

		QHBoxLayout * pQHBoxLayout_cnvButtons = new QHBoxLayout;
                {
			QPushButton * pQPushButton_cnvRestart = new QPushButton;
			{
				pQPushButton_cnvRestart->setText ( QObject::tr ( "&Restart" ) );

				connect ( pQPushButton_cnvRestart, SIGNAL ( clicked () ), this, SLOT ( convertNxtRestart () ) );
			}
			QPushButton * pQPushButton_cnvNxt = new QPushButton;
			{
				pQPushButton_cnvNxt->setText ( QObject::tr ( "Convert &line" ) );

				connect ( pQPushButton_cnvNxt, SIGNAL ( clicked () ), this, SLOT ( convertNxt () ) );
			}
			QPushButton * pQPushButton_cnvtAll = new QPushButton;
			{
				pQPushButton_cnvtAll->setText ( QObject::tr ( "Convert &all" ) );

				connect ( pQPushButton_cnvtAll, SIGNAL ( clicked () ), this, SLOT ( convertAll () ) );
			}
			pQHBoxLayout_cnvButtons->addStretch ();
			pQHBoxLayout_cnvButtons->addWidget ( pQPushButton_cnvRestart );
			pQHBoxLayout_cnvButtons->addWidget ( pQPushButton_cnvNxt );
			pQHBoxLayout_cnvButtons->addWidget ( pQPushButton_cnvtAll );
		}
		
		QGroupBox * pQGroupBox_fileBrowserDst = new QGroupBox ( tr ( "Destination file browser" ) );
                {
			QVBoxLayout * pQVBoxLayout = new QVBoxLayout;
			{
				QHBoxLayout * pQHBoxLayout = new QHBoxLayout;
				{
					QHBoxLayout * pQHBoxLayout_tabSpace = new QHBoxLayout;
					{
						QLabel * pQLabel = new QLabel;
						{
							pQLabel->setText ( QObject::tr ( "Tab space:" ) );
						}
						this->pQSpinBox_tabSpaceDst = new QSpinBox;
						{
							this->pQSpinBox_tabSpaceDst->setMaximum ( 100 );
							this->pQSpinBox_tabSpaceDst->setMinimum ( 1 );
							this->pQSpinBox_tabSpaceDst->setValue ( 4 );
						}
					
						pQHBoxLayout_tabSpace->addWidget ( pQLabel );
						pQHBoxLayout_tabSpace->addWidget ( this->pQSpinBox_tabSpaceDst );
					}
					
					pQHBoxLayout->addLayout ( pQHBoxLayout_tabSpace );
					pQHBoxLayout->addStretch ();
				}			
			
				this->pEdtEditorWidget_dst = new EdtEditorWidget;
				{
					this->pEdtEditorWidget_dst->setTabStopWidth ( 4 );
					this->pEdtEditorWidget_dst->setLineWrapMode ( QPlainTextEdit::NoWrap );
					
					connect ( this->pQSpinBox_tabSpaceDst,
						SIGNAL ( valueChanged ( int ) ),
						this->pEdtEditorWidget_dst,
						SLOT ( setTabStopWidth ( int ) )
					);
				}
				pQVBoxLayout->addLayout ( pQHBoxLayout );
				pQVBoxLayout->addWidget ( this->pEdtEditorWidget_dst );
			}
			pQGroupBox_fileBrowserDst->setLayout ( pQVBoxLayout );
		}

		QHBoxLayout * pQHBoxLayout_buttons = new QHBoxLayout;
                {
			QPushButton * pQPushButton_use = new QPushButton;
			{
				pQPushButton_use->setText ( QObject::tr ( "&Use converted file" ) );

				connect ( pQPushButton_use, SIGNAL ( clicked () ), this, SLOT ( useDstFile () ) );
			}
/*			QPushButton * pQPushButton_close = new QPushButton;
			{
				pQPushButton_close->setText ( QObject::tr ( "&Close" ) );

				connect ( pQPushButton_close, SIGNAL ( clicked () ), this, SLOT ( reject () ) );
			}*/
			
			pQHBoxLayout_buttons->addStretch ();
			pQHBoxLayout_buttons->addWidget ( pQPushButton_use );
// 			pQHBoxLayout_buttons->addWidget ( pQPushButton_close );
		}
		
		pQVBoxLayout_dialog->addWidget ( pQGroupBox_source );
		pQVBoxLayout_dialog->addWidget ( pQGroupBox_fileBrowserSrc );
		pQVBoxLayout_dialog->addLayout ( pQHBoxLayout_cnvButtons );
		pQVBoxLayout_dialog->addWidget ( pQGroupBox_fileBrowserDst );
		pQVBoxLayout_dialog->addLayout ( pQHBoxLayout_buttons );
	}
	
	QWidget::setLayout ( pQVBoxLayout_dialog );
//         QDialog::setLayout ( pQVBoxLayout_dialog );
// 	QDialog::setWindowTitle ( QString ( tr ( "Assembler file import" ) ) );
//         QDialog::resize ( 800, 600 );

	this->pPicPblzeAsmImportMetrx      = new PicPblzeAsmImportMetrx;
	this->pPicPblzeAsmImportOpenPICIDE = new PicPblzeAsmImportOpenPICIDE;
	this->pPicPblzeAsmImportXilinx     = new PicPblzeAsmImportXilinx;

// 	this->srcFileSelect ( "/home/christoph/Projekte/SW-Entwicklung/openPicIdePrj/openPICIDE/importFileXilinx.psm" );
// 	this->srcFileSelect ( "/home/christoph/Projekte/SW-Entwicklung/openPicIdePrj/openPICIDE/importFileMetrx.psm" );
}

/**
 *****************************************************************************************************************************
 */

void EdtDlgFilter::setPath ( QString QString_path )
{
	this->QString_path = QString_path;
}

/**
 *****************************************************************************************************************************
 */

bool EdtDlgFilter::chkSettings ( void )
{
	if ( pQComboBox_srcSyntax->itemData ( pQComboBox_srcSyntax->currentIndex() ).toInt() < 0 )
	{
		QMessageBox QMessageBox_err;
		{
			QMessageBox_err.setText ( "Invalid settings." );
			QMessageBox_err.setInformativeText ( "Please select the source syntax to import." );
			QMessageBox_err.setStandardButtons ( QMessageBox::Ok );
			QMessageBox_err.setIcon ( QMessageBox::Critical );
			
			QMessageBox_err.exec();
		}
		
		return FALSE;
	}	
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

void EdtDlgFilter::convertAll ( void )
{
	// Check if settings valid
	if ( ! this->chkSettings () )
		return;	
	
	QString QString_line;
	
// 	this->pEdtEditorWidget_dst->setUpdatesEnabled ( FALSE );
	
	// Get line from source
	while ( this->pEdtEditorWidget_src->getLine ( this->i_lineCntr, & QString_line ) )
	{
		// Convert line
		QString_line = this->convertLine ( QString_line );
	
		// Set converted line to destination
// 		this->pEdtEditorWidget_dst->setLine ( this->i_lineCntr, QString_line );
		this->pEdtEditorWidget_dst->appendPlainText ( QString_line );

		// Set highlighting
		this->i_lineCntr++;
	
		this->pEdtEditorWidget_src->selectLine ( this->i_lineCntr );
		this->pEdtEditorWidget_dst->selectLine ( this->i_lineCntr );
		
		this->pEdtEditorWidget_src->ensureCursorVisible ();
		this->pEdtEditorWidget_dst->ensureCursorVisible ();

		QApplication::processEvents ( QEventLoop::AllEvents );
	}
	
// 	this->pEdtEditorWidget_src->selectLine ( this->i_lineCntr );
// 	this->pEdtEditorWidget_dst->selectLine ( this->i_lineCntr );
	
// 	this->pEdtEditorWidget_src->ensureCursorVisible ();
// 	this->pEdtEditorWidget_dst->ensureCursorVisible ();

// 	this->pEdtEditorWidget_dst->setUpdatesEnabled ( TRUE );
}

/**
 *****************************************************************************************************************************
 */

void EdtDlgFilter::convertNxtRestart ( void )
{
	this->i_lineCntr = 0;

	this->pEdtEditorWidget_src->selectLine ( this->i_lineCntr );
	this->pEdtEditorWidget_dst->selectLine ( this->i_lineCntr );
	
	this->pEdtEditorWidget_src->ensureCursorVisible ();
	this->pEdtEditorWidget_dst->clear ();
// 	this->pEdtEditorWidget_dst->clearLineHighlighting ();
}

/**
 *****************************************************************************************************************************
 */

void EdtDlgFilter::convertNxt ( void )
{
	// Check if settings valid
	if ( ! this->chkSettings () )
		return;	
	
	QString QString_line;
	
	// Get line from source
	if ( ! this->pEdtEditorWidget_src->getLine ( this->i_lineCntr, & QString_line ) )
		return;
	
	// Convert line
	QString_line = this->convertLine ( QString_line );
	
	// Set converted line to destination
	this->pEdtEditorWidget_dst->setLine ( this->i_lineCntr, QString_line );

	// Set highlighting
	this->i_lineCntr++;
	
	this->pEdtEditorWidget_src->selectLine ( this->i_lineCntr );
	this->pEdtEditorWidget_dst->selectLine ( this->i_lineCntr );
	
	this->pEdtEditorWidget_src->ensureCursorVisible ();
	this->pEdtEditorWidget_dst->ensureCursorVisible ();
}

/**
 *****************************************************************************************************************************
 */

void EdtDlgFilter::useDstFile ( void )
{
	emit fileFiltered ( this->pEdtEditorWidget_dst->toPlainText () );
	
	this->pEdtEditorWidget_src->selectLine ( 0 );
	this->pEdtEditorWidget_dst->clear ();
}

/**
 *****************************************************************************************************************************
 */

void EdtDlgFilter::srcFileSelect ( QString QString_srcFile )
{
	// Get file path
	if ( QString_srcFile.isEmpty() )
	{
		// Init dialog
		QFileDialog QFileDialog_file;
		QFileDialog_file.setViewMode ( QFileDialog::Detail );
		QFileDialog_file.setDefaultSuffix ( QString ( "*" ) );
		QFileDialog_file.setAcceptMode ( QFileDialog::AcceptOpen );
		QFileDialog_file.setWindowTitle ( QObject::tr ( "Select source file" ) );
		QFileDialog_file.setNameFilter ( QObject::tr ( "Assembler files (*.asm *.psm)" ) );
		QFileDialog_file.setFileMode ( QFileDialog::ExistingFiles );
		QFileDialog_file.setDirectory ( this->QString_path );
		
		if ( ! QFileDialog_file.exec () )
			return;

		QStringList QStringList_files = QFileDialog_file.selectedFiles ();

		if ( QStringList_files.count () != 1 )
			return;

		QString_srcFile =  QStringList_files.at ( 0 );
	}

	// Set source file
	this->pQLineEdit_srcFilePath->setText ( QString_srcFile );
	
	// Check, if file exists
	{
		if ( ! QFileInfo ( QString_srcFile ).isReadable () )
			return;

		this->QString_path = QFileInfo ( QString_srcFile ).path ();
		
		this->pEdtEditorWidget_src->clear ();
		this->pEdtEditorWidget_dst->clear ();

		QFile QFile_srcFile ( this->pQLineEdit_srcFilePath->text () );

		if ( ! QFile_srcFile.open ( QIODevice::ReadOnly | QIODevice::Text ) )
			return;

		this->pEdtEditorWidget_src->setPlainText( QFile_srcFile.readAll() );
// 		this->pQTextDocument->setPlainText( QFile_srcFile.readAll() );

		QFile_srcFile.close();
		
		// Select first line
		this->pEdtEditorWidget_src->selectLine ( 0 );
		this->pEdtEditorWidget_dst->selectLine ( 0 );
		
		this->i_lineCntr = 0;
	}
}

/**
 *****************************************************************************************************************************
 */

QString EdtDlgFilter::convertLine ( QString QString_line )
{
	// Check, which syntax is selected
	switch ( pQComboBox_srcSyntax->itemData ( pQComboBox_srcSyntax->currentIndex() ).toInt() )
	{
		case eSyntaxOpenPICIDE_v0_3_0:	this->pPicPblzeAsmImportOpenPICIDE->convertLine ( & QString_line );	break;
		case eSyntaxMediatronix:	this->pPicPblzeAsmImportMetrx->convertLine ( & QString_line );		break;
		case eSyntaxXilinx:		this->pPicPblzeAsmImportXilinx->convertLine ( & QString_line );		break;
	}

	return QString_line;
}

/**
 *****************************************************************************************************************************
 */

void EdtDlgFilter::setHighlightingParameter ( EdtEditorHighlighter::sHighlightingParameter_t sHighlightingParameter )
{
	this->sHighlightingParameter = sHighlightingParameter;
	
	this->pEdtEditorWidget_dst->setHighlightingParameter ( sHighlightingParameter );
	this->setHighlightingParameterSrc ();
}

/**
 *****************************************************************************************************************************
 */

void EdtDlgFilter::setHighlightingParameterSrc ( void )
{
	switch ( pQComboBox_srcSyntax->itemData ( pQComboBox_srcSyntax->currentIndex() ).toInt() )
	{
		case eSyntaxOpenPICIDE_v0_3_0:
			sHighlightingParameter.keyWords.QStringList_cmd		= PicPblzeAsmParser::getCmdList ( PicPblzeSet::ePblze3 );
			sHighlightingParameter.keyWords.QStringList_directive	= PicPblzeAsmParser::getDirectiveList ( PicPblzeSet::ePblze3 );
			sHighlightingParameter.keyWords.QStringList_hwComponent	= PicPblzeAsmParser::getHwComponentList ( PicPblzeSet::ePblze3 );
			sHighlightingParameter.keyWords.QMap_numberRegExp	= PicPblzeAsmParser::getNumberRegExp ( PicPblzeSet::ePblze3 );
			break;
		
		case eSyntaxMediatronix:
			
// 			this->pPicPblzeAsmImportMetrx->convertLine ( & QString_line );
			break;
			
		case eSyntaxXilinx:
// 			this->pPicPblzeAsmImportOpenPICIDE->convertLine ( & QString_line );
// 			this->lineSubstXilinx ( & sLineFragments  );
			break;
			
		default:
			sHighlightingParameter.keyWords.QStringList_cmd.clear ();
			sHighlightingParameter.keyWords.QStringList_directive.clear ();
			sHighlightingParameter.keyWords.QStringList_hwComponent.clear ();
			sHighlightingParameter.keyWords.QMap_numberRegExp.clear ();
			break;
	}
	
	this->pEdtEditorWidget_src->setHighlightingParameter ( sHighlightingParameter );
}
