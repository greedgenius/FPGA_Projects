/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeAsmImportXilinx.h"

/**
 *****************************************************************************************************************************
 */

PicPblzeAsmImportXilinx::PicPblzeAsmImportXilinx () : PicImport ()
{
}

/**
 *****************************************************************************************************************************
 */

QStringList PicPblzeAsmImportXilinx::getCmdList ( void )
{
}

/**
 *****************************************************************************************************************************
 */

QStringList PicPblzeAsmImportXilinx::getDirectiveList ( void )
{
}

/**
 *****************************************************************************************************************************
 */

QStringList PicPblzeAsmImportXilinx::getHwComponentList ( void )
{
}

/**
 *****************************************************************************************************************************
 */

QMap<QString, QStringList> PicPblzeAsmImportXilinx::getNumberRegExp ( void )
{
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportXilinx::convertLine ( QString * pQString_line )
{
	PicImport::sLineFragments_t sLineFragments;

	// Split lines into fragments
	sLineFragments = PicImport::lineSplit ( * pQString_line );

	PicImport::eRetVal_t eRetVal;

	// Substitute line
	eRetVal = this->lineSubst ( & sLineFragments );

	// Combine fragments to line
	if ( eRetVal == eRetValChanged )
		*pQString_line = PicImport::lineCombine ( & sLineFragments );

	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportXilinx::lineSubst ( PicImport::sLineFragments_t * psLineFragments )
{
	QString QString_cmd  = psLineFragments->QString_2_text.toUpper();
	QString QString_arg0 = psLineFragments->QString_4_text;
	QString QString_arg1 = psLineFragments->QString_6_text;
	
// 	qDebug() << QString_cmd;

	// PicoBlaze - Picoblaze3
	     if ( QString ( "RETURN" )  == QString_cmd ) { return this->renameCmd     ( psLineFragments ); }
	else if ( QString ( "RETURNI" ) == QString_cmd ) { return this->renameCmd     ( psLineFragments ); }
	else if ( QString ( "ADDCY" )   == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "SUBCY" )   == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "INPUT" )   == QString_cmd ) { return this->chkInstRegIO   ( psLineFragments ); }
	else if ( QString ( "OUTPUT" )  == QString_cmd ) { return this->chkInstRegIO   ( psLineFragments ); }
	else if ( QString ( "ENABLE" )  == QString_cmd ) { return this->chkInstInt     ( psLineFragments ); }
	else if ( QString ( "DISABLE" ) == QString_cmd ) { return this->chkInstInt     ( psLineFragments ); }
	else if ( QString ( "COMPARE" ) == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "ADD" )     == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "AND" )     == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "CALL" )    == QString_cmd ) { return eRetValUnchanged; }
	else if ( QString ( "JUMP" )    == QString_cmd ) { return eRetValUnchanged; }
	else if ( QString ( "LOAD" )    == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "OR" )      == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "RL" )      == QString_cmd ) { return eRetValUnchanged; }
	else if ( QString ( "RR" )      == QString_cmd ) { return eRetValUnchanged; }
	else if ( QString ( "SL0" )     == QString_cmd ) { return eRetValUnchanged; }
	else if ( QString ( "SL1" )     == QString_cmd ) { return eRetValUnchanged; }
	else if ( QString ( "SLA" )     == QString_cmd ) { return eRetValUnchanged; }
	else if ( QString ( "SLX" )     == QString_cmd ) { return eRetValUnchanged; }
	else if ( QString ( "SR0" )     == QString_cmd ) { return eRetValUnchanged; }
	else if ( QString ( "SR1" )     == QString_cmd ) { return eRetValUnchanged; }
	else if ( QString ( "SRA" )     == QString_cmd ) { return eRetValUnchanged; }
	else if ( QString ( "SRX" )     == QString_cmd ) { return eRetValUnchanged; }
	else if ( QString ( "SUB" )     == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "TEST" )    == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "XOR" )     == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "STORE" )   == QString_cmd ) { return this->chkInstRegIO   ( psLineFragments ); }
	else if ( QString ( "FETCH" )   == QString_cmd ) { return this->chkInstRegIO   ( psLineFragments ); }
	
	// PicoBlaze 6
	else if ( QString ( "STAR" )		== QString_cmd ) { return eRetValUnchanged; }
	else if ( QString ( "TESTCY" )		== QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "COMPARECY" )	== QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "REGBANK" )		== QString_cmd ) { return eRetValUnchanged; }
	else if ( QString ( "OUTPUTK" )		== QString_cmd ) { return this->chkInstRegIO   ( psLineFragments ); }
	else if ( QString ( "JUMP@" )		== QString_cmd ) { return this->renameCmd      ( psLineFragments ); }
	else if ( QString ( "CALL@" )		== QString_cmd ) { return this->renameCmd      ( psLineFragments ); }
	else if ( QString ( "LOAD&RETURN" )	== QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "HWBUILD" )		== QString_cmd ) { return eRetValUnchanged; }
	
	
	else if ( QString ( "ADDRESS" )  == QString_cmd ) { return this->chkInstAddr     ( psLineFragments ); }
	else if ( QString ( "CONSTANT" ) == QString_cmd ) { return this->chkInstConstant ( psLineFragments ); }
	else if ( QString ( "NAMEREG" )  == QString_cmd ) { return this->chkInstNamereg  ( psLineFragments ); }

	return eRetValUnchanged;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportXilinx::renameCmd ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;
	
	QString QString_cmd = psLineFragments->QString_2_text.toUpper();

	     if ( QString ( "RETURN" )      == QString_cmd ) { QString_cmd = QString ( "RET" );		eRetVal = eRetValChanged; }
	else if ( QString ( "RETURNI" )     == QString_cmd ) { QString_cmd = QString ( "RETI" );	eRetVal = eRetValChanged; }
	else if ( QString ( "CALL@" )       == QString_cmd ) { QString_cmd = QString ( "CALL" );	eRetVal = eRetValChanged; }
	else if ( QString ( "JUMP@" )       == QString_cmd ) { QString_cmd = QString ( "JUMP" ); 	eRetVal = eRetValChanged; }
	
	psLineFragments->QString_2_text = QString_cmd;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportXilinx::chkInstInt ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;
	
	QString QString_cmd = psLineFragments->QString_2_text.toUpper();

	     if ( QString ( "ENABLE" )  == QString_cmd ) { QString_cmd = QString ( "EINT" ); eRetVal = eRetValChanged; }
	else if ( QString ( "DISABLE" ) == QString_cmd ) { QString_cmd = QString ( "DINT" ); eRetVal = eRetValChanged; }
	
	psLineFragments->QString_2_text = QString_cmd;
	psLineFragments->QString_4_text.clear();
	psLineFragments->QString_6_text.clear();
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportXilinx::chkInstRegVari ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_cmd  = psLineFragments->QString_2_text.toUpper();
	QString QString_arg1 = psLineFragments->QString_6_text;

	     if ( QString ( "ADDCY" )       == QString_cmd ) { QString_cmd = QString ( "ADDC" ); 	eRetVal = eRetValChanged; }
	else if ( QString ( "SUBCY" )       == QString_cmd ) { QString_cmd = QString ( "SUBC" ); 	eRetVal = eRetValChanged; }
	else if ( QString ( "COMPARE" )     == QString_cmd ) { QString_cmd = QString ( "COMP" ); 	eRetVal = eRetValChanged; }
	else if ( QString ( "COMPARECY" )   == QString_cmd ) { QString_cmd = QString ( "COMPC" ); 	eRetVal = eRetValChanged; }
	else if ( QString ( "TESTCY" )      == QString_cmd ) { QString_cmd = QString ( "TESTC" ); 	eRetVal = eRetValChanged; }
	else if ( QString ( "LOAD&RETURN" ) == QString_cmd ) { QString_cmd = QString ( "LOADRET" ); 	eRetVal = eRetValChanged; }

	this->chkArgNumber ( & QString_arg1, & eRetVal );

	psLineFragments->QString_2_text = QString_cmd;
	psLineFragments->QString_6_text = QString_arg1;

	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportXilinx::chkInstRegIO ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_cmd  = psLineFragments->QString_2_text.toUpper();
	QString QString_arg0 = psLineFragments->QString_4_text;
	QString QString_arg1 = psLineFragments->QString_6_text;

	     if ( QString ( "INPUT" )   == QString_cmd ) { QString_cmd = QString ( "IN" ); 	eRetVal = eRetValChanged; }
	else if ( QString ( "OUTPUT" )  == QString_cmd ) { QString_cmd = QString ( "OUT" ); 	eRetVal = eRetValChanged; }
	else if ( QString ( "OUTPUTK" ) == QString_cmd ) { QString_cmd = QString ( "OUT" );	eRetVal = eRetValChanged; }

	this->chkArgNumber ( & QString_arg0, & eRetVal );
	this->chkArgNumber ( & QString_arg1, & eRetVal );
	
	psLineFragments->QString_2_text = QString_cmd;
	psLineFragments->QString_4_text = QString_arg0;
	psLineFragments->QString_6_text = QString_arg1;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportXilinx::chkInstAddr ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_cmd  = psLineFragments->QString_2_text.toUpper();
	QString QString_arg0 = psLineFragments->QString_4_text;

	if ( QString ( "ADDRESS" ) == QString_cmd ) { QString_cmd = QString ( "ORG" ); 	eRetVal = eRetValChanged; }
	
	this->chkArgNumber ( & QString_arg0, & eRetVal );

	psLineFragments->QString_2_text = QString_cmd;
	psLineFragments->QString_4_text = QString_arg0;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportXilinx::chkInstConstant ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_cmd  = psLineFragments->QString_2_text.toUpper();
	QString QString_arg0 = psLineFragments->QString_4_text;
	QString QString_arg1 = psLineFragments->QString_6_text;

	if ( QString ( "CONSTANT" ) == QString_cmd ) { QString_cmd = QString ( "EQU" ); 	eRetVal = eRetValChanged; }

	if ( QString_arg0.at ( QString_arg0.size() - 1 ) == QChar ( ',' ) )
		QString_arg0.remove ( QString_arg0.size() - 1, 1 );

	this->chkArgNumber ( & QString_arg1, & eRetVal );
	
	psLineFragments->QString_2_text = QString_arg0;
	psLineFragments->QString_4_text = QString_cmd;
	psLineFragments->QString_6_text = QString_arg1;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportXilinx::chkInstNamereg ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_cmd  = psLineFragments->QString_2_text.toUpper();
	QString QString_arg0 = psLineFragments->QString_4_text;
	QString QString_arg1 = psLineFragments->QString_6_text;

	if ( QString ( "NAMEREG" ) == QString_cmd ) { QString_cmd = QString ( "EQU" ); 	eRetVal = eRetValChanged; }
	
	if ( QString_arg0.at ( QString_arg0.size() - 1 ) == QChar ( ',' ) )
		QString_arg0.remove ( QString_arg0.size() - 1, 1 );

	psLineFragments->QString_2_text = QString_arg1;
	psLineFragments->QString_4_text = QString_cmd;
	psLineFragments->QString_6_text = QString_arg0;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmImportXilinx::chkArgNumber ( QString * pQString_arg, PicImport::eRetVal_t * peRetVal )
{
	//********************************************************************************************************************
	//* Check for hex
	//********************************************************************************************************************
	if ( pQString_arg->contains ( QRegExp ( "^[0-9a-fA-F]*,?$" ) ) )
	{
		pQString_arg->insert ( 0, "0x" );
		
		if ( eRetValUnchanged == *peRetVal )
			*peRetVal = eRetValChanged;
		
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

