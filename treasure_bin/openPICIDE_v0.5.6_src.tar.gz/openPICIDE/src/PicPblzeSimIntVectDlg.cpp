/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeSimIntVectDlg.h"

/**
 *****************************************************************************************************************************
 */

PicPblzeSimIntVectDlg::PicPblzeSimIntVectDlg ( QWidget * pQWidget_parent ) : QDialog ( pQWidget_parent )
{
	QVBoxLayout * pQVBoxLayout = new QVBoxLayout;
	{
		QLabel * pQLabel;
		
		pQLabel = new QLabel;
		{
			pQLabel->setText ( tr ( "An interrupt is being handled." ) );
						      
			pQLabel->setTextFormat ( Qt::RichText );
		}
		pQVBoxLayout->addWidget ( pQLabel );

		pQLabel = new QLabel;
		{
			pQLabel->setText ( tr ( "Since you are using banks and the program counter <br/>"	\
						"points to a command line within the shared range, <br/>"	\
						"the simulator has no information about the current, <br/>"	\
						"bank selection." ) );
						      
			pQLabel->setTextFormat ( Qt::RichText );
		}
		pQVBoxLayout->addWidget ( pQLabel );

		pQLabel = new QLabel;
		{
			pQLabel->setText ( tr ( "Please select a bank from list below." ) );
						      
			pQLabel->setTextFormat ( Qt::RichText );
		}
		pQVBoxLayout->addWidget ( pQLabel );

		this->pQTreeView = new QTreeView ( this );
		{
			this->pQStandardItemModel = new QStandardItemModel ( this );
			
			this->pQTreeView->setModel ( this->pQStandardItemModel );
			this->pQTreeView->setRootIsDecorated ( FALSE );
			this->pQTreeView->setAlternatingRowColors ( TRUE );
			this->pQTreeView->setHeaderHidden ( TRUE );

			connect ( 
				this->pQTreeView, 
				SIGNAL ( clicked ( QModelIndex ) ), 
				this, 
				SLOT ( hndlClick ( QModelIndex ) )
			);
			connect ( 
				this->pQTreeView, 
				SIGNAL ( doubleClicked ( QModelIndex ) ), 
				this, 
				SLOT ( hndlDblClick ( QModelIndex ) )
			);
		}
		
		// Set Button Layout
		QHBoxLayout * pQHBoxLayout_buttons = new QHBoxLayout;
		{
			// Set Buttons
			QPushButton * pQPushButton_Ok     = new QPushButton ( tr ( "&Ok" ) );
			QPushButton * pQPushButton_cancel = new QPushButton ( tr ( "&Cancel" ) );

			pQPushButton_Ok->setDefault ( TRUE );
			
	// 		QDialog::setTabOrder ( pQPushButton_Ok, pQPushButton_cancel );
			
			connect ( pQPushButton_Ok,     SIGNAL ( clicked() ), this, SLOT ( handleEventOk() ) );

			pQHBoxLayout_buttons->addStretch ( 1 );
			pQHBoxLayout_buttons->addWidget ( pQPushButton_Ok );
		}
		
		// Insert Pushbuttons
		
		pQVBoxLayout->addWidget ( this->pQTreeView );
		pQVBoxLayout->addLayout ( pQHBoxLayout_buttons );
	}
	
	// Set dialog layout
// 	QVBoxLayout * pQVBoxLayout_main = new QVBoxLayout;
// 	pQVBoxLayout_main->addLayout ( QHBoxLayout_NaviAndPages );
// 	pQVBoxLayout_main->addSpacing ( 12 );
// 	pQVBoxLayout_main->addLayout ( pQHBoxLayout_buttons );

	QDialog::setLayout ( pQVBoxLayout );
	QDialog::setWindowTitle ( QObject::tr ( "Select bank for interrupt" ) );
	QDialog::resize ( 100, 100 );
}

/**
 *****************************************************************************************************************************
 */

int PicPblzeSimIntVectDlg::getBankSelection ( int i_bankCount )
{
// 	this->i_bankSel = 0;

	this->pQStandardItemModel->clear ();
	
	this->pQStandardItemModel->setColumnCount ( 1 );
	this->pQStandardItemModel->setRowCount ( 0 );

	for ( int i_iterator = 0; i_iterator < i_bankCount; ++i_iterator )
	{
		QStandardItem * pQStandardItem = new QStandardItem;
		{
			pQStandardItem->setEditable ( FALSE );
			pQStandardItem->setText ( QString ( "Bank %1" ).arg ( i_iterator ) );
		}		

		this->pQStandardItemModel->insertRow ( i_iterator );
		this->pQStandardItemModel->setItem   ( i_iterator, 0, pQStandardItem );
	}

	// Select first row
	this->pQTreeView->setCurrentIndex ( this->pQTreeView->model()->index ( 0, 0 ) );

	QDialog::exec();

	return this->pQTreeView->currentIndex().row();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimIntVectDlg::hndlClick ( QModelIndex QModelIndex_clicked )
{
// 	this->i_bankSel = QModelIndex_clicked.row();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimIntVectDlg::hndlDblClick ( QModelIndex QModelIndex_clicked )
{
// 	this->i_bankSel = QModelIndex_clicked.row();
	
	QDialog::close();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeSimIntVectDlg::handleEventOk ( void )
{
	QDialog::close();
}

/**
 *****************************************************************************************************************************
 */










