/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "Pic.h"
#include "PicPblze.h"

Pic::Pic ( Mod * pMod, QObject * pQObject_parent ) : QObject ( pQObject_parent )
{
	// Init
	this->pMod = pMod;
	this->sPicCurrent.pPicNone = NULL;
}

/**
 *****************************************************************************************************************************
 */

Pic::~Pic ( void )
{
	this->removePic();
}

/**
 *****************************************************************************************************************************
 */

void Pic::setupMenuBar ( QMenuBar * pQMenuBar )
{
	// Check, if pic valid
	if ( ! this->sPicCurrent.pPicNone )
		return;

	// Set settings
	if ( this->sPicCurrent.QString_picType == PicPblze::getName () )
	{
		PicPblze * pPicPblze = static_cast <PicPblze *> ( this->sPicCurrent.pPicNone );
		pPicPblze->setupMenuBar ( pQMenuBar );
	}
}

/**
 *****************************************************************************************************************************
 */

void Pic::changeSettings ( void )
{
	QString QString_picTypeNew = this->pMod->pSet->Prj.sPic.QString_picType;

	if ( ! this->sPicCurrent.pPicNone )
	{
		if ( ! this->createPic ( QString_picTypeNew ) )
			return;
	}
	else if ( this->sPicCurrent.QString_picType != QString_picTypeNew )
	{
		this->removePic ();

		if ( ! this->createPic ( QString_picTypeNew ) )
			return;
	}

	this->sPicCurrent.QString_picType = QString_picTypeNew;

	// Set settings
	if ( QString_picTypeNew == PicPblze::getName () )
	{
		PicPblze * pPicPblze = static_cast <PicPblze *> ( this->sPicCurrent.pPicNone );
		pPicPblze->changeSettings ();
	}
}

/**
 *****************************************************************************************************************************
 */

bool Pic::createPic ( QString QString_pic )
{
	if ( QString_pic == PicPblze::getName () )
	{
		this->sPicCurrent.pPicNone = static_cast <PicNone *> ( new PicPblze ( this->pMod ) );

		if ( ! this->sPicCurrent.pPicNone )
			return FALSE;

		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

void Pic::removePic ( void )
{
	if ( ! this->sPicCurrent.pPicNone )
		return;

	if ( this->sPicCurrent.QString_picType == PicPblze::getName () )
	{
		PicPblze * pPicPblze = static_cast <PicPblze *> ( this->sPicCurrent.pPicNone );
		delete pPicPblze;
	}

	this->sPicCurrent.pPicNone = NULL;
}

/**
 *****************************************************************************************************************************
 */


