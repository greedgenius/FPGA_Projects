/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   The original code of this file was copied from nokia qt 4.6.0 examples and then modified for openPICIDE.                *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PICIOFIFOVALDLGEDITOR_H
#define PICIOFIFOVALDLGEDITOR_H

#include <QtCore>
#include <QtGui>

/**
 *****************************************************************************************************************************
 *
 *      \brief Text editor widget.
 *
 *	This code
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-09-15
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */

class PicIOFifoEditorLeftMargin;

class PicIOFifoEditor : public QPlainTextEdit
{
		Q_OBJECT

	public:

		/// Constructor. This class is the left margin of the PicIOFifoEditor widget.
		/// \param pQWidget_parent	Reference to parent widget
		PicIOFifoEditor ( QWidget * pQWidget_parent = 0 );

		/// Paint method for painting the left margin.
		/// Will be called by \c PicIOFifoEditorLeftMargin class.
		/// \param pQPaintEvent		Paint event
		void leftMarginPaintEvent ( QPaintEvent * pQPaintEvent );

		/// Calculates the with of the left margin from line number digits.
		/// \retval int			Line margin width
		int  leftMarginWidth ( void );

		/// Gets the line number from y coordinate.
		/// \param i_posY		Y coordinate
		void  leftMarginLineFromPos ( int i_posY );

		/// Sets the value \c QString_value to the line referenced by \c i_valuePtr.
		/// \param QString_value	Value
		void setValue ( QString QString_value );

		/// Gets the read values referenced by \c i_valuePtr.
		/// \param pQString_valueCur	Reference to current return value
		/// \param pQString_valueNxt	Reference to next return value
		/// \param b_incPtr		Increment pointer
		/// \retval bool		True, if value exists, otherwise false
		bool getRdValue ( QString * pQString_valueCur, QString * pQString_valueNxt, bool b_incPtr = FALSE );

		/// Gets the value referenced by \c i_valuePtr.
		/// \param pQString_valueCur	Reference to current return value
		/// \param pQString_valueLst	Reference to next return value
		void getWrValue ( QString * pQString_valueCur, QString * pQString_valueLst );

		/// Highlights line
		/// \param QTextCursor_highlight	Text cursor to highlight
		void setLineHighlight ( QTextCursor QTextCursor_highlight );

		/// Clears line highlighting
		void clearLineHighlight ( void );

		/// Sets background color for cursor,
		/// \param QColor_bgCursor		Color
		void setBgColorCursor ( QColor QColor_bgCursor );

		/// Sets background color for cursor,
		/// \param QColor_bgCursor		Color
		void setBgColorHighlight ( QColor QColor_bgHighlight );

		/// Change base
		/// \param i_base		Base
		void setBase ( int i_base );

	signals:

		/// Signs that the line reference icon or the values are beeing changed via gui.
		void valuesChanged ( void );

	protected:

		/// Handles all resize events.
		/// \param pQResizeEvent_event	Resize event
		void resizeEvent ( QResizeEvent * pQResizeEvent_event );

	private slots:

		/// Updates the left margin width if the block count was changed.
		/// \param i_newBlockCount	New block count
		void updateLeftMarginWidth ( int i_newBlockCount );

		/// Updates the left margin. Will be called, if the content of the left margin was changed.
		/// \param QRect			Rectangle
		/// \param i_pixelScrolledVertical	The pixel, the document was scralled vertical
		void updateLeftMargin ( const QRect &, int i_pixelScrolledVertical );

		/// Highlights the current line, the cursor is located.
		void highlightCurrentLine();

	private:

		/// The cursor selection
		QTextEdit::ExtraSelection ExtraSelection_cursor;

		/// A list of all selections to highlight
		QList<QTextEdit::ExtraSelection> QListExtraSelection_highlight;

		/// The left margin widget
		QWidget * pPicIOFifoEditorLeftMargin;

		/// Base
		int i_base;

		/// The line number reference the icon points to
		int i_valuePtr;

		/// Sets all extraselections to the document widget.
		void setLineHighlights ( void );
};

/**
 *****************************************************************************************************************************
 *
 *      \brief Text editor left margin widget.
 *
 *	This code
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-09-15
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class PicIOFifoEditorLeftMargin : public QWidget
{
		Q_OBJECT

	public:

		/// Constructor. This class is the left margin of the PicIOFifoEditor widget.
		/// \param pPicIOFifoEditor	Reference to parent widget
		PicIOFifoEditorLeftMargin ( PicIOFifoEditor * pPicIOFifoEditor ) : QWidget ( pPicIOFifoEditor )
		{
			this->pPicIOFifoEditor = pPicIOFifoEditor;
		}

		/// Returns the size hint.
		/// \retval QSize	Size hint
		QSize sizeHint() const
		{
			return QSize ( this->pPicIOFifoEditor->leftMarginWidth(), 0 );
		}

	protected:

		/// Handles double click event.
		/// \param pQMouseEvent		Mouse event
		void mouseDoubleClickEvent ( QMouseEvent * pQMouseEvent )
		{
			this->pPicIOFifoEditor->leftMarginLineFromPos ( pQMouseEvent->y() );
			QWidget::update ();
		}

		/// Paints the widget.
		/// \param pQPaintEvent		Paint event
		void paintEvent ( QPaintEvent * pQPaintEvent )
		{
			this->pPicIOFifoEditor->leftMarginPaintEvent ( pQPaintEvent );
		}

	private:

		/// Reference to parent widget.
		PicIOFifoEditor * pPicIOFifoEditor;
};

#endif
