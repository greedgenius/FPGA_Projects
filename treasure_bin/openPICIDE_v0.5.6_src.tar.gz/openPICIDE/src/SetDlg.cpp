/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include <iostream>
#include "SetDlg.h"

/**
 *****************************************************************************************************************************
 */

SetDlg::SetDlg ( Set Set_dlg, QWidget * pQWidget_parent ) : QDialog ( pQWidget_parent )
{
	this->Set_dlg = Set_dlg;

	// Set navigator and content layout
	QHBoxLayout * QHBoxLayout_NaviAndPages = new QHBoxLayout;
	{
		// Set content page widgets
		{
			this->pSetDlgPgVer = new SetDlgPgVer ( & this->Set_dlg.Prj );
			this->pSetDlgPgPic = new SetDlgPgPic ( & this->Set_dlg.Prj );
			this->pSetDlgPgSrc = new SetDlgPgSrc ( & this->Set_dlg.Prj );
			this->pSetDlgPgApp = new SetDlgPgApp ( & this->Set_dlg.App );

			this->pQStackedWidget_pages = new QStackedWidget;
			{
				this->pQStackedWidget_pages->setMinimumWidth ( 40 );
				
				this->pQStackedWidget_pages->addWidget ( this->pSetDlgPgVer );
				this->pQStackedWidget_pages->addWidget ( this->pSetDlgPgPic );
				this->pQStackedWidget_pages->addWidget ( this->pSetDlgPgSrc );
				this->pQStackedWidget_pages->addWidget ( this->pSetDlgPgApp );
			}
		}

		// Set navigator list
		{
			this->pQListWidget_pageNavi = new QListWidget;
			this->pQListWidget_pageNavi->setViewMode ( QListView::IconMode );
			this->pQListWidget_pageNavi->setIconSize ( QSize ( 96, 84 ) );
			this->pQListWidget_pageNavi->setMovement ( QListView::Static );
			this->pQListWidget_pageNavi->setMaximumWidth ( 128 );
			this->pQListWidget_pageNavi->setSpacing ( 12 );
			
			connect ( this->pQListWidget_pageNavi,
			          SIGNAL ( currentItemChanged ( QListWidgetItem *, QListWidgetItem * ) ),
			          this,
			          SLOT ( changePage ( QListWidgetItem *, QListWidgetItem* ) ) );

			this->pQListWidget_pageNavi->setCurrentRow ( 0 );

			QListWidgetItem * pQListWidgetItem_pageVersion = new QListWidgetItem ( this->pQListWidget_pageNavi );
			pQListWidgetItem_pageVersion->setIcon ( QIcon ( ":/prj/img/prj/dlgNavVer.png" ) );
			pQListWidgetItem_pageVersion->setText ( tr ( "Version" ) );
			pQListWidgetItem_pageVersion->setTextAlignment ( Qt::AlignHCenter );
			pQListWidgetItem_pageVersion->setFlags ( Qt::ItemIsSelectable | Qt::ItemIsEnabled );
			
			QListWidgetItem * pQListWidgetItem_pageProcessor = new QListWidgetItem ( this->pQListWidget_pageNavi );
			pQListWidgetItem_pageProcessor->setIcon ( QIcon ( ":/prj/img/prj/dlgNavPic.png" ) );
			pQListWidgetItem_pageProcessor->setText ( tr ( "Processor" ) );
			pQListWidgetItem_pageProcessor->setTextAlignment ( Qt::AlignHCenter );
			pQListWidgetItem_pageProcessor->setFlags ( Qt::ItemIsSelectable | Qt::ItemIsEnabled );

			QListWidgetItem * pQListWidgetItem_pageSources = new QListWidgetItem ( this->pQListWidget_pageNavi );
			pQListWidgetItem_pageSources->setIcon ( QIcon ( ":/prj/img/prj/dlgNavSrc.png" ) );
			pQListWidgetItem_pageSources->setText ( tr ( "Sources" ) );
			pQListWidgetItem_pageSources->setTextAlignment ( Qt::AlignHCenter );
			pQListWidgetItem_pageSources->setFlags ( Qt::ItemIsSelectable | Qt::ItemIsEnabled );

			QListWidgetItem * pQListWidgetItem_pageApp = new QListWidgetItem ( this->pQListWidget_pageNavi );
			pQListWidgetItem_pageApp->setIcon ( QIcon ( ":/prj/img/prj/dlgNavSup.png" ) );
			pQListWidgetItem_pageApp->setText ( tr ( "Application" ) );
			pQListWidgetItem_pageApp->setTextAlignment ( Qt::AlignHCenter );
			pQListWidgetItem_pageApp->setFlags ( Qt::ItemIsSelectable | Qt::ItemIsEnabled );

			this->pQListWidget_pageNavi->resize ( this->pQListWidget_pageNavi->minimumSize () );
			
			if ( ! Set_dlg.Prj.sPrj.b_prjVld )
			{
				pQListWidgetItem_pageVersion->setFlags ( ! Qt::ItemIsEnabled );
				pQListWidgetItem_pageProcessor->setFlags ( ! Qt::ItemIsEnabled );
				pQListWidgetItem_pageSources->setFlags ( ! Qt::ItemIsEnabled );
			
				this->pQListWidget_pageNavi->setCurrentItem ( pQListWidgetItem_pageApp );
			}
			else
			{
				this->pQListWidget_pageNavi->setCurrentItem ( pQListWidgetItem_pageVersion );
			}
		}

		// Set help viewer
/*		{
			this->pQTextBrowser = new QTextBrowser ( this->pQListWidget_pageNavi );
			{
				this->pQTextBrowser->setMinimumWidth ( 300 );
			}
		}*/
		
		QHBoxLayout_NaviAndPages->addWidget ( this->pQListWidget_pageNavi );
		QHBoxLayout_NaviAndPages->addWidget ( this->pQStackedWidget_pages, 1 );
// 		QHBoxLayout_NaviAndPages->addWidget ( this->pQTextBrowser );
	}

	// Set Button Layout
	QHBoxLayout * pQHBoxLayout_buttons = new QHBoxLayout;
	{
		// Set Buttons
		QPushButton * pQPushButton_Ok     = new QPushButton ( tr ( "&Ok" ) );
		QPushButton * pQPushButton_cancel = new QPushButton ( tr ( "&Cancel" ) );

		pQPushButton_Ok->setDefault ( TRUE );
		
// 		QDialog::setTabOrder ( pQPushButton_Ok, pQPushButton_cancel );
		
		connect ( pQPushButton_Ok,     SIGNAL ( clicked() ), this, SLOT ( handleEventOk() ) );
		connect ( pQPushButton_cancel, SIGNAL ( clicked() ), this, SLOT ( handleEventCancel() ) );

		pQHBoxLayout_buttons->addStretch ( 1 );
		pQHBoxLayout_buttons->addWidget ( pQPushButton_Ok );
		pQHBoxLayout_buttons->addWidget ( pQPushButton_cancel );
	}

	// Set dialog layout
	QVBoxLayout * pQVBoxLayout_main = new QVBoxLayout;
	pQVBoxLayout_main->addLayout ( QHBoxLayout_NaviAndPages );
	pQVBoxLayout_main->addSpacing ( 12 );
	pQVBoxLayout_main->addLayout ( pQHBoxLayout_buttons );

	QDialog::setLayout ( pQVBoxLayout_main );
	QDialog::setWindowTitle ( QObject::tr ( "Settings" ) );
	QDialog::resize(700, 500);
}

/**
 *****************************************************************************************************************************
 */

void SetDlg::handleEventOk ( void )
{
	// Collect from gui
	this->pSetDlgPgVer->getSet ();
	this->pSetDlgPgPic->getSet ();
	this->pSetDlgPgSrc->getSet ();
	this->pSetDlgPgApp->getSet ();

	emit changed ( & this->Set_dlg );

	QDialog::close();
}

/**
 *****************************************************************************************************************************
 */

void SetDlg::handleEventCancel ( void )
{
	QDialog::close();
}

/**
 *****************************************************************************************************************************
 */

void SetDlg::changePage ( QListWidgetItem * pQListWidgetItem_current, QListWidgetItem * pQListWidgetItem_previous )
{
	if ( ! pQListWidgetItem_current )
		pQListWidgetItem_current = pQListWidgetItem_previous;

	this->pQStackedWidget_pages->setCurrentIndex ( this->pQListWidget_pageNavi->row ( pQListWidgetItem_current ) );
}

/**
 *****************************************************************************************************************************
 */




