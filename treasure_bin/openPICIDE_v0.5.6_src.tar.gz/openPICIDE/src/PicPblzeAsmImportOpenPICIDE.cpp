/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeAsmImportOpenPICIDE.h"

/**
 *****************************************************************************************************************************
 */

PicPblzeAsmImportOpenPICIDE::PicPblzeAsmImportOpenPICIDE () : PicImport ()
{
}

/**
 *****************************************************************************************************************************
 */

QStringList PicPblzeAsmImportOpenPICIDE::getCmdList ( void )
{
}

/**
 *****************************************************************************************************************************
 */

QStringList PicPblzeAsmImportOpenPICIDE::getDirectiveList ( void )
{
}

/**
 *****************************************************************************************************************************
 */

QStringList PicPblzeAsmImportOpenPICIDE::getHwComponentList ( void )
{
}

/**
 *****************************************************************************************************************************
 */

QMap<QString, QStringList> PicPblzeAsmImportOpenPICIDE::getNumberRegExp ( void )
{
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportOpenPICIDE::convertLine ( QString * pQString_line )
{
	PicImport::sLineFragments_t sLineFragments;

	// Split lines into fragments
	sLineFragments = PicImport::lineSplit ( * pQString_line );

	PicImport::eRetVal_t eRetVal;

	// Substitute line
	eRetVal = this->lineSubst ( & sLineFragments );

	// Combine fragments to line
	if ( eRetVal == eRetValChanged )
		*pQString_line = PicImport::lineCombine ( & sLineFragments );

	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportOpenPICIDE::lineSubst ( PicImport::sLineFragments_t * psLineFragments )
{
	QString QString_cmd  = psLineFragments->QString_2_text.toUpper();
	QString QString_arg0 = psLineFragments->QString_4_text;
	QString QString_arg1 = psLineFragments->QString_6_text;
	
// 	qDebug() << QString_cmd;

	     if ( QString ( "RETURN" )  == QString_cmd ) { return this->chkInstRet      ( psLineFragments ); }
	else if ( QString ( "RETURNI" ) == QString_cmd ) { return this->chkInstRet      ( psLineFragments ); }
	else if ( QString ( "ADDCY" )   == QString_cmd ) { return this->chkInstRegVari  ( psLineFragments ); }
	else if ( QString ( "SUBCY" )   == QString_cmd ) { return this->chkInstRegVari  ( psLineFragments ); }
	else if ( QString ( "INPUT" )   == QString_cmd ) { return this->chkInstRegIO    ( psLineFragments ); }
	else if ( QString ( "OUTPUT" )  == QString_cmd ) { return this->chkInstRegIO    ( psLineFragments ); }
	else if ( QString ( "ENABLE" )  == QString_cmd ) { return this->chkInstInt      ( psLineFragments ); }
	else if ( QString ( "DISABLE" ) == QString_cmd ) { return this->chkInstInt      ( psLineFragments ); }
	else if ( QString ( "COMPARE" ) == QString_cmd ) { return this->chkInstRegVari  ( psLineFragments ); }
	else if ( QString ( "ADD" )     == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "AND" )     == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "CALL" )    == QString_cmd ) { return this->chkInstBranch  ( psLineFragments ); }
	else if ( QString ( "JUMP" )    == QString_cmd ) { return this->chkInstBranch  ( psLineFragments ); }
	else if ( QString ( "LOAD" )    == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "OR" )      == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "RL" )      == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "RR" )      == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SL0" )     == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SL1" )     == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SLA" )     == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SLX" )     == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SR0" )     == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SR1" )     == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SRA" )     == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SRX" )     == QString_cmd ) { return this->chInstReg      ( psLineFragments ); }
	else if ( QString ( "SUB" )     == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "TEST" )    == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "XOR" )     == QString_cmd ) { return this->chkInstRegVari ( psLineFragments ); }
	else if ( QString ( "STORE" )   == QString_cmd ) { return this->chkInstRegIO   ( psLineFragments ); }
	else if ( QString ( "FETCH" )   == QString_cmd ) { return this->chkInstRegIO   ( psLineFragments ); }
	
	// openPICIDE v0.1 - v0.3 compiler directives
	else if ( QString ( "ADDRESS" )  == QString_cmd ) { return this->chkInstAddr     ( psLineFragments ); }
	else if ( QString ( "CONSTANT" ) == QString_cmd ) { return this->chkInstConstant ( psLineFragments ); }
	else if ( QString ( "NAMEREG" )  == QString_cmd ) { return this->chkInstNamereg  ( psLineFragments ); }

	return eRetValUnchanged;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportOpenPICIDE::chkInstRet ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;
	
	QString QString_cmd = psLineFragments->QString_2_text.toUpper();

	     if ( QString ( "RETURN" )  == QString_cmd ) { QString_cmd = QString ( "RET" );  eRetVal = eRetValChanged; }
	else if ( QString ( "RETURNI" ) == QString_cmd ) { QString_cmd = QString ( "RETI" ); eRetVal = eRetValChanged; }
	
	psLineFragments->QString_2_text = QString_cmd;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportOpenPICIDE::chkInstInt ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;
	
	QString QString_cmd = psLineFragments->QString_2_text.toUpper();

	     if ( QString ( "ENABLE" )  == QString_cmd ) { QString_cmd = QString ( "EINT" ); eRetVal = eRetValChanged; }
	else if ( QString ( "DISABLE" ) == QString_cmd ) { QString_cmd = QString ( "DINT" ); eRetVal = eRetValChanged; }
	
	psLineFragments->QString_2_text = QString_cmd;
	psLineFragments->QString_4_text.clear();
	psLineFragments->QString_6_text.clear();
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportOpenPICIDE::chkInstRegVari ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_cmd  = psLineFragments->QString_2_text.toUpper();

	     if ( QString ( "ADDCY" )   == QString_cmd ) { QString_cmd = QString ( "ADDC" ); 	eRetVal = eRetValChanged; }
	else if ( QString ( "SUBCY" )   == QString_cmd ) { QString_cmd = QString ( "SUBC" ); 	eRetVal = eRetValChanged; }
	else if ( QString ( "COMPARE" ) == QString_cmd ) { QString_cmd = QString ( "COMP" ); 	eRetVal = eRetValChanged; }

	psLineFragments->QString_2_text = QString_cmd;

	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportOpenPICIDE::chkInstBranch ( PicImport::sLineFragments_t * psLineFragments )
{
	return eRetValUnchanged;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportOpenPICIDE::chInstReg ( PicImport::sLineFragments_t * psLineFragments )
{
	return eRetValUnchanged;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportOpenPICIDE::chkInstRegIO ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_cmd  = psLineFragments->QString_2_text.toUpper();

	     if ( QString ( "INPUT" )  == QString_cmd ) { QString_cmd = QString ( "IN" ); 	eRetVal = eRetValChanged; }
	else if ( QString ( "OUTPUT" ) == QString_cmd ) { QString_cmd = QString ( "OUT" ); 	eRetVal = eRetValChanged; }

	psLineFragments->QString_2_text = QString_cmd;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportOpenPICIDE::chkInstAddr ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_cmd  = psLineFragments->QString_2_text.toUpper();

	if ( QString ( "ADDRESS" ) == QString_cmd ) { QString_cmd = QString ( "ORG" ); 	eRetVal = eRetValChanged; }
	
	psLineFragments->QString_2_text = QString_cmd;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportOpenPICIDE::chkInstConstant ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_cmd  = psLineFragments->QString_2_text.toUpper();
	QString QString_arg0 = psLineFragments->QString_4_text;
	QString QString_arg1 = psLineFragments->QString_6_text;

	if ( QString ( "CONSTANT" ) == QString_cmd ) { QString_cmd = QString ( "EQU" ); 	eRetVal = eRetValChanged; }

	if ( QString_arg0.at ( QString_arg0.size() - 1 ) == QChar ( ',' ) )
		QString_arg0.remove ( QString_arg0.size() - 1, 1 );

	psLineFragments->QString_2_text = QString_arg0;
	psLineFragments->QString_4_text = QString_cmd;
	psLineFragments->QString_6_text = QString_arg1;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

PicImport::eRetVal_t PicPblzeAsmImportOpenPICIDE::chkInstNamereg ( PicImport::sLineFragments_t * psLineFragments )
{
	eRetVal_t eRetVal = eRetValUnchanged;

	QString QString_cmd  = psLineFragments->QString_2_text.toUpper();
	QString QString_arg0 = psLineFragments->QString_4_text;		// Register
	QString QString_arg1 = psLineFragments->QString_6_text;		// Name

	if ( QString ( "NAMEREG" ) == QString_cmd ) { QString_cmd = QString ( "EQU" ); 	eRetVal = eRetValChanged; }
	
	if ( QString_arg0.at ( QString_arg0.size() - 1 ) == QChar ( ',' ) )
		QString_arg0.remove ( QString_arg0.size() - 1, 1 );

	psLineFragments->QString_2_text = QString_arg1;
	psLineFragments->QString_4_text = QString_cmd;
	psLineFragments->QString_6_text = QString_arg0;
	
	return eRetVal;
}

/**
 *****************************************************************************************************************************
 */

