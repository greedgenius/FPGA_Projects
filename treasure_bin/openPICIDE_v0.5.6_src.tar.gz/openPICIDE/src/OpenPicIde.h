/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef OpenPicIde_H
#define OpenPicIde_H

#include <QtGui>
#include <QtCore>

#include "Mod.h"
#include "SupChkUpdate.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Main window widget class.
 *
 *
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 * Change log
 *
 * 2009-08-30
 *	Freeze for first release
 *
 * 2009-09-11
 *	Restore window geometry from previous session
 *	Fix parent widget of splash screen
 *
 * 2009-10-03
 *	Console help text added
 *
 * 2010-03-06
 *	Added checking for updates
 *
 *****************************************************************************************************************************
 */

class OpenPicIde : public QMainWindow
{
		Q_OBJECT

	public:

		/// Constructor
		/// \param i_argc			Argument count
		/// \param pac_argv[]			Pointer to argument list
		OpenPicIde ( int i_argc, char * pac_argv[] );

	public slots:

		/// Handles project closed event. Will be called by project manager class.
		void projectClosed ( void );

		/// Handles project changed event. Will be called by project manager class.
		void settingsChanged ( void );

		/// Tidies up if the mainwindow is about to close.
		void projectTidyUp ( void );

		/// Shows update info
		void showUpdateInfo ( bool b_expired );

	protected:

		void closeEvent ( QCloseEvent * pQCloseEvent );

	private slots:

		/// Action handler. Shows the about dialog.
		void about ( void );

		/// Action handler. Shows the left dock widget.
		void viewDockWidgetL ( void );

		/// Action handler. Shows the bottom dock widget.
		void viewDockWidgetB ( void );

		/// Action handler. Shows the right dock widget.
		void viewDockWidgetR ( void );

		/// Action handler. Shows all dock widgets.
		void viewDockWidgetAll ( void );

		/// Action handler. Shows the splash screen.
		void splashScreenStart ( void );

		/// Kills the splash screen. Will be called by single shot timer.
		void splashScreenStop ( void );
		
		/// Shows the support dialog
		void viewSupportDlg ( void );

	private:

		/// Version of openPICIDE
// 		QString QString_version;

		/// Sets up menubar.
		void setupMenuBar ( void );

		/// Handle arguments given by program start.
		void handleArgs ( int i_argc, char * pac_argv[] );

		/// Prints console help text
		void printConsoleHelp ( void );
		
		/// Checks for updates
		void chkUpdate ( void );

		/// Set
		Mod * pMod;

		/// Checks for updates
		SupChkUpdate * pSupChkUpdate;
		
		/// Create actions
		void createActions();

		/// Create menus from actions
		void createMenus();

		/// Holding view menu instance
		QMenu * pQMenu_view;

		/// Holding help menu instance
		QMenu * pQMenu_help;

		/// Action: View left dock widget
		QAction * pQAction_viewDockWidgetL;

		/// Action: View bottom dock widget
		QAction * pQAction_viewDockWidgetB;

		/// Action: View right dock widget
		QAction * pQAction_viewDockWidgetR;

		/// Action: View all dock widgets
		QAction * pQAction_viewDockWidgetAll;

		/// Action: Show splash screen
		QAction * pQAction_splashScreen;

		/// Action: Show about dialog
		QAction * pQAction_about;

		/// Action: Show qt dialog
		QAction * pQAction_aboutQt;

		/// Action: Show update info dialog
		QAction * pQAction_chkUpdate;

		/// Splash screen, showed by \c splashScreenStart and stopped by \c splashScreenStop
		QSplashScreen QSplashScreen_start;
};

#endif
