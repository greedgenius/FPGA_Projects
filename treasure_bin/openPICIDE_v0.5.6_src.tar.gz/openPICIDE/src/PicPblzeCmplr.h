/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PICPBLZECMPLR_H
#define PICPBLZECMPLR_H

#include <QtCore>
#include <QtGui>

#include "PicPblzeAsmParser.h"
#include "Msg.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Xilinx PicoBlaze (tm) assembler compiler.
 *
 *
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.1
 *
 *	Change log
 *
 *	2009-08-30	Freeze for first release
 *	2009-09-09	Change memset to for-loop.
 *	2009-10-02	Change handling of NZ|Z|NC|C to case insensitive
 *	2009-10-04	Renamed some things
 * 	2011-08-30	Fixed bug: replacing "\n" with "\r\n" results in an damaged file on windows systems
 *
 *****************************************************************************************************************************
 */

class PicPblzeCmplr : public PicPblzeAsmParser
{
	Q_OBJECT

	// Constructor
	public:
		
		/// Constructor.
		/// \param pQObject_parent		Pointer to parent widget
                PicPblzeCmplr ( QObject * pQObject_parent = 0 );

		/// Destructor. Tidies up.
		~PicPblzeCmplr ( void );

	// Parameter handling
	public:

		enum eOutputType_t {
			E_OUT_VHDL,
			E_OUT_VERILOG,
			E_OUT_MEM,
			E_OUT_HEX
		};

		struct sCfg_t {

			PicPblzeAsmParser::sCfg_t sCfg_asmParser;

			QString QString_templateFilePath;
			QString QString_outputFilePath;
			QString QString_entityName;
			
			eOutputType_t eOutputType;
		} sCfg;

		/// Sets environment parameter
		/// \param sCfg			Environment parameter
		/// \retval bool			Success state
		bool setCfg ( sCfg_t sCfg );
		
	// Setup Memory map
	protected:
		
		struct sMemCell_t
		{
			bool b_valid;
			
			bool b_used;
			
			/// Processor memory lines
			unsigned int ui_value;
		};
		

		sMemCell_t * asMemCell;
		
	// Write file
	protected:

		/// Writes output file
		/// \retval bool			TRUE, if success, otherwise FALSE
		bool writeOutputFile ( void );

		/// Gets vhdl rom init value from processor memory line
		/// \param i_line		Processor memory line number
		/// \retval QString		Rom init value
		bool getVhdlInit ( int i_fragmentAddr, QString * pQString_fragment );

		/// Gets vhdl rom init value from processor memory line
		/// \param i_line		Processor memory line number
		/// \retval QString		Rom init value
		bool getVhdlInitH ( int i_fragmentAddr, QString * pQString_fragment );

		/// Gets vhdl rom init value from processor memory line
		/// \param i_line		Processor memory line number
		/// \retval QString		Rom init value
		bool getVhdlInitL ( int i_fragmentAddr, QString * pQString_fragment );

		/// Gets vhdl rom parity init value from processor memory line
		/// \param i_line		Processor memory line number
		/// \retval QString		Rom init value
		bool getVhdlInitP ( int i_fragmentAddr, QString * pQString_fragment );

		/// Gets vhdl rom parity init value from processor memory line
		/// \param i_line		Processor memory line number
		/// \retval QString		Rom init value
		bool getVhdlInitPH ( int i_fragmentAddr, QString * pQString_fragment );
		
		/// Gets vhdl rom parity init value from processor memory line
		/// \param i_line		Processor memory line number
		/// \retval QString		Rom init value
		bool getVhdlInitPL ( int i_fragmentAddr, QString * pQString_fragment );
		
		/// Writes vhdl or verilog output file
		/// \retval bool		True, if success, otherwise false
		bool writeOutputFileVhdlVerilog ( void );

		/// Writes mem output file
		/// \retval bool		True, if success, otherwise false
		bool writeOutputFileMem ( void );

		/// Writes hex output file
		/// \retval bool		True, if success, otherwise false
		bool writeOutputFileHex ( void );

	// Message handling
	protected:
		
		enum eMsgType_t
		{
			eMsgType_ok,

			eMsgType_warn,
			eMsgType_tmemStuffing,

			eMsgType_err,
			eMsgType_templateFileIO,
			eMsgType_outputFileIO,
			eMsgType_entityName,
			eMsgType_compError,
			eMsgType_tmemSizeToSmall
		};
		
		void msgEmit ( eMsgType_t eMsgType );

		void msgEmit ( eMsgType_t eMsgType, sCodeLine_t * psCodeLine );

		/// Emits message.
		/// \param pMsg				Message
		void msgEmit ( Msg * pMsg, eMsgType_t eMsgType );
};

#endif
