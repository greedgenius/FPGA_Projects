/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PicPblzeAsmImportMetrx_H
#define PicPblzeAsmImportMetrx_H

#include <QtGui>
#include <QtCore>

#include "PicImport.h"

/**
 *****************************************************************************************************************************
 *
 *	\brief Filter dialog class
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-12-08
 *	\version	0.1.0
 *
 *	Change log
 *
 *	2009-12-08
 *		Generated
 *
 *****************************************************************************************************************************
 */

class PicPblzeAsmImportMetrx : PicImport
{
	public:

		/// Constructor. Generates the dialog layout.
		PicPblzeAsmImportMetrx ();

		PicImport::eRetVal_t convertLine ( QString * pQString_line );

	private:

		PicImport::eRetVal_t lineSubst      ( PicImport::sLineFragments_t * psLineFragments );

		PicImport::eRetVal_t chkInstRet     ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chkInstInt     ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chkInstRegVari ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chkInstBranch  ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chInstReg      ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chkInstOrg     ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chkInstRegIO   ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chkInstEqu     ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chkInstDs      ( PicImport::sLineFragments_t * psLineFragments );
		PicImport::eRetVal_t chkOsolete     ( PicImport::sLineFragments_t * psLineFragments );
		
		bool chkArgNumber ( QString * pQString_arg, PicPblzeAsmImportMetrx::eRetVal_t * peRetVal );
		bool chkArgReg    ( QString * pQString_arg, PicPblzeAsmImportMetrx::eRetVal_t * peRetVal );
};

#endif
