/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PICSIMIO_H
#define PICSIMIO_H

#include <QtCore>
#include <QtGui>

#include "PicIOPort8Bit.h"
#include "PicIOFifo8Bit.h"
#include "PicIOMem.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Picoblaze (tm) io widget.
 *
 *	The widget contains devices like ports and fifos. The devices are organized in a doubly connected device list.
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class PicIO : public QWidget
{
		Q_OBJECT

	public:

		/// Constructor.
		/// \param pQObject_parent		Pointer to parent widget
		PicIO ( QWidget * pQWidget_parent = 0 );

		/// Destructor. Tidies up.
		~PicIO();

		/// Sets base.
		/// \param i_base		Integer base
		void setBase ( int i_base );

		/// Checks, if an element with the given address is in widget list.
		/// \param i_addr		IO address
		/// \retval bool		
// 		bool checkDevValid ( int i_addr );

		/// Sets value to given io address
		/// \param i_addr		IO address
		/// \param QString_addrSymbol	Substitute
		/// \param i_value		Value
		/// \retval bool		True, if success, otherwise false
		bool setValue ( int i_addr, QString QString_addrSymbol, int i_value );

		/// Gets value to given io address
		/// \param i_addr		IO address
		/// \param QString_addrSymbol	Substitute
		/// \param pi_value		Value
		/// \retval bool		True, if success, otherwise false
		bool getValue ( int i_addr, QString QString_addrSymbol, int * pi_value );

		/// Clears highlighting
		void clearHighlighted ( void );

		/// Clears all
		void clear ( void );

	signals:

		/// Signs that content changed
		/// \param pQWidget		Reference to itself
		void contentChanged ( QWidget * pQWidget );

	private:

		/// Integer base
		int i_base;

		/// IO device type
		enum eIOType_t {
			ePort	= 0,
			eFifo	= 1,
			eMem	= 2
		};

		/// Device list element
		struct sDevElement_t
		{
			eIOType_t eIOType;

			QWidget * pQWidget;

			sDevElement_t * psDevElement_prev;
			sDevElement_t * psDevElement_next;
		};

		PicIOCommon::eDirection_t eDirection_last;
		
		/// Device list start element.
		sDevElement_t * sDevElement_start;

		/// Device list stop element.
		sDevElement_t * sDevElement_stop;

		/// Devices list to select for adding.
		QComboBox * pQComboBox_device;

		/// Scroll area containing devices list.
		QScrollArea * pQScrollArea_devLst;

		/// Layout to combine all devices from device list.
		QVBoxLayout * pQVBoxLayout_devLst;

		/// Adds an port device to device list.
		/// \param eIOType	Device to add
		/// \param eDirection	Direction
		sDevElement_t * addDev ( eIOType_t eIOType, PicIOCommon::eDirection_t eDirection );

	private slots:

		/// Adds element to io device list
		sDevElement_t * addDevFromMenu ( void );

		/// Closes the given device.
		/// \param pQWidget		Device widget
		void closeDev ( QWidget * pQWidget );

		/// Close all devices
		void closeAllDev ( void );

};

#endif
