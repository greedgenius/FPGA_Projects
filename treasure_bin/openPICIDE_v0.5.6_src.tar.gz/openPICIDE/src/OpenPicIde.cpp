/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "OpenPicIde.h"

#include <QtGui>
#include <QtCore>
#include <iostream>

#include "SupChkUpdate.h"
#include "Set.h"
#include "Prj.h"
#include "Edt.h"
#include "Pic.h"
#include "About.h"
#include "SupDlg.h"
#include "StatusBar.h"

/**
 *****************************************************************************************************************************
 */

OpenPicIde::OpenPicIde ( int i_argc, char * pac_argv[] ) : QMainWindow () 
{
// 	// Start splash screen
// 	this->splashScreenStart ();

	// Setup root elements
	this->pMod = new Mod ();
		
	// Setup common gui elements
	this->createActions();
	this->createMenus();

	this->pMod->pSet             = new Set;
	this->pMod->pQMainWindow     = this;
	this->pMod->pMainDockAreaL   = new MainDockAreaL ( QString(), QMainWindow::parentWidget() );
	this->pMod->pMainDockAreaB   = new MainDockAreaB ( QString(), QMainWindow::parentWidget() );
	this->pMod->pMainDockAreaR   = new MainDockAreaR ( QString(), QMainWindow::parentWidget() );
	this->pMod->pStatusBar       = new StatusBar ( QMainWindow::parentWidget() );

	this->pMod->pQMainWindow->setStatusBar ( this->pMod->pStatusBar );
	
	this->addDockWidget ( Qt::LeftDockWidgetArea,   this->pMod->pMainDockAreaL );
	this->addDockWidget ( Qt::BottomDockWidgetArea, this->pMod->pMainDockAreaB );
	this->addDockWidget ( Qt::RightDockWidgetArea,  this->pMod->pMainDockAreaR );
	
	connect ( qApp,
	          SIGNAL ( aboutToQuit ( ) ),
	          this,
	          SLOT ( projectTidyUp ( ) )
	        );

	QMainWindow::setWindowTitle ( QString ( "openPICIDE" ) );
	QMainWindow::setWindowIcon ( QIcon ( ":/main/img/main/appIcon.png" ) );
	QMainWindow::resize ( this->pMod->pSet->App.sGui.i_mainWindowWidth, this->pMod->pSet->App.sGui.i_mainWindowHeight );
	QMainWindow::move   ( this->pMod->pSet->App.sGui.i_mainWindowX,     this->pMod->pSet->App.sGui.i_mainWindowY );
	QMainWindow::setIconSize ( QSize ( this->pMod->pSet->App.sGui.i_iconSize, this->pMod->pSet->App.sGui.i_iconSize ) );
	
	// Setup editor
	this->pMod->pEdt = new Edt ( this->pMod, QMainWindow::parentWidget () );
	{
		QMainWindow::setCentralWidget ( this->pMod->pEdt );
	}
	
	// Setup project manager with project menu entries
	this->pMod->pPrj = new Prj ( this->pMod, QMainWindow::parentWidget() );

	connect ( this->pMod->pPrj,
	          SIGNAL ( settingsChanged () ),
	          this,
	          SLOT ( settingsChanged () )
	        );

	connect ( this->pMod->pPrj,
	          SIGNAL ( projectClosed ( ) ),
	          this,
	          SLOT ( projectClosed ( ) )
	        );

	this->setupMenuBar();

	QTimer::singleShot ( 1000, this, SLOT ( splashScreenStop () ) );

	this->handleArgs ( i_argc, pac_argv );

// 	this->pMod->pPrj->openProject( this->pMod->pSet->App.sPrj.QStringList_recent.at ( 0 ) );

	if ( this->pMod->pSet->App.sSup.b_showStartInfo )
		this->pMod->pEdt->setupHlpDocument ( QUrl ( "qthelp://openPICIDE/openPICIDE/openPICIDE/000_gettingStarted/index.html" ) );

	this->pMod->pStatusBar->showMessage ( tr ( "Ready" ) );
	
	// Check for update
	this->chkUpdate ();
	
	// Start splash screen
	this->splashScreenStart ();
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::closeEvent ( QCloseEvent * pQCloseEvent )
{
	this->pMod->pSet->App.sGui.i_mainWindowWidth  = QMainWindow::width ();
	this->pMod->pSet->App.sGui.i_mainWindowHeight = QMainWindow::height ();
	this->pMod->pSet->App.sGui.i_mainWindowX      = QMainWindow::x ();
	this->pMod->pSet->App.sGui.i_mainWindowY      = QMainWindow::y ();
	
	this->pMod->pSet->App.setDirty ();

	pQCloseEvent->accept ();
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::handleArgs ( int i_argc, char * pac_argv[] )
{
	for ( int i_iterator = 0; i_iterator < i_argc; i_iterator++ )
	{
		QString QString_arg ( pac_argv [ i_iterator ] );

		if ( QString_arg.toUpper() .contains ( ".OPENPICIDE" ) )
			this->pMod->pPrj->openProject ( QString_arg );

		if ( QString_arg.toUpper().contains ( "--HELP" ) )
			this->printConsoleHelp ();

		if ( QString_arg.toUpper().contains ( "-H" ) )
		this->printConsoleHelp ();
	}
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::printConsoleHelp ( void )
{
	std::cout << "Usage: openpicide projectfile.openPicIde" << std::endl;
	std::cout << std::endl;
	std::cout << "--help Prints this help text" << std::endl;
	std::cout << "-h     Prints this help text" << std::endl;

	// Exit application
	QApplication::quit ();
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::projectTidyUp ( void )
{
	this->pMod->pSet->Prj.closePrj ();
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::createActions()
{
	// View menu actions
	this->pQAction_viewDockWidgetL = new QAction ( tr ( "View left dock" ), this );
	this->pQAction_viewDockWidgetL->setStatusTip ( tr ( "Views left dock" ) );
	connect ( this->pQAction_viewDockWidgetL, SIGNAL ( triggered() ), this, SLOT ( viewDockWidgetL() ) );

	this->pQAction_viewDockWidgetB = new QAction ( tr ( "View bottom dock" ), this );
	this->pQAction_viewDockWidgetB->setStatusTip ( tr ( "Views bottom dock" ) );
	connect ( this->pQAction_viewDockWidgetB, SIGNAL ( triggered() ), this, SLOT ( viewDockWidgetB() ) );

	this->pQAction_viewDockWidgetR = new QAction ( tr ( "View right dock" ), this );
	this->pQAction_viewDockWidgetR->setStatusTip ( tr ( "Views right dock" ) );
	connect ( this->pQAction_viewDockWidgetR, SIGNAL ( triggered() ), this, SLOT ( viewDockWidgetR() ) );

	this->pQAction_viewDockWidgetAll = new QAction ( tr ( "View all docks" ), this );
	this->pQAction_viewDockWidgetAll->setStatusTip ( tr ( "Views all docks" ) );
	connect ( this->pQAction_viewDockWidgetAll, SIGNAL ( triggered() ), this, SLOT ( viewDockWidgetAll() ) );

	// Help menu actions
	this->pQAction_splashScreen = new QAction ( tr ( "Splash screen" ), this );
	this->pQAction_splashScreen->setStatusTip ( tr ( "Shows splash Screen" ) );
	connect ( this->pQAction_splashScreen, SIGNAL ( triggered() ), this, SLOT ( splashScreenStart() ) );

	this->pQAction_about = new QAction ( tr ( "&About openPICIDE" ), this );
	this->pQAction_about->setStatusTip ( tr ( "Shows the application's About box" ) );
	connect ( this->pQAction_about, SIGNAL ( triggered() ), this, SLOT ( about() ) );

	this->pQAction_aboutQt = new QAction ( tr ( "About &Qt" ), this );
	this->pQAction_aboutQt->setStatusTip ( tr ( "Shows the Qt library's About box" ) );
	connect ( this->pQAction_aboutQt, SIGNAL ( triggered() ), qApp, SLOT ( aboutQt() ) );
	
	this->pQAction_chkUpdate = new QAction ( tr ( "Check for updates..." ), this );
	this->pQAction_chkUpdate->setStatusTip ( tr ( "Shows the updates check dialog" ) );
	connect ( this->pQAction_chkUpdate, SIGNAL ( triggered() ), this, SLOT ( viewSupportDlg() ) );
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::createMenus()
{
	this->pQMenu_view = menuBar()->addMenu ( QString() );
	this->pQMenu_view->setTitle ( tr ( "&View" ) );
	this->pQMenu_view->addAction ( this->pQAction_viewDockWidgetL );
	this->pQMenu_view->addAction ( this->pQAction_viewDockWidgetB );
	this->pQMenu_view->addAction ( this->pQAction_viewDockWidgetR );
	this->pQMenu_view->addAction ( this->pQAction_viewDockWidgetAll );

	this->pQMenu_help = menuBar()->addMenu ( QString() );
	this->pQMenu_help->setTitle ( tr ( "&Help" ) );
	this->pQMenu_help->addAction ( this->pQAction_splashScreen );
	this->pQMenu_help->addAction ( this->pQAction_chkUpdate );
	this->pQMenu_help->addSeparator ();
	this->pQMenu_help->addAction ( this->pQAction_about );
	this->pQMenu_help->addAction ( this->pQAction_aboutQt );
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::setupMenuBar ( void )
{
	QMainWindow::menuBar()->clear();

	if ( this->pMod->pPrj )
		this->pMod->pPrj->setupMenuBar ( QMainWindow::menuBar() );

	this->menuBar()->addMenu ( pQMenu_view );

	if ( this->pMod->pEdt )
		this->pMod->pEdt->setupMenuBar ( QMainWindow::menuBar() );

	if ( this->pMod->pPic )
		this->pMod->pPic->setupMenuBar ( QMainWindow::menuBar() );

	QMainWindow::menuBar()->addSeparator();
	QMainWindow::menuBar()->addMenu ( pQMenu_help );
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::settingsChanged ( void )
{
// 	if ( ! this->pMod->pEdt )
// 	{
// 		this->pMod->pEdt = new Edt ( this->pMod, QMainWindow::parentWidget () );
// 
// 		QMainWindow::setCentralWidget ( this->pMod->pEdt );
// 	}

	if ( ! this->pMod->pPic )
		this->pMod->pPic = new Pic ( this->pMod, QMainWindow::parentWidget() );

	QString QString_title;
	{
		if ( ! this->pMod->pSet->Prj.sVer.QString_title.isEmpty() )
			QString_title = this->pMod->pSet->Prj.sVer.QString_title;
		else
			QString_title = this->pMod->pSet->Prj.sPrj.QString_prjFile;
		
		if ( ! this->pMod->pSet->Prj.sVer.QString_version.isEmpty() )
			QString_title += " (" + this->pMod->pSet->Prj.sVer.QString_version + ")";
	
		QString_title += " - openPICIDE";

		QMainWindow::setWindowTitle ( QString_title );
	}

	this->pMod->pPic->changeSettings ();
	this->pMod->pEdt->changeSettings ();

	this->setupMenuBar ();
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::projectClosed ( void )
{
	QMainWindow::setWindowTitle ( QString ( "openPICIDE" ) );

	if ( this->pMod->pPic )
		delete ( this->pMod->pPic );
	
	this->pMod->pPic = NULL;

	this->pMod->pEdt->closeAllWithoutMemory ();
	this->pMod->pPrj->setupMenuBar ( menuBar() );
	this->setupMenuBar ();
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::about()
{
	About * pAbout = new About ( & this->pMod->pSet->App );
	pAbout->exec ();
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::viewDockWidgetL()
{
	if ( this->pMod->pMainDockAreaL )
		this->pMod->pMainDockAreaL->show();
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::viewDockWidgetB()
{
	if ( this->pMod->pMainDockAreaB )
		this->pMod->pMainDockAreaB->show();
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::viewDockWidgetR()
{
	if ( this->pMod->pMainDockAreaR )
		this->pMod->pMainDockAreaR->show();
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::viewDockWidgetAll()
{
	this->viewDockWidgetL();
	this->viewDockWidgetB();
	this->viewDockWidgetR();
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::splashScreenStart ( void )
{
	this->QSplashScreen_start.finish ( QMainWindow::parentWidget() );
	this->QSplashScreen_start.setPixmap ( QPixmap ( ":/main/img/main/splash.png" ) );

	this->QSplashScreen_start.show ();
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::splashScreenStop ( void )
{
	this->QSplashScreen_start.finish ( this );
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::viewSupportDlg ( void )
{
	SupDlg SupDlg_inst ( & this->pMod->pSet->App, this );

	SupDlg_inst.exec ();
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::chkUpdate ( void )
{
	int i_elapsedDays = this->pMod->pSet->App.sSup.QDate_lstUpdateChk.daysTo ( QDate::currentDate() );
	
	switch ( this->pMod->pSet->App.sSup.eChkIval )
	{
		case SetApp::eChkIvalNever:
			
			return;
			
		case SetApp::eChkIvalDaily:
			
			if ( i_elapsedDays <= 0 )
				return;
			
			break;
			
		case SetApp::eChkIvalWeekly:
			
			if ( i_elapsedDays < 7 )
				return;
			
			break;
			
		case SetApp::eChkIvalMonthly:
			
			if ( i_elapsedDays < this->pMod->pSet->App.sSup.QDate_lstUpdateChk.daysInMonth() )
				return;

			break;
			
		default:
			qDebug() << "OpenPicIde::chkUpdate - Unknown update inverval";
	}

	// Check for new version
	this->pSupChkUpdate = new SupChkUpdate ();
	
	connect (
		this->pSupChkUpdate,
		SIGNAL ( expired ( bool ) ),
		this,
		SLOT ( showUpdateInfo ( bool ) )
	);

	this->pSupChkUpdate->chkUpdate ( this->pMod->pSet->App.sSup.QString_appVer, this->pMod->pSet->App.sSup.QString_serNo, this->pMod->pSet->App.sSup.QString_platform, TRUE );
}

/**
 *****************************************************************************************************************************
 */

void OpenPicIde::showUpdateInfo ( bool b_expired )
{
	disconnect (
		this->pSupChkUpdate,
		SIGNAL ( expired ( bool ) ),
		this,
		SLOT ( showUpdateInfo ( bool ) )
	);

	if ( b_expired )
// 		this->pSupChkUpdate->showUpdateInfo();
		this->viewSupportDlg ();
	
	this->pMod->pSet->App.sSup.QDate_lstUpdateChk = QDate::currentDate();
	this->pMod->pSet->App.setDirty();
	
	delete this->pSupChkUpdate;
}

/**
 *****************************************************************************************************************************
 */






