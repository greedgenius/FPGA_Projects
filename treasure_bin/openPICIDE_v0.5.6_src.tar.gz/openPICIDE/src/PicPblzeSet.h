/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PICPBLZESETTINGS_H
#define PICPBLZESETTINGS_H

#include <QtCore>
#include <QtXml>

/**
	@author Christoph Fauck <christoph.fauck@fauck-technologies.com>
*/

class PicPblzeSet
{

	public:

		PicPblzeSet();

		/// Processor derivates
		enum ePicDerivate_t {
			ePblzeCpld = 0,
			ePblze     = 1,
			ePblzeII   = 2,
			ePblze3    = 3,
			ePblze6    = 4
		};

		/// Returns derivate names
		/// \param ePicDerivates	Derivate type
		/// \retval QString		Derivate name
		static QString getDerivateName ( ePicDerivate_t ePicDerivate );

	// Memory parameter
	public:
		
		enum eMemSharedLoc_t
		{
			eMemSharedLocHighAddr,
			eMemSharedLocLowAddr
		};
		
		eMemSharedLoc_t eMemSharedLoc;

		int i_memBankSize;
		int i_memBankCount;
		
		void getMemBankSizeMinMax ( ePicDerivate_t ePicDerivate, int * pi_min, int * pi_max );
		
	// Processor parameter
	public:
		
		ePicDerivate_t ePicDerivate;
		
		int i_scrpdSize;
		int i_intVector;
		int i_clkFreq;


	// Compiler
	public:
		
		QString QString_entityName;
		QString QString_vhdlTemplateFile;
		QString QString_vhdlOutputFile;
		QString QString_verilogTemplateFile;
		QString QString_verilogOutputFile;
		QString QString_memOutputFile;
		QString QString_hexOutputFile;
		
	// Read and write configuration xml stream
	public:
		
		void rdXml ( QXmlStreamReader * pQXmlStreamReader, QString QString_prjPath );
		void rdXmlV00 ( QXmlStreamReader * pQXmlStreamReader, QString QString_prjPath );
		void rdXmlV01 ( QXmlStreamReader * pQXmlStreamReader, QString QString_prjPath );
		void wrXml ( QXmlStreamWriter * pQXmlStreamWriter, QString QString_prjPath );
};

#endif
