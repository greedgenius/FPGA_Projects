/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PICNONE_H
#define PICNONE_H

#include <QtCore>
#include <QtGui>

#include "Mod.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Processor template instance.
 *
 *
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *****************************************************************************************************************************
 */
class PicNone : public QObject
{

		Q_OBJECT

	public:

		/// Returns name of processor
		static QString getName ( void );

		/// Constructor.
		/// \param pMod				Pointer collection to root elements
		/// \param pQObject_parent		Pointer to parent widget
		PicNone ( Mod * pMod, QObject * pQObject_parent = 0 );

		/// Sets the project settings to the pic. The method will be called if the project settings changed.
		void changeSettings ( void );

	signals:

		/// Selects line in editor. Will be emitted by \c selectLine()
		/// \param	QString_filePath	File name to select the document
		/// \param	i_lineNumber		Line number to scroll to
		void lineSelected ( QString QString_filePath, int i_lineNumber );
};

#endif
