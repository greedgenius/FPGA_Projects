/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PicImport_H
#define PicImport_H

#include <QtGui>
#include <QtCore>

/**
 *****************************************************************************************************************************
 *
 *	\brief Filter dialog class
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-12-08
 *	\version	0.1.0
 *
 *	Change log
 *
 *	2009-12-08
 *		Generated
 *
 *****************************************************************************************************************************
 */

class PicImport
{
	public:

		/// Constructor. Generates the dialog layout.
		PicImport ();
		
		enum eRetVal_t
		{
			eRetValUnchanged,	// Must be the first one: eRetValUnchanged = FALSE
			eRetValChanged,
			eRetValErr
		};
		
		eRetVal_t convertLine ( QString * pQString_line );
		
		QString getErrMsg ( void );

	protected:

		struct sLineFragments_t
		{
			QString QString_0_reference;
			QString QString_1_spacer;
			QString QString_2_text;		// Cmd
			QString QString_3_spacer;
			QString QString_4_text;		// Arg0
			QString QString_5_spacer;
			QString QString_6_text;		// Arg1
			QString QString_7_spacer;
			QString QString_8_comment;
		};

		sLineFragments_t lineSplit ( QString QString_line );

		QString lineCombine ( sLineFragments_t * psLineFragments );
		
		QString QString_errMsg;
};

#endif
