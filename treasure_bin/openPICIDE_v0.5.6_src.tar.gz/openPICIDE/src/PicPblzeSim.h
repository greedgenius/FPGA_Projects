/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#ifndef PicPblzeSim_H
#define PicPblzeSim_H

#include <QtCore>
#include <QtGui>

#include "Mod.h"
#include "PicPblzeAsmParser.h"

#include "PicPblzeSimCore.h"
#include "PicIO.h"
#include "PicEdtInterrupt.h"
#include "PicPblzeSimCoreCallStack.h"

/**
 *****************************************************************************************************************************
 *
 *      \brief Xilinx PicoBlaze (tm) simulator.
 *
 *	
 *
 *	\author 	Christoph Fauck <christoph.fauck@fauck.com>
 *	\date		2009-08-30
 *	\version	0.1.0
 *
 *	Change log
 *
 *	2009-10-02	Change handling of NZ|Z|NC|C to case insensitive
 *	2009-10-04	Renamed some things
 * 	2011-08-23	Fixed bug: Interrupts are now restored during RETI command
 *
 *****************************************************************************************************************************
 */
class PicPblzeSim : public PicPblzeAsmParser
{

		Q_OBJECT

	// Constructor
	public:

		/// Constructor.
		/// \param pMod			Pointer collection to root elements
		/// \param pQWidget_parent	Pointer to parent widget
		PicPblzeSim ( Mod * pMod, QObject * pQObject_parent = 0 );

		/// Destructor.
		~PicPblzeSim();
		
	// Parameter handling
	public:
		
		struct sCfg_t {

			PicPblzeAsmParser::sCfg_t sCfg_asmParser;

			int i_scrpdSize;
		};

		/// Sets base.
		/// \param i_base	Integer base
		void setBase ( int i_base );
		
		/// Sets breakpoints to simulator
		void setBreakpoints ( QMap<QString,QList<int> > QMap_breakpoints );

		/// Clear all breakpoints
		void clearBreakpoints ( void );

		/// Sets breakpoint to the code line element given by \c i_fileNumber and \c i_lineNumber.
		/// If the element doesn't exist or doesn't contain a command, the next element with
		/// a valid command will be used.
		/// \param i_fileNumber		File number
		/// \param i_lineNumber		Line number
		void setBreakpoint ( int i_fileNumber, int i_lineNumber );

	// State handling
	public:
		
		enum eState_t {
			e_disabled,
			e_idle,
			e_run,
			e_fatalError
		};

		/// State
		eState_t eState;

		/// Gets simulator status
		/// \retval eState_t	Simulator status
		eState_t getSimStatus ( void );

	// Gui handling
	private:
		

		/// Create dock widgets
		void createDockWidgets ( void );

		/// Delete dock widgets
		void removeDockWidgets ( void );
		
	// Simulation control
	public:
		
		/// Initializes the simulator
		/// \param pQStringList_filePath 	File list
		/// \retval bool			Success state
		bool simStart ( sCfg_t sCfg );
		
		/// Reloads code base
		/// \param pQStringList_filePath 	File list
		/// \retval bool			Success state
		bool simReload ( sCfg_t sCfg );

		/// Sets program counter from code line
		void setPcFromCodeLine ( QString QString_filePath, int i_lineNumber );

		/// Sets simulator to run mode
		void simRun ( void );

		/// Stops run mode
		void simStop ( void );

		/// Sets simulator to next instruction mode
		void simNextInstruction ( void );

		/// Sets simulator to next line mode
		void simNextLine ( void );

		/// Sets simulator to interrupt mode
		void simInt ( void );

		/// Sets simulator to reset mode
		void simRst ( void );

		/// Sets simulator to run to end of call mode
		void simToEndOfCall ( void );
		
	// Simulation
	private:
		/// Control flags
		enum eFlgCtrl_t
		{
			eFlagNoChange,
			eFlagCalc,
			eFlagClear
		};

		/// Class containing gui elements of the main window
		Mod * pMod;
		
		/// Gui elements
		struct sHw_t
		{
			/// Processor core widget
			PicPblzeSimCore * pPicPblzeSimCore;

			/// Processor io widget
			PicIO * pPicIO;

			/// Processor call stack
			PicPblzeSimCoreCallStack * pPicPblzeSimCoreCallStack;
			
			/// Program counter
			sCodeLine_t * psCodeLine_pc;
			
			/// Call stack return pointer
			QList < PicPblzeAsmParser::sCodeLine_t *> QList_callStack;
			
			/// Backup zero flag for interrupt
			int i_zeroFlagIntBackup;
			
			/// Backup carry flag for interrupt
			int i_carryFlagIntBackup;
		} sHw;
		
	// Handle source
	private:
		
		void selectSrcFromPc ( void );
		
	signals:

		/// Signs the next command line
		/// \param QString_filePath	File path
		/// \param i_lineNumber		Line number
		void selectSrc ( QUrl QUrl_src );

	// Simulate commands
	private:
		
		/// Execute code line
		/// \retval bool	True, if line executed successfull, otherwise false
		bool simCmd ( void );

		/// Finds next line with command set.
		void simCmdFindNext ( void );

		/// Simulate command: EINT, DINT, ...
		/// \param b_intEn	Interrupt enable/disable
		/// \retval eRetVal_t	Success state
		bool simCmdIntEn ( bool b_intEn );

		/// Simulate command: ADD
		/// \param b_carryEn	Carry bit enable/disable
		/// \retval bool	Success state
		bool simCmdAdd ( bool b_carryEn );

		/// Simulate command: AND
		/// \retval eRetVal_t	Success state
		bool simCmdAnd ( void );

		/// Simulate command: CALL
		/// \retval eRetVal_t	Success state
		bool simCmdCall ( void );

		/// Simulate command: COMPARE
		/// \param b_carryEn	Carry bit enable/disable
		/// \retval eRetVal_t	Success state
		bool simCmdCompare ( bool b_carryEn );

		/// Simulate command: FETCH
		/// \retval eRetVal_t	Success state
		bool simCmdFetch ( void );

		/// Simulate command: INPUT
		/// \retval eRetVal_t	Success state
		bool simCmdInput ( void );

		/// Simulate command: JUMP
		/// \retval eRetVal_t	Success state
		bool simCmdJump ( void );

		/// Simulate command: LOAD
		/// \retval eRetVal_t	Success state
		bool simCmdLoad ( void );

		/// Simulate command: OR
		/// \retval eRetVal_t	Success state
		bool simCmdOr ( void );

		/// Simulate command: OUTPUT
		/// \retval eRetVal_t	Success state
		bool simCmdOutput ( void );

		/// Simulate command: RETURN
		/// \retval eRetVal_t	Success state
		bool simCmdReturn ( void );

		/// Simulate command: RETURNI
		/// \retval eRetVal_t	Success state
		bool simCmdReturnI ( void );

		/// Simulate command: RL
		/// \retval eRetVal_t	Success state
		bool simCmdRL ( void );

		/// Simulate command: RR
		/// \retval eRetVal_t	Success state
		bool simCmdRR ( void );

		/// Simulate command: SL
		/// \retval eRetVal_t	Success state
		bool simCmdSL ( void );

		/// Simulate command: SR
		/// \retval eRetVal_t	Success state
		bool simCmdSR ( void );

		/// Simulate command: STORE
		/// \retval eRetVal_t	Success state
		bool simCmdStore ( void );

		/// Simulate command: SUB
		/// \retval bool	Success state
		bool simCmdSub ( bool b_carryEn );

		/// Simulate command: TEST
		/// \param b_carryEn	Carry bit enable/disable
		/// \retval eRetVal_t	Success state
		bool simCmdTest ( bool b_carryEn );

		/// Simulate command: XOR
		/// \retval eRetVal_t	Success state
		bool simCmdXOr ( void );

		/// Simulate command: REGBANK
		/// \retval eRetVal_t	Success state
		bool simCmdRBank ( void );

		/// Simulate command: STAR
		/// \retval eRetVal_t	Success state
		bool simCmdStar ( void );

		/// Simulate command: LOADRET
		/// \retval eRetVal_t	Success state
		bool simCmdLoadRet ( void );

		/// Simulate command: LOADRET
		/// \retval eRetVal_t	Success state
		bool simCmdHwbld ( void );
		
	// Simulate arguments
	private:
		
		/// Gets value from register
		/// \param Qstring_arg		Argument
		/// \param pQString_reg		Pointer to return register name
		/// \param pi_value		Pointer to return value
		/// \retval bool		True, if successful, otherwise false
		bool simArgReg ( QString Qstring_arg, QString * pQString_reg, int * pi_value = NULL );

		/// Gets value from constant/register
		/// \param Qstring_arg		Argument
		/// \param pi_value		Pointer to return value
		/// \retval bool		True, if successful, otherwise false
		bool simArgRegNum ( QString QString_arg, int * pi_value );

		/// Gets value from port
		/// \param Qstring_arg		Argument
		/// \param pi_value		Pointer to return value
		/// \param pQString_portSubst	Pointer to return port substitute
		/// \retval bool		True, if successful, otherwise false
		bool simArgPSAddr ( QString QString_arg, int * pi_value, QString * pQString_portSubst = NULL );

		/// Gets code line element from argument
		/// \param Qstring_arg		Argument
		/// \param ppsCodeLine		Pointer to return code line element
		/// \retval bool		True, if successful, otherwise false
		bool simArgMAddr ( QString QString_arg, PicPblzeAsmParser::sCodeLine_t ** ppsCodeLine );

	// Set hardware
	private:
		
		/// Checks if argument is branch argument
		/// \param QString_arg		Argument
		/// \retval bool		True, if argument is branch argument, otherwise false
		bool hwChkBranch ( QString QString_arg );

		/// Sets carry bit from result
		/// \param i_result
		void hwSetCarryFromResult ( int i_result );

		/// Sets zero bit from result
		/// \param i_result
		void hwSetZeroFromResult ( int i_result );

		/// Sets register
		/// \param QString_reg		Register name
		/// \param QString_reg		Register substitute
		/// \param QString_reg		Register value
		/// \retval bool
		void hwSetReg ( QString QString_reg, QString QString_regSubst, int i_result );
		
		/// Set program counter from given value
		/// \param sCodeLine		Code line
		void hwSetPc ( PicPblzeAsmParser::sCodeLine_t * psCodeLine );

		/// Set following program counter
		void hwSetPcNext ( void );
		
		/// Checks hardware for interrupt
		/// \retval bool		TRUE if success, otherwise FALSE
		bool hwChkInt ( void );

		/// Pushes program counter to callstack
		/// \retval bool		TRUE, if callstack overflow, otherwise FALSE
		bool hwPushPcToCallstack ( void );
		
		/// Pulls the last program counter from callstack
		bool hwPullPcFromCallstack ( void );
		
	// Message handling
	private:
		
		enum eMsgType_t
		{
			eMsgType_ok,

			eMsgType_warn,
			eMsgType_simInteractReq,

			eMsgType_err,
			eMsgType_simErr,
			eMsgType_simNoMoreCmds,
			eMsgType_simWrongAddr,
			eMsgType_callStackOverflow,
			eMsgType_callStackEmpty,
			eMsgType_undefinedIsr
		};
		
		void msgEmit ( eMsgType_t eMsgType );

		void msgEmit ( eMsgType_t eMsgType, sCodeLine_t * psCodeLine );

		/// Emits message.
		/// \param pMsg				Message
		void msgEmit ( Msg * pMsg, eMsgType_t eMsgType );
		
		
};

#endif
