/*****************************************************************************************************************************
 *   Copyright (C) 2009 by Christoph Fauck                                                                                   *
 *   Christoph Fauck <christoph.fauck@fauck.com>                                                                             *
 *                                                                                                                           *
 *   This file is part of openPICIDE.                                                                                        *
 *                                                                                                                           *
 *   openPICIDE is free software: you can redistribute it and/or modify it under the terms of the GNU General                *
 *   Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option)       *
 *   any later version.                                                                                                      *
 *                                                                                                                           *
 *   openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied        *
 *   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  *
 *                                                                                                                           *
 *   You should have received a copy of the GNU General Public License along with openPICIDE.                                *
 *   If not, see <http://www.gnu.org/licenses/>.                                                                             *
 *                                                                                                                           *
 ****************************************************************************************************************************/

#include "PicPblzeAsmParser.h"
#include "stdio.h"

/**
 *****************************************************************************************************************************
 */

QStringList PicPblzeAsmParser::getCmdList ( PicPblzeSet::ePicDerivate_t ePicDerivate )
{
	QStringList QStringList_cmd;

	QStringList_cmd

		<< "RET"
		<< "RETI"
		<< "ADDC"
		<< "SUBC"
		<< "IN"
		<< "OUT"
		<< "EINT"
		<< "DINT"
		<< "ENABLE"
		<< "DISABLE"
		<< "ADD"
		<< "AND"
		<< "CALL"
		<< "JUMP"
		<< "LOAD"
		<< "OR"
		<< "RL"
		<< "RR"
		<< "SL0"
		<< "SL1"
		<< "SLA"
		<< "SLX"
		<< "SR0"
		<< "SR1"
		<< "SRA"
		<< "SRX"
		<< "SUB"
		<< "XOR";

	if ( ePicDerivate == PicPblzeSet::ePblze3 )
	{
		QStringList_cmd
			<< "COMP"
			<< "TEST"
			<< "FETCH"
			<< "STORE";
	}
	else if ( ePicDerivate == PicPblzeSet::ePblze6 )
	{
		QStringList_cmd
			<< "COMP"
			<< "COMPC"
			<< "TEST"
			<< "TESTC"
			<< "FETCH"
			<< "STORE"
			<< "STAR"
			<< "REGBANK"
			<< "OUTK"
			<< "HWBUILD"
			<< "LOADRET";
	}

	return QStringList_cmd;
}

/**
 *****************************************************************************************************************************
 */

QStringList PicPblzeAsmParser::getDirectiveList ( PicPblzeSet::ePicDerivate_t ePicDerivate )
{
	QStringList QStringList_cmd;

	QStringList_cmd
		<< "ORG"
		<< "EQU"
		<< "MFLAG";

	return QStringList_cmd;
}

/**
 *****************************************************************************************************************************
 */

QStringList PicPblzeAsmParser::getHwComponentList ( PicPblzeSet::ePicDerivate_t ePicDerivate )
{
	QStringList QStringList_hwComponent;

	switch ( ePicDerivate )
	{
		case PicPblzeSet::ePblzeCpld:
			QStringList_hwComponent << "s0" << "s1" << "s2" << "s3" << "s4" << "s5" << "s6" << "s7";
			break;

		case PicPblzeSet::ePblze:
			QStringList_hwComponent << "s0" << "s1" << "s2" << "s3" << "s4" << "s5" << "s6" << "s7";
			QStringList_hwComponent << "s8" << "s9" << "sA" << "sB" << "sC" << "sD" << "sE" << "sF";
			break;

		case PicPblzeSet::ePblzeII:
			QStringList_hwComponent << "s00" << "s01" << "s02" << "s03" << "s04" << "s05" << "s06" << "s07";
			QStringList_hwComponent << "s08" << "s09" << "s0A" << "s0B" << "s0C" << "s0D" << "s0E" << "s0F";
			QStringList_hwComponent << "s10" << "s11" << "s12" << "s13" << "s14" << "s15" << "s16" << "s17";
			QStringList_hwComponent << "s18" << "s19" << "s1A" << "s1B" << "s1C" << "s1D" << "s1E" << "s1F";
			break;

		case PicPblzeSet::ePblze3:
			QStringList_hwComponent << "s0" << "s1" << "s2" << "s3" << "s4" << "s5" << "s6" << "s7";
			QStringList_hwComponent << "s8" << "s9" << "sA" << "sB" << "sC" << "sD" << "sE" << "sF";
			break;
			
		case PicPblzeSet::ePblze6:
			QStringList_hwComponent << "s0" << "s1" << "s2" << "s3" << "s4" << "s5" << "s6" << "s7";
			QStringList_hwComponent << "s8" << "s9" << "sA" << "sB" << "sC" << "sD" << "sE" << "sF";
			break;
	}

	QStringList_hwComponent << "SHARED" << "BANK0" << "BANK1" << "BANK2" << "BANK3";

	return QStringList_hwComponent;
}

/**
 *****************************************************************************************************************************
 */

QMap<QString,QStringList> PicPblzeAsmParser::getNumberRegExp ( PicPblzeSet::ePicDerivate_t ePicDerivate )
{
	QMap<QString, QStringList> QMap_numberRegExp;

	QMap_numberRegExp[ "HEX" ] << "\\b0x[0-9A-Fa-f]+\\b" << "\\b\\$[0-9A-Fa-f]+\\b";
	QMap_numberRegExp[ "DEC" ] << "\\b[0-9]+\\b";
	QMap_numberRegExp[ "OCT" ] << "\\b\\\\[0-9]+\\b";

	return QMap_numberRegExp;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Constructor
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

PicPblzeAsmParser::PicPblzeAsmParser ( QObject * pQObject_parent ) : QObject ( pQObject_parent )
{
	this->psCodeLine_start   = NULL;
	this->psCodeLine_stop    = NULL;

	this->sCfg.i_memBankCount = 1;
	this->sCfg.i_memBankSize  = 0;
	this->sCfg.i_scrpdSize    = 0;
	this->sCfg.i_intVector    = 0;
	this->sCfg.ePicDerivate   = PicPblzeSet::ePblze3;
	
	this->sMem.apsCodeLine_memMap = NULL;
}

/**
 *****************************************************************************************************************************
 */

PicPblzeAsmParser::~PicPblzeAsmParser ()
{
	this->clear();
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Parameter handling
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

void PicPblzeAsmParser::clear ( void )
{
	// Delete memory map
	{
		if ( this->sMem.apsCodeLine_memMap )
			delete[] this->sMem.apsCodeLine_memMap;
		
		this->sMem.apsCodeLine_memMap = NULL;
	}

	sCodeLine_t * psCodeLine = this->psCodeLine_start;
	sCodeLine_t * psCodeLine_del;

	if ( psCodeLine )
	{
		psCodeLine_del = psCodeLine;
		psCodeLine = psCodeLine->psCodeLine_next;

		delete psCodeLine_del;
	}

	this->psCodeLine_start = NULL;
	this->psCodeLine_stop  = NULL;

	this->QMap_refs.clear();
	this->QMap_constants.clear();
	this->QMap_regSubst.clear();
	
	this->sMsg.i_errCntr = 0;
	
	memset ( & this->sInstCount, 0, sizeof ( sInstCount_t ) );
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::setCfg ( sCfg_t sCfg )
{
	// Clear parser
	this->clear ();

	// Store parameter
	this->sCfg = sCfg;
	
	// Print parameter for debugging
	qDebug() << "PicPblzeAsmParser::setCfg:	ePicDerivate:		" << PicPblzeSet::getDerivateName ( this->sCfg.ePicDerivate );
	qDebug() << "PicPblzeAsmParser::setCfg:	i_memBankCount:		" << this->sCfg.i_memBankCount;
	qDebug() << "PicPblzeAsmParser::setCfg:	i_memBankSize:		" << this->sCfg.i_memBankSize;
	qDebug() << "PicPblzeAsmParser::setCfg:	QStringList_filePath:	" << this->sCfg.QStringList_filePath;
	qDebug() << "PicPblzeAsmParser::setCfg:	eMemSharedLoc:		" << this->sCfg.eMemSharedLoc;
	
	// Set key words and command lists
	this->QStringList_keyWords << this->getCmdList         ( this->sCfg.ePicDerivate );
	this->QStringList_keyWords << this->getDirectiveList   ( this->sCfg.ePicDerivate );
	this->QStringList_keyWords << this->getHwComponentList ( this->sCfg.ePicDerivate );
	this->QStringList_cmd      << this->getCmdList         ( this->sCfg.ePicDerivate );
	
	// Add files to code base
	for ( int i_iterator = 0; i_iterator < this->sCfg.QStringList_filePath.count(); i_iterator++ )
	{
		if ( ! this->addFile ( i_iterator, this->sCfg.QStringList_filePath.at ( i_iterator ) ) )
			return FALSE;
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Reading files to chained list
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::addFile ( int i_fileNumber, QString QString_filePath )
{
	// Open, read and close files
	{
		QFile QFile_temp ( QString_filePath );

		if ( ! QFile_temp.open ( QIODevice::ReadOnly | QIODevice::Text ) )
		{
			this->msgEmit ( eMsgType_fileIO, QString_filePath );
			return FALSE;
		}
		
		this->msgEmit ( eMsgType_readingFile, QString_filePath );

		int i_lineNumber = 0;

		while ( ! QFile_temp.atEnd() )
			this->addCodeLine ( i_fileNumber, i_lineNumber++, QFile_temp.readLine() );

		QFile_temp.close();
	}
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::addCodeLine ( int i_fileNumber, int i_lineNumber, QString QString_line )
{
	//********************************************************************************************************************
	//* Get new line element
	//********************************************************************************************************************
	sCodeLine_t * psCodeLine = new sCodeLine_t;

	if ( ! psCodeLine )
		return FALSE;

	//********************************************************************************************************************
	//* Append element to chain
	//********************************************************************************************************************
	if ( ! this->psCodeLine_start )
	{
		this->psCodeLine_start = psCodeLine;
		this->psCodeLine_stop  = psCodeLine;

		this->psCodeLine_start->psCodeLine_prev = NULL;
	}
	else
	{
		psCodeLine->psCodeLine_prev = this->psCodeLine_stop;
		this->psCodeLine_stop->psCodeLine_next = psCodeLine;
		this->psCodeLine_stop  = psCodeLine;
	}
	psCodeLine->psCodeLine_next = NULL;

	//********************************************************************************************************************
	//* Set line element data
	//********************************************************************************************************************
	psCodeLine->i_fileNumber = i_fileNumber;
	psCodeLine->i_lineNumber = i_lineNumber;
	psCodeLine->QString_line = QString_line;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Parsing code lines
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::parse ( void )
{
	//********************************************************************************************************************
	//* Check, if code loaded
	//********************************************************************************************************************
	if ( ! this->psCodeLine_start )
	{
		this->msgEmit ( eMsgType_ivldCodeLineCnt );
		return FALSE;
	}

	//********************************************************************************************************************
	//* Split loaded code lines into components like opcodes and directives
	//********************************************************************************************************************
	if ( ! this->parseLine() )
	{
		this->msgEmit ( eMsgType_err );
		return FALSE;
	}

	//********************************************************************************************************************
	//* Check commands and their arguments
	//********************************************************************************************************************
	if ( ! this->chkCmd() )
	{
		this->msgEmit ( eMsgType_err );
		return FALSE;
	}

	//********************************************************************************************************************
	//* Set code line addresses
	//********************************************************************************************************************
	if ( ! this->memOrganize() )
	{
		this->msgEmit ( eMsgType_err );
		return FALSE;
	}

	//********************************************************************************************************************
	//* Emit success message
	//********************************************************************************************************************
	this->msgEmit ( eMsgType_ok );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::parseLine ( void )
{
	sCodeLine_t * psCodeLine = this->psCodeLine_start;

	while ( psCodeLine )
	{
		//************************************************************************************************************
		//* Remove Line ending
		//************************************************************************************************************
		QString QString_line;
		{
			QString_line = psCodeLine->QString_line;
			
			QString_line.remove ( QString ( "\n" ) );
		}
		
		//************************************************************************************************************
		//* Preset line flags
		//************************************************************************************************************
		psCodeLine->i_addr	= -1;
		psCodeLine->eMFlag	= eMFlag_unset;
		psCodeLine->eLineType	= eLineType_unset;

		//************************************************************************************************************
		//* Check for comment
		//************************************************************************************************************
		if ( QString_line.contains ( QRegExp ( "^\\s*;" ) ) )
		{
			psCodeLine->eLineType	= eLineType_comment;
			psCodeLine = psCodeLine->psCodeLine_next;
			continue;
		}

		//************************************************************************************************************
		//* Check for line empty
		//************************************************************************************************************
		else if ( QString_line.contains ( QRegExp ( "^[\\s\\t]*$" ) ) )
		{
			psCodeLine->eLineType	= eLineType_empty;
			psCodeLine = psCodeLine->psCodeLine_next;
			continue;
		}

		//************************************************************************************************************
		//* Handle as command line
		//************************************************************************************************************
		else
		{
			// Remove "blanks" and "comments from end of line"
			QString_line = QString_line.section ( QChar ( ';' ), 0, 0, QString::SectionSkipEmpty );
			
			//****************************************************************************************************
			//* Extract label
			//****************************************************************************************************
			int i_colonCnt = QString_line.count ( QChar ( ':' ) );

			if ( i_colonCnt == 1 )
			{
				// Extract label
				QString QString_ref = QString_line.section ( QChar ( ':' ), 0, 0, QString::SectionSkipEmpty ).remove ( QRegExp ( "^\\s+" ) );

				if ( QString_ref.contains ( QRegExp ( "\\s+" ) ) )
				{
					++this->sMsg.i_errCntr;
					this->msgEmit ( eMsgType_ivldColon, psCodeLine );
				}
				
				// Check, if multiple used label
				if ( this->QMap_refs.contains ( QString_ref ) )
				{
					++this->sMsg.i_errCntr;
					this->msgEmit ( eMsgType_argRefAlreadyUsed, psCodeLine );
				}

				// Add label to list
				this->QMap_refs [ QString_ref ] = psCodeLine;

				// Remove label from line
				QString_line = QString_line.section ( QChar ( ':' ), 1, 1, QString::SectionSkipEmpty );
			}
			else if ( i_colonCnt > 1 )
			{
				++this->sMsg.i_errCntr;
				this->msgEmit ( eMsgType_ivldColon, psCodeLine );
			}

			//************************************************************************************************************
			//* Extract directive
			//************************************************************************************************************
			QString QString_lineUpper = psCodeLine->QString_line.toUpper ();

			if ( QString_lineUpper.contains ( QRegExp ( "\\bORG\\b" ) ) )
			{
				if ( this->parseDirectiveOrg   ( QString_line, psCodeLine ) )
				{
					psCodeLine->eLineType = eLineType_dirOrg;
				}
				else
				{
					++this->sMsg.i_errCntr;
				}
			}   
			else if ( QString_lineUpper.contains ( QRegExp ( "\\bEQU\\b" ) ) )
			{
				if ( this->parseDirectiveEqu   ( QString_line, psCodeLine ) )
				{
					psCodeLine->eLineType = eLineType_dirEqu;
				}
				else
				{
					++this->sMsg.i_errCntr;
				}
			}
			else if ( QString_lineUpper.contains ( QRegExp ( "\\bMFLAG\\b" ) ) )
			{
				if ( this->parseDirectiveMflag ( QString_line, psCodeLine ) )
				{
					psCodeLine->eLineType = eLineType_dirMflag;
				}
				else
				{
					++this->sMsg.i_errCntr;
				}
			}

			//************************************************************************************************************
			//* Extract opcode
			//************************************************************************************************************
			else
			{
				if ( this->parseOpcode ( QString_line, psCodeLine ) )
					psCodeLine->eLineType = eLineType_cmd;
			}

			//************************************************************************************************************
			//* Check error counter
			//************************************************************************************************************
			if ( this->sMsg.i_errCntr > 9 )
				break;			
		}

		psCodeLine = psCodeLine->psCodeLine_next;
	}

	if ( this->sMsg.i_errCntr > 0 )
		return FALSE;
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::parseCheckSymbol ( sCodeLine_t * psCodeLine, QString QString_symbol )
{
	// Check substitute name against keywords
	if ( this->QStringList_keyWords.contains ( QString_symbol.toUpper () ) )
	{
		this->msgEmit ( eMsgType_argNoKeyword, psCodeLine );
		return FALSE;
	}
	// Check substitute name against register
	if ( this->checkArgReg ( QString_symbol ) )
	{
		this->msgEmit ( eMsgType_argNoReg, psCodeLine );
		return FALSE;
	}
	// Check substitute name against number
	if ( this->checkArgNumber ( QString_symbol ) )
	{
		this->msgEmit ( eMsgType_argNoNumber, psCodeLine );
		return FALSE;
	}
	// Check substitute name against used constants
	if ( this->QMap_constants.contains ( QString_symbol ) )
	{
		this->msgEmit ( eMsgType_argUsedAsConst, psCodeLine );
		return FALSE;
	}
	// Check substitute name against used register substitutes
	if ( this->QMap_regSubst.contains ( QString_symbol ) )
	{
		this->msgEmit ( eMsgType_argUsedAsReg, psCodeLine );
		return FALSE;
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::parseDirectiveOrg ( QString & QString_line, sCodeLine_t * psCodeLine )
{
	QStringList QStringList_terms = QString_line.split ( QRegExp ( "\\s+" ), QString::SkipEmptyParts );

	// Check term count
	if ( QStringList_terms.count () != 2 )
	{
		this->msgEmit ( eMsgType_ivldSyntax, psCodeLine );
		return FALSE;
	}

	// Check, if line starts with keyword
	if ( QStringList_terms.at ( 0 ).toUpper () != QString ( "ORG" ) )
	{
		this->msgEmit ( eMsgType_ivldSyntax, psCodeLine );
		return FALSE;
	}

	// Get number
	{
		QString QString_number = QStringList_terms.at ( 1 );
		int i_value;

		if ( ! this->checkArgNumber ( QString_number, & i_value, this->sCfg.i_memBankSize - 1 ) )
		{
			this->msgEmit ( eMsgType_argExpNumber, psCodeLine );
			return FALSE;
		}

		psCodeLine->i_addr = i_value;
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::parseDirectiveEqu ( QString & QString_line, sCodeLine_t * psCodeLine )
{
	QStringList QStringList_terms = QString_line.split ( QRegExp ( "\\s+" ), QString::SkipEmptyParts );

	// Check term count
	if ( QStringList_terms.count () != 3 )
	{
		this->msgEmit ( eMsgType_ivldSyntax, psCodeLine );
		return FALSE;
	}

	// Checks for keyword
	if ( QStringList_terms.at ( 1 ).toUpper () != QString ( "EQU" ) )
	{
		this->msgEmit ( eMsgType_ivldSyntax, psCodeLine );
		return FALSE;
	}

	int i_value;
	QString QString_reg;

	// Check, if register substitute
	if ( this->checkArgReg ( QStringList_terms.at ( 2 ), & QString_reg ) )
	{
		if ( ! this->parseCheckSymbol ( psCodeLine, QStringList_terms.at ( 0 ) ) )
			return FALSE;

		// Set substitute
		this->QMap_regSubst[ QStringList_terms.at ( 0 ) ] = QString_reg;
	}
	// Check, if constant
	else if ( this->checkArgNumber ( QStringList_terms.at ( 2 ), & i_value ) )
	{
		if ( ! this->parseCheckSymbol ( psCodeLine, QStringList_terms.at ( 0 ) ) )
			return FALSE;

		// Set substitute
		this->QMap_constants[ QStringList_terms.at ( 0 ) ] = i_value;
	}
	else
	{
		this->msgEmit ( eMsgType_argExpRegNumber, psCodeLine );
		return FALSE;
	}
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::parseDirectiveMflag ( QString & QString_line, sCodeLine_t * psCodeLine )
{
	QStringList QStringList_terms = QString_line.split ( QRegExp ( "\\s+" ), QString::SkipEmptyParts );

	// Check term count
	if ( QStringList_terms.count () != 2 )
	{
		this->msgEmit ( eMsgType_ivldSyntax, psCodeLine );
		return FALSE;
	}

	// Check, if line starts with keyword
	if ( QStringList_terms.at ( 0 ).toUpper () != QString ( "MFLAG" ) )
	{
		this->msgEmit ( eMsgType_ivldSyntax, psCodeLine );
		return FALSE;
	}

	// Check argument
	{
		QString QString_flag = QStringList_terms.at ( 1 ).toUpper ();
	
		if      ( QString_flag == "SHARED" )	psCodeLine->eMFlag = eMFlag_shared;
		else if ( QString_flag == "BANK0" )	psCodeLine->eMFlag = eMFlag_bank0;
		else if ( QString_flag == "BANK1" )	psCodeLine->eMFlag = eMFlag_bank1;
		else if ( QString_flag == "BANK2" )	psCodeLine->eMFlag = eMFlag_bank2;
		else if ( QString_flag == "BANK3" )	psCodeLine->eMFlag = eMFlag_bank3;
		else
		{
			this->msgEmit ( eMsgType_argExpMFLag, psCodeLine );
			return FALSE;
		}
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::parseOpcode ( QString & QString_line, sCodeLine_t * psCodeLine )
{
	// Extract command
	psCodeLine->QString_cmd = QString_line.section ( QRegExp ( "\\s+" ), 0, 0, QString::SectionSkipEmpty );

	// Extract arguments
	QString QString_args = QString_line.section ( QRegExp ( "\\s+" ), 1, -1, QString::SectionSkipEmpty ).remove ( QRegExp ( "\\s+" ) );

	psCodeLine->QStringList_args = QString_args.split ( QChar ( ',' ), QString::SkipEmptyParts );
	
	
	if ( psCodeLine->QString_cmd.isEmpty() )
		return FALSE;
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Check commands and their arguments
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::chkCmd ( void )
{
	sCodeLine_t * psCodeLine = this->psCodeLine_start;

	while ( psCodeLine )
	{
		// Skip no-cmd-lines
		if ( psCodeLine->eLineType < eLineType_cmd )
		{
			psCodeLine = psCodeLine->psCodeLine_next;
			continue;
		}

		bool b_retValLoop = TRUE;

		QString QString_cmd = psCodeLine->QString_cmd.toUpper ();

		// Check, if command supported by selected derivate
		if ( ! this->QStringList_cmd.contains ( QString_cmd ) )
		{
			this->msgEmit ( eMsgType_ivldCmd, psCodeLine );
			b_retValLoop = FALSE;
		}

		if ( b_retValLoop )
		{
			     if ( "RET"     == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdRet;     b_retValLoop = this->compileCmd_Return  ( psCodeLine ); }
			else if ( "RETI"    == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdReti;    b_retValLoop = this->compileCmd_ReturnI ( psCodeLine ); }
			else if ( "ADDC"    == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdAddc;    b_retValLoop = this->compileCmd_R_RK    ( psCodeLine ); }
			else if ( "SUBC"    == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdSubc;    b_retValLoop = this->compileCmd_R_RK    ( psCodeLine ); }
			else if ( "IN"      == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdIn;      b_retValLoop = this->compileCmd_R_IO    ( psCodeLine ); }
			else if ( "OUT"     == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdOut;     b_retValLoop = this->compileCmd_Out     ( psCodeLine ); }
			else if ( "EINT"    == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdEint;    b_retValLoop = this->compileCmd_Int     ( psCodeLine ); }
			else if ( "DINT"    == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdDint;    b_retValLoop = this->compileCmd_Int     ( psCodeLine ); }
			else if ( "COMP"    == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdComp;    b_retValLoop = this->compileCmd_R_RK    ( psCodeLine ); }
			else if ( "COMPC"   == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdCompC;   b_retValLoop = this->compileCmd_R_RK    ( psCodeLine ); }
			else if ( "ADD"     == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdAdd;     b_retValLoop = this->compileCmd_R_RK    ( psCodeLine ); }
			else if ( "AND"     == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdAnd;     b_retValLoop = this->compileCmd_R_RK    ( psCodeLine ); }
			else if ( "CALL"    == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdCall;    b_retValLoop = this->compileCmd_Branch  ( psCodeLine ); }
			else if ( "HWBUILD" == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdHwbld;   b_retValLoop = this->compileCmd_R       ( psCodeLine ); }
			else if ( "JUMP"    == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdJump;    b_retValLoop = this->compileCmd_Branch  ( psCodeLine ); }
			else if ( "LOAD"    == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdLoad;    b_retValLoop = this->compileCmd_R_RK    ( psCodeLine ); }
			else if ( "OR"      == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdOr;      b_retValLoop = this->compileCmd_R_RK    ( psCodeLine ); }
			else if ( "RL"      == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdRl;      b_retValLoop = this->compileCmd_R       ( psCodeLine ); }
			else if ( "RR"      == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdRr;      b_retValLoop = this->compileCmd_R       ( psCodeLine ); }
			else if ( "SL0"     == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdSl0;     b_retValLoop = this->compileCmd_R       ( psCodeLine ); }
			else if ( "SL1"     == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdSl1;     b_retValLoop = this->compileCmd_R       ( psCodeLine ); }
			else if ( "SLA"     == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdSlA;     b_retValLoop = this->compileCmd_R       ( psCodeLine ); }
			else if ( "SLX"     == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdSlX;     b_retValLoop = this->compileCmd_R       ( psCodeLine ); }
			else if ( "SR0"     == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdSr0;     b_retValLoop = this->compileCmd_R       ( psCodeLine ); }
			else if ( "SR1"     == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdSr1;     b_retValLoop = this->compileCmd_R       ( psCodeLine ); }
			else if ( "SRA"     == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdSrA;     b_retValLoop = this->compileCmd_R       ( psCodeLine ); }
			else if ( "SRX"     == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdSrX;     b_retValLoop = this->compileCmd_R       ( psCodeLine ); }
			else if ( "SUB"     == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdSub;     b_retValLoop = this->compileCmd_R_RK    ( psCodeLine ); }
			else if ( "TEST"    == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdTest;    b_retValLoop = this->compileCmd_R_RK    ( psCodeLine ); }
			else if ( "TESTC"   == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdTestC;   b_retValLoop = this->compileCmd_R_RK    ( psCodeLine ); }
			else if ( "XOR"     == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdXor;     b_retValLoop = this->compileCmd_R_RK    ( psCodeLine ); }
			else if ( "STORE"   == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdStore;   b_retValLoop = this->compileCmd_R_IO    ( psCodeLine ); }
			else if ( "FETCH"   == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdFetch;   b_retValLoop = this->compileCmd_R_IO    ( psCodeLine ); }
			else if ( "STAR"    == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdStar;    b_retValLoop = this->compileCmd_R_R     ( psCodeLine ); }
			else if ( "REGBANK" == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdRBank;   b_retValLoop = this->compileCmd_RBank   ( psCodeLine ); }
			else if ( "LOADRET" == QString_cmd ) { psCodeLine->eLineType = eLineType_cmdLoadRet; b_retValLoop = this->compileCmd_R_K     ( psCodeLine ); }
			else
			{
				this->msgEmit ( eMsgType_ivldCmd, psCodeLine );
				b_retValLoop = FALSE;
			}
		}
		
		if ( ! b_retValLoop )
			++sMsg.i_errCntr;

		if ( sMsg.i_errCntr > 9 )
			return FALSE;
		
		psCodeLine = psCodeLine->psCodeLine_next;
	}
	
	if ( sMsg.i_errCntr > 0 )
		return FALSE;
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::compileCmd_Return ( sCodeLine_t * psCodeLine )
{
	int i_argCount = psCodeLine->QStringList_args.count();

	//********************************************************************************************************************
	//* Check argument count
	//********************************************************************************************************************
	if ( i_argCount > 1 )
	{
		this->msgEmit ( eMsgType_argCnt, psCodeLine );
		return FALSE;
	}

	//********************************************************************************************************************
	//* Check branch condition
	//********************************************************************************************************************
	if ( i_argCount == 1 )
	{
		QString QString_arg = psCodeLine->QStringList_args.at ( eFrstArg ).toUpper ();

		if ( ! checkBranchCondition ( QString_arg ) )
		{
			this->msgEmit ( eMsgType_argExpBranchCond, psCodeLine );
			return FALSE;
		}
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::compileCmd_ReturnI ( sCodeLine_t * psCodeLine )
{
	//********************************************************************************************************************
	//* Check argument count
	//********************************************************************************************************************
	if ( psCodeLine->QStringList_args.count() != 1 )
	{
		this->msgEmit ( eMsgType_argCnt, psCodeLine );
		return FALSE;
	}

	//********************************************************************************************************************
	//* Check argument
	//********************************************************************************************************************
	QString QString_arg = psCodeLine->QStringList_args.at ( eFrstArg ).toUpper ();

	if ( QString_arg == QString ( "ENABLE" ) )
	{
		return TRUE;
	}
	else if ( QString_arg == QString ( "DISABLE" ) )
	{
		return TRUE;
	}

	this->msgEmit ( eMsgType_argExpedEnDisable, psCodeLine );
	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::compileCmd_RBank ( sCodeLine_t * psCodeLine )
{
	//********************************************************************************************************************
	//* Check argument count
	//********************************************************************************************************************
	if ( psCodeLine->QStringList_args.count() != 1 )
	{
		this->msgEmit ( eMsgType_argCnt, psCodeLine );
		return FALSE;
	}

	//********************************************************************************************************************
	//* Check argument
	//********************************************************************************************************************
	QString QString_arg = psCodeLine->QStringList_args.at ( eFrstArg ).toUpper ();

	if ( QString_arg == QString ( "A" ) )
	{
		return TRUE;
	}
	else if ( QString_arg == QString ( "B" ) )
	{
		return TRUE;
	}

	this->msgEmit ( eMsgType_argExpedRegBank, psCodeLine );
	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::compileCmd_R_R ( sCodeLine_t * psCodeLine )
{
	//********************************************************************************************************************
	//* Check argument count
	//********************************************************************************************************************
	if ( psCodeLine->QStringList_args.count() != 2 )
	{
		this->msgEmit ( eMsgType_argCnt, psCodeLine );
		return FALSE;
	}

	//********************************************************************************************************************
	//* Check, if first argument
	//********************************************************************************************************************
	{
		// Check for register
		if ( ! this->checkArgRegSubst ( psCodeLine->QStringList_args.at ( eFrstArg ) ) )
		{
			this->msgEmit ( eMsgType_argExpReg, psCodeLine );
			return FALSE;
		}
	}

	//********************************************************************************************************************
	//* Check, if second argument
	//********************************************************************************************************************
	{
		// Check for register
		if ( ! this->checkArgRegSubst ( psCodeLine->QStringList_args.at ( eScndArg ) ) )
		{
			this->msgEmit ( eMsgType_argExpReg, psCodeLine );
			return FALSE;
		}
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::compileCmd_R_RK ( sCodeLine_t * psCodeLine )
{
	//********************************************************************************************************************
	//* Check argument count
	//********************************************************************************************************************
	if ( psCodeLine->QStringList_args.count() != 2 )
	{
		this->msgEmit ( eMsgType_argCnt, psCodeLine );
		return FALSE;
	}

	//********************************************************************************************************************
	//* Check, if first argument
	//********************************************************************************************************************
	{
		// Check for register
		if ( ! this->checkArgRegSubst ( psCodeLine->QStringList_args.at ( eFrstArg ) ) )
		{
			this->msgEmit ( eMsgType_argExpReg, psCodeLine );
			return FALSE;
		}
	}

	//********************************************************************************************************************
	//* Check, if second argument
	//********************************************************************************************************************
	{
		// Check for register
		if ( this->checkArgRegSubst ( psCodeLine->QStringList_args.at ( eScndArg ) ) )
		{
			return TRUE;
		}
		// Check for number and constant
		else if ( this->checkArgNumberConst ( psCodeLine->QStringList_args.at ( eScndArg ) ) )
		{
			return TRUE;
		}

		this->msgEmit ( eMsgType_argExpRegNumber, psCodeLine );
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::compileCmd_R_K ( sCodeLine_t * psCodeLine )
{
	//********************************************************************************************************************
	//* Check argument count
	//********************************************************************************************************************
	if ( psCodeLine->QStringList_args.count() != 2 )
	{
		this->msgEmit ( eMsgType_argCnt, psCodeLine );
		return FALSE;
	}

	//********************************************************************************************************************
	//* Check, if first argument
	//********************************************************************************************************************
	{
		// Check for register
		if ( ! this->checkArgRegSubst ( psCodeLine->QStringList_args.at ( eFrstArg ) ) )
		{
			this->msgEmit ( eMsgType_argExpReg, psCodeLine );
			return FALSE;
		}
	}

	//********************************************************************************************************************
	//* Check, if second argument
	//********************************************************************************************************************
	{
		// Check for number and constant
		if ( this->checkArgNumberConst ( psCodeLine->QStringList_args.at ( eScndArg ) ) )
		{
			return TRUE;
		}

		this->msgEmit ( eMsgType_argExpRegNumber, psCodeLine );
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::compileCmd_R_IO ( sCodeLine_t * psCodeLine )
{
	//********************************************************************************************************************
	//* Check argument count
	//********************************************************************************************************************
	if ( psCodeLine->QStringList_args.count() != 2 )
	{
		this->msgEmit ( eMsgType_argCnt, psCodeLine );
		return FALSE;
	}

	//********************************************************************************************************************
	//* Check, if first argument
	//********************************************************************************************************************
	{
		if ( ! this->checkArgRegSubst ( psCodeLine->QStringList_args.at ( eFrstArg ) ) )
		{
			this->msgEmit ( eMsgType_argExpReg, psCodeLine );
			return FALSE;
		}
	}

	//********************************************************************************************************************
	//* Check, if second argument
	//********************************************************************************************************************
	{
		// Check for number and constant
		if ( this->checkArgNumberConst ( psCodeLine->QStringList_args.at ( eScndArg ) ) )
		{
			return TRUE;
		}
		// Check for register mapped port
		else if ( this->checkArgAddrByReg ( psCodeLine->QStringList_args.at ( eScndArg ) ) )
		{
			return TRUE;
		}

		this->msgEmit ( eMsgType_argExpPort, psCodeLine );
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::compileCmd_Int ( sCodeLine_t * psCodeLine )
{
	//********************************************************************************************************************
	//* Concatenate cmd and arg0 to multipart command
	//********************************************************************************************************************
	QString QString_cmd = psCodeLine->QString_cmd.toUpper();

	if ( psCodeLine->QStringList_args.count() == 1 )
	{
		QString_cmd += QString ( " " )  += psCodeLine->QStringList_args.at ( eFrstArg ).toUpper();
		psCodeLine->QStringList_args.clear();
	}

	//********************************************************************************************************************
	//* Check multipart command
	//********************************************************************************************************************
	if ( QString_cmd == QString ( "DISABLE INTERRUPT" ) )
	{
		psCodeLine->QString_cmd = QString_cmd;
	}
	else if ( QString_cmd == QString ( "DINT" ) )
	{
		psCodeLine->QString_cmd = QString_cmd;
	}
	else if ( QString_cmd == QString ( "ENABLE INTERRUPT" ) )
	{
		psCodeLine->QString_cmd = QString_cmd;
	}
	else if ( QString_cmd == QString ( "EINT" ) )
	{
		psCodeLine->QString_cmd = QString_cmd;
	}
	else
	{
		this->msgEmit ( eMsgType_ivldCmd, psCodeLine );
		return FALSE;
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::compileCmd_Branch ( sCodeLine_t * psCodeLine )
{
	//********************************************************************************************************************
	//* Check argument count
	//********************************************************************************************************************
	int i_argCount = psCodeLine->QStringList_args.count();

	if ( ( i_argCount < 1 ) || ( i_argCount > 2 ) )
	{
		this->msgEmit ( eMsgType_argCnt, psCodeLine );
		return FALSE;
	}

	//********************************************************************************************************************
	//* Address only
	//********************************************************************************************************************
	if ( i_argCount == 1 )
	{
		// Check for label
		if ( this->checkArgRef ( psCodeLine->QStringList_args.at ( eFrstArg ) ) )
			return TRUE;

		// Check for number and constant
		else if ( this->checkArgNumberConst ( psCodeLine->QStringList_args.at ( eFrstArg ), NULL, ( this->sCfg.i_memBankSize - 1 ) ) )
			return TRUE;

		this->msgEmit ( eMsgType_argExpAddr, psCodeLine );
		return FALSE;
	}
	
	//********************************************************************************************************************
	//* 
	//********************************************************************************************************************
	QString QString_arg0 = psCodeLine->QStringList_args.at ( eFrstArg );
	QString QString_arg1 = psCodeLine->QStringList_args.at ( eScndArg );
		
	// Check if register referenced address
	if ( QString_arg0.contains ( "(" ) || QString_arg1.contains ( ")" )  )
	{
		// Check if arguments allowed
		if ( this->sCfg.ePicDerivate != PicPblzeSet::ePblze6 )
		{
			this->msgEmit ( eMsgType_ivldArg, psCodeLine );
			return FALSE;
		}
		
		// Check for brackets
		if ( QString_arg0.at ( 0 ) != QChar ( '(' ) )
		{
			this->msgEmit ( eMsgType_argExpBracket, psCodeLine );
			return FALSE;
		}
		
		if ( QString_arg1.at ( QString_arg1.length() - 1 ) != QChar ( ')' ) )
		{
			this->msgEmit ( eMsgType_argExpBracket, psCodeLine );
			return FALSE;
		}
		
		// Remove brackets
		QString_arg0 = QString_arg0.remove ( 0, 1 );
		QString_arg1 = QString_arg1.remove ( QString_arg1.length() - 1, 1 );
		
// 		psCodeLine->QStringList_args.at ( eFrstArg ) = QString_arg0;
// 		psCodeLine->QStringList_args.at ( eScndArg ) = QString_arg1;
		
		// Check for register
		if ( ! this->checkArgRegSubst ( QString_arg0 ) )
		{
			this->msgEmit ( eMsgType_argExpReg, psCodeLine );
			return FALSE;
		}
		
		// Check for register
		if ( ! this->checkArgRegSubst ( QString_arg1 ) )
		{
			this->msgEmit ( eMsgType_argExpReg, psCodeLine );
			return FALSE;
		}

		return TRUE;
	}
	else
	{
		if ( ! this->checkBranchCondition ( QString_arg0 ) )
		{
			this->msgEmit ( eMsgType_argExpBranchCond, psCodeLine );
			return FALSE;
		}
		
		// Check for label
		if ( this->checkArgRef ( QString_arg1 ) )
			return TRUE;

		// Check for number and constant
		else if ( this->checkArgNumberConst ( QString_arg1, NULL, ( this->sCfg.i_memBankSize - 1 ) ) )
			return TRUE;
		
		this->msgEmit ( eMsgType_argExpAddr, psCodeLine );
		return FALSE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */


bool PicPblzeAsmParser::compileCmd_R ( sCodeLine_t * psCodeLine )
{
	//********************************************************************************************************************
	//* Check argument count
	//********************************************************************************************************************
	if ( psCodeLine->QStringList_args.count() != 1 )
	{
		this->msgEmit ( eMsgType_argCnt, psCodeLine );
		return FALSE;
	}

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	if ( this->checkArgRegSubst ( psCodeLine->QStringList_args.at ( eFrstArg ) ) )
	{
		return TRUE;
	}

	this->msgEmit ( eMsgType_argExpReg, psCodeLine );
	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::compileCmd_Out( sCodeLine_t * psCodeLine )
{
	//********************************************************************************************************************
	//* Check argument count
	//********************************************************************************************************************
	if ( psCodeLine->QStringList_args.count() != 2 )
	{
		this->msgEmit ( eMsgType_argCnt, psCodeLine );
		return FALSE;
	}

	// Check first argument for register 
	if ( this->checkArgRegSubst ( psCodeLine->QStringList_args.at ( eFrstArg ) ) )
	{
		// Check second argument for register
		if ( this->checkArgRegSubst ( psCodeLine->QStringList_args.at ( eScndArg ) ) )
			return TRUE;

		// Check second argument for number and constant
		else if ( this->checkArgNumberConst ( psCodeLine->QStringList_args.at ( eScndArg ) ) )
			return TRUE;

		// Check second argument for register mapped port
		else if ( this->checkArgAddrByReg ( psCodeLine->QStringList_args.at ( eScndArg ) ) )
			return TRUE;

		this->msgEmit ( eMsgType_argExpRegNumber, psCodeLine );
	}
	else
	{
		if ( this->sCfg.ePicDerivate != PicPblzeSet::ePblze6 )
		{
			this->msgEmit ( eMsgType_argExpReg, psCodeLine );
			return FALSE;
		}
		
		// Check first argument for number and constant
		if ( ! this->checkArgNumberConst ( psCodeLine->QStringList_args.at ( eFrstArg ) ) )
			return FALSE;
		
		// Check second argument for number and constant
		if ( this->checkArgNumberConst ( psCodeLine->QStringList_args.at ( eScndArg ), NULL, 0xF ) )
			return TRUE;

		this->msgEmit ( eMsgType_argExpPort, psCodeLine );
	}
	
	return FALSE;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Checking arguments
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::checkArgNumber ( QString QString_arg, int * pi_argDecimal, int i_maximum )
{
	//********************************************************************************************************************
	//* Check for hex 0x00
	//********************************************************************************************************************
	if ( QString_arg.contains ( QRegExp ( "^0x[0-9a-fA-F]*$" ) ) )
	{
		int i_argDecimal = QString_arg.toInt ( 0, 16 );

		if ( pi_argDecimal )
			*pi_argDecimal = i_argDecimal;

		if ( i_argDecimal <= i_maximum )
			return TRUE;
	}

	//********************************************************************************************************************
	//* Check for hex $00
	//********************************************************************************************************************
	else if ( QString_arg.contains ( QRegExp ( "^\\$[0-9a-fA-F]*$" ) ) )
	{
		QString_arg.remove ( 0, 1 );

		int i_argDecimal = QString_arg.toInt ( 0, 16 );

		if ( pi_argDecimal )
			*pi_argDecimal = i_argDecimal;

		if ( i_argDecimal <= i_maximum )
			return TRUE;
	}

	//********************************************************************************************************************
	//* Check for decimal
	//********************************************************************************************************************
	else if ( QString_arg.contains ( QRegExp ( "^[0-9]*$" ) ) )
	{
		int i_argDecimal = QString_arg.toInt ();

		if ( pi_argDecimal )
			*pi_argDecimal = i_argDecimal;

		if ( i_argDecimal <= i_maximum )
			return TRUE;
	}

	//********************************************************************************************************************
	//* Check for octal
	//********************************************************************************************************************
	else if ( QString_arg.contains ( QRegExp ( "^\\\\[0-9]*$" ) ) )
	{
		QString_arg.remove ( 0, 1 );

		int i_argDecimal = QString_arg.toInt ( 0, 8 );

		if ( pi_argDecimal )
			*pi_argDecimal = i_argDecimal;

		if ( i_argDecimal <= i_maximum )
			return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::checkArgNumberConst ( QString QString_arg, int * pi_argDecimal, int i_maximum )
{
	//********************************************************************************************************************
	//* Check for constant
	//********************************************************************************************************************
	if ( QMap_constants.contains ( QString_arg ) )
	{
		int i_argDecimal = QMap_constants [ QString_arg ];

		if ( pi_argDecimal )
		{
			*pi_argDecimal = i_argDecimal;
		}

		if ( i_argDecimal <= i_maximum )
		{
			return TRUE;
		}
	}

	//********************************************************************************************************************
	//* Check for number
	//********************************************************************************************************************
	else if ( this->checkArgNumber ( QString_arg, pi_argDecimal, i_maximum ) )
	{
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::checkArgReg ( QString QString_arg, QString * pQString_reg )
{
	QRegExp QRegExp_reg;

	switch ( this->sCfg.ePicDerivate )
	{
		case PicPblzeSet::ePblzeCpld:
			QRegExp_reg = QRegExp ( "^[sS][0-7]$" );
			break;

		case PicPblzeSet::ePblze:
			QRegExp_reg = QRegExp ( "^[sS][0-9a-fA-F]$" );
			break;

		case PicPblzeSet::ePblzeII:
			QRegExp_reg = QRegExp ( "^[sS][0-9a-fA-F][0-9a-fA-F]$" );
			break;

		case PicPblzeSet::ePblze3:
			QRegExp_reg = QRegExp ( "^[sS][0-9a-fA-F]$" );
			break;
			
		case PicPblzeSet::ePblze6:
			QRegExp_reg = QRegExp ( "^[sS][0-9a-fA-F]$" );
			break;
			
		default:
			this->msgEmit ( eMsgType_picUnsupported );
			return FALSE;
	}

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	if ( QString_arg.contains ( QRegExp_reg ) )
	{
		if ( pQString_reg )
		{
			*pQString_reg = QString_arg.toUpper ();

			pQString_reg->replace ( 0, 1, QChar ( 's' ) );
		}
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::checkArgRegSubst ( QString QString_arg, QString * pQString_reg )
{
	//********************************************************************************************************************
	//* Check for register substitution
	//********************************************************************************************************************
	if ( QMap_regSubst.contains ( QString_arg ) )
	{
		if ( pQString_reg )
		{
			*pQString_reg = QMap_regSubst [ QString_arg ];
		}
		return TRUE;
	}

	//********************************************************************************************************************
	//* Check for register
	//********************************************************************************************************************
	else if ( this->checkArgReg ( QString_arg, pQString_reg ) )
	{
		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::checkArgRef ( QString QString_arg, sCodeLine_t ** ppsCodeLine )
{
	//********************************************************************************************************************
	//* Check for label
	//********************************************************************************************************************
	if ( QMap_refs.contains ( QString_arg ) )
	{
		if ( ppsCodeLine )
			*ppsCodeLine = QMap_refs [ QString_arg ];

		return TRUE;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::checkArgAddrByReg ( QString QString_arg, QString * pQString_reg, QString * pQString_regSubst )
{
	//********************************************************************************************************************
	//* Check for register mapped port
	//********************************************************************************************************************
	if ( ! QString_arg.contains ( QRegExp ( "(\\w)" ) ) )
		return FALSE;

	//********************************************************************************************************************
	//* Remove brackets ( )
	//********************************************************************************************************************
	QString_arg = QString_arg.remove ( 0, 1 );
	QString_arg = QString_arg.remove ( QString_arg.length() - 1, 1 );

	//********************************************************************************************************************
	//* Check for register substitution
	//********************************************************************************************************************
	if ( ! this->checkArgRegSubst ( QString_arg, pQString_reg ) )
		return FALSE;

	if ( pQString_regSubst )
		*pQString_regSubst = QString_arg;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::checkBranchCondition ( QString QString_arg )
{
	QString_arg = QString_arg.toUpper ();

	if ( ! QString_arg.contains ( QRegExp ( "\\b(C|NC|Z|NZ)\\b" ) ) )
	{
		return FALSE;
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Memory organization
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::memOrganize ( void )
{
	if ( ! this->memDetectRanges () )
		return FALSE;
	
	if ( ! this->memChkCalls () )
		return FALSE;
	
	if ( ! this->memSetAddresses () )
		return FALSE;
	
// 	this->memDbgCodeBase ();
	
	if ( ! this->memMap () )
		return FALSE;
	
// 	this->memDbgMap ();
	
	if ( ! this->memMapChk () )
		return FALSE;
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::memDetectRanges ( void )
{
	//********************************************************************************************************************
	//* Preset parameter
	//********************************************************************************************************************
	this->sMem.sMemRangeShared.psCodeLine_start	= NULL;
	this->sMem.sMemRangeBank0.psCodeLine_start	= NULL;
	this->sMem.sMemRangeBank1.psCodeLine_start	= NULL;
	this->sMem.sMemRangeBank2.psCodeLine_start	= NULL;
	this->sMem.sMemRangeBank3.psCodeLine_start	= NULL;
	
	//********************************************************************************************************************
	//* Parse code base for memory flags and get memory range sizes
	//********************************************************************************************************************
	eMFlag_t eMFlag_cur = eMFlag_unset;
	
	sCodeLine_t * psCodeLine = this->psCodeLine_start;
	
	while ( psCodeLine )
	{
		if ( psCodeLine->eLineType == eLineType_dirMflag )
		{
			switch ( psCodeLine->eMFlag )
			{
				case eMFlag_shared:

					// Check if flag still used
					if ( this->sMem.sMemRangeShared.psCodeLine_start )
					{
						this->msgEmit ( eMsgType_memRangeDuplicate, psCodeLine );
						return FALSE;
					}
					
					this->sMem.sMemRangeShared.psCodeLine_start = psCodeLine;
					
					eMFlag_cur = psCodeLine->eMFlag;
					
					break;
					
				case eMFlag_bank0:

					// Check if flag still used
					if ( this->sMem.sMemRangeBank0.psCodeLine_start )
					{
						this->msgEmit ( eMsgType_memRangeCntExceeded, psCodeLine );
						return FALSE;
					}
					
					this->sMem.sMemRangeBank0.psCodeLine_start = psCodeLine;
					
					eMFlag_cur = psCodeLine->eMFlag;
					
					break;
					
				case eMFlag_bank1:

					// Check if flag still used
					if ( this->sMem.sMemRangeBank1.psCodeLine_start )
					{
						this->msgEmit ( eMsgType_memRangeDuplicate, psCodeLine );
						return FALSE;
					}
					
					this->sMem.sMemRangeBank1.psCodeLine_start = psCodeLine;
					
					// Check if usage allowed by bankCount value
					if ( this->sCfg.i_memBankCount < 2 )
					{
						this->msgEmit ( eMsgType_memRangeCntExceeded, psCodeLine );
						return FALSE;
					}
					
					eMFlag_cur = psCodeLine->eMFlag;
					
					break;
					
				case eMFlag_bank2:

					// Check if flag still used
					if ( this->sMem.sMemRangeBank2.psCodeLine_start )
					{
						this->msgEmit ( eMsgType_memRangeDuplicate, psCodeLine );
						return FALSE;
					}
					
					this->sMem.sMemRangeBank2.psCodeLine_start = psCodeLine;
					
					// Check if usage allowed by bankCount value
					if ( this->sCfg.i_memBankCount < 3 )
					{
						this->msgEmit ( eMsgType_memRangeCntExceeded, psCodeLine );
						return FALSE;
					}
					
					eMFlag_cur = psCodeLine->eMFlag;
					
					break;
					
				case eMFlag_bank3:

					if ( this->sMem.sMemRangeBank3.psCodeLine_start )
					{
						this->msgEmit ( eMsgType_memRangeDuplicate, psCodeLine );
						return FALSE;
					}
					
					this->sMem.sMemRangeBank3.psCodeLine_start = psCodeLine;
					
					// Check if usage allowed by bankCount value
					if ( this->sCfg.i_memBankCount < 4 )
					{
						this->msgEmit ( eMsgType_memRangeCntExceeded, psCodeLine );
						return FALSE;
					}
					
					eMFlag_cur = psCodeLine->eMFlag;
					
					break;
			}
		}
		
		psCodeLine->eMFlag = eMFlag_cur;

		psCodeLine = psCodeLine->psCodeLine_next;
	}

	//********************************************************************************************************************
	//* Handle unset memory range
	//********************************************************************************************************************

	// Check for unset memory range
	if ( this->sMem.sMemRangeShared.psCodeLine_start || 
	     this->sMem.sMemRangeBank0.psCodeLine_start  || 
	     this->sMem.sMemRangeBank1.psCodeLine_start  || 
	     this->sMem.sMemRangeBank2.psCodeLine_start  || 
	     this->sMem.sMemRangeBank3.psCodeLine_start )
	{
		psCodeLine = this->psCodeLine_start;
		
		while ( psCodeLine )
		{
			if ( ( psCodeLine->eLineType > eLineType_cmd ) && ( psCodeLine->eMFlag == eMFlag_unset ) )
			{
				this->msgEmit ( eMsgType_memOutOfBank, psCodeLine );
				return FALSE;
			}
		
			psCodeLine = psCodeLine->psCodeLine_next;
		}
	}
	
	// If we have only unset memory range -> locate to bank0 range
	else
	{
		psCodeLine = this->psCodeLine_start;
		
		this->sMem.sMemRangeBank0.psCodeLine_start = psCodeLine;
	
		while ( psCodeLine )
		{
			psCodeLine->eMFlag = eMFlag_bank0;

			psCodeLine = psCodeLine->psCodeLine_next;
		}
	}
	
// 	qDebug() << "PicPblzeAsmParser::memDetectRanges: psCodeLine_startShared	= " << this->sMem.sMemRangeShared.psCodeLine_start;
// 	qDebug() << "PicPblzeAsmParser::memDetectRanges: psCodeLine_startBank0	= " << this->sMem.sMemRangeBank0.psCodeLine_start;
// 	qDebug() << "PicPblzeAsmParser::memDetectRanges: psCodeLine_startBank1 	= " << this->sMem.sMemRangeBank1.psCodeLine_start;
// 	qDebug() << "PicPblzeAsmParser::memDetectRanges: psCodeLine_startBank2 	= " << this->sMem.sMemRangeBank2.psCodeLine_start;
// 	qDebug() << "PicPblzeAsmParser::memDetectRanges: psCodeLine_startBank3 	= " << this->sMem.sMemRangeBank3.psCodeLine_start;

	//********************************************************************************************************************
	//* Check memory bank range usage
	//********************************************************************************************************************
	
	if   ( ! this->sMem.sMemRangeBank0.psCodeLine_start )						this->msgEmit ( eMsgType_unusedBank0 );
	if ( ( ! this->sMem.sMemRangeBank1.psCodeLine_start ) &&  ( this->sCfg.i_memBankCount > 1 ) )	this->msgEmit ( eMsgType_unusedBank1 );
	if ( ( ! this->sMem.sMemRangeBank2.psCodeLine_start ) &&  ( this->sCfg.i_memBankCount > 2 ) )	this->msgEmit ( eMsgType_unusedBank2 );
	if ( ( ! this->sMem.sMemRangeBank3.psCodeLine_start ) &&  ( this->sCfg.i_memBankCount > 3 ) )	this->msgEmit ( eMsgType_unusedBank3 );

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::memChkCalls ( void )
{
	sCodeLine_t * psCodeLine = this->psCodeLine_start;
	
	while ( psCodeLine )
	{
		if ( ( psCodeLine->eLineType == eLineType_cmdCall ) || ( psCodeLine->eLineType == eLineType_cmdJump ) )
		{
			// Continue if shared memory
			if ( psCodeLine->eMFlag == eMFlag_shared )
			{
				psCodeLine = psCodeLine->psCodeLine_next;
				continue;
			}
			
			// Get reference
			QString QString_ref;

			if ( psCodeLine->QStringList_args.count() > 1 )
				QString_ref = psCodeLine->QStringList_args.at ( 1 );

			else
				QString_ref = psCodeLine->QStringList_args.at ( 0 );

			// Check if reference is register content: destination can not be tested here
			if ( QString_ref.contains ( "(" ) || QString_ref.contains ( ")" ) )
			{
				psCodeLine = psCodeLine->psCodeLine_next;
				continue;
			}
			
			// Check destination code line location
			if ( ! QMap_refs.contains ( QString_ref ) )
			{
				this->msgEmit( eMsgType_argExpAddr, psCodeLine );
				return FALSE;
			}
			
			sCodeLine_t * psCodeLine_dst = QMap_refs.value ( QString_ref );
			
			// Continue if shared memory
			if ( psCodeLine_dst->eMFlag == eMFlag_shared )
			{
				psCodeLine = psCodeLine->psCodeLine_next;
				continue;
			}
			
			// Continue if same memory bank
			if ( psCodeLine_dst->eMFlag == psCodeLine->eMFlag )
			{
				psCodeLine = psCodeLine->psCodeLine_next;
				continue;
			}
			
			this->msgEmit ( eMsgType_memExpIntermedCall,  psCodeLine );
			return FALSE;
		}

		psCodeLine = psCodeLine->psCodeLine_next;
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::memSetAddresses ( void )
{
	//********************************************************************************************************************
	//* Preset parameter
	//********************************************************************************************************************
	this->sMem.sMemRangeShared.i_addrStart	= -1;
	this->sMem.sMemRangeShared.i_addrStop	= -1;
	
	this->sMem.sMemRangeBank0.i_addrStart	= -1;
	this->sMem.sMemRangeBank0.i_addrStop	= -1;
	this->sMem.sMemRangeBank1.i_addrStart	= -1;
	this->sMem.sMemRangeBank1.i_addrStop	= -1;
	this->sMem.sMemRangeBank2.i_addrStart	= -1;
	this->sMem.sMemRangeBank2.i_addrStop	= -1;
	this->sMem.sMemRangeBank3.i_addrStart	= -1;
	this->sMem.sMemRangeBank3.i_addrStop	= -1;

	int i_addrStart = 0;
	int i_addrStop  = 0;

	//********************************************************************************************************************
	//* Set shared range
	//********************************************************************************************************************
	if ( this->sMem.sMemRangeShared.psCodeLine_start )
	{
		i_addrStart = 0;
		i_addrStop  = this->sCfg.i_memBankSize;
			
		if ( this->sCfg.eMemSharedLoc == PicPblzeSet::eMemSharedLocHighAddr )
		{
			if ( ! this->memSetAddressRangeDown ( eMFlag_shared, this->sMem.sMemRangeShared.psCodeLine_start, & i_addrStart, i_addrStop ) )
				return FALSE;
		}
		else
		{
			if ( ! this->memSetAddressRangeUp ( eMFlag_shared, this->sMem.sMemRangeShared.psCodeLine_start, i_addrStart, & i_addrStop ) )
				return FALSE;
		}
			
		this->sMem.sMemRangeShared.i_addrStart = i_addrStart;
		this->sMem.sMemRangeShared.i_addrStop  = i_addrStop;
		
		qDebug() << "PicPblzeAsmParser::memSetAddresses: this->sMem.sMemRangeShared.i_addrStart	= " << this->sMem.sMemRangeShared.i_addrStart;
		qDebug() << "PicPblzeAsmParser::memSetAddresses: this->sMem.sMemRangeShared.i_addrStop	= " << this->sMem.sMemRangeShared.i_addrStop;
	}
	//********************************************************************************************************************
	//* Set bank0 range
	//********************************************************************************************************************
	if ( this->sMem.sMemRangeBank0.psCodeLine_start )
	{
		if ( this->sMem.sMemRangeShared.psCodeLine_start )
		{
			if ( this->sCfg.eMemSharedLoc == PicPblzeSet::eMemSharedLocHighAddr )
			{
				i_addrStart = 0;
				i_addrStop  = this->sMem.sMemRangeShared.i_addrStart;
			}
			else
			{
				i_addrStart = this->sMem.sMemRangeShared.i_addrStop;
				i_addrStop  = this->sCfg.i_memBankSize;
			}
		}
		else
		{
			i_addrStart = 0;
			i_addrStop  = this->sCfg.i_memBankSize;
		}
		
		if ( ! this->memSetAddressRangeUp ( eMFlag_bank0, this->sMem.sMemRangeBank0.psCodeLine_start, i_addrStart, & i_addrStop ) )
			return FALSE;
		
		this->sMem.sMemRangeBank0.i_addrStart = i_addrStart;
		this->sMem.sMemRangeBank0.i_addrStop  = i_addrStop;
		
		qDebug() << "PicPblzeAsmParser::memSetAddresses: this->sMem.sMemRangeBank0.i_addrStart	= " << this->sMem.sMemRangeBank0.i_addrStart;
		qDebug() << "PicPblzeAsmParser::memSetAddresses: this->sMem.sMemRangeBank0.i_addrStop	= " << this->sMem.sMemRangeBank0.i_addrStop;
	}
	
	//********************************************************************************************************************
	//* Set bank1 range
	//********************************************************************************************************************
	if ( this->sMem.sMemRangeBank1.psCodeLine_start )
	{
		if ( this->sMem.sMemRangeShared.psCodeLine_start )
		{
			if ( this->sCfg.eMemSharedLoc == PicPblzeSet::eMemSharedLocHighAddr )
			{
				i_addrStart = 0;
				i_addrStop  = this->sMem.sMemRangeShared.i_addrStart;
			}
			else
			{
				i_addrStart = this->sMem.sMemRangeShared.i_addrStop;
				i_addrStop  = this->sCfg.i_memBankSize;
			}
		}
		else
		{
			i_addrStart = 0;
			i_addrStop  = this->sCfg.i_memBankSize;
		}
		
		if ( ! this->memSetAddressRangeUp ( eMFlag_bank1, this->sMem.sMemRangeBank1.psCodeLine_start, i_addrStart, & i_addrStop ) )
			return FALSE;
		
		this->sMem.sMemRangeBank1.i_addrStart = i_addrStart;
		this->sMem.sMemRangeBank1.i_addrStop  = i_addrStop;
		
		qDebug() << "PicPblzeAsmParser::memSetAddresses: this->sMem.sMemRangeBank1.i_addrStart	= " << this->sMem.sMemRangeBank1.i_addrStart;
		qDebug() << "PicPblzeAsmParser::memSetAddresses: this->sMem.sMemRangeBank1.i_addrStop	= " << this->sMem.sMemRangeBank1.i_addrStop;
	}
	
	//********************************************************************************************************************
	//* Set bank2 range
	//********************************************************************************************************************
	if ( this->sMem.sMemRangeBank2.psCodeLine_start )
	{
		if ( this->sMem.sMemRangeShared.psCodeLine_start )
		{
			if ( this->sCfg.eMemSharedLoc == PicPblzeSet::eMemSharedLocHighAddr )
			{
				i_addrStart = 0;
				i_addrStop  = this->sMem.sMemRangeShared.i_addrStart;
			}
			else
			{
				i_addrStart = this->sMem.sMemRangeShared.i_addrStop;
				i_addrStop  = this->sCfg.i_memBankSize;
			}
		}
		else
		{
			i_addrStart = 0;
			i_addrStop  = this->sCfg.i_memBankSize;
		}
		
		if ( ! this->memSetAddressRangeUp ( eMFlag_bank2, this->sMem.sMemRangeBank2.psCodeLine_start, i_addrStart, & i_addrStop ) )
			return FALSE;
		
		this->sMem.sMemRangeBank2.i_addrStart = i_addrStart;
		this->sMem.sMemRangeBank2.i_addrStop  = i_addrStop;
		
		qDebug() << "PicPblzeAsmParser::memSetAddresses: this->sMem.sMemRangeBank2.i_addrStart	= " << this->sMem.sMemRangeBank2.i_addrStart;
		qDebug() << "PicPblzeAsmParser::memSetAddresses: this->sMem.sMemRangeBank2.i_addrStop	= " << this->sMem.sMemRangeBank2.i_addrStop;
	}
	
	//********************************************************************************************************************
	//* Set bank3 range
	//********************************************************************************************************************
	if ( this->sMem.sMemRangeBank3.psCodeLine_start )
	{
		if ( this->sMem.sMemRangeShared.psCodeLine_start )
		{
			if ( this->sCfg.eMemSharedLoc == PicPblzeSet::eMemSharedLocHighAddr )
			{
				i_addrStart = 0;
				i_addrStop  = this->sMem.sMemRangeShared.i_addrStart;
			}
			else
			{
				i_addrStart = this->sMem.sMemRangeShared.i_addrStop;
				i_addrStop  = this->sCfg.i_memBankSize;
			}
		}
		else
		{
			i_addrStart = 0;
			i_addrStop  = this->sCfg.i_memBankSize;
		}
		
		if ( ! this->memSetAddressRangeUp ( eMFlag_bank3, this->sMem.sMemRangeBank3.psCodeLine_start, i_addrStart, & i_addrStop ) )
			return FALSE;
		
		this->sMem.sMemRangeBank3.i_addrStart = i_addrStart;
		this->sMem.sMemRangeBank3.i_addrStop  = i_addrStop;
		
		qDebug() << "PicPblzeAsmParser::memSetAddresses: this->sMem.sMemRangeBank3.i_addrStart	= " << this->sMem.sMemRangeBank3.i_addrStart;
		qDebug() << "PicPblzeAsmParser::memSetAddresses: this->sMem.sMemRangeBank3.i_addrStop	= " << this->sMem.sMemRangeBank3.i_addrStop;
	}
	
	//********************************************************************************************************************
	//* Set reference addresses
	//********************************************************************************************************************
	{
		int i_addrRun;
		
		sCodeLine_t * psCodeLine = this->psCodeLine_stop;
	
		while ( psCodeLine )
		{
			if ( psCodeLine->i_addr != -1 )
				i_addrRun = psCodeLine->i_addr;

			else
				psCodeLine->i_addr = i_addrRun;

			psCodeLine = psCodeLine->psCodeLine_prev;
		}
	}
	
	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::memSetAddressRangeDown ( eMFlag_t eMFlag, sCodeLine_t * psCodeLine_start, int * pi_addrStart, int i_addrStop )
{
	sCodeLine_t * psCodeLine;
	sCodeLine_t * psCodeLine_stop;
	
	int i_addrRun = *pi_addrStart;
	
	bool b_addrFixedEn = FALSE;
	
	//********************************************************************************************************************
	//* Set fixed address range
	//********************************************************************************************************************
	psCodeLine = psCodeLine_start;
	
	while ( psCodeLine )
	{
		if ( psCodeLine->eMFlag != eMFlag )
			break;

		// Check for address correction directive
		if ( psCodeLine->eLineType == eLineType_dirOrg )
		{
			// Check for overlapping address range
			if ( psCodeLine->i_addr < i_addrRun )
			{
				this->msgEmit ( eMsgType_memAddrConflict, psCodeLine );
				return FALSE;
			}

			b_addrFixedEn = TRUE;
			i_addrRun     = psCodeLine->i_addr;
		}

		// Check for command
		if ( psCodeLine->eLineType > eLineType_cmd )
		{
			// Check if max memory size exceeded
			if ( i_addrRun >= i_addrStop )
			{
				this->msgEmit ( eMsgType_memOutOfRange, psCodeLine );
				return FALSE;
			}
		
			if ( b_addrFixedEn )
				psCodeLine->i_addr = i_addrRun;
			
			++i_addrRun;
		}
	
		psCodeLine_stop = psCodeLine;
	
		psCodeLine = psCodeLine->psCodeLine_next;
	}
	
	//********************************************************************************************************************
	//* Set dynamic address range
	//********************************************************************************************************************
	i_addrRun = i_addrStop;
	
	while ( psCodeLine )
	{
		if ( psCodeLine->eLineType > eLineType_cmd )
		{
			if ( psCodeLine->i_addr != -1 )
				i_addrRun = psCodeLine->i_addr;
			else
				psCodeLine->i_addr = --i_addrRun;
		}
	
		psCodeLine = psCodeLine->psCodeLine_prev;
	}
	
	//********************************************************************************************************************
	//* Set reference addresses
	//********************************************************************************************************************
	psCodeLine = psCodeLine_stop;

	while ( psCodeLine )
	{
		if ( psCodeLine->i_addr != -1 )
			i_addrRun = psCodeLine->i_addr;
		else
			psCodeLine->i_addr = i_addrRun;
	
		psCodeLine = psCodeLine->psCodeLine_prev;
	}

	*pi_addrStart = i_addrRun;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::memSetAddressRangeUp ( eMFlag_t eMFlag, sCodeLine_t * psCodeLine_start, int i_addrStart, int * pi_addrStop )
{
	sCodeLine_t * psCodeLine = psCodeLine_start;
	
	int i_addrRun = i_addrStart;
	
	//********************************************************************************************************************
	//* Set dynamic and fixed address range
	//********************************************************************************************************************
	while ( psCodeLine )
	{
		if ( psCodeLine->eMFlag != eMFlag )
			break;

		// Check for address correction directive
		if ( psCodeLine->eLineType == eLineType_dirOrg )
		{
			// Check for overlapping address range
			if ( psCodeLine->i_addr < i_addrRun )
			{
				this->msgEmit ( eMsgType_memAddrConflict, psCodeLine );
				return FALSE;
			}

			i_addrRun = psCodeLine->i_addr;
		}
		
		// Check for command
		if ( psCodeLine->eLineType > eLineType_cmd )
		{
			// Check if max memory size exceeded
			if ( i_addrRun >= *pi_addrStop )
			{
				this->msgEmit ( eMsgType_memOutOfRange, psCodeLine );
				return FALSE;
			}

			psCodeLine->i_addr = i_addrRun++;
		}
		
		psCodeLine_stop = psCodeLine;
	
		psCodeLine = psCodeLine->psCodeLine_next;
	}

	*pi_addrStop = i_addrRun;

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::memMap ( void )
{
// 	sCodeLine_t * psCodeLine;
// 
	// Calculate memory size
	this->sMem.i_memSize = this->sCfg.i_memBankCount * this->sCfg.i_memBankSize;

	// Allocate code base memory map
	if ( ! this->sMem.apsCodeLine_memMap )
		this->sMem.apsCodeLine_memMap = new sCodeLine_t * [ this->sMem.i_memSize ];

	// Preset memMap with NULL
	memset ( this->sMem.apsCodeLine_memMap, NULL, this->sMem.i_memSize * sizeof ( sCodeLine_t * ) );

	// Preset instruction count
	memset ( & this->sInstCount, NULL, sizeof ( sInstCount_t ) );

	// Setup memory map for bank 0
	if ( this->sCfg.i_memBankCount >= 1 )
	{
		sCodeLine_t ** ppsCodeLine_bankStart = this->sMem.apsCodeLine_memMap;
		
		// Map shared range
		if ( ! this->memMapRange ( this->sMem.sMemRangeShared.psCodeLine_start, ppsCodeLine_bankStart, & this->sInstCount.i_bank0 ) )
			return FALSE;
		
		this->sInstCount.i_shared = this->sInstCount.i_bank0;
		
		// Map bank0 range
		if ( ! this->memMapRange ( this->sMem.sMemRangeBank0.psCodeLine_start, ppsCodeLine_bankStart, & this->sInstCount.i_bank0 ) )
			return FALSE;
	}

	// Setup memory map for bank 1
	if ( this->sCfg.i_memBankCount >= 2 )
	{
		sCodeLine_t ** ppsCodeLine_bankStart = & this->sMem.apsCodeLine_memMap[ this->sCfg.i_memBankSize ];
		
		// Map shared range
		if ( ! this->memMapRange ( this->sMem.sMemRangeShared.psCodeLine_start, ppsCodeLine_bankStart, & this->sInstCount.i_bank1 ) )
			return FALSE;
		
		// Map bank1 range
		if ( ! this->memMapRange ( this->sMem.sMemRangeBank1.psCodeLine_start, ppsCodeLine_bankStart, & this->sInstCount.i_bank1 ) )
			return FALSE;
	}

	// Setup memory map for bank 2
	if ( this->sCfg.i_memBankCount >= 3 )
	{
		sCodeLine_t ** ppsCodeLine_bankStart = & this->sMem.apsCodeLine_memMap[ 2 * this->sCfg.i_memBankSize ];
		
		// Map shared range
		if ( ! this->memMapRange ( this->sMem.sMemRangeShared.psCodeLine_start, ppsCodeLine_bankStart, & this->sInstCount.i_bank2 ) )
			return FALSE;
		
		// Map bank2 range
		if ( ! this->memMapRange ( this->sMem.sMemRangeBank2.psCodeLine_start, ppsCodeLine_bankStart, & this->sInstCount.i_bank2 ) )
			return FALSE;
	}

	// Setup memory map for bank 3
	if ( this->sCfg.i_memBankCount >= 4 )
	{
		sCodeLine_t ** ppsCodeLine_bankStart = & this->sMem.apsCodeLine_memMap[ 3 * this->sCfg.i_memBankSize ];
		
		// Map shared range
		if ( ! this->memMapRange ( this->sMem.sMemRangeShared.psCodeLine_start, ppsCodeLine_bankStart, & this->sInstCount.i_bank3 ) )
			return FALSE;
		
		// Map bank3 range
		if ( ! this->memMapRange ( this->sMem.sMemRangeBank3.psCodeLine_start, ppsCodeLine_bankStart, & this->sInstCount.i_bank3 ) )
			return FALSE;
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::memMapRange ( sCodeLine_t * psCodeLine_start, sCodeLine_t ** apsCodeLine, int * pi_memCntr )
{
	int i_addrStop  = this->sCfg.i_memBankSize;

	sCodeLine_t * psCodeLine = psCodeLine_start;

	while ( psCodeLine )
	{
		if ( psCodeLine->eLineType > eLineType_cmd )
		{
			// Check if end of range reached
			if ( psCodeLine->eMFlag != psCodeLine_start->eMFlag )
				break;

			// Check if memory map range is being exceeded
			if ( psCodeLine->i_addr >= this->sCfg.i_memBankSize )
			{
				this->msgEmit ( eMsgType_memOverflow );
				return FALSE;
			}
			
			// Map code line into memory map
			if ( psCodeLine->eLineType > eLineType_cmd )
			{
				apsCodeLine[ psCodeLine->i_addr ] = psCodeLine;
				*pi_memCntr += 1;
			}
		}

		psCodeLine = psCodeLine->psCodeLine_next;
	}

	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::memMapChk ( void )
{
	int i_intVector = this->sCfg.i_intVector;
	
	// Check interrupt vector size
	if ( i_intVector >= this->sCfg.i_memBankSize )
	{
		this->msgEmit ( eMsgType_intVectorOor );
		return FALSE;
	}
	
	// Check bank0 for interrupt vector valid
	if ( ( i_intVector < this->sMem.i_memSize ) && ( ! this->sMem.apsCodeLine_memMap[ i_intVector ] ) )
	{
		this->msgEmit ( eMsgType_unusedIntVectorBank0 );
	}
	
	// Check bank1 for interrupt vector valid
	i_intVector += this->sCfg.i_memBankSize;
	
	if ( ( i_intVector < this->sMem.i_memSize ) &&  ( ! this->sMem.apsCodeLine_memMap[ i_intVector ] ) )
	{
		this->msgEmit ( eMsgType_unusedIntVectorBank1 );
	}
	
	// Check bank2 for interrupt vector valid
	i_intVector += this->sCfg.i_memBankSize;
	
	if ( ( i_intVector < this->sMem.i_memSize ) &&  ( ! this->sMem.apsCodeLine_memMap[ i_intVector ] ) )
	{
		this->msgEmit ( eMsgType_unusedIntVectorBank2 );
	}
	
	// Check bank3 for interrupt vector valid
	i_intVector += this->sCfg.i_memBankSize;
	
	if ( ( i_intVector < this->sMem.i_memSize ) &&  ( ! this->sMem.apsCodeLine_memMap[ i_intVector ] ) )
	{
		this->msgEmit ( eMsgType_unusedIntVectorBank3 );
	}
	
	
	
/*	{
		sCodeLine_t * psCodeLine = psCodeLine_start;

		while ( psCodeLine )
		
	for ( int i_iterator = 0; i_iterator < this->sMem.i_memSize; ++i_iterator )
	{
		psCodeLine = ;
		
	}*/
		

// this->sMem.apsCodeLine_memMap


	return TRUE;
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeAsmParser::memDbgCodeBase ( void )
{
	sCodeLine_t * psCodeLine = this->psCodeLine_start;

	printf ( "PicPblzeAsmParser::memDbgCodeBase: Print code base\n" );
	
	printf ( "\n\n\nMemType	| Addr	| CMD	| CodeLine\n" );
	
	while ( psCodeLine )
	{
/*		if ( psCodeLine->eLineType > eLineType_cmd )
		{*/
			switch ( psCodeLine->eMFlag )
			{
				case eMFlag_unset:	printf ( "Unset" );	break;
				case eMFlag_shared:	printf ( "Shared" );	break;
				case eMFlag_bank0:	printf ( "Bank0" );	break;
				case eMFlag_bank1:	printf ( "Bank1" );	break;
				case eMFlag_bank2:	printf ( "Bank2" );	break;
				case eMFlag_bank3:	printf ( "Bank3" );	break;
				default:		printf ( "Error" );	break;
			}
	
			printf ( "	| %04d", psCodeLine->i_addr );
			printf ( "	| %s", psCodeLine->QString_cmd.toUtf8().data() );
			printf ( "	| %s", psCodeLine->QString_line.toUtf8().data() );
			
// 			printf ( "\n" );
// 		}
	
		psCodeLine = psCodeLine->psCodeLine_next;
	}
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeAsmParser::memDbgMap ( void )
{
	sCodeLine_t * psCodeLine = this->psCodeLine_start;

	printf ( "PicPblzeAsmParser::memDbgMap Print memMap\n" );
	
	printf ( "\n\n\nMemType	| Addr	| CodeLine\n" );
	
	for ( int i_iterator = 0; i_iterator < this->sMem.i_memSize; ++i_iterator )
	{
		psCodeLine = this->sMem.apsCodeLine_memMap[ i_iterator ];
		
		if ( ! psCodeLine )
			continue;
		
		switch ( psCodeLine->eMFlag )
		{
			case eMFlag_unset:	printf ( "Unset" );	break;
			case eMFlag_shared:	printf ( "Shared" );	break;
			case eMFlag_bank0:	printf ( "Bank0" );	break;
			case eMFlag_bank1:	printf ( "Bank1" );	break;
			case eMFlag_bank2:	printf ( "Bank2" );	break;
			case eMFlag_bank3:	printf ( "Bank3" );	break;
			default:		printf ( "Error" );	break;
		}

		printf ( "	| %04d", i_iterator );
		printf ( "	| %s", psCodeLine->QString_line.toUtf8().data() );

// 		printf ( "\n" );
	}
}

/**
 *****************************************************************************************************************************
 */

PicPblzeAsmParser::sInstCount_t * PicPblzeAsmParser::getInstCount ( void )
{
	return & this->sInstCount;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Message handling
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

QString PicPblzeAsmParser::msgGetFilePath ( int i_fileNumber )
{
	if ( ( i_fileNumber >= 0 ) && ( this->sCfg.QStringList_filePath.size() >= i_fileNumber ) )
		return this->sCfg.QStringList_filePath.at ( i_fileNumber );

	return QString();
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeAsmParser::msgEmit ( eMsgType_t eMsgType )
{
	Msg * pMsg = new Msg;
	
	this->msgEmit ( pMsg, eMsgType );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeAsmParser::msgEmit ( eMsgType_t eMsgType, QString QString_filePath )
{
	Msg * pMsg = new Msg;
	
	pMsg->QUrl_srcUrl.setScheme( "file" );
	pMsg->QUrl_srcUrl.setPath ( QString_filePath );
	
	this->msgEmit ( pMsg, eMsgType );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeAsmParser::msgEmit ( eMsgType_t eMsgType, sCodeLine_t * psCodeLine )
{
	Msg * pMsg = new Msg;
	
	pMsg->QUrl_srcUrl.setScheme( "file" );
	pMsg->QUrl_srcUrl.setPath ( this->msgGetFilePath ( psCodeLine->i_fileNumber ) );
	pMsg->QUrl_srcUrl.setFragment ( QString::number ( psCodeLine->i_lineNumber ) );
	
	this->msgEmit ( pMsg, eMsgType );
}

/**
 *****************************************************************************************************************************
 */

void PicPblzeAsmParser::msgEmit ( Msg * pMsg, eMsgType_t eMsgType )
{
	QString QString_hlpFragment;
	
	// Set message text
	switch ( eMsgType )
	{
		// Ok messages
		case eMsgType_ok:
			
			QString_hlpFragment	= "ok";
			pMsg->eStatus 		= Msg::e_ok;
			pMsg->QString_msg 	= tr ( "Code checked - no errors found" );
			break;

		// Ok messages
		case eMsgType_readingFile:
			
			QString_hlpFragment	= "readingFile";
			pMsg->eStatus 		= Msg::e_ok;
			pMsg->QString_msg 	= tr ( "Reading file..." );
			break;
			
		// Warnings
		case eMsgType_unusedBank0:
			
			QString_hlpFragment	= "unusedBank";
			pMsg->eStatus 		= Msg::e_warning;
			pMsg->QString_msg 	= tr ( "Bank 0 unused" );
			break;

		case eMsgType_unusedBank1:
			
			QString_hlpFragment	= "unusedBank";
			pMsg->eStatus 		= Msg::e_warning;
			pMsg->QString_msg 	= tr ( "Bank 1 unused" );
			break;
			
		case eMsgType_unusedBank2:
			
			QString_hlpFragment	= "unusedBank";
			pMsg->eStatus 		= Msg::e_warning;
			pMsg->QString_msg 	= tr ( "Bank 2 unused" );
			break;
			
		case eMsgType_unusedBank3:
			
			QString_hlpFragment	= "unusedBank";
			pMsg->eStatus 		= Msg::e_warning;
			pMsg->QString_msg 	= tr ( "Bank 3 unused" );
			break;
			
		case eMsgType_unusedIntVectorBank0:
			
			QString_hlpFragment	= "unusedIntVectorBank";
			pMsg->eStatus 		= Msg::e_warning;
			pMsg->QString_msg 	= tr ( "Interrupt vector references unused address in Bank 0" );
			break;
			
		case eMsgType_unusedIntVectorBank1:
			
			QString_hlpFragment	= "unusedIntVectorBank";
			pMsg->eStatus 		= Msg::e_warning;
			pMsg->QString_msg 	= tr ( "Interrupt vector references unused address in Bank 1" );
			break;
			
		case eMsgType_unusedIntVectorBank2:
			
			QString_hlpFragment	= "unusedIntVectorBank";
			pMsg->eStatus 		= Msg::e_warning;
			pMsg->QString_msg 	= tr ( "Interrupt vector references unused address in Bank 2" );
			break;
			
		case eMsgType_unusedIntVectorBank3:
			
			QString_hlpFragment	= "unusedIntVectorBank";
			pMsg->eStatus 		= Msg::e_warning;
			pMsg->QString_msg 	= tr ( "Interrupt vector references unused address in Bank 3" );
			break;
			
		// Error messages
		case eMsgType_err:
			
			QString_hlpFragment	= "err";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Code checked - errors found" );
			break;
			
			
		case eMsgType_fileIO:
			
			QString_hlpFragment	= "fileIO";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "File io error" );
			break;
			
		case eMsgType_ivldCodeLineCnt:
			
			QString_hlpFragment	= "ivldCodeLineCnt";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "No code lines found" );
			break;
			
		case eMsgType_ivldColon:
			
			QString_hlpFragment	= "ivldColon";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Unexpected colon found in line" );
			break;
			
		case eMsgType_ivldSyntax:
			
			QString_hlpFragment	= "ivldSyntax";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Invalid Syntax" );
			break;
			
		case eMsgType_ivldCmd:
			
			QString_hlpFragment	= "ivldCmd";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Unknown command" );
			break;
			
		case eMsgType_argCnt:
			
			QString_hlpFragment	= "argCnt";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Invalid argument count" );
			break;
			
		case eMsgType_ivldArg:
			
			QString_hlpFragment	= "ivldArg";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Invalid argument" );
			break;
			
		case eMsgType_argNoKeyword:
			
			QString_hlpFragment	= "argNoKeyword";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Unexpected keyword" );
			break;
			
		case eMsgType_argNoNumber:
			
			QString_hlpFragment	= "argNoNumber";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Unexpected number" );
			break;
			
		case eMsgType_argNoReg:
			
			QString_hlpFragment	= "argNoReg";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Unexpected register" );
			break;
			
		case eMsgType_argExpBracket:
			
			QString_hlpFragment	= "argExpBracket";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Missing bracket" );
			break;
			
		case eMsgType_argExpNumber:
			
			QString_hlpFragment	= "argExpNumber";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Number expected or number out of range" );
			break;
			
		case eMsgType_argExpReg:
			
			QString_hlpFragment	= "argExpReg";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Register expected" );
			break;
			
		case eMsgType_argExpRegNumber:
			
			QString_hlpFragment	= "argExpRegNumber";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Register or number expected" );
			break;
			
		case eMsgType_argExpPort:
			
			QString_hlpFragment	= "argExpPort";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Port or register-referenced-port expected" );
			break;
			
		case eMsgType_argExpBranchCond:
			
			QString_hlpFragment	= "argExpBranchCond";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Branch condition expected" );
			break;
			
		case eMsgType_argExpAddr:
			
			QString_hlpFragment	= "argExpAddr";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Address expected" );
			break;
			
		case eMsgType_argExpMFLag:
			
			QString_hlpFragment	= "argExpMFLag";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Memory flag expected" );
			break;
			
		case eMsgType_argExpedEnDisable:
			
			QString_hlpFragment	= "argExpedEnDisable";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "ENABLE/DISABLE expected" );
			break;
			
		case eMsgType_argExpedRegBank:
			
			QString_hlpFragment	= "argExpedRegBank";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Register bank expected" );
			break;
			
		case eMsgType_argUsedAsConst:
			
			QString_hlpFragment	= "argUsedAsConst";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Symbol already used as constant symbol" );
			break;
			
		case eMsgType_argUsedAsReg:
			
			QString_hlpFragment	= "argUsedAsReg";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Symbol already used as register symbol" );
			break;
			
		case eMsgType_argRefAlreadyUsed:
			
			QString_hlpFragment	= "argRefAlreadyUsed";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Symbol already used as label" );
			break;
			
		case eMsgType_memRangeDuplicate:
			
			QString_hlpFragment	= "memRangeDuplicate";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Memory range flag already used" );
			break;
			
		case eMsgType_memRangeCntExceeded:
			
			QString_hlpFragment	= "memRangeCntExceeded";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Memory range count exceeded" );
			break;
			
		case eMsgType_memOutOfBank:
			
			QString_hlpFragment	= "memOutOfBank";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Memory outside of shared range and bank range used" );
			break;
			
		case eMsgType_memAddrConflict:
			
			QString_hlpFragment	= "memAddrConflict";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Address conflict" );
			break;
			
		case eMsgType_memOutOfRange:
			
			QString_hlpFragment	= "memOutOfRange";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Memory out of range" );
			break;
			
		case eMsgType_memExpIntermedCall:
			
			QString_hlpFragment	= "memExpIntermedCall";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Expecting intermediate call" );
			break;
			
		case eMsgType_intVectorOor:
			
			QString_hlpFragment	= "ivldIntVector";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Interrupt vector exceeds memory size" );
			break;
			
		case eMsgType_memOverflow:
			
			QString_hlpFragment	= "memOverflow";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Internal error: Memory overflow" );
			break;
			
		case eMsgType_picUnsupported:
			
			QString_hlpFragment	= "picUnsupported";
			pMsg->eStatus 		= Msg::e_error;
			pMsg->QString_msg 	= tr ( "Internal error: Processor not supported" );
			break;

	}

	pMsg->QUrl_hlpUrl = QUrl ( "qthelp://openPICIDE/openPICIDE/openPICIDE/800_processors/XilinxPicoBlaze/800_messages/index.html" );

	pMsg->QUrl_hlpUrl.setFragment ( QString_hlpFragment);
	
	emit message ( pMsg );
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Miscellaneous
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

PicPblzeAsmParser::sCodeLine_t * PicPblzeAsmParser::getPcFromCodeLine ( QString QString_filePath, int i_lineNumber, int * pi_pc )
{
	if ( ! this->sCfg.QStringList_filePath.contains ( QString_filePath ) )
		return NULL;

	int i_fileNumber = this->sCfg.QStringList_filePath.indexOf ( QString_filePath );

	sCodeLine_t * psCodeLine = PicPblzeAsmParser::psCodeLine_start;

	while ( psCodeLine )
	{
		if ( ( psCodeLine->i_fileNumber == i_fileNumber ) && ( psCodeLine->i_lineNumber >= i_lineNumber ) )
		{
			while ( psCodeLine )
			{
				if ( psCodeLine->eLineType > eLineType_cmd )
				{
					if ( pi_pc )
						*pi_pc = psCodeLine->i_addr;
					
					return psCodeLine;
				}
				psCodeLine = psCodeLine->psCodeLine_next;
			}
			return NULL;
		}
		psCodeLine = psCodeLine->psCodeLine_next;
	}
	
	return NULL;
}

/**
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *** Used within simulator
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 *****************************************************************************************************************************
 */

// PicPblzeAsmParser::sCodeLine_t * PicPblzeAsmParser::getPcStart ( void )
// {
// 	sCodeLine_t * psCodeLine = this->psCodeLine_start;
// 
// 	while ( psCodeLine )
// 	{
// 		if ( ! psCodeLine->QString_cmd.isEmpty() )
// 			return psCodeLine;
// 
// 		psCodeLine = psCodeLine->psCodeLine_next;
// 	}
// 
// 	return NULL;
// }

/**
 *****************************************************************************************************************************
 */

PicPblzeAsmParser::sCodeLine_t * PicPblzeAsmParser::getIntPtr ( sCodeLine_t * sCodeLine_pc )
{
	if ( ! sCodeLine_pc )
		sCodeLine_pc = this->psCodeLine_start;
	
// 	sCodeLine_t * psCodeLine = this->psCodeLine_start;

	while ( sCodeLine_pc )
	{
		// Mask relevant bits of address and check for interrupt vector address
		if ( ( sCodeLine_pc->i_addr & 0x3FF ) == 0x3FF )
			return sCodeLine_pc;

		sCodeLine_pc = sCodeLine_pc->psCodeLine_next;
	}

	return NULL;
}

/**
 *****************************************************************************************************************************
 */
int PicPblzeAsmParser::getFileNumber ( QString QString_FilePath )
{
	if ( this->sCfg.QStringList_filePath.contains ( QString_FilePath ) )
		return this->sCfg.QStringList_filePath.indexOf ( QString_FilePath );

	return -1;
}

/**
 *****************************************************************************************************************************
 */

bool PicPblzeAsmParser::getCodeLineByAddr ( int i_addr, sCodeLine_t ** ppsCodeLine )
{
	sCodeLine_t * psCodeLine = this->psCodeLine_start;

	while ( psCodeLine )
	{
		if ( ( psCodeLine->i_addr == i_addr ) && ( psCodeLine->eLineType > eLineType_cmd ) )
		{
			*ppsCodeLine = psCodeLine;
			return TRUE;
		}
		psCodeLine = psCodeLine->psCodeLine_next;
	}

	return FALSE;
}

/**
 *****************************************************************************************************************************
 */

