#!/usr/bin/perl

#########################################################################################################
#  Copyright (C) 2009 by Christoph Fauck                                                                #
#  Christoph Fauck <christoph.fauck@fauck.com>                                                          #
#                                                                                                       #
#  This file is part of openPICIDE.                                                                     #
#                                                                                                       #
#  openPICIDE is free software: you can redistribute it and/or modify it under the terms of the         #
#  GNU General Public License as published by the Free Software Foundation, either version 3 of the     #
#  License, or (at your option) any later version.                                                      #
#                                                                                                       #
#  openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without      #
#  even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       #
#  General Public License for more details.                                                             #
#                                                                                                       #
#  You should have received a copy of the GNU General Public License along with openPICIDE.             #
#  If not, see <http://www.gnu.org/licenses/>.                                                          #
#                                                                                                       #
#########################################################################################################

use Switch;
use File::Basename;
use Term::ReadKey;

renameTags();

sub renameTags
{
	my $argCnt = $#ARGV + 1;

	if ( $argCnt < 3 )
	{
		printf "Aborting:\n";
		printf "	Wrong argument count!!!\n";
		printf "\n";
		printf "Use:\n";
		printf "	renameTags.pl srcPath \"srcTag\" \"dstTag\"\n";
		printf "\n";
		return;
	}

	my $srcPath = $ARGV[ 0 ];
	   $srcTag  = $ARGV[ 1 ];
	   $dstTag  = $ARGV[ 2 ];

	renameTagsHndlPath ( $srcPath );
}


# #########################################################################################################
# # Parse given source
# #########################################################################################################

sub renameTagsHndlPath
{
	my $srcPath = $_[0];

	####################################################################
	# Check if file
	####################################################################
	if ( -f $srcPath )
	{
 		renameTagsHndlFile ( $srcPath );
		return;
	}

	printf ( "Handle dir:  $srcPath\n" );

	####################################################################
	# Read directory list
	####################################################################
	opendir ( DIRHNDLR, $srcPath ) or die $!;

	my @dirList = readdir ( DIRHNDLR ) or die $!;

	closedir ( DIRHNDLR );

	@dirList = sort ( @dirList );

	####################################################################
	# Parse directory list
	####################################################################
	foreach my $dirEntry ( @dirList )
	{
		if ( ( $dirEntry eq "." ) or ( $dirEntry eq ".." ) )
		{
			next;
		}

		renameTagsHndlPath ( "$srcPath/$dirEntry" );
	}
}

# #########################################################################################################
# # Rename tags
# #########################################################################################################

sub renameTagsHndlFile
{
	my $srcPath = $_[0];

	printf ( "Handle file: $srcPath\n" );

	my $colorSrc = "\033[1;31m";
	my $colorDst = "\033[1;32m";
	my $colorStd = "\033[0m";

	####################################################################
	# Parse file
	####################################################################
	my $tmpPath = "$srcPath.tmp";

	open ( TMPFILE, "> $tmpPath" ) or die $!;
	open ( SRCFILE, "< $srcPath" ) or die $!;

	my $lineNo = 0;

	while ( <SRCFILE> )
	{
		my $lineSrc = $_;
		my $lineDst = $_;

		$lineNo++;

		while ( $lineDst =~ s/$srcTag/$dstTag/ )
		{
			# Color lines
			my $lineSrcColored = $lineSrc;
			my $lineDstColored = $lineDst;

			$lineSrcColored  =~ s/$srcTag/$colorSrc$srcTag$colorStd/;
			$lineDstColored =~ s/$dstTag/$colorDst$dstTag$colorStd/;

			# Get user interaction
			printf ( "	Line %5d: $lineSrcColored", $lineNo );
			printf ( "	        to: $lineDstColored\n" );

			my $key = "";

			print "	Replace? Press [n|N] for skip, everything else for replace: \n";

			$key = getc(STDIN);

			if ( $key eq "n" || $key eq "N" )
			{
				$lineDst = $lineSrc;
			}
			else
			{
				$lineSrc = $lineDst;
			}
		}

		printf ( TMPFILE "$lineDst" );
	}

	close ( SRCFILE );
	close ( TMPFILE );

	rename ( $tmpPath, $srcPath );

	####################################################################
	# Extract file name
	####################################################################
	my ( $fileName, $filePath, $fileSuffix ) = fileparse ( $srcPath, "\.[^.]*" );

	my $srcFileName = $fileName;
	my $dstFileName = $fileName;

	####################################################################
	# Check file name to rename
	####################################################################
	while ( $dstFileName =~ s/$srcTag/$dstTag/ )
	{
		# Color lines
		my $srcFileNameColored = $srcFileName;
		my $dstFileNameColored = $dstFileName;

		$srcFileNameColored =~ s/$srcTag/$colorSrc$srcTag$colorStd/;
		$dstFileNameColored =~ s/$dstTag/$colorDst$dstTag$colorStd/;

		printf ( "	Rename file: $srcFileNameColored -> $dstFileNameColored\n" );

		my $key = "";

		print "	Rename? Press [n|N] for skip, everything else for rename: \n";

		$key = getc(STDIN);

		if ( $key ne "n" && $key ne "N" )
		{
			my $dstPath = $filePath . $dstFileName . $fileSuffix;

			rename ( $srcPath, $dstPath );
		}
	}
	return;

}
