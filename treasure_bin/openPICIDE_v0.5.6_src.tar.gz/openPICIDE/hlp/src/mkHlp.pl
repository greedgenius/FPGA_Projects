#!/usr/bin/perl

#########################################################################################################
#  Copyright (C) 2009 by Christoph Fauck                                                                #
#  Christoph Fauck <christoph.fauck@fauck.com>                                                          #
#                                                                                                       #
#  This file is part of openPICIDE.                                                                     #
#                                                                                                       #
#  openPICIDE is free software: you can redistribute it and/or modify it under the terms of the         #
#  GNU General Public License as published by the Free Software Foundation, either version 3 of the     #
#  License, or (at your option) any later version.                                                      #
#                                                                                                       #
#  openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without      #
#  even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       #
#  General Public License for more details.                                                             #
#                                                                                                       #
#  You should have received a copy of the GNU General Public License along with openPICIDE.             #
#  If not, see <http://www.gnu.org/licenses/>.                                                          #
#                                                                                                       #
#########################################################################################################

use File::Copy;

require "translatePsmToHtml.pl";

setupQHelpCollectionProject();

#########################################################################################################
# Setup QHelpCollectionProject
#########################################################################################################

sub setupQHelpCollectionProject
{
# 	@manuals = ( "openPICIDE","XilinxPicoBlaze" );
	@manuals = ( "openPICIDE" );

	# Translate psm files to html
	translatePsm ( @manuals );

	open ( OUTFILE, "> hlpCollection.qhcp" );

	print OUTFILE "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n";
	print OUTFILE "<QHelpCollectionProject version=\"1.0\">\n";
	print OUTFILE "	<docFiles>\n";
	print OUTFILE "		<register>\n";

	foreach my $manual ( @manuals )
	{
		print OUTFILE "			<file>$manual.qch</file>\n";
	}

	print OUTFILE "		</register>\n";
	print OUTFILE "	</docFiles>\n";
	print OUTFILE "</QHelpCollectionProject>\n";

	close ( OUTFILE );

	foreach my $manual ( @manuals )
	{
		setupQtHelpProject ( $manual );
	}

	####################################################################
	# Setup help collection
	####################################################################
	if ( system ( "qcollectiongenerator hlpCollection.qhcp -o hlpCollection.qhc" ) )
	{
		die "\nFatal error!\n\n";
	}

	####################################################################
	# Tidy yup
	####################################################################
	foreach my $manual ( @manuals )
	{
		unlink ( "$manual.qhp" );
	}

	unlink ( "hlpCollection.qhcp" );

	####################################################################
	# Move to binary folder
	####################################################################
	foreach my $manual ( @manuals )
	{
		move ( "$manual.qch", "../hlp/$manual.qch" );
	}
	move ( "hlpCollection.qhc", "../hlp/hlpCollection.qhc" );

	####################################################################
	# Show results
	####################################################################
	if ( system ( "assistant -collectionFile ../hlp/hlpCollection.qhc" ) )
	{
		die "\nFatal error!\n\n";
	}
}

#########################################################################################################
# Setup QtHelpProject
#########################################################################################################

sub setupQtHelpProject
{
	my $dir         = $_[0];
	my $nameSpace   = $_[0];
	my $virtFolder  = $_[0];
	my $outfileBase = $_[0];

	my $indent      = "		";

	open ( OUTFILE, "> $outfileBase.qhp" );

	print OUTFILE "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
	print OUTFILE "<QtHelpProject version=\"1.0\">\n";
	print OUTFILE "	<namespace>$nameSpace</namespace>\n";
	print OUTFILE "	<virtualFolder>$virtFolder</virtualFolder>\n";
	print OUTFILE "	<filterSection>\n";

	setupToc      ( $dir, $indent );
	setupKeywords ( $dir, $indent );
	setupFiles    ( $dir, $indent );

	print OUTFILE "	</filterSection>\n";
	print OUTFILE "</QtHelpProject>\n";

	close ( OUTFILE );

	if ( system ( "qhelpgenerator $outfileBase.qhp -o $outfileBase.qch" ) )
	{
		die "\nError during generation of qch file: $outfileBase.qch\n\n";
	}
}

#########################################################################################################
# Setup toc
#########################################################################################################
sub setupToc
{
	my $dir    = $_[0];
	my $indent = $_[1];

	print OUTFILE "$indent<toc>\n";

	setupTocHndlDir ( $dir, $indent."	" );

	print OUTFILE "$indent</toc>\n";
}

sub setupTocHndlDir
{
	my $dir    = $_[0];
	my $indent = $_[1];

	####################################################################
	# Read directory list
	####################################################################
	opendir ( DIRHNDLR, $dir ) or die $!;

	my @dirList = readdir ( DIRHNDLR ) or die $!;

	closedir ( DIRHNDLR );

	@dirList = sort ( @dirList );

	####################################################################
	# Parse directory list
	####################################################################
	my $dirEntryEn = setupTocOpenDir ( $dir, $indent );

	foreach my $entry ( @dirList )
	{
		my $entryPath = "$dir/$entry";

		if ( ( $entry eq "." ) or ( $entry eq ".." )  or ( $entry eq "index.html" ) )
		{
			next;
		}

		if ( -f $entryPath and -r $entryPath and $entry =~ /.*html$/ )
		{
			setupTocHndlFile ( $entryPath, $indent."	" );
		}
		elsif ( -d $entryPath )
		{
			setupTocHndlDir ( $entryPath, $indent."	" );
		}
	}

	if ( $dirEntryEn )
	{
		setupTocCloseDir ( $indent );
	}
}

sub setupTocOpenDir
{
	my $file = "$_[0]/index.html";
	my $indent = $_[1];

	if ( -f $file and -r $file )
	{
		print OUTFILE "$indent<section title=\"";

		setupTocParseFile ( $file );

		print OUTFILE "\" ref=\"$file\">\n";
		return 1;
	}

	return 0;
}

sub setupTocCloseDir
{
	my $indent = $_[0];
	print OUTFILE "$indent</section>\n";
}

sub setupTocHndlFile
{
	my $file = $_[0];
	my $indent = $_[1];

	print OUTFILE "$indent<section title=\"";

	setupTocParseFile ( $file );

	print OUTFILE "\" ref=\"$file\"/>\n";
}

sub setupTocParseFile
{
	my $file  = $_[0];

	open ( FILE, "<$file" ) or die $!;

	while ( <FILE> )
	{
		if ( $_ =~ /meta.*title.*content=\"(.+?)\"/ )
		{
			my $title = $1;
			print OUTFILE "$title";
# 			break;
		}
	}
	close FILE;
}

#########################################################################################################
# Setup keywords
#########################################################################################################
sub setupKeywords
{
	my $dir    = $_[0];
	my $indent = $_[1];

	print OUTFILE "$indent<keywords>\n";

	setupKeywordsHndlDir ( $dir, $indent );

	print OUTFILE "$indent</keywords>\n";
}
sub setupKeywordsHndlDir
{
	my $dir    = $_[0];
	my $indent = $_[1];

	####################################################################
	# Read directory list
	####################################################################
	opendir ( DIRHNDLR, $dir ) or die $!;

	my @dirList = readdir ( DIRHNDLR ) or die $!;

	closedir ( DIRHNDLR );

	@dirList = sort ( @dirList );

	####################################################################
	# Parse directory list
	####################################################################
	foreach my $entry ( @dirList )
	{
		my $entryPath = "$dir/$entry";

		if ( ( $entry eq "." ) or ( $entry eq ".." ) )
		{
			next;
		}

		if ( -f $entryPath and -r $entryPath and $entry =~ /.*html$/ )
		{
			setupKeywordsHndlFile ( $entryPath, $indent."	" );
		}
		elsif ( -d $entryPath )
		{
			setupKeywordsHndlDir ( $entryPath, $indent );
		}
	}
}

sub setupKeywordsHndlFile
{
	my $file = $_[0];
	my $indent = $_[1];

	@keywords = setupKeywordsParseFile ( $file );

	foreach my $keyword ( @keywords )
	{
# 		$keyword = lc ( $keyword );

		$keyword =~ s/_/ /g;

		print OUTFILE "$indent<keyword name=\"$keyword\" ref=\"$file\"/>\n";
	}
}

sub setupKeywordsParseFile
{
	my $file  = $_[0];
	my $keywords;

	open ( FILE, "<$file" ) or die $!;

	while ( <FILE> )
	{
		if ( $_ =~ /meta.*keyword.*content=\"(.+?)\"/ )
		{
			$keywords = $1;
		}
	}

	close FILE;

	# Remove blanks
	$keywords =~ s/ //g;

	return split ( /,/, $keywords );
}

#########################################################################################################
# Setup files
#########################################################################################################
sub setupFiles
{
	my $dir    = $_[0];
	my $indent = $_[1];

	print OUTFILE "$indent<files>\n";

	setupFilesCommon  ( "common", $indent."	" );
	setupFilesHndlDir ( $dir, $indent."	" );

	print OUTFILE "$indent</files>\n";
}

sub setupFilesHndlDir
{
	my $dir    = $_[0];
	my $indent = $_[1];

	####################################################################
	# Read directory list
	####################################################################
	opendir ( DIRHNDLR, $dir ) or die $!;

	my @dirList = readdir ( DIRHNDLR ) or die $!;

	closedir ( DIRHNDLR );

	@dirList = sort ( @dirList );

	####################################################################
	# Parse directory list
	####################################################################
	foreach my $entry ( @dirList )
	{
		my $entryPath = "$dir/$entry";

		system ( "touch $entryPath" );

		if ( ( $entry eq "." ) or ( $entry eq ".." ) )
		{
			next;
		}

		if ( -f $entryPath and -r $entryPath  )
		{
			if ( $entry =~ /.*html$/ or $entry =~ /.*css$/  or $entry =~ /.*png$/ or $entry =~ /.*gif$/ or $entry =~ /.*jpg$/ or $entry =~ /.*psm$/ or $entry =~ /.*vhd/ )
			{
				print OUTFILE "$indent<file>$entryPath</file>\n";
			}
		}
		elsif ( -d $entryPath )
		{
			setupFilesHndlDir ( $entryPath, $indent );
		}
	}
}


sub setupFilesCommon
{
	my $dir    = $_[0];
	my $indent = $_[1];

	####################################################################
	# Read directory list
	####################################################################
	opendir ( DIRHNDLR, $dir ) or die $!;

	my @dirList = readdir ( DIRHNDLR ) or die $!;

	closedir ( DIRHNDLR );

	@dirList = sort ( @dirList );

	####################################################################
	# Parse directory list
	####################################################################
	foreach my $entry ( @dirList )
	{
		my $entryPath = "$dir/$entry";

		system ( "touch $entryPath" );

		if ( -f $entryPath and -r $entryPath )
		{
				print OUTFILE "$indent<file>$entryPath</file>\n";
		}
	}
}

