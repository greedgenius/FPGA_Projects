#!/usr/bin/perl

#########################################################################################################
#  Copyright (C) 2009 by Christoph Fauck                                                                #
#  Christoph Fauck <christoph.fauck@fauck.com>                                                          #
#                                                                                                       #
#  This file is part of openPICIDE.                                                                     #
#                                                                                                       #
#  openPICIDE is free software: you can redistribute it and/or modify it under the terms of the         #
#  GNU General Public License as published by the Free Software Foundation, either version 3 of the     #
#  License, or (at your option) any later version.                                                      #
#                                                                                                       #
#  openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without      #
#  even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       #
#  General Public License for more details.                                                             #
#                                                                                                       #
#  You should have received a copy of the GNU General Public License along with openPICIDE.             #
#  If not, see <http://www.gnu.org/licenses/>.                                                          #
#                                                                                                       #
#########################################################################################################

use Switch;

use constant TABSPACE => 8;

# translatePsm ( "openPICIDE" );

sub translatePsm
{
# 	my @manuals = ( "openPICIDE","XilinxPicoBlaze" );
	my @manuals = $_[0];

	foreach my $manual ( @manuals )
	{
		translatePsmHndlDir ( "./$manual" );
	}
}

sub translatePsmHndlDir
{
	my $dir = $_[0];

	####################################################################
	# Read directory list
	####################################################################
	opendir ( DIRHNDLR, $dir ) or die $!;

	my @dirList = readdir ( DIRHNDLR ) or die $!;

	closedir ( DIRHNDLR );

	@dirList = sort ( @dirList );

	####################################################################
	# Parse directory list
	####################################################################
	foreach my $entry ( @dirList )
	{
		my $entryPath = "$dir/$entry";

		if ( ( $entry eq "." ) or ( $entry eq ".." ) )
		{
			next;
		}

		if ( -f $entryPath and -r $entryPath and $entry =~ /.*htmltmpl$/ )
		{
			translatePsmHndlFile ( $dir, $entry );
		}
		elsif ( -d $entryPath )
		{
			translatePsmHndlDir ( $entryPath );
		}
	}
}

sub translatePsmHndlFile
{
	my $dir          = $_[0];
	my $fileTemplate = $_[1];

	####################################################################
	# Get basename
	####################################################################
	my $fileBasename = $fileTemplate;
	
	$fileBasename =~ s/\.htmltmpl$//g;

# 	print "$dir\n";
# 	print "$fileTemplate\n";
# 	print "$fileBasename\n";

	####################################################################
	# Opens destination html file
	####################################################################
	open ( OUTFILE, "> $dir/$fileBasename.html" );

	translatePsmParseTemplateFile ( $dir, $fileTemplate );

	close ( OUTFILE );
}

#########################################################################################################
# Parse template file
#########################################################################################################

sub translatePsmParseTemplateFile
{
	my $dir          = $_[0];
	my $fileTemplate = $_[1];

	####################################################################
	# Opens and parse template file
	####################################################################
	open ( FILE_TEMPLATE, "<$dir/$fileTemplate" ) or die $!;

	while ( <FILE_TEMPLATE> )
	{
		my $line = $_;

		if ( $line =~ /#include/ )
		{
			my $filePsm = $line;

			$filePsm =~ s/\r//g; 
			$filePsm =~ s/\n//g; 
			$filePsm =~ s/^.*#include\s+\"//g;
			$filePsm =~ s/\".*$//g;

			print "Parsing file: $filePsm\n";

			translatePsmParsePsmFile ( $dir, $filePsm );
		}
		else
		{
			print OUTFILE $line;
		}
	}

	close FILE_TEMPLATE;
}

#########################################################################################################
# Parse file
#########################################################################################################

sub translatePsmParsePsmFile
{
	my $dir    = $_[0];
	my $file   = $_[1];
	my $lineNo = 0;

	open ( FILE_PSM, "<$dir/$file" ) or die $!;

	print OUTFILE "<div class=\"asmCode\">\n";

	print OUTFILE "	Source file: <a href=\"$file\">$file</a>";

	print OUTFILE "	<pre>\n";

	while ( <FILE_PSM> )
	{
		printf ( OUTFILE "<font class=\"lno\">% 4u</font>", ++$lineNo );

		translatePsmParsePsmFileLine ( $_ );

		printf ( OUTFILE "\n" );
	}

	print OUTFILE "</pre>\n";
	print OUTFILE "</div>\n";

	close FILE_PSM;
}

sub translatePsmParsePsmFileLine
{
	my $line = $_[0];

	# Remove line breaks
	$line =~ s/\r//g; 
	$line =~ s/\n//g; 

	# Replace tabs
	{
		my $lineReformated = "";

		my $length = length ( $line );

		for ( my $iterator = 0, my $spcCnt = 0; $iterator < $length; ++$iterator, ++$spcCnt )
		{
			if ( $spcCnt >= TABSPACE )
			{
				$spcCnt = 0;
			}

			my $char = substr ( $line, $iterator, 1 );

			if ( $char eq "	" )
			{
				while ( $spcCnt < TABSPACE )
				{
					$lineReformated .= " ";

					++$spcCnt;
				}
			}
			else
			{
				$lineReformated .= $char;
			}
		}

		$line = $lineReformated;
	}

	# Adjust fragment pointer
	my $fragPtr = 0;
	{
		# Fragments
		#
		# 	label:	cmd	arg0,	arg1	; Comment
		#
		# 0: Blanks
		# 1: label
		# 2: Blanks
		# 3: Cmd
		# 4: Blanks
		# 5: Arg0
		# 6: Blanks
		# 7: Arg1
		# 8: Blanks
		# 9: Comment

		# Adjust fragment pointer
		if    ( $line =~ /^\s*\S*:/ )	{ $fragPtr = 0; }
		elsif ( $line =~ /^\S*:/ )	{ $fragPtr = 1; }
		elsif ( $line =~ /^\s*\S*/ )	{ $fragPtr = 2; }
		elsif ( $line =~ /^\S*/ )	{ $fragPtr = 3; }

	}

	# Split into fragments
	my @frags = ( "", "", "", "", "", "", "", "", "" );
	{
		my $length  = length ( $line );
		my $commentEn = 0;

		for ( my $charPos = 0; $charPos < $length; ++$charPos )
		{
			my $char = substr ( $line, $charPos, 1 );

			if ( $char eq ";" )
			{
				$fragPtr = 9;
				$commentEn = 1;
			}

			if ( not $commentEn )
			{
				# If blank
				if ( $char =~ /\s+/ )
				{
					if ( $fragPtr % 2 )
					{
						++$fragPtr;
					}
				}

				# If non-blank
				else
				{
					if ( not $fragPtr % 2 )
					{
						++$fragPtr;
					}
				}
			}
			@frags[ $fragPtr ] .= $char;
		}
	}

	# Print fragments
	{
		if ( @frags[ 0 ] ) { translatePsmPrintBlank   ( @frags[ 0 ] ); }			# 0: Blanks
		if ( @frags[ 1 ] ) { translatePsmPrintLabel   ( @frags[ 1 ], @frags[ 0 ] ); }		# 1: label
		if ( @frags[ 2 ] ) { translatePsmPrintBlank   ( @frags[ 2 ] ); }			# 2: Blanks
		if ( @frags[ 3 ] ) { translatePsmPrintTag     ( @frags[ 3 ] ); }			# 3: Cmd
		if ( @frags[ 4 ] ) { translatePsmPrintBlank   ( @frags[ 4 ] ); }			# 4: Blanks
		if ( @frags[ 5 ] ) { translatePsmPrintTag     ( @frags[ 5 ] ); }			# 5: Arg0
		if ( @frags[ 6 ] ) { translatePsmPrintBlank   ( @frags[ 6 ] ); }			# 6: Blanks
		if ( @frags[ 7 ] ) { translatePsmPrintTag     ( @frags[ 7 ] ); }			# 7: Arg1
		if ( @frags[ 8 ] ) { translatePsmPrintBlank   ( @frags[ 8 ] ); }			# 8: Blanks
		if ( @frags[ 9 ] ) { translatePsmPrintComment ( @frags[ 9 ] ); }			# 9: Comment
	}
}

sub translatePsmPrintBlank
{
	print OUTFILE "$_[0]";

}

sub translatePsmPrintLabel
{
	$tag    = $_[0];
	$blanks = $_[1];

	if ( $blanks )
	{
		print OUTFILE "$tag";
		return;
	}

	print OUTFILE "<lbl>$tag</lbl>";
}

sub translatePsmPrintTag 
{
	$tag = $_[0];

	# Check for decimals
	if ( $tag =~ /^[0-9]*$/ )
	{
		print OUTFILE "<num>$tag</num>";
		return;
	}

	# Check for hex
	if ( $tag =~ /^0x[0-9A-Fa-f]*$/ )
	{
		print OUTFILE "<num>$tag</num>";
		return;
	}

	# Check for octal
	if ( $tag =~ /^\/[0-9A-Fa-f]*$/ )
	{
		print OUTFILE "<num>$tag</num>";
		return;
	}

	# Check for register
	if ( $tag =~ /^s[0-9A-Fa-f]*$/ )
	{
		print OUTFILE "<hw>$tag</hw>";
		return;
	}

	# Check for keyword arguments
	if ( uc ( $tag ) =~ /^BANK[0-9]+$/ )
	{
		print OUTFILE "<kwdArg>$tag</kwdArg>";
		return;
	}
	elsif ( uc ( $tag ) =~ /^SHARED$/ )
	{
		print OUTFILE "<kwdArg>$tag</kwdArg>";
		return;
	}

	switch ( uc ( $tag ) )
	{
		# Check for keywords
		case "MFLAG"	{ print OUTFILE "<kwd>$tag</kwd>" }
		case "EQU"	{ print OUTFILE "<kwd>$tag</kwd>" }
		case "ORG"	{ print OUTFILE "<kwd>$tag</kwd>" }

		# Check for commands
		case "RET"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "RETI"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "ADDC"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "SUBC"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "IN"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "OUT"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "EINT"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "DINT"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "COMP"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "COMPC"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "ADD"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "AND"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "CALL"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "HWBUILD"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "JUMP"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "LOAD"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "OR"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "RL"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "RR"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "SL0"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "SL1"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "SLA"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "SLX"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "SR0"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "SR1"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "SRA"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "SRX"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "SUB"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "TEST"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "TESTC"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "XOR"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "STORE"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "FETCH"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "STAR"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "REGBANK"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "LOADRET"	{ print OUTFILE "<cmd>$tag</cmd>" }

		# Check for special arguments
		case "ENABLE"	{ print OUTFILE "<cmd>$tag</cmd>" }
		case "DISABLE"	{ print OUTFILE "<cmd>$tag</cmd>" }

		# rest
		else		{ print OUTFILE "$tag";           }
	}
}

sub translatePsmPrintComment 
{
	$tag = $_[0];

	# Print separator line (; #########################)
	if ( $tag =~ /^\; #/ )
	{
		$tag = "<font class=\"sep\">$tag</font>";
	}

	# Document header
	elsif ( ( $tag =~ /^\;\*/ ) or ( $tag =~ /^\;\ */ ) )
	{
		$tag = "<font class=\"doc\">$tag</font>";
	}

	# Highlight navi commands

	# \navGrpEnd
	if ( $tag =~ m/(\\navGrpEnd)/ )
	{
		my $subst = $1;		$tag =~ s/\\navGrpEnd/<font class="navi">$subst<\/font>/g;
	}

	# \navGrpBegin
	{
		my $keyWord = "navGrpBegin";

		if ( $tag =~ m/(\\$keyWord\s+\S+)/ )
		{
			my $subst = $1;
			$tag =~ s/\\$keyWord\s+\S+/<font class="navi">$subst<\/font>/g;
		}
		elsif ( $tag =~ m/(\\$keyWord)/ )
		{
			my $subst = $1;	$tag =~ s/\\$keyWord/<font class="navi">$subst<\/font>/g;
		}
	}

	# \navConst
	{
		my $keyWord = "navConst";

		if ( $tag =~ m/(\\$keyWord\s+\S+)/ )
		{
			my $subst = $1;
			$tag =~ s/\\$keyWord\s+\S+/<font class="navi">$subst<\/font>/g;
		}
		elsif ( $tag =~ m/(\\$keyWord)/ )
		{
			my $subst = $1;	$tag =~ s/\\$keyWord/<font class="navi">$subst<\/font>/g;
		}
	}

	# \navHw
	{
		my $keyWord = "navHw";

		if ( $tag =~ m/(\\$keyWord\s+\S+)/ )
		{
			my $subst = $1;
			$tag =~ s/\\$keyWord\s+\S+/<font class="navi">$subst<\/font>/g;
		}
		elsif ( $tag =~ m/(\\$keyWord)/ )
		{
			my $subst = $1;	$tag =~ s/\\$keyWord/<font class="navi">$subst<\/font>/g;
		}
	}

	# \navSep
	{
		my $keyWord = "navSep";

		if ( $tag =~ m/(\\$keyWord\s+\S+)/ )
		{
			my $subst = $1;
			$tag =~ s/\\$keyWord\s+\S+/<font class="navi">$subst<\/font>/g;
		}
		elsif ( $tag =~ m/(\\$keyWord)/ )
		{
			my $subst = $1;	$tag =~ s/\\$keyWord/<font class="navi">$subst<\/font>/g;
		}
	}

	print OUTFILE "<font class=\"rem\">$tag</font>";
}

return 1;