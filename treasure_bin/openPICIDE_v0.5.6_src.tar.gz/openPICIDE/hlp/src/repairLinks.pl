#!/usr/bin/perl

#########################################################################################################
#  Copyright (C) 2009 by Christoph Fauck                                                                #
#  Christoph Fauck <christoph.fauck@fauck.com>                                                          #
#                                                                                                       #
#  This file is part of openPICIDE.                                                                     #
#                                                                                                       #
#  openPICIDE is free software: you can redistribute it and/or modify it under the terms of the         #
#  GNU General Public License as published by the Free Software Foundation, either version 3 of the     #
#  License, or (at your option) any later version.                                                      #
#                                                                                                       #
#  openPICIDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without      #
#  even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       #
#  General Public License for more details.                                                             #
#                                                                                                       #
#  You should have received a copy of the GNU General Public License along with openPICIDE.             #
#  If not, see <http://www.gnu.org/licenses/>.                                                          #
#                                                                                                       #
#########################################################################################################

use Switch;
use File::Path;

use constant TABSPACE => 8;

repLnk ( "openPICIDE" );

sub repLnk
{
	my @manuals = $_[0];

	@linkIdCollection;

	# Collect link ids
	foreach my $manual ( @manuals )
	{
		repLnkCollectLinkIdsHndlDir ( "./$manual" );
	}

	# Print link collection
	{
		print "Link collection:\n";

		foreach my $linkIdRef ( @linkIdCollection )
		{
			print "	@$linkIdRef[0]\n";
			print "		@$linkIdRef[1]\n";
		}
		print "\n";
	}

	# Replace link ids
	{
		print "Repair links:\n";

repLnkReplaceLinkIdsHndlFile ( "./openPICIDE/000_gettingStarted", "../", "index.html" );

# 		foreach my $manual ( @manuals )
# 		{
# 			repLnkReplaceLinkIdsHndlDir ( "./$manual", "./" );
# 		}
}
}

############################################################################
# Collect link ids
############################################################################
sub repLnkCollectLinkIdsHndlDir
{
	my $dir = $_[0];

	####################################################################
	# Read directory list
	####################################################################
	opendir ( DIRHNDLR, $dir ) or die $!;

	my @dirList = readdir ( DIRHNDLR ) or die $!;

	closedir ( DIRHNDLR );

	@dirList = sort ( @dirList );

	####################################################################
	# Parse directory list
	####################################################################
	foreach my $entry ( @dirList )
	{
		my $entryPath = "$dir/$entry";

		if ( ( $entry eq "." ) or ( $entry eq ".." ) )
		{
			next;
		}

		if ( -f $entryPath and -r $entryPath and $entry =~ /.*html$/ )
		{
			repLnkCollectLinkIdsHndlFile ( $dir, $entry );
		}
		elsif ( -d $entryPath )
		{
			repLnkCollectLinkIdsHndlDir ( $entryPath );
		}
	}
}

sub repLnkCollectLinkIdsHndlFile
{
	my $dir  = $_[0];
	my $file = $_[1];

	print "";

	####################################################################
	# Opens and parse html file
	####################################################################
	open ( FILE_HTML, "<$dir/$file" ) or die $!;

	while ( <FILE_HTML> )
	{
		$line = $_;

		if ( $line =~ /meta.*linkId.*content=\"(.+?)\"/ )
		{
			my @linkId = ( $1, "$dir/$file" );

			push ( @linkIdCollection, \@linkId );

			break;
		}
	}

	close FILE_HTML;
}


############################################################################
# Replace link ids
############################################################################
sub repLnkReplaceLinkIdsHndlDir
{
	my $dir      = $_[0];
	my $rootPath = $_[1];

	####################################################################
	# Read directory list
	####################################################################
	opendir ( DIRHNDLR, $dir ) or die $!;

	my @dirList = readdir ( DIRHNDLR ) or die $!;

	closedir ( DIRHNDLR );

	@dirList = sort ( @dirList );

	####################################################################
	# Parse directory list
	####################################################################
	foreach my $entry ( @dirList )
	{
		my $entryPath = "$dir/$entry";

		if ( ( $entry eq "." ) or ( $entry eq ".." ) )
		{
			next;
		}

		if ( -f $entryPath and -r $entryPath and $entry =~ /.*html$/ )
		{
			repLnkReplaceLinkIdsHndlFile ( $dir, $rootPath, $entry );
		}
		elsif ( -d $entryPath )
		{
			repLnkReplaceLinkIdsHndlDir ( $entryPath, "../$rootPath" );
		}
	}
}

sub repLnkReplaceLinkIdsHndlFile
{
	my $dir      = $_[0];
	my $rootPath = $_[1];
	my $file     = $_[2];

	print "	$dir/$file\n";

	####################################################################
	# Opens and parse html file
	####################################################################
	open ( FILE_HTML,    "<$dir/$file" ) or die $!;
	open ( FILE_HTMLTMP, "> $dir/$file.tmp" ) or die $!;

	while ( <FILE_HTML> )
	{
		$line = $_;

		if ( 1 <  scalar ( my @array = ( $line =~ /href/g ) ) )
		{
			die "More than one link per line - aborting!\n"
		}

		if ( $line =~ /(<a.*linkId.*<\/a>)/ )
		{
			my $link = $1;

# 			print "$link\n";

			if ( $link =~ /linkId=\"(\S+)\" href=\"(\S+)\"/ )
			{
				my $linkId = $1;
				my $url    = $rootPath . repLnkGetLink ( $linkId, $2 );


				# Remove path to html file here

				print "		Found linkId: $linkId\n";
				print "			From: $link\n";

				$link =~ s/linkId=\"\S+\"\s+href=\"\S+\"/linkId=\"$linkId\" href=\"$url\"/g;

				print "			To:   $link\n";
			}

			$line =~ s/<a.*linkId.*<\/a>/$link/g;

		}

		print FILE_HTMLTMP "	$line\n";
	}

	close FILE_HTML;
	close FILE_HTMLTMP;
}

sub repLnkGetLink
{
	my $linkId  = $_[0];
	my $url     = $_[1];

	foreach my $linkIdRef ( @linkIdCollection )
	{
		if ( @$linkIdRef[ 0 ] eq $linkId )
		{
			return @$linkIdRef[ 1 ];
		}
	}

	return $url;
}

# return 1;