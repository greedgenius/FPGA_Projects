Module Description: 
	DSTM Demo is a project to demonstrate how to transfer data	
	to and from a Digilent FPGA board using the DSTM module of
	the Adept SDK.

Hardware Setup:
	Load the DSTM reference design into a supported Digilent FPGA board.
	See VHDL files for this design in the logic directory.
	