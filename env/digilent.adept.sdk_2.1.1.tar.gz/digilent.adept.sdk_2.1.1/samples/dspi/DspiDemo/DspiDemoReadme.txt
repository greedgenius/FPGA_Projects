Module Description: 
	DSPI Demo is a project to demonstrate how to transfer data
	via SPI using the DSPI module of the Adept SDK.

Hardware Setup:
	Short pins 2 and 3 (MOSI and MISO) of connector JD on the I/O Explorer together.
	Connect the I/O Explorer to the PC via USB.