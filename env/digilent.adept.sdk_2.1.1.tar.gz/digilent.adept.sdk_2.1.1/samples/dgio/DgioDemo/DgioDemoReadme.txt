Module Description:

	This project illustrates used of the DGIO functions to interract
	with the swiches, buttons, dip switches, and LEDs on the
	I/O Explorer board.

	The I/O Explorer has the following GIO ports and channels
		Port 0, chan 0	= LEDs, 16 bits, discrete out
		Port 0, chan 1	= Slide Switches, 8 bits, discrete in
		Port 0, chan 2	= Push Buttons, 4 bits, discrete in	
		Port 0, chan 3	= Dip Switches, 4 bits, discrete in	


Hardware Setup:
	Connect the I/O Explorer via USB.