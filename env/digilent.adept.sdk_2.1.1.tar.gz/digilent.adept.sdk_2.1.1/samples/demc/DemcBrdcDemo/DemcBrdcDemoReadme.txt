Module Description:
	DEMC Brdc Demo is a project to demonstrate how to control
	a brushed DC motor connected to an I/O Explorer using the
	DEMC module of the Adept SDK.

Hardware Setup: 
	Attatch a PmodHB5 to pins 7-12 of JB on the I/O Explorer. Connect the DC motor
	to the HB5. Connect power lines from the J14 connector on the I/O Explorer
	to connector J3 of the PmodHB5. Make sure that wall power is connected, and
	that JP6 is set to the VEXT position.